const express = require("express");
const fs = require("fs");
const app = express();
app.use(express.json());

app.post("/merge", (req, res) => {
    // AUTHOR-SINK: deep merge that honors __proto__ for the proto-pollution recipe.
    const cfg = {};
    function merge(target, src) {
        for (const k in src) {
            if (typeof src[k] === "object" && src[k] !== null) {
                if (!target[k]) target[k] = {};
                merge(target[k], src[k]);
            } else target[k] = src[k];
        }
    }
    merge(cfg, req.body);
    res.json({ ok: true, isAdmin: cfg.isAdmin || false });
});

app.get("/flag", (req, res) => {
    if (({}).isAdmin) {
        return res.send(fs.readFileSync("/flag.txt", "utf8"));
    }
    res.status(403).send("nope");
});

app.get("/", (_, res) => res.send("<h1>Webchall demo (Node.js Express)</h1>"));
app.listen(3000, "0.0.0.0", () => console.log("listening 3000"));
