from flask import Flask, render_template_string, request
import os

app = Flask(__name__)

INDEX = """
<!doctype html>
<h1>Webchall demo (Flask)</h1>
<form method=post>
  <input name=msg placeholder="say hi"/>
  <button>send</button>
</form>
{% if msg %}<p>{{msg}}</p>{% endif %}
"""


@app.route("/", methods=["GET", "POST"])
def index():
    msg = ""
    if request.method == "POST":
        # AUTHOR-SINK: deliberately render user input as a template.
        # This is the intended SSTI; replace with a safer placeholder
        # if the recipe does not call for SSTI.
        msg = render_template_string(request.form.get("msg", ""))
    return render_template_string(INDEX, msg=msg)


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
