"""Reference exploit placeholder — author MUST replace with a real chain."""
import sys, urllib.request

def solve(target: str = "http://127.0.0.1:8080/") -> str:
    with urllib.request.urlopen(target, timeout=5) as r:
        return r.read().decode()

if __name__ == "__main__":
    target = sys.argv[1] if len(sys.argv) > 1 else "http://127.0.0.1:8080/"
    print(solve(target))
