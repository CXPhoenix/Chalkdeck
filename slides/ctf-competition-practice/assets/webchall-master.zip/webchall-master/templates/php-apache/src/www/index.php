<?php
// AUTHOR-SINK: phar:// metadata deserialization.
//
// The recipe `php-phar-deserialize` plants this two-step chain:
//   1. Author uploads a polyglot file (e.g. .jpg with .phar metadata) to
//      /var/www/html/uploads/. (In a real challenge ship an upload form here.)
//   2. Player triggers `file_exists('phar:///var/www/html/uploads/x.jpg/x')`.
//      PHP automatically deserializes the .phar metadata under the phar://
//      stream wrapper, instantiating the embedded object and triggering its
//      __destruct / __wakeup / __toString gadget chain -> RCE.
//
// The Demo class below is the gadget; its __destruct executes shell commands
// stored in $cmd. A canonical exploit ships a .phar whose metadata is
// `serialize(new Demo("cat /flag.txt"))`.

class Demo {
    public $cmd = "";
    public function __destruct() {
        if (!empty($this->cmd)) {
            system($this->cmd);
        }
    }
}

if (isset($_GET['file'])) {
    // The vulnerable sink: file_exists() honors stream wrappers including
    // phar://, even when the developer thought it was a plain filesystem
    // existence check. This is the fingerprint of CVE-class phar attacks.
    @file_exists($_GET['file']);
    echo "checked";
}
?>
<!doctype html>
<h1>Webchall demo (PHP + Apache, phar:// recipe)</h1>
<p>Try <code>?file=phar:///var/www/html/uploads/x.jpg/x</code> after uploading a polyglot.</p>
