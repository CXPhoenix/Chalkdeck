<?php
echo "<h1>Webchall demo (PHP-FPM behind nginx)</h1>";
