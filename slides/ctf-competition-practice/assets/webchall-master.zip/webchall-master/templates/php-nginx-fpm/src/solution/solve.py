import sys, urllib.request

def solve(target: str = "http://127.0.0.1:8081/") -> str:
    with urllib.request.urlopen(target, timeout=5) as r:
        return r.read().decode()

if __name__ == "__main__":
    target = sys.argv[1] if len(sys.argv) > 1 else "http://127.0.0.1:8081/"
    print(solve(target))
