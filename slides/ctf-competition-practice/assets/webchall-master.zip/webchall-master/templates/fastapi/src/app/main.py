from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse
import pickle, base64

app = FastAPI()


@app.get("/", response_class=HTMLResponse)
async def index() -> str:
    return "<h1>Webchall demo (FastAPI)</h1>"


@app.post("/restore")
async def restore(request: Request):
    # AUTHOR-SINK: pickle.loads on user-controlled bytes.
    raw = await request.body()
    try:
        data = pickle.loads(base64.b64decode(raw))
    except Exception as exc:
        return {"error": str(exc)}
    return {"ok": True, "data": str(data)[:128]}
