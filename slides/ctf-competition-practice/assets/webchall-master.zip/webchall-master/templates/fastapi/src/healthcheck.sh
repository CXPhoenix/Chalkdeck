#!/bin/sh
# Author-side flag verifier — NOT a Docker HEALTHCHECK.
# The validator runs this once to confirm the flag is reachable inside the
# container. Do NOT wire it into the Dockerfile HEALTHCHECK directive or
# docker-compose `healthcheck:` block — that would leak the flag into
# `docker inspect`, daemon logs, and log aggregators. The Dockerfiles ship
# their own HTTP-probe HEALTHCHECK that doesn't touch the flag file.
set -e
cat /flag.txt
