---
name: webchall-master
description: "出 Web Exploitation CTF 賽題的 user skill。當使用者要『出 web ctf 題』、scaffold Flask/FastAPI/PHP/Node.js/nginx/apache 賽題、設計 SSTI/SQLi/SSRF/RCE 題目、分析賽題 unintended solve、或將賽題包裝成 CTFd/rCTF/picoCTF 格式時觸發。內含七階段流水線（Brief → Design → Scaffold → Implement → Analyze → Validate → Publish），每階段以 sub-agent 對抗審查作為門檻。讀程式碼／看 wiki／單純問概念時不要觸發。"
license: MIT
compatibility:
  system_packages:
    - "Python 3.10+"
    - "Docker（僅 webchall_analyze.py runtime fuzz 階段需要）"
  python_packages:
    - "pyyaml>=6.0"
    - "jinja2>=3.1"
    - "httpx>=0.27"
metadata:
  author: webchall-master
  version: "0.1"
  generatedBy: "Spectra"
---

> [English](SKILL.md) | **繁體中文**

# 概述

`webchall-master` 是一個使用者層級 skill，從零產出可上架的 Web Exploitation CTF 賽題：

- 七階段流水線（Brief → Design → Scaffold → Implement → Analyze → Validate → Publish），每階段結尾強制 sub-agent 對抗審查。
- Karpathy 三層 LLM Wiki（`wiki/`），覆蓋 OWASP Top 10（2025 RC、2021、2017）、OWASP API Top 10 2023、PortSwigger Web Security Academy 全 31 主題，與 2024–2025 框架 CVE（Flask/Werkzeug、FastAPI/Starlette、PHP、Node.js/Express、nginx、Apache HTTP Server）。
- 七支 Python CLI：`webchall_init`、`webchall_analyze`（靜態 AST + runtime HTTP fuzz）、`webchall_validate`（嚴格規則目錄，`--soft` 降級）、`webchall_publish`、`webchall_manifest`、`webchall_wiki`、`webchall_bootstrap`（事件初始化，產生 `.rules.env`）。
- 每個 stack 模板同時包含單一 `Dockerfile`（per-user instance）與 `docker-compose.yml`（賽後快速部署）。

skill 採跨模型中立寫法：本檔案僅以指令式 Markdown 與 shell 呼叫敘述，不嵌入任何特定 agent 的工具名。請見 `reference/agent-tools.md` 的工具對照（Claude Code ⇄ Codex ⇄ Gemini ⇄ Copilot CLI）。

# 何時使用

當作者想：

- 為 CTF 賽事 scaffold 新 web 賽題。
- 對既有賽題目錄執行靜態 + fuzz 分析。
- 驗證賽題是否可上架（CTFd ctfcli + rCTF + picoCTF schema）。
- 產出去除 flag 的選手分發樹 `publish/`。
- 查詢內建漏洞 wiki（依 OWASP id／PortSwigger 主題／框架／CVE）。

不要使用於：

- 純讀原始碼、無出題意圖。
- 純概念性問題（直接指向 wiki 即可）。

# Stage 0 前置條件：CTF 事件 repo 根目錄的 `.rules.env`

在任何階段啟動之前，先確認 `.rules.env` 存在於 CTF 事件 repo 根目錄（呼叫此 skill 時的 cwd）。此檔為事件層級設定（一場賽事一份，跨多題共用），由 `webchall-rules-env` 能力定義 15 個鍵的 schema。

若檔案缺失或解析失敗，Stage 1（Brief）必須以退出碼 2 結束，並提示作者執行：

```sh
python <skill-dir>/scripts/webchall_bootstrap.py \
    --name TEST.HSCTF --long-name 'Test HSCTF' \
    --flag-prefix TEST.HSCTF --port-range 8080:8099 --yes
```

主機代理（Claude 或其他 runtime）在每次進入 skill session 前 SHALL 讀取 `.rules.env`，並把其值套用到下列四個下游決策點：

1. **玩家面文案** — 產生賽題頁、提示、README 等任何玩家可見文字時，套用 `PLAYER_FACING_LOCALE`、`BLOCK_PRC_VOCAB`、`ENFORCE_ANTI_AI_SLOP`。
2. **Flag 格式** — 制訂或驗證 canonical flag 時必用 `FLAG_REGEX` 與 `FLAG_FORMAT_LITERAL`，禁止臨時自行決定格式。
3. **Host port 配置** — 新賽題 port 一律落在 `[HOST_PORT_RANGE_START, HOST_PORT_RANGE_END]` 範圍內，避免同事件多題撞 port。
4. **驗證提示** — 引導作者填 `challenge.yml` 與 manifest 時，提示 `CATEGORIES`、`DIFFICULTIES`、`FLAG_TYPE`、`FLAG_ASSET_VERSION_CONTROLLED` 的合法值。

下游階段入口（`webchall_analyze.py`、`webchall_validate.py`、`webchall_publish.py`）容忍 `.rules.env` 缺檔，會退回硬編碼預設，確保已封存賽題仍可重跑。

# 七階段流水線

每階段從 `.webchall.manifest.yaml` 讀取輸入，將輸出寫回磁碟後才交出控制權。每階段結尾透過 `reference/audit-personas/` 中三種角色之一進行 sub-agent 對抗審查。stage N 的審查結論非 `pass` 或 `advisory` 時，skill 不可進入 stage N+1。

| 階段 | 輸入 | CLI | 輸出 | 審查角色 |
|---|---|---|---|---|
| 1. Brief | 作者意圖 | （互動） | 已寫入 stack、漏洞分類、難度、主題、flag 格式的 manifest | Confused Player |
| 2. Design | brief manifest | `webchall_wiki.py find` | manifest 的 `recipe_id` 與 `concept_refs` | Unintended Solver |
| 3. Scaffold | manifest | `webchall_init.py --stack <s> --recipe <r> --slug <slug>` | `<slug>/src/`、`<slug>/publish/`、`<slug>/solution/`、`.webchall.manifest.yaml` | Confused Player |
| 4. Implement | scaffold 樹 | （作者編輯原始碼 + 撰寫 `solution/solve.py`） | 可運作的漏洞賽題 + 預期解 | 三角色全跑 |
| 5. Analyze | 賽題目錄 | `webchall_analyze.py <slug>/` | 靜態 + runtime 兩階段 finding JSON／SARIF | Unintended Solver |
| 6. Validate | 賽題目錄 | `webchall_validate.py <slug>/` | 嚴格規則通過；任一 fail → 非零 exit | Brute-Forcer |
| 7. Publish | 賽題目錄 | `webchall_publish.py <slug>/` | `<slug>/publish/` + `<slug>/adapters/{ctfcli,rctf,picoctf}.yml` | Unintended Solver |

每階段完成後執行：

```sh
python <skill-dir>/scripts/webchall_manifest.py mark-stage-complete <slug>/ <stage>
python <skill-dir>/scripts/webchall_manifest.py append-audit-verdict <slug>/ <stage> <pass|advisory|fail>
```

`fail` 結論會阻擋階段推進，直到修補後的後續審查回 `pass` 或 `advisory`。

# 跨上下文／跨 session／跨模型

- 每賽題狀態存在 `<slug>/.webchall.manifest.yaml`。對既有 slug 重新進入 skill 會偵測 manifest、摘要已完成階段，並從第一個未完成階段恢復。
- 跨賽題的長期記憶寫入 `wiki/log.md`（append-only）。
- 跨模型：本檔案、`SKILL.md`、`AGENTS.md` 只用指令式 Markdown 與 shell 呼叫敘述。跨 runtime 工具對照見 `reference/agent-tools.md`。

# Wiki 契約（Karpathy 三層）

- `wiki/raw/` — Layer 1，不可變原始來源。永不直接編輯；上游有變動時 ingest 新的 fetch-date 檔案。
- `wiki/{taxonomies,concepts,frameworks,cves,recipes}/` — Layer 2，由 agent 維護的編譯產物，由 `profile.yaml` 強制 frontmatter schema。
- `AGENTS.md` — Layer 3，紀律檔。

執行 `webchall_wiki.py verify` 強制所有不變式（schema 一致性、cross-link 死連、raw 檔 SHA-256 完整性、CVE 覆蓋面、跨模型 lint）。

# 快速指令

```sh
# 開新賽題
python <skill-dir>/scripts/webchall_init.py --stack flask --recipe flask-ssti-jinja-cycler --slug demo-ssti

# Wiki 查詢
python <skill-dir>/scripts/webchall_wiki.py find --portswigger server-side-template-injection

# 分析 + 驗證
python <skill-dir>/scripts/webchall_analyze.py demo-ssti/
python <skill-dir>/scripts/webchall_validate.py demo-ssti/

# 發佈
python <skill-dir>/scripts/webchall_publish.py demo-ssti/
```
