#!/usr/bin/env python3
"""webchall_wiki — Karpathy three-layer LLM Wiki management CLI.

Subcommands:
  ingest <url|path>           — copy a raw source into wiki/raw/
  compile [--all|--concept]   — re-derive Layer-2 pages
  find ...                    — query Layer-2 by owasp / portswigger / framework / cve
  verify [--max-age <days>] [--cross-model-lint] [--check-cve-coverage]
"""

from __future__ import annotations

import argparse
import datetime as _dt
import hashlib
import ipaddress
import socket
import sys
import urllib.error
import urllib.request
from pathlib import Path
from urllib.parse import urlparse

# Make `_wcm_common` importable when invoked as `python webchall_wiki.py ...`.
sys.path.insert(0, str(Path(__file__).parent))
from _wcm_common import wiki as wiki_lib  # noqa: E402
from _wcm_common.reporters import Finding, to_pretty  # noqa: E402


SKILL_DIR = Path(__file__).resolve().parent.parent
WIKI_DIR = SKILL_DIR / "wiki"
RAW_DIR = WIKI_DIR / "raw"


_SAFE_NAME_RE = __import__("re").compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$")


def _is_blocked_host(host: str) -> bool:
    """Reject loopback, link-local, RFC1918, ULA, multicast, and unspecified.

    Resolves the host to addresses and rejects if ANY resolved address is in a
    blocked range — this prevents DNS-rebinding from sneaking past the check.
    """
    try:
        infos = socket.getaddrinfo(host, None)
    except socket.gaierror:
        return True  # Conservatively block unresolvable hosts.
    for info in infos:
        addr = info[4][0]
        try:
            ip = ipaddress.ip_address(addr)
        except ValueError:
            return True
        if (ip.is_loopback or ip.is_link_local or ip.is_private
                or ip.is_multicast or ip.is_unspecified or ip.is_reserved):
            return True
    return False


class _SafeRedirectHandler(urllib.request.HTTPRedirectHandler):
    """Restrict redirects to https:// AND reject targets that resolve to
    private/link-local/loopback addresses."""

    def redirect_request(self, req, fp, code, msg, headers, newurl):
        parsed = urlparse(newurl)
        if parsed.scheme != "https":
            raise urllib.error.HTTPError(
                newurl, code, f"refusing redirect to non-https scheme {parsed.scheme!r}",
                headers, fp,
            )
        if not parsed.hostname or _is_blocked_host(parsed.hostname):
            raise urllib.error.HTTPError(
                newurl, code,
                f"refusing redirect to private/link-local/loopback host {parsed.hostname!r}",
                headers, fp,
            )
        return super().redirect_request(req, fp, code, msg, headers, newurl)


def _https_opener() -> urllib.request.OpenerDirector:
    return urllib.request.build_opener(_SafeRedirectHandler())


def _read_url_or_path(target: str) -> tuple[str, bytes]:
    """Fetch from an https URL (with redirect-validating opener) or a path under
    CWD. Refuse file://, ftp:// and any other scheme to stop SSRF / arbitrary
    file reads through the ingest command. The custom opener also blocks
    redirects to private/link-local/loopback addresses on every hop."""
    if target.startswith("https://"):
        parsed = urlparse(target)
        if not parsed.hostname or _is_blocked_host(parsed.hostname):
            raise ValueError(
                f"refusing to ingest {target!r}: host resolves to a "
                "blocked range (loopback / link-local / private / multicast)"
            )
        opener = _https_opener()
        with opener.open(target, timeout=10) as r:
            return target, r.read()
    if target.startswith(("http://", "ftp://", "file://", "gopher://", "ldap://")):
        raise ValueError(
            f"refusing to ingest {target!r}: only https URLs and local paths are allowed"
        )
    # Treat as local path; require it to resolve under CWD.
    p = Path(target).resolve()
    cwd = Path.cwd().resolve()
    if not str(p).startswith(str(cwd) + "/") and p != cwd:
        raise ValueError(
            f"refusing to ingest local path {target!r}: must be under CWD {cwd}"
        )
    return p.as_uri(), p.read_bytes()


def _sanitize_for_log(value: str) -> str:
    """Escape control bytes so an attacker-controlled URL cannot inject forged
    headings into wiki/log.md."""
    safe = value.encode("unicode_escape").decode("ascii")
    return safe.replace("|", "\\u007c")


def _safe_under(root: Path, name: str) -> Path:
    """Reject path components with traversal or absolute prefixes."""
    if not _SAFE_NAME_RE.match(name):
        raise ValueError(
            f"unsafe path segment {name!r}: must match {_SAFE_NAME_RE.pattern}"
        )
    candidate = (root / name).resolve()
    if not str(candidate).startswith(str(root.resolve()) + "/"):
        raise ValueError(f"path {candidate} escapes {root}")
    return candidate


def cmd_ingest(args: argparse.Namespace) -> int:
    try:
        source_url, body_bytes = _read_url_or_path(args.target)
    except ValueError as e:
        print(str(e), file=sys.stderr)
        return 2
    body = body_bytes.decode("utf-8", errors="replace")
    if not body.endswith("\n"):
        body += "\n"
    sha = hashlib.sha256(body.encode("utf-8")).hexdigest()
    today = _dt.date.today().isoformat()
    raw_name = args.name or (Path(args.target).name or f"ingest-{today}.md")
    if not raw_name.endswith(".md"):
        raw_name += ".md"
    try:
        if args.subdir:
            subdir = _safe_under(RAW_DIR, args.subdir)
            subdir.mkdir(parents=True, exist_ok=True)
            out = _safe_under(subdir, raw_name)
        else:
            out = _safe_under(RAW_DIR, raw_name)
    except ValueError as e:
        print(f"refusing to ingest: {e}", file=sys.stderr)
        return 2
    if out.exists():
        print(f"refusing to overwrite {out}; ingest a new file with a different name "
              "if a re-fetch is intended", file=sys.stderr)
        return 2
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(
        f"---\nsource_url: {source_url}\nfetched_date: {today}\n"
        f"sha256: {sha}\ningest_method: {args.method}\n---\n\n{body}",
        encoding="utf-8",
    )
    log = WIKI_DIR / "log.md"
    log.parent.mkdir(parents=True, exist_ok=True)
    safe_url = _sanitize_for_log(source_url)
    with log.open("a", encoding="utf-8") as f:
        f.write(f"\n## [{today}] ingest | {out.relative_to(WIKI_DIR)} from {safe_url}\n")
    print(f"wrote {out}")
    return 0


def cmd_compile(args: argparse.Namespace) -> int:
    """Compile is a no-op stub here — pages are author-maintained from sources.

    A future iteration may auto-generate concept pages from raw/ via templates.
    For now this command refreshes `last_compiled` on touched pages to satisfy
    the `last_compiled` invariant.
    """
    today = _dt.date.today().isoformat()
    targets = []
    if args.all:
        targets = list(wiki_lib.iter_pages(WIKI_DIR))
    elif args.concept:
        p = WIKI_DIR / "concepts" / f"{args.concept}.md"
        if not p.exists():
            print(f"no such concept: {p}", file=sys.stderr)
            return 1
        targets = [wiki_lib.parse(p)]
    else:
        print("compile requires --all or --concept <id>", file=sys.stderr)
        return 2
    for page in targets:
        page.frontmatter["last_compiled"] = today
        wiki_lib.write(page)
    print(f"refreshed last_compiled on {len(targets)} pages")
    return 0


def cmd_find(args: argparse.Namespace) -> int:
    pages = list(wiki_lib.iter_pages(WIKI_DIR))
    matches = []
    for p in pages:
        fm = p.frontmatter
        if args.owasp and args.owasp not in (fm.get("owasp") or []):
            # Tolerate fuzzy match on category (e.g. "A05:2025")
            if not any(args.owasp in str(o) for o in (fm.get("owasp") or [])):
                continue
        if args.portswigger and fm.get("portswigger") != args.portswigger:
            continue
        if args.framework and p.type == "framework" and p.id != args.framework:
            continue
        if args.cve and args.cve not in str(fm.get("cve_id", "")):
            continue
        if args.framework and p.type != "framework" and args.framework not in (fm.get("related") or []):
            # Allow concept/recipe pages whose related includes the framework.
            related = [r.rsplit("/", 1)[-1] for r in (fm.get("related") or [])]
            if args.framework not in related:
                continue
        matches.append(p)
    for p in matches:
        rel = p.path.relative_to(WIKI_DIR)
        print(f"{p.id}\t{rel}")
    return 0 if matches else 1


def cmd_verify(args: argparse.Namespace) -> int:
    profile = wiki_lib.load_profile(WIKI_DIR)
    findings: list[Finding] = []
    findings += wiki_lib.verify_required_dirs(WIKI_DIR, profile)
    findings += wiki_lib.verify_frontmatter_schema(WIKI_DIR, profile)
    findings += wiki_lib.verify_dead_links(WIKI_DIR)
    findings += wiki_lib.verify_duplicate_ids(WIKI_DIR)
    findings += wiki_lib.verify_raw_immutability(RAW_DIR)
    findings += wiki_lib.verify_log_format(WIKI_DIR, profile)
    findings += wiki_lib.verify_taxonomy_coverage(WIKI_DIR)
    if args.cross_model_lint:
        findings += wiki_lib.verify_cross_model_lint(SKILL_DIR)
    if args.check_cve_coverage:
        findings += wiki_lib.verify_cve_coverage(WIKI_DIR)
    if args.max_age:
        findings += wiki_lib.verify_stale_pages(WIKI_DIR, args.max_age)
    print(to_pretty(findings))
    errors = [f for f in findings if f.severity == "error"]
    return 1 if errors else 0


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="webchall_wiki", description=__doc__)
    sub = p.add_subparsers(dest="cmd", required=True)

    pi = sub.add_parser("ingest", help="copy a raw source into wiki/raw/")
    pi.add_argument("target", help="URL or local path")
    pi.add_argument("--name", help="output filename (default derived from target)")
    pi.add_argument("--subdir", help="subdirectory under wiki/raw/ (e.g. cve-advisories)")
    pi.add_argument("--method", default="manual",
                    help="ingest_method tag (e.g. condensed-summary)")
    pi.set_defaults(func=cmd_ingest)

    pc = sub.add_parser("compile", help="re-derive Layer-2 pages")
    pc.add_argument("--all", action="store_true")
    pc.add_argument("--concept", help="concept id to compile")
    pc.set_defaults(func=cmd_compile)

    pf = sub.add_parser("find", help="query Layer-2 pages")
    pf.add_argument("--owasp", help="OWASP category id, e.g. A05:2025")
    pf.add_argument("--portswigger", help="PortSwigger topic slug")
    pf.add_argument("--framework", help="framework id (flask, fastapi, ...)")
    pf.add_argument("--cve", help="CVE id substring")
    pf.set_defaults(func=cmd_find)

    pv = sub.add_parser("verify", help="run wiki invariant checks")
    pv.add_argument("--max-age", type=int, help="warn on pages older than N days")
    pv.add_argument("--cross-model-lint", action="store_true")
    pv.add_argument("--check-cve-coverage", action="store_true")
    pv.set_defaults(func=cmd_verify)

    return p


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
