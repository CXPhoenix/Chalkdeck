#!/usr/bin/env python3
"""webchall_publish — build deterministic publish/ + adapter files from src/.

Usage:
  webchall_publish.py <challenge-dir>
"""

from __future__ import annotations

import argparse
import re
import shutil
import sys
from pathlib import Path

import yaml

sys.path.insert(0, str(Path(__file__).parent))
from _wcm_common import manifest as manifest_lib  # noqa: E402
from _wcm_common.rules import _flag_needles  # noqa: E402


# Files explicitly NEVER copied into publish/.
DENY_NAMES = {
    "flag.txt",
    "healthcheck.sh",
    ".env",
    ".webchall.manifest.yaml",
}
DENY_DIRS = {"solution", ".git", "__pycache__", ".venv", "node_modules"}

# AUTHOR-ONLY scrubber — strips lines flagged inside source files. Covers the
# common comment leaders: hash (Python/shell/YAML/Conf), slash-slash (JS/PHP),
# SQL `--`, HTML `<!-- ... -->`, and Jinja `{# ... #}`.
AUTHOR_ONLY_LINE = re.compile(
    r"""^\s*(?:
        \# | //  | --     # hash, slash, SQL
      | <!-- .*? -->      # HTML comment
      | \{\# .*? \#\}     # Jinja comment
    )\s*AUTHOR-ONLY.*$""",
    re.MULTILINE | re.VERBOSE,
)


def _copy_filtered(src: Path, dst: Path, canonical_flag: str) -> None:
    if dst.exists():
        shutil.rmtree(dst)
    dst.mkdir(parents=True)
    needles = _flag_needles(canonical_flag) if (
        canonical_flag and canonical_flag != "FLAG{REPLACE_ME_BEFORE_SHIPPING}"
    ) else []
    for item in sorted(src.rglob("*")):
        if item.is_dir():
            continue
        if item.name in DENY_NAMES:
            continue
        rel = item.relative_to(src)
        if any(part in DENY_DIRS for part in rel.parts):
            continue
        out = dst / rel
        out.parent.mkdir(parents=True, exist_ok=True)
        # Pre-flight encoding-aware leak scan on raw bytes — catches binary
        # assets that would otherwise be byte-copied verbatim by shutil.copy2.
        try:
            data = item.read_bytes()
        except OSError:
            continue
        for form, needle in needles:
            if needle in data:
                raise SystemExit(
                    f"refusing to publish: source file {item} contains the "
                    f"canonical flag in {form} encoding. Move it to a deny-listed "
                    "path or remove the flag-bearing content before publish."
                )
        try:
            text = data.decode("utf-8")
            scrubbed = AUTHOR_ONLY_LINE.sub("", text)
            if canonical_flag and canonical_flag != "FLAG{REPLACE_ME_BEFORE_SHIPPING}":
                scrubbed = scrubbed.replace(canonical_flag, "FLAG{REDACTED}")
            out.write_text(scrubbed, encoding="utf-8")
        except UnicodeDecodeError:
            # Binary file: byte-copy is safe ONLY because we already scanned
            # for every encoding-aware needle above.
            shutil.copy2(item, out)


def _public_compose(src_compose: Path) -> dict:
    data = yaml.safe_load(src_compose.read_text(encoding="utf-8")) or {}
    services = data.get("services", {})
    for svc in services.values():
        # Strip author-only env vars and volumes.
        if "volumes" in svc:
            del svc["volumes"]
    return data


def _challenge_yml(mfst: dict, slug: str) -> dict:
    title = slug.replace("-", " ").title()
    return {
        "name": title,
        "author": "webchall-master",
        "category": "web",
        "description": f"{title} — see README.player.md",
        "attribution": "webchall-master",
        "value": 100,
        "type": "standard",
        "version": "0.1",
        "image": ".",
        "protocol": "http",
        "host": "127.0.0.1",
        "flags": [mfst.get("canonical_flag", "FLAG{REPLACE_ME_BEFORE_SHIPPING}")],
        "topics": [mfst.get("vulnerability_class", "web")],
        "tags": ["web", mfst.get("stack", "")],
    }


def _rctf_yml(challenge: dict) -> dict:
    return {
        "name": challenge["name"],
        "category": challenge["category"],
        "description": challenge["description"],
        "points": challenge["value"],
        "flag": challenge["flags"][0],
    }


def _picoctf_yml(challenge: dict) -> dict:
    return {
        "name": challenge["name"],
        "category": challenge["category"],
        "description": challenge["description"],
        "points": challenge["value"],
        "flag": challenge["flags"][0],
        "author": challenge["author"],
        "hints": [],
        "tags": challenge.get("tags", []),
    }


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(prog="webchall_publish", description=__doc__)
    p.add_argument("challenge_dir", type=Path)
    args = p.parse_args(argv)

    challenge = args.challenge_dir
    src = challenge / "src"
    publish = challenge / "publish"
    adapters = challenge / "adapters"
    if not src.exists():
        print(f"missing src/ at {src}", file=sys.stderr)
        return 1

    try:
        mfst = manifest_lib.load(challenge)
    except manifest_lib.ManifestError as e:
        print(f"manifest error: {e}", file=sys.stderr)
        return 1

    canonical = mfst.get("canonical_flag", "")
    if not canonical or canonical == "FLAG{REPLACE_ME_BEFORE_SHIPPING}":
        print("refusing to publish: canonical_flag is unset or the placeholder. "
              "Update .webchall.manifest.yaml AND src/flag.txt before publish.",
              file=sys.stderr)
        return 1
    _copy_filtered(src, publish, canonical_flag=canonical)

    # Public compose — drop volumes, repurpose for player redeploy.
    src_compose = src / "docker-compose.yml"
    if src_compose.exists():
        public = _public_compose(src_compose)
        with (publish / "docker-compose.public.yml").open("w", encoding="utf-8") as f:
            yaml.safe_dump(public, f, sort_keys=False)

    # Refuse to publish if publish/ contains the canonical flag in ANY of the
    # encoding-aware forms (literal/base64/hex/url/etc). Mirrors the validator
    # rule_flag_not_in_publish so author-time and publish-time agree.
    if canonical and canonical != "FLAG{REPLACE_ME_BEFORE_SHIPPING}":
        post_needles = _flag_needles(canonical)
        for f in publish.rglob("*"):
            if not f.is_file():
                continue
            try:
                data = f.read_bytes()
            except OSError:
                continue
            for form, needle in post_needles:
                if needle in data:
                    print(f"flag leaked into {f} ({form} encoding); aborting publish",
                          file=sys.stderr)
                    return 1

    # Emit adapter files.
    adapters.mkdir(exist_ok=True)
    chall = _challenge_yml(mfst, mfst.get("slug", challenge.name))
    (adapters / "ctfcli.yml").write_text(
        yaml.safe_dump(chall, sort_keys=False), encoding="utf-8"
    )
    (challenge / "challenge.yml").write_text(
        yaml.safe_dump(chall, sort_keys=False), encoding="utf-8"
    )
    (adapters / "rctf.yml").write_text(
        yaml.safe_dump(_rctf_yml(chall), sort_keys=False), encoding="utf-8"
    )
    (adapters / "picoctf.yml").write_text(
        yaml.safe_dump(_picoctf_yml(chall), sort_keys=False), encoding="utf-8"
    )

    print(f"✓ published {challenge.name}: publish/ + adapters/{{ctfcli,rctf,picoctf}}.yml")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
