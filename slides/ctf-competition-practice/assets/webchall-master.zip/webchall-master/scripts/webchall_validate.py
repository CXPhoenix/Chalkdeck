#!/usr/bin/env python3
"""webchall_validate — strict rule catalog + --soft downgrade.

Usage:
  webchall_validate.py <challenge-dir> [--soft] [--json] [--sarif]
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from _wcm_common import rules as rule_lib  # noqa: E402
from _wcm_common.reporters import to_json, to_pretty, to_sarif  # noqa: E402


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(prog="webchall_validate", description=__doc__)
    p.add_argument("challenge_dir", type=Path)
    p.add_argument("--soft", action="store_true",
                   help="downgrade errors to warnings AND exit 0. JSON/SARIF "
                        "output records each finding's original_severity so "
                        "downstream tools cannot lose the underlying severity.")
    p.add_argument("--json", action="store_true", help="emit JSON report")
    p.add_argument("--sarif", action="store_true", help="emit SARIF report")
    args = p.parse_args(argv)

    findings = rule_lib.run_all(args.challenge_dir)
    has_real_errors = any(f.severity == "error" for f in findings)

    if args.soft:
        for f in findings:
            if f.severity == "error":
                f.extra["original_severity"] = "error"
                f.severity = "warning"

    if args.sarif:
        sys.stdout.write(to_sarif(findings, tool_name="webchall_validate"))
    elif args.json:
        sys.stdout.write(to_json(findings))
    else:
        sys.stdout.write(to_pretty(findings))
        if has_real_errors and args.soft:
            sys.stdout.write(
                "\n⚠ --soft active — errors downgraded. Real errors MUST be "
                "fixed before ship; --soft is for early drafts only.\n"
            )

    if args.soft:
        return 0
    return 1 if has_real_errors else 0


if __name__ == "__main__":
    raise SystemExit(main())
