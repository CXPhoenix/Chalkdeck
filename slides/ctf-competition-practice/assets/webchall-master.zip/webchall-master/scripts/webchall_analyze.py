#!/usr/bin/env python3
"""webchall_analyze — static AST + runtime HTTP fuzz analyzer.

Usage:
  webchall_analyze.py <challenge-dir> [--no-runtime] [--target URL]
                      [--json|--sarif]
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from _wcm_common import http_fuzz, rules_env, static_fuzz  # noqa: E402
from _wcm_common.docker_helpers import compose_session, docker_available  # noqa: E402
from _wcm_common.reporters import Finding, to_json, to_pretty, to_sarif  # noqa: E402


DEFAULT_TARGETS_BY_STACK = {
    "flask": "http://127.0.0.1:5000",
    "fastapi": "http://127.0.0.1:8000",
    "php-apache": "http://127.0.0.1:8080",
    "php-nginx-fpm": "http://127.0.0.1:8081",
    "nodejs-express": "http://127.0.0.1:3000",
    "static-nginx": "http://127.0.0.1:8082",
}


def _check_port_against_rules_env(target: str) -> Finding | None:
    """Emit a warning if `target`'s port falls outside the event's
    HOST_PORT_RANGE. Silently skips when `.rules.env` is absent or lacks
    the keys (archived/legacy contexts).
    """
    start = rules_env.get("HOST_PORT_RANGE_START")
    end = rules_env.get("HOST_PORT_RANGE_END")
    if not start or not end:
        return None
    try:
        from urllib.parse import urlparse
        port = urlparse(target).port
        if port is None:
            return None
        if int(start) <= port <= int(end):
            return None
        return Finding(
            rule="host_port_out_of_range", severity="warning",
            location=target,
            summary=(
                f"host port {port} outside .rules.env HOST_PORT_RANGE "
                f"[{start}, {end}]"
            ),
        )
    except (ValueError, TypeError):
        return None


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(prog="webchall_analyze", description=__doc__)
    p.add_argument("challenge_dir", type=Path)
    p.add_argument("--no-runtime", action="store_true",
                   help="skip docker-compose runtime fuzz phase")
    p.add_argument("--target", help="override runtime target URL")
    p.add_argument("--json", action="store_true")
    p.add_argument("--sarif", action="store_true")
    args = p.parse_args(argv)

    src = args.challenge_dir / "src"
    findings: list[Finding] = []

    # Port-range advisory: emit at the start so it appears even if --no-runtime.
    # Use --target if explicitly set; otherwise resolve via stack default below.
    if args.target:
        port_finding = _check_port_against_rules_env(args.target)
        if port_finding is not None:
            findings.append(port_finding)

    # Static phase ---
    findings.extend(static_fuzz.analyze_static(src))

    # Runtime phase ---
    if args.no_runtime:
        findings.append(Finding(rule="runtime_skipped", severity="advisory",
                                location=str(args.challenge_dir),
                                summary="runtime phase skipped (--no-runtime)"))
    elif not docker_available():
        findings.append(Finding(rule="runtime_skipped", severity="advisory",
                                location=str(args.challenge_dir),
                                summary="docker not available; runtime phase skipped"))
    else:
        # Read manifest stack to pick a default target.
        target = args.target
        if not target:
            try:
                from _wcm_common import manifest as m
                stack = m.load(args.challenge_dir).get("stack", "flask")
                target = DEFAULT_TARGETS_BY_STACK.get(stack, "http://127.0.0.1:5000")
            except Exception:
                target = "http://127.0.0.1:5000"
            # Now that the target is resolved (no explicit --target), check it
            # against the event's HOST_PORT_RANGE.
            port_finding = _check_port_against_rules_env(target)
            if port_finding is not None:
                findings.append(port_finding)
        try:
            with compose_session(src):
                # Wait for boot.
                from urllib.parse import urlparse
                u = urlparse(target)
                from _wcm_common.docker_helpers import wait_for_port
                if not wait_for_port(u.hostname or "127.0.0.1", u.port or 80, timeout=20):
                    findings.append(Finding(rule="runtime_unreachable", severity="warning",
                                            location=target,
                                            summary="container did not become reachable in 20s"))
                else:
                    findings.extend(http_fuzz.fuzz_paths(target))
                    findings.extend(http_fuzz.fuzz_ssti_markers(target))
        except Exception as e:
            findings.append(Finding(rule="runtime_error", severity="warning",
                                    location=str(src),
                                    summary=f"runtime fuzz failed: {e}"))

    if args.sarif:
        sys.stdout.write(to_sarif(findings, tool_name="webchall_analyze"))
    elif args.json:
        sys.stdout.write(to_json(findings))
    else:
        sys.stdout.write(to_pretty(findings))

    # Analyzer is informational; non-zero only on hard runtime errors.
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
