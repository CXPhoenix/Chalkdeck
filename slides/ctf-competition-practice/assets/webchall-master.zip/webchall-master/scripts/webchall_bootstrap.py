#!/usr/bin/env python3
"""webchall_bootstrap — generate a `.rules.env` for a CTF event repo root.

Usage:
  webchall_bootstrap.py [--name <CTF_EVENT_NAME>] [--long-name <name>]
                        [--flag-prefix <prefix>] [--port-range <start>:<end>]
                        [--force] [--yes]

Generates the event-scoped `.rules.env` defined by the `webchall-rules-env`
capability — 15 keys covering flag format, port allocation, locale, and
anti-AI-slop rules. Without flags, runs interactively; with flags, runs
non-interactively. Refuses to overwrite an existing file unless `--force`
is passed.
"""

from __future__ import annotations

import argparse
import difflib
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from _wcm_common import rules_env  # noqa: E402


# Defaults for the 11 keys that have a sensible non-author default. The four
# keys without defaults (CTF_EVENT_NAME, CTF_EVENT_LONG_NAME, FLAG_REGEX,
# FLAG_FORMAT_LITERAL) MUST be supplied by flag, prompt, or derivation.
DEFAULTS: dict[str, str] = {
    "FLAG_TYPE": "static",
    "FLAG_ASSET_VERSION_CONTROLLED": "true",
    "AUTHOR_NAME": "",
    "AUTHOR_EMAIL": "",
    "CATEGORIES": "web,crypto,pwn,rev,forensics,misc,osint",
    "DIFFICULTIES": "beginner,easy,medium,hard,expert",
    "HOST_PORT_RANGE_START": "8080",
    "HOST_PORT_RANGE_END": "8099",
    "PLAYER_FACING_LOCALE": "zh-Hant-TW",
    "SPEC_LOCALE": "en",
    "BLOCK_PRC_VOCAB": "true",
    "ENFORCE_ANTI_AI_SLOP": "true",
}


def derive_flag_keys(prefix: str) -> tuple[str, str]:
    r"""Derive (FLAG_REGEX, FLAG_FORMAT_LITERAL) from a flag prefix.

    Example: prefix='ISIP.HSCTF' yields:
      FLAG_REGEX = r'ISIP\.HSCTF\{\S+\}'
      FLAG_FORMAT_LITERAL = 'ISIP.HSCTF{<text>}'
    """
    escaped = re.escape(prefix)
    flag_regex = escaped + r"\{\S+\}"
    flag_literal = f"{prefix}{{<text>}}"
    return flag_regex, flag_literal


def parse_port_range(spec: str) -> tuple[int, int]:
    """Parse 'start:end' into (start, end). Raises ValueError on bad input."""
    if ":" not in spec:
        raise ValueError(f"--port-range must be 'start:end', got {spec!r}")
    s, e = spec.split(":", 1)
    return int(s), int(e)


def main(argv: list[str] | None = None, *, out_override: Path | None = None) -> int:
    """Entry point. `out_override` is a programmatic-only escape hatch for tests
    that need to write to a tmpdir; it is intentionally NOT exposed as a CLI
    flag because allowing arbitrary `--out` paths would let an unprivileged
    attacker write `.rules.env`-shaped content anywhere the user has write
    access (e.g., `~/.ssh/config`).
    """
    p = argparse.ArgumentParser(prog="webchall_bootstrap", description=__doc__)
    p.add_argument("--name", help="CTF_EVENT_NAME (e.g. ISIP.HSCTF)")
    p.add_argument("--long-name", dest="long_name",
                   help="CTF_EVENT_LONG_NAME (e.g. 'ISIP HSCTF')")
    p.add_argument("--flag-prefix", dest="flag_prefix",
                   help="prefix for FLAG_REGEX/FLAG_FORMAT_LITERAL "
                        "(e.g. ISIP.HSCTF)")
    p.add_argument("--port-range", dest="port_range",
                   help="HOST_PORT_RANGE_START:HOST_PORT_RANGE_END (e.g. 8080:8099)")
    p.add_argument("--author-name", dest="author_name", default=None,
                   help="AUTHOR_NAME for challenge.yml (per-developer override)")
    p.add_argument("--author-email", dest="author_email", default=None,
                   help="AUTHOR_EMAIL for challenge.yml (per-developer override)")
    p.add_argument("--flag-type", dest="flag_type", default=None,
                   choices=list(rules_env.FLAG_TYPE_ENUM),
                   help="FLAG_TYPE override (default: static)")
    p.add_argument("--force", action="store_true",
                   help="overwrite existing .rules.env (requires --yes in non-TTY; "
                        "always requires typed 'yes' in TTY)")
    p.add_argument("--yes", action="store_true",
                   help="skip confirmation prompts in non-TTY mode")
    args = p.parse_args(argv)

    target = (
        out_override if out_override is not None
        else Path.cwd() / rules_env.DEFAULT_FILENAME
    )

    interactive = sys.stdin.isatty() and (
        not args.name or not args.long_name or not args.flag_prefix or not args.port_range
    )

    # Refuse silent partial defaults in non-TTY mode: missing required flags
    # would otherwise be filled with surprising values (e.g., long-name
    # silently defaulting to short-name in CI).
    if not sys.stdin.isatty():
        missing = [
            flag for flag, val in [
                ("--name", args.name),
                ("--long-name", args.long_name),
                ("--flag-prefix", args.flag_prefix),
                ("--port-range", args.port_range),
            ] if not val
        ]
        if missing:
            print(
                f"error: required in non-TTY mode: {', '.join(missing)}",
                file=sys.stderr,
            )
            return 1

    try:
        mapping = _build_mapping(args, interactive=interactive)
    except ValueError as e:
        print(f"error: {e}", file=sys.stderr)
        return 1

    # Validate before any overwrite confirmation — fail fast on bad inputs.
    try:
        rules_env.validate(rules_env.normalize_for_write(mapping))
    except ValueError as e:
        print(f"error: {e}", file=sys.stderr)
        return 1

    if target.exists():
        if not args.force:
            print(".rules.env already exists; pass --force to overwrite",
                  file=sys.stderr)
            return 1
        if not _confirm_overwrite(target, mapping, yes=args.yes):
            print("aborted", file=sys.stderr)
            return 1

    try:
        rules_env.write(target, mapping, force=True)
    except FileExistsError:
        # Lost a race with a concurrent author — re-display diff and refuse
        # rather than silently overwriting their work.
        print(
            f"refusing: {target} appeared between check and write; "
            "another author may have just written it. Re-run to confirm.",
            file=sys.stderr,
        )
        return 1
    print(f"✓ wrote {target}")
    if not (args.author_name or args.author_email or mapping.get("AUTHOR_NAME") or mapping.get("AUTHOR_EMAIL")):
        print(
            "note: AUTHOR_NAME and AUTHOR_EMAIL are empty; challenge.yml will "
            "ship with author='TODO'. Set them via --author-name / --author-email "
            f"or edit {target} directly.",
            file=sys.stderr,
        )
    return 0


def _build_mapping(args: argparse.Namespace, *, interactive: bool) -> dict[str, str]:
    """Compose the 15-key mapping from flags, defaults, and prompts."""
    mapping = dict(DEFAULTS)

    name = args.name or (_prompt("CTF_EVENT_NAME (e.g. ISIP.HSCTF): ")
                         if interactive else None)
    if not name:
        raise ValueError("CTF_EVENT_NAME is required (--name)")
    if not re.fullmatch(r"[A-Za-z0-9._-]+", name):
        raise ValueError(
            f"CTF_EVENT_NAME {name!r} must match ^[A-Za-z0-9._-]+$"
        )
    mapping["CTF_EVENT_NAME"] = name

    long_name = args.long_name or (_prompt(
        f"CTF_EVENT_LONG_NAME [{name}]: ", default=name
    ) if interactive else name)
    mapping["CTF_EVENT_LONG_NAME"] = long_name

    flag_prefix = args.flag_prefix or (_prompt(
        f"flag prefix (used to derive FLAG_REGEX/FLAG_FORMAT_LITERAL) [{name}]: ",
        default=name,
    ) if interactive else name)
    if not re.fullmatch(r"[A-Za-z0-9._-]+", flag_prefix):
        raise ValueError(
            f"--flag-prefix {flag_prefix!r} must match ^[A-Za-z0-9._-]+$"
        )
    flag_regex, flag_literal = derive_flag_keys(flag_prefix)
    mapping["FLAG_REGEX"] = flag_regex
    mapping["FLAG_FORMAT_LITERAL"] = flag_literal

    if args.port_range:
        start, end = parse_port_range(args.port_range)
        mapping["HOST_PORT_RANGE_START"] = str(start)
        mapping["HOST_PORT_RANGE_END"] = str(end)
    elif interactive:
        rng = _prompt(
            f"HOST_PORT_RANGE_START:END [{DEFAULTS['HOST_PORT_RANGE_START']}:"
            f"{DEFAULTS['HOST_PORT_RANGE_END']}]: ",
            default=f"{DEFAULTS['HOST_PORT_RANGE_START']}:{DEFAULTS['HOST_PORT_RANGE_END']}",
        )
        start, end = parse_port_range(rng)
        mapping["HOST_PORT_RANGE_START"] = str(start)
        mapping["HOST_PORT_RANGE_END"] = str(end)

    if args.author_name is not None:
        mapping["AUTHOR_NAME"] = args.author_name
    if args.author_email is not None:
        mapping["AUTHOR_EMAIL"] = args.author_email
    if args.flag_type is not None:
        mapping["FLAG_TYPE"] = args.flag_type

    return mapping


def _prompt(message: str, *, default: str | None = None) -> str:
    """Read a line from stdin with an optional default."""
    raw = input(message).strip()
    if not raw and default is not None:
        return default
    return raw


def _confirm_overwrite(
    target: Path,
    new_mapping: dict[str, str],
    *,
    yes: bool,
) -> bool:
    """Print a unified diff and require confirmation. Returns True to proceed.

    Confirmation rules:
      - Non-TTY: `--yes` skips the prompt (CI / automation flow).
      - TTY: `--yes` is IGNORED — typed `yes` is always required. This
        preserves the human safety net even when the user has formed a
        habit of pasting `--force --yes`.
    """
    existing = target.read_text(encoding="utf-8").splitlines(keepends=True)
    proposed = rules_env.render(
        rules_env.normalize_for_write(new_mapping)
    ).splitlines(keepends=True)
    diff = "".join(difflib.unified_diff(
        existing, proposed,
        fromfile=str(target),
        tofile=str(target) + " (proposed)",
    ))
    print(diff, end="")
    is_tty = sys.stdin.isatty()
    if not is_tty:
        if not yes:
            print(
                "\nrefusing: --force in non-TTY mode requires --yes",
                file=sys.stderr,
            )
            return False
        return True
    answer = input("\nType 'yes' to overwrite: ").strip()
    return answer == "yes"


if __name__ == "__main__":
    raise SystemExit(main())
