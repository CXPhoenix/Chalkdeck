#!/usr/bin/env python3
"""webchall_manifest — manage `.webchall.manifest.yaml` per challenge.

Subcommands:
  show <challenge-dir>
  mark-stage-complete <challenge-dir> <stage>
  append-audit-verdict <challenge-dir> <stage> <pass|advisory|fail> [--note ...]
  resume <challenge-dir>
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from _wcm_common import PIPELINE_STAGES  # noqa: E402
from _wcm_common import manifest as manifest_lib  # noqa: E402


def cmd_show(args: argparse.Namespace) -> int:
    import yaml
    print(yaml.safe_dump(manifest_lib.load(args.challenge_dir), sort_keys=False))
    return 0


def cmd_mark(args: argparse.Namespace) -> int:
    try:
        manifest_lib.mark_stage_complete(args.challenge_dir, args.stage)
    except manifest_lib.ManifestError as e:
        print(f"refused: {e}", file=sys.stderr)
        return 1
    print(f"✓ marked {args.stage} complete")
    return 0


def cmd_append_audit(args: argparse.Namespace) -> int:
    manifest_lib.append_audit_verdict(args.challenge_dir, args.stage, args.verdict,
                                      note=args.note)
    print(f"✓ audit verdict recorded: {args.stage}={args.verdict}")
    return 0


def cmd_resume(args: argparse.Namespace) -> int:
    stage = manifest_lib.first_incomplete_stage(args.challenge_dir)
    if stage is None:
        print("all stages complete; nothing to resume")
        return 0
    print(f"resume from stage: {stage}")
    return 0


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="webchall_manifest", description=__doc__)
    sub = p.add_subparsers(dest="cmd", required=True)

    ps = sub.add_parser("show")
    ps.add_argument("challenge_dir", type=Path)
    ps.set_defaults(func=cmd_show)

    pm = sub.add_parser("mark-stage-complete")
    pm.add_argument("challenge_dir", type=Path)
    pm.add_argument("stage", choices=list(PIPELINE_STAGES))
    pm.set_defaults(func=cmd_mark)

    pa = sub.add_parser("append-audit-verdict")
    pa.add_argument("challenge_dir", type=Path)
    pa.add_argument("stage", choices=list(PIPELINE_STAGES))
    pa.add_argument("verdict", choices=["pass", "advisory", "fail"])
    pa.add_argument("--note", default="")
    pa.set_defaults(func=cmd_append_audit)

    pr = sub.add_parser("resume")
    pr.add_argument("challenge_dir", type=Path)
    pr.set_defaults(func=cmd_resume)

    return p


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
