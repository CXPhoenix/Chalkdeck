"""webchall-master common library — shared by all seven entry points."""

__version__ = "0.1.0"

SKILL_ROOT_NAME = "webchall-master"
MANIFEST_NAME = ".webchall.manifest.yaml"
MANIFEST_SCHEMA_VERSION = "1.0"
SUPPORTED_STACKS = (
    "flask",
    "fastapi",
    "php-apache",
    "php-nginx-fpm",
    "nodejs-express",
    "static-nginx",
)
PIPELINE_STAGES = (
    "brief",
    "design",
    "scaffold",
    "implement",
    "analyze",
    "validate",
    "publish",
)
DEFAULT_FLAG_REGEX = r"^FLAG\{[!-~]+\}$"


def default_flag_regex() -> str:
    """Three-layer FLAG_REGEX lookup for downstream loaders.

    Resolution order:
      1. `.rules.env` `FLAG_REGEX` at cwd, if present and parseable.
      2. The hardcoded fallback `DEFAULT_FLAG_REGEX`.

    The manifest's per-challenge `flag_regex` is layer 0 — callers MUST
    consult the manifest first, and only invoke this function when the
    manifest does not declare one. Reads are lazy; no cross-stage cache.
    """
    # Local import avoids the module-level circular dep risk: rules_env
    # is loaded only when this function is actually called.
    from . import rules_env as _re
    return _re.get("FLAG_REGEX", fallback=DEFAULT_FLAG_REGEX)
