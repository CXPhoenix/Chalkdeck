"""Wiki frontmatter + cross-link + invariant logic.

Backs `webchall_wiki.py` and is also imported by `webchall_validate.py` to
verify manifest references resolve to real wiki pages.
"""

from __future__ import annotations

import datetime as _dt
import hashlib
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

import yaml

from .reporters import Finding


WIKI_DIRS = ("taxonomies", "concepts", "frameworks", "cves", "recipes")
RAW_DIR = "raw"
LOG_HEADING_RE = re.compile(r"^## \[\d{4}-\d{2}-\d{2}\] (ingest|query|lint) \| .+$")
AUTHOR_NOTES_RE = re.compile(
    r"<!--\s*AUTHOR-NOTES:BEGIN\s*-->(.*?)<!--\s*AUTHOR-NOTES:END\s*-->",
    re.DOTALL,
)


@dataclass
class Page:
    path: Path
    frontmatter: dict
    body: str

    @property
    def id(self) -> str:
        return str(self.frontmatter.get("id", ""))

    @property
    def type(self) -> str:
        return str(self.frontmatter.get("type", ""))


def parse(path: Path) -> Page:
    raw = path.read_text(encoding="utf-8")
    if not raw.startswith("---\n"):
        raise ValueError(f"{path}: missing YAML frontmatter")
    end = raw.find("\n---", 4)
    if end == -1:
        raise ValueError(f"{path}: unterminated frontmatter")
    fm = yaml.safe_load(raw[4:end]) or {}
    body = raw[end + 4 :].lstrip("\n")
    return Page(path=path, frontmatter=fm, body=body)


def write(page: Page) -> None:
    fm_text = yaml.safe_dump(page.frontmatter, sort_keys=False, allow_unicode=True)
    page.path.parent.mkdir(parents=True, exist_ok=True)
    page.path.write_text(f"---\n{fm_text}---\n\n{page.body}", encoding="utf-8")


def iter_pages(wiki_dir: Path) -> Iterable[Page]:
    for sub in WIKI_DIRS:
        for p in (wiki_dir / sub).glob("*.md"):
            yield parse(p)


class ProfileMissingError(FileNotFoundError):
    """Raised when profile.yaml is absent — a missing profile silently
    disables every profile-driven validator, which is dangerous."""


def load_profile(wiki_root: Path, *, allow_missing: bool = False) -> dict:
    """profile.yaml lives at the skill root, not inside wiki/.

    Raises ProfileMissingError when the profile is absent (unless
    `allow_missing=True`). This is intentional: a silent empty-dict fallback
    would let every required-dirs / required-fields / log-format-strict /
    validator-extensions check pass with zero output.
    """
    candidate = wiki_root.parent / "profile.yaml"
    if not candidate.exists():
        if allow_missing:
            return {}
        raise ProfileMissingError(
            f"profile.yaml not found at {candidate}. Without it the wiki has "
            "no schema enforcement. Pass allow_missing=True to bypass."
        )
    return yaml.safe_load(candidate.read_text(encoding="utf-8")) or {}


def required_fields(profile: dict, page_type: str) -> list[str]:
    return list(profile.get("required_fields", {}).get(page_type, []))


# ---------------------------------------------------------------------------
# Verification rules
# ---------------------------------------------------------------------------

def verify_frontmatter_schema(wiki_dir: Path, profile: dict) -> list[Finding]:
    findings: list[Finding] = []
    for page in iter_pages(wiki_dir):
        for f in required_fields(profile, page.type):
            if f not in page.frontmatter:
                findings.append(
                    Finding(
                        rule="frontmatter_schema",
                        severity="error",
                        location=str(page.path),
                        summary=f"missing required field '{f}' for type {page.type!r}",
                    )
                )
    return findings


def verify_required_dirs(wiki_dir: Path, profile: dict) -> list[Finding]:
    findings: list[Finding] = []
    for d in profile.get("required_dirs", []):
        path = wiki_dir / d
        if not path.exists() or not any(path.iterdir()):
            findings.append(
                Finding(
                    rule="required_dirs",
                    severity="error",
                    location=str(path),
                    summary=f"required directory '{d}' is missing or empty",
                )
            )
    return findings


def verify_dead_links(wiki_dir: Path) -> list[Finding]:
    """Every related/concept_refs/cve_refs/applicable_concepts entry MUST resolve
    AND target the right category for each field. e.g., a `cves:` entry on a
    framework page MUST point at a cve-typed page, not a concept."""
    pages = list(iter_pages(wiki_dir))
    by_id = {p.id: p for p in pages}
    by_path = {p.path.relative_to(wiki_dir).with_suffix("").as_posix(): p for p in pages}

    # Field -> set of acceptable target page types.
    expected_types = {
        "related": {"taxonomy", "concept", "framework", "cve", "recipe"},
        "concept_refs": {"concept", "framework"},  # recipes can reference both
        "cve_refs": {"cve"},
        "applicable_concepts": {"concept"},
        "cves": {"cve"},
    }

    findings: list[Finding] = []
    for page in pages:
        for k, accepted in expected_types.items():
            entries = page.frontmatter.get(k, []) or []
            for entry in entries:
                target = by_path.get(entry) or by_id.get(entry)
                if target is None:
                    findings.append(
                        Finding(
                            rule="dead_link",
                            severity="error",
                            location=str(page.path),
                            summary=f"unresolved {k} entry {entry!r}",
                        )
                    )
                    continue
                if target.type not in accepted:
                    findings.append(
                        Finding(
                            rule="dead_link",
                            severity="error",
                            location=str(page.path),
                            summary=f"{k} entry {entry!r} resolves to type {target.type!r} "
                                    f"but {sorted(accepted)} expected",
                        )
                    )
    return findings


def verify_duplicate_ids(wiki_dir: Path) -> list[Finding]:
    seen: dict[str, Path] = {}
    findings: list[Finding] = []
    for page in iter_pages(wiki_dir):
        if page.id in seen:
            findings.append(
                Finding(
                    rule="duplicate_id",
                    severity="error",
                    location=str(page.path),
                    summary=f"id {page.id!r} duplicates {seen[page.id]}",
                )
            )
        else:
            seen[page.id] = page.path
    return findings


def verify_raw_immutability(raw_dir: Path) -> list[Finding]:
    findings: list[Finding] = []
    for p in raw_dir.rglob("*.md"):
        text = p.read_text(encoding="utf-8")
        m = re.search(r"\nsha256:\s*([0-9a-f]{64})\n", text)
        if not m:
            findings.append(
                Finding(
                    rule="raw_file_tampering",
                    severity="error",
                    location=str(p),
                    summary="missing sha256 in frontmatter",
                )
            )
            continue
        recorded = m.group(1)
        body = text.split("\n---\n", 1)[1].lstrip("\n") if "\n---\n" in text else ""
        actual = hashlib.sha256(body.encode("utf-8")).hexdigest()
        if recorded != actual:
            findings.append(
                Finding(
                    rule="raw_file_tampering",
                    severity="error",
                    location=str(p),
                    summary="sha256 in frontmatter does not match body",
                )
            )
    return findings


def verify_log_format(wiki_dir: Path, profile: dict) -> list[Finding]:
    if not profile.get("log_format_strict", False):
        return []
    log = wiki_dir / "log.md"
    if not log.exists():
        return [Finding(rule="log_format", severity="error", location=str(log),
                        summary="log.md missing")]
    findings: list[Finding] = []
    for i, line in enumerate(log.read_text(encoding="utf-8").splitlines(), start=1):
        if line.startswith("## ") and not LOG_HEADING_RE.match(line):
            findings.append(
                Finding(
                    rule="log_format",
                    severity="error",
                    location=f"{log}:{i}",
                    summary=f"log heading does not match strict format: {line!r}",
                )
            )
    return findings


def verify_stale_pages(wiki_dir: Path, max_age_days: int) -> list[Finding]:
    today = _dt.date.today()
    findings: list[Finding] = []
    for page in iter_pages(wiki_dir):
        last = page.frontmatter.get("last_compiled")
        if not last:
            continue
        try:
            d = _dt.date.fromisoformat(str(last))
        except ValueError:
            continue
        if (today - d).days > max_age_days:
            findings.append(
                Finding(
                    rule="webchall-stale-pages",
                    severity="warning",
                    location=str(page.path),
                    summary=f"page last compiled {(today - d).days}d ago (> {max_age_days}d)",
                )
            )
    return findings


def verify_cve_coverage(wiki_dir: Path, min_per_stack: int = 3) -> list[Finding]:
    pages = list(iter_pages(wiki_dir))
    framework_ids = [p.id for p in pages if p.type == "framework"]
    counts = {fid: 0 for fid in framework_ids}
    for p in pages:
        if p.type != "cve":
            continue
        for r in p.frontmatter.get("related", []) or []:
            tail = r.rsplit("/", 1)[-1]
            if tail in counts:
                counts[tail] += 1
    findings: list[Finding] = []
    for fid, c in counts.items():
        if c < min_per_stack:
            findings.append(
                Finding(
                    rule="webchall-cve-coverage",
                    severity="error",
                    location=f"frameworks/{fid}.md",
                    summary=f"only {c} CVE pages reference framework {fid!r} (need >= {min_per_stack})",
                )
            )
    return findings


CLAUDE_TOOL_TOKENS = (
    "TodoWrite",
    "AskUserQuestion",
    "WebFetch",
    "WebSearch",
    "EnterPlanMode",
    "ExitPlanMode",
    "ScheduleWakeup",
)
# Plain words that need special handling (would false-positive in shell snippets).
# Token list deliberately excludes "Read", "Write", "Edit", "Bash", "Glob", "Grep",
# "Skill", "Agent", "Task" because those words appear in normal English prose
# (e.g., "read the file", "write a test"). Cross-model lint targets only
# unambiguous Claude tool names.


def verify_cross_model_lint(skill_dir: Path) -> list[Finding]:
    findings: list[Finding] = []
    targets = ["SKILL.md", "SKILL.zhTW.md", "AGENTS.md"]
    for name in targets:
        p = skill_dir / name
        if not p.exists():
            continue
        for i, line in enumerate(p.read_text(encoding="utf-8").splitlines(), start=1):
            for tok in CLAUDE_TOOL_TOKENS:
                if tok in line:
                    findings.append(
                        Finding(
                            rule="webchall-cross-model-lint",
                            severity="error",
                            location=f"{p}:{i}",
                            summary=f"normative file mentions Claude tool name {tok!r}",
                        )
                    )
    return findings


def verify_taxonomy_coverage(wiki_dir: Path) -> list[Finding]:
    """Each OWASP Top 10 / API taxonomy MUST list 10 categories;
    PortSwigger Web Security Academy MUST enumerate at least 31 distinct topics."""
    findings: list[Finding] = []
    expectations = {
        "owasp-top10-2025": ("A", 10),
        "owasp-top10-2021": ("A", 10),
        "owasp-top10-2017": ("A", 10),
        "owasp-api-top10-2023": ("API", 10),
    }
    for tid, (prefix, n) in expectations.items():
        p = wiki_dir / "taxonomies" / f"{tid}.md"
        if not p.exists():
            findings.append(
                Finding(rule="taxonomy_coverage", severity="error", location=str(p),
                        summary=f"missing taxonomy {tid}")
            )
            continue
        text = p.read_text(encoding="utf-8")
        # Count distinct category numbers in level-2 headings.
        pattern = re.compile(rf"^## {re.escape(prefix)}0?(\d{{1,2}})\b", re.MULTILINE)
        unique = {m.group(1).lstrip("0") or "0" for m in pattern.finditer(text)}
        if len(unique) < n:
            findings.append(
                Finding(
                    rule="taxonomy_coverage",
                    severity="error",
                    location=str(p),
                    summary=f"taxonomy {tid} has {len(unique)} {prefix}x categories (need {n})",
                )
            )

    # PortSwigger taxonomy: count topic bullets across the three groupings.
    ps_path = wiki_dir / "taxonomies" / "portswigger-academy.md"
    if not ps_path.exists():
        findings.append(Finding(rule="taxonomy_coverage", severity="error",
                                location=str(ps_path),
                                summary="missing portswigger-academy taxonomy"))
    else:
        text = ps_path.read_text(encoding="utf-8")
        # Each topic is a `- <topic>` line; many also follow `- <topic> →`.
        # Count first-level bullets that appear under any `## ` heading.
        topic_lines = re.findall(r"^- \S", text, re.MULTILINE)
        if len(topic_lines) < 31:
            findings.append(Finding(
                rule="taxonomy_coverage",
                severity="error",
                location=str(ps_path),
                summary=f"PortSwigger taxonomy has {len(topic_lines)} topic bullets "
                        f"(need >= 31 per spec)",
            ))
    return findings
