"""`.rules.env` parser, validator, and writer.

Single source of truth for the 15-key event-scoped CTF authoring schema.
Pure stdlib (re, pathlib, shlex) — no third-party dependencies.

Public API:
    load(path)                 -> dict[str, str]
    get(key, fallback, *, path) -> str | None
    write(path, mapping, *, force) -> None

The file format is a strict dotenv subset: KEY=VALUE per line, full-line
`#` comments, blank lines ignored, quoted values via POSIX shell rules.
Variable expansion (`$VAR`), `export` prefixes, and multi-line values are
explicitly rejected — a caller that needs richer expressiveness should use
a real config format, not extend this parser.
"""

from __future__ import annotations

import os
import re
import shlex
import tempfile
from pathlib import Path
from typing import Iterable

# === Schema: the 15 documented keys (Approach 2) ===

REQUIRED_KEYS: tuple[str, ...] = (
    "CTF_EVENT_NAME",
    "CTF_EVENT_LONG_NAME",
    "FLAG_REGEX",
    "FLAG_FORMAT_LITERAL",
    "FLAG_TYPE",
    "FLAG_ASSET_VERSION_CONTROLLED",
    "AUTHOR_NAME",
    "AUTHOR_EMAIL",
    "CATEGORIES",
    "DIFFICULTIES",
    "HOST_PORT_RANGE_START",
    "HOST_PORT_RANGE_END",
    "PLAYER_FACING_LOCALE",
    "SPEC_LOCALE",
    "BLOCK_PRC_VOCAB",
    "ENFORCE_ANTI_AI_SLOP",
)

FLAG_TYPE_ENUM = ("static", "dynamic")
BOOL_KEYS = ("FLAG_ASSET_VERSION_CONTROLLED", "BLOCK_PRC_VOCAB", "ENFORCE_ANTI_AI_SLOP")
LOCALE_KEYS = ("PLAYER_FACING_LOCALE", "SPEC_LOCALE")
PORT_MIN, PORT_MAX = 1024, 65535
DEFAULT_FILENAME = ".rules.env"

# DoS guard: cap on file size we agree to read. The 15-key schema renders to
# under 1 KiB; anything beyond a few KiB is either malicious or a runaway tool.
MAX_FILE_BYTES = 64 * 1024

# Keys an attacker could inject to alter process environment when the file is
# loaded via `docker-compose --env-file` or similar. We block at the schema
# layer rather than trusting downstream env-loaders to filter.
_FORBIDDEN_EXTRA_KEY_PATTERNS = (
    re.compile(r"^LD_"),                     # LD_PRELOAD, LD_LIBRARY_PATH
    re.compile(r"^DYLD_"),                   # macOS equivalent
    re.compile(r"^PYTHON"),                  # PYTHONPATH, PYTHONSTARTUP
    re.compile(r"^PATH$"),
    re.compile(r"^(HTTP|HTTPS|NO|ALL)_PROXY$"),
    re.compile(r"^GIT_"),                    # GIT_SSH_COMMAND, etc.
)

# Regexes --------------------------------------------------------------------

_KEY_RE = re.compile(r"^[A-Z][A-Z0-9_]*$")
_LINE_RE = re.compile(r"^([A-Z][A-Z0-9_]*)=(.*)$")
_EVENT_NAME_RE = re.compile(r"^[A-Za-z0-9._-]+$")
_LOCALE_RE = re.compile(r"^[a-z]{2,3}(-[A-Z][a-z]{3})?(-[A-Z]{2})?$")
_LOWER_TOKEN_RE = re.compile(r"^[a-z]+$")


# === Parsing ==================================================================


def _parse_text(text: str) -> dict[str, str]:
    """Parse the dotenv subset; raises ValueError on malformed lines.

    Exposed (with leading underscore) for unit tests that exercise parser
    behavior without involving the schema validator.
    """
    out: dict[str, str] = {}
    for lineno, raw in enumerate(text.splitlines(), start=1):
        line = raw.rstrip("\r")
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            continue
        if stripped.startswith("export "):
            raise ValueError(
                f"line {lineno}: `export` prefix is not permitted in .rules.env"
            )
        m = _LINE_RE.match(stripped)
        if not m:
            raise ValueError(
                f"line {lineno}: malformed declaration {stripped!r} "
                "(expected KEY=VALUE with KEY matching ^[A-Z][A-Z0-9_]*$)"
            )
        key, raw_value = m.group(1), m.group(2)
        # Strip an inline trailing comment only when the value is unquoted.
        # Quoted values keep `#` as literal content (e.g., regex character class).
        value = _decode_value(raw_value, lineno=lineno)
        if "$" in value and _looks_like_expansion(value):
            raise ValueError(
                f"line {lineno}: variable expansion ($VAR) is not permitted in .rules.env"
            )
        out[key] = value
    return out


def _decode_value(raw: str, *, lineno: int) -> str:
    r"""Decode a raw RHS using POSIX shell quoting rules via shlex.

    For unquoted values, strip a trailing `# comment`. For quoted values, the
    shlex tokenizer handles escapes and preserves backslashes inside single
    quotes verbatim — so `FLAG_REGEX='ISIP\.HSCTF\{\S+\}'` returns the
    literal `ISIP\.HSCTF\{\S+\}`.
    """
    raw = raw.strip()
    if not raw:
        return ""
    # shlex with posix=True respects single/double quotes the same way bash does.
    # We use it as a tokenizer and reject multi-token values (would imply unquoted
    # whitespace, which is disallowed by spec).
    try:
        lexer = shlex.shlex(raw, posix=True)
        lexer.whitespace_split = True
        lexer.commenters = "#"
        tokens = list(lexer)
    except ValueError as e:
        raise ValueError(f"line {lineno}: cannot tokenize value {raw!r}: {e}") from e
    if not tokens:
        return ""
    if len(tokens) > 1:
        raise ValueError(
            f"line {lineno}: value contains unquoted whitespace; "
            "wrap multi-word values in single or double quotes"
        )
    return tokens[0]


def _looks_like_expansion(value: str) -> bool:
    """Heuristic: matches `$NAME` or `${NAME}` patterns inside the value."""
    return bool(re.search(r"\$\{?[A-Za-z_]\w*\}?", value))


# === Public read API =========================================================


def load(path: Path) -> dict[str, str]:
    """Parse `.rules.env` at `path`. Returns `{}` if the file does not exist.
    Raises `ValueError` on malformed content or oversized file.
    """
    p = Path(path)
    if not p.exists():
        return {}
    if p.is_dir():
        raise ValueError(f"{p} is a directory, not a regular file")
    size = p.stat().st_size
    if size > MAX_FILE_BYTES:
        raise ValueError(
            f"{p} is {size} bytes; refusing to parse files larger than "
            f"{MAX_FILE_BYTES} bytes (DoS guard)"
        )
    return _parse_text(p.read_text(encoding="utf-8"))


def get(
    key: str,
    fallback: str | None = None,
    *,
    path: Path | None = None,
) -> str | None:
    """Return the value for `key` from `.rules.env` at `path` (default cwd).
    Returns `fallback` if the file is absent or the key is not declared.
    """
    target = Path(path) if path is not None else Path.cwd() / DEFAULT_FILENAME
    try:
        data = load(target)
    except ValueError:
        # A malformed file at use-site MUST NOT break a fallback caller; the
        # Stage 1 entry gate is the only place that rejects malformed files.
        return fallback
    return data.get(key, fallback)


# === Validation ==============================================================


def validate(mapping: dict[str, str]) -> None:
    """Validate `mapping` against the 15-key schema. Raises ValueError on
    any failure; the message names the offending key(s).
    """
    missing = [k for k in REQUIRED_KEYS if k not in mapping]
    if missing:
        raise ValueError(f"missing required keys: {missing}")
    errors: list[str] = []
    for key in REQUIRED_KEYS:
        try:
            _validate_key(key, mapping[key])
        except ValueError as e:
            errors.append(str(e))
    # Cross-key invariants -----------------------------------------------------
    if not errors:
        try:
            start = int(mapping["HOST_PORT_RANGE_START"])
            end = int(mapping["HOST_PORT_RANGE_END"])
            if end < start:
                errors.append(
                    "HOST_PORT_RANGE_END must be >= HOST_PORT_RANGE_START"
                )
        except ValueError:
            pass  # already reported by per-key validation
        flag_re = mapping["FLAG_REGEX"]
        flag_lit = mapping["FLAG_FORMAT_LITERAL"]
        if "<text>" not in flag_lit:
            errors.append(
                "FLAG_FORMAT_LITERAL must contain the substring '<text>'"
            )
        else:
            sample = flag_lit.replace("<text>", "EXAMPLE_FLAG")
            try:
                if not re.fullmatch(flag_re, sample):
                    errors.append(
                        f"FLAG_FORMAT_LITERAL inconsistent with FLAG_REGEX: "
                        f"sample {sample!r} does not match {flag_re!r}"
                    )
                # Stringency floor: reject obviously permissive regexes that
                # would let any string be accepted as a flag. A real CTF flag
                # regex MUST reject the empty string and a single character.
                if re.fullmatch(flag_re, "") or re.fullmatch(flag_re, "a"):
                    errors.append(
                        f"FLAG_REGEX {flag_re!r} is too permissive: must reject "
                        "empty string and single-character input"
                    )
            except re.error:
                pass  # already reported by per-key validation
    # Forbid extra keys that would poison process environment when loaded by
    # docker-compose --env-file or python-dotenv (LD_PRELOAD, PYTHONPATH, ...).
    for k in mapping:
        if k in REQUIRED_KEYS:
            continue
        for pat in _FORBIDDEN_EXTRA_KEY_PATTERNS:
            if pat.match(k):
                errors.append(
                    f"extra key {k!r} matches forbidden pattern "
                    f"{pat.pattern!r} (would poison process environment)"
                )
                break
    if errors:
        raise ValueError(
            "validation failed:\n  - " + "\n  - ".join(errors)
        )


def _validate_key(key: str, value: str) -> None:
    if not _KEY_RE.match(key):
        raise ValueError(f"invalid key name: {key!r}")
    # Per-key rules. Each branch raises ValueError with the key name in the message.
    if key == "CTF_EVENT_NAME":
        if not value:
            raise ValueError("CTF_EVENT_NAME must be non-empty")
        if not _EVENT_NAME_RE.match(value):
            raise ValueError(
                f"CTF_EVENT_NAME {value!r} must match ^[A-Za-z0-9._-]+$"
            )
    elif key == "CTF_EVENT_LONG_NAME":
        if not value:
            raise ValueError("CTF_EVENT_LONG_NAME must be non-empty")
    elif key == "FLAG_REGEX":
        try:
            re.compile(value)
        except re.error as e:
            raise ValueError(f"FLAG_REGEX does not compile as Python regex: {e}") from e
    elif key == "FLAG_FORMAT_LITERAL":
        if not value:
            raise ValueError("FLAG_FORMAT_LITERAL must be non-empty")
        # The cross-key match against FLAG_REGEX is checked in validate().
    elif key == "FLAG_TYPE":
        if value not in FLAG_TYPE_ENUM:
            raise ValueError(
                f"FLAG_TYPE {value!r} not in enum {list(FLAG_TYPE_ENUM)}"
            )
    elif key in BOOL_KEYS:
        if value.lower() not in ("true", "false"):
            raise ValueError(
                f"{key} must be literal 'true' or 'false', got {value!r}"
            )
    elif key == "AUTHOR_NAME":
        # MAY be empty per spec — per-developer override is opt-in. When set,
        # restrict to a safe charset to prevent injection into challenge.yml or
        # downstream shell-using tools.
        if value and not re.fullmatch(r"[\w .+\-]{1,128}", value):
            raise ValueError(
                f"AUTHOR_NAME {value!r} must match [\\w .+\\-]{{1,128}} "
                "(letters, digits, space, dot, plus, hyphen, underscore)"
            )
    elif key == "AUTHOR_EMAIL":
        if value:
            # Conservative subset of RFC-5322: no shell metacharacters, NUL,
            # newlines, angle brackets, quotes, or backticks.
            if not re.fullmatch(
                r"[A-Za-z0-9._%+\-]{1,64}@[A-Za-z0-9.\-]{1,253}", value
            ):
                raise ValueError(
                    f"AUTHOR_EMAIL {value!r} must be a plain RFC-5322-lite "
                    "address (no shell metacharacters, no quotes)"
                )
    elif key in ("CATEGORIES", "DIFFICULTIES"):
        tokens = [t.strip() for t in value.split(",")] if value else []
        if not tokens or tokens == [""]:
            raise ValueError(f"{key} must be a non-empty comma-separated list")
        for t in tokens:
            if not _LOWER_TOKEN_RE.match(t):
                raise ValueError(
                    f"{key} token {t!r} must match ^[a-z]+$ (lowercase only)"
                )
        if key == "CATEGORIES" and "web" not in tokens:
            raise ValueError("CATEGORIES must contain at least 'web'")
    elif key in ("HOST_PORT_RANGE_START", "HOST_PORT_RANGE_END"):
        try:
            port = int(value)
        except ValueError as e:
            raise ValueError(f"{key} must be an integer, got {value!r}") from e
        if not (PORT_MIN <= port <= PORT_MAX):
            raise ValueError(
                f"{key}={port} must be in [{PORT_MIN}, {PORT_MAX}]"
            )
    elif key in LOCALE_KEYS:
        if not _LOCALE_RE.match(value):
            raise ValueError(
                f"{key} {value!r} must match BCP-47 form ^[a-z]{{2,3}}(-[A-Z][a-z]{{3}})?(-[A-Z]{{2}})?$"
            )
    # Unknown REQUIRED_KEYS would be a programmer error — validate() iterates
    # REQUIRED_KEYS so we cannot reach here for unknown keys.


# === Public write API ========================================================


def write(
    path: Path,
    mapping: dict[str, str],
    *,
    force: bool = False,
) -> None:
    """Persist `mapping` to `path` as dotenv. Validates the schema first.

    Refuses to overwrite an existing file unless `force=True`.
    Boolean values are normalized to lowercase on write.

    Atomic write semantics: writes to a uniquely-named tempfile in the same
    directory, then `os.replace`s onto the target. On any exception the
    tempfile is cleaned up; the target either reflects the new content
    completely or remains untouched.
    """
    if not isinstance(path, (str, os.PathLike)):
        raise TypeError(
            f"write(path, mapping): path must be str|PathLike, "
            f"got {type(path).__name__}; did you swap arguments?"
        )
    if not isinstance(mapping, dict):
        raise TypeError(
            f"write(path, mapping): mapping must be dict, "
            f"got {type(mapping).__name__}; did you swap arguments?"
        )
    p = Path(path)
    if p.exists() and not force:
        raise FileExistsError(
            f"{p} already exists; pass force=True to overwrite"
        )
    normalized = normalize_for_write(mapping)
    validate(normalized)
    text = render(normalized)

    # tempfile.NamedTemporaryFile: unique name avoids stomping on stale `.tmp`
    # files left by previous interrupted runs. delete=False because we want to
    # outlive the context manager and replace the target atomically.
    tmp_path: Path | None = None
    try:
        with tempfile.NamedTemporaryFile(
            mode="w",
            encoding="utf-8",
            dir=p.parent,
            prefix=p.name + ".",
            suffix=".tmp",
            delete=False,
        ) as fh:
            tmp_path = Path(fh.name)
            fh.write(text)
        os.replace(tmp_path, p)
        tmp_path = None  # success — target now owns the bytes
    finally:
        if tmp_path is not None and tmp_path.exists():
            tmp_path.unlink()


def normalize_for_write(mapping: dict[str, str]) -> dict[str, str]:
    """Public: return a copy with BOOL_KEYS lowercased and stripped, and any
    other values coerced to `str`. Caller may pass non-string-typed values
    (e.g. int from a YAML loader) safely.
    """
    out: dict[str, str] = {k: str(v) for k, v in mapping.items()}
    for k in BOOL_KEYS:
        if k in out:
            out[k] = out[k].strip().lower()
    return out


# Backward-compat alias — internal callers historically used the underscore name.
_normalize_for_write = normalize_for_write


def render(mapping: dict[str, str]) -> str:
    """Render the mapping as a sectioned dotenv file. Required keys are emitted
    in five labeled sections; additional unknown keys (custom author keys) are
    appended verbatim under a final section so that round-trip preserves them.
    """
    sections: list[tuple[str, Iterable[str]]] = [
        ("Event identity", ("CTF_EVENT_NAME", "CTF_EVENT_LONG_NAME")),
        ("Flag", (
            "FLAG_REGEX",
            "FLAG_FORMAT_LITERAL",
            "FLAG_TYPE",
            "FLAG_ASSET_VERSION_CONTROLLED",
        )),
        ("Author (per-developer override)", ("AUTHOR_NAME", "AUTHOR_EMAIL")),
        ("Categories / Difficulty enums", ("CATEGORIES", "DIFFICULTIES")),
        ("Port allocation", ("HOST_PORT_RANGE_START", "HOST_PORT_RANGE_END")),
        ("Locale / Content rules", (
            "PLAYER_FACING_LOCALE",
            "SPEC_LOCALE",
            "BLOCK_PRC_VOCAB",
            "ENFORCE_ANTI_AI_SLOP",
        )),
    ]
    lines: list[str] = []
    emitted: set[str] = set()
    for header, keys in sections:
        lines.append(f"# === {header} ===")
        for k in keys:
            lines.append(f"{k}={_quote_if_needed(mapping[k])}")
            emitted.add(k)
        lines.append("")
    extras = [k for k in mapping if k not in emitted]
    if extras:
        lines.append("# === Custom author keys ===")
        for k in extras:
            lines.append(f"{k}={_quote_if_needed(mapping[k])}")
        lines.append("")
    return "\n".join(lines).rstrip("\n") + "\n"


# Backward-compat alias — internal callers historically used the underscore name.
_render = render


def _quote_if_needed(value: str) -> str:
    """Wrap value in single quotes when it contains shell-special characters
    or whitespace; otherwise emit bare. Single quotes preserve backslashes
    literally, which matters for FLAG_REGEX.
    """
    if value == "":
        return ""
    if re.fullmatch(r"[A-Za-z0-9._:/=,@+-]+", value):
        return value
    # Use single quotes; values containing single quotes themselves are not
    # expected in the documented schema, so we don't try to escape them.
    if "'" in value:
        # Fall back to double quotes; backslashes in regex still survive because
        # the parser uses shlex which handles standard escapes.
        return '"' + value.replace('"', '\\"') + '"'
    return f"'{value}'"
