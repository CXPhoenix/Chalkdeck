"""Docker / docker-compose orchestration helpers used by analyzer + tests."""

from __future__ import annotations

import shutil
import subprocess
import time
from contextlib import contextmanager
from pathlib import Path


def docker_available() -> bool:
    return shutil.which("docker") is not None


def compose_up(src_dir: Path, *, project: str = "webchall") -> None:
    cmd = ["docker", "compose", "-f", str(src_dir / "docker-compose.yml"),
           "-p", project, "up", "-d", "--build"]
    subprocess.check_call(cmd)


def compose_down(src_dir: Path, *, project: str = "webchall") -> None:
    cmd = ["docker", "compose", "-f", str(src_dir / "docker-compose.yml"),
           "-p", project, "down", "-v"]
    subprocess.call(cmd)


@contextmanager
def compose_session(src_dir: Path, *, project: str = "webchall"):
    """Bring up docker-compose for the duration of a `with` block.

    `compose_up` runs INSIDE the try-block so a build failure still triggers
    `compose_down` (which would otherwise leak partially-built containers).
    `compose_down` uses `subprocess.check_call` so a teardown failure is
    visible — silently leaving the per-user instance running with the flag
    mounted defeats the per-challenge isolation invariant.
    """
    try:
        compose_up(src_dir, project=project)
        yield
    finally:
        cmd = ["docker", "compose", "-f", str(src_dir / "docker-compose.yml"),
               "-p", project, "down", "-v"]
        subprocess.check_call(cmd)


def wait_for_port(host: str, port: int, *, timeout: float = 15.0) -> bool:
    import socket
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        try:
            with socket.create_connection((host, port), timeout=1.0):
                return True
        except OSError:
            time.sleep(0.5)
    return False
