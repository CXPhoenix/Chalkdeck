"""Report formatters for analyzer / validator output."""

from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field
from typing import Iterable


VALID_SEVERITIES = ("error", "warning", "advisory")


@dataclass
class Finding:
    rule: str
    severity: str  # "error" | "warning" | "advisory"
    location: str
    summary: str
    detail: str = ""
    extra: dict = field(default_factory=dict)

    def __post_init__(self) -> None:
        if self.severity not in VALID_SEVERITIES:
            raise ValueError(
                f"Finding.severity must be one of {VALID_SEVERITIES}; "
                f"got {self.severity!r} (rule={self.rule!r})"
            )


def to_json(findings: Iterable[Finding]) -> str:
    return json.dumps([asdict(f) for f in findings], indent=2, ensure_ascii=False)


def to_sarif(findings: Iterable[Finding], tool_name: str = "webchall-master") -> str:
    sev_map = {"error": "error", "warning": "warning", "advisory": "note"}
    results = []
    rules: dict[str, dict] = {}
    for f in findings:
        rules.setdefault(
            f.rule,
            {
                "id": f.rule,
                "shortDescription": {"text": f.rule},
                "defaultConfiguration": {"level": sev_map.get(f.severity, "note")},
            },
        )
        results.append(
            {
                "ruleId": f.rule,
                "level": sev_map.get(f.severity, "note"),
                "message": {"text": f"{f.summary}: {f.detail}".strip(": ")},
                "locations": [
                    {"physicalLocation": {"artifactLocation": {"uri": f.location}}}
                ],
            }
        )
    sarif = {
        "$schema": "https://json.schemastore.org/sarif-2.1.0",
        "version": "2.1.0",
        "runs": [
            {
                "tool": {
                    "driver": {
                        "name": tool_name,
                        "rules": list(rules.values()),
                    }
                },
                "results": results,
            }
        ],
    }
    return json.dumps(sarif, indent=2, ensure_ascii=False)


def to_pretty(findings: Iterable[Finding]) -> str:
    findings = list(findings)
    if not findings:
        return "no findings.\n"
    sev_glyph = {"error": "✗", "warning": "⚠", "advisory": "ℹ"}
    lines = []
    for f in findings:
        glyph = sev_glyph.get(f.severity, "·")
        lines.append(f"{glyph} [{f.severity:7}] {f.rule}: {f.summary}")
        lines.append(f"    @ {f.location}")
        if f.detail:
            lines.append(f"      {f.detail}")
    return "\n".join(lines) + "\n"
