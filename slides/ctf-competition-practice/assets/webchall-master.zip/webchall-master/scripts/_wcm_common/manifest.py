"""Manifest read/write API for `.webchall.manifest.yaml`."""

from __future__ import annotations

import datetime as _dt
from pathlib import Path
from typing import Any

import yaml

from . import (
    DEFAULT_FLAG_REGEX,
    MANIFEST_NAME,
    MANIFEST_SCHEMA_VERSION,
    PIPELINE_STAGES,
    SUPPORTED_STACKS,
)


class ManifestError(Exception):
    """Raised when manifest schema is invalid."""


def manifest_path(challenge_dir: Path) -> Path:
    return Path(challenge_dir) / MANIFEST_NAME


def seed(
    challenge_dir: Path,
    *,
    slug: str,
    stack: str,
    recipe_id: str,
    vulnerability_class: str,
    difficulty: str = "medium",
    flag_regex: str = DEFAULT_FLAG_REGEX,
    canonical_flag: str = "FLAG{REPLACE_ME_BEFORE_SHIPPING}",
    concept_refs: list[str] | None = None,
) -> dict[str, Any]:
    """Create a fresh manifest with all required fields populated."""
    if stack not in SUPPORTED_STACKS:
        raise ManifestError(f"unsupported stack: {stack}")
    data: dict[str, Any] = {
        "schema_version": MANIFEST_SCHEMA_VERSION,
        "slug": slug,
        "stack": stack,
        "recipe_id": recipe_id,
        "vulnerability_class": vulnerability_class,
        "difficulty": difficulty,
        "concept_refs": list(concept_refs or []),
        "flag_regex": flag_regex,
        "canonical_flag": canonical_flag,
        "stages": {s: {"complete": False, "completed_at": None} for s in PIPELINE_STAGES},
        "audit_log": [],
        "created_at": _dt.date.today().isoformat(),
    }
    save(challenge_dir, data)
    return data


def load(challenge_dir: Path) -> dict[str, Any]:
    p = manifest_path(challenge_dir)
    if not p.exists():
        raise ManifestError(f"manifest not found at {p}")
    with p.open("r", encoding="utf-8") as f:
        data = yaml.safe_load(f) or {}
    _validate(data)
    return data


def save(challenge_dir: Path, data: dict[str, Any]) -> None:
    _validate(data)
    p = manifest_path(challenge_dir)
    p.parent.mkdir(parents=True, exist_ok=True)
    with p.open("w", encoding="utf-8") as f:
        yaml.safe_dump(data, f, sort_keys=False, allow_unicode=True)


def mark_stage_complete(challenge_dir: Path, stage: str) -> dict[str, Any]:
    if stage not in PIPELINE_STAGES:
        raise ManifestError(f"unknown stage: {stage}")
    data = load(challenge_dir)
    # Predecessor enforcement: every earlier stage MUST already be complete.
    # The skill spec demands "refuse to advance to stage N+1 until stage N has
    # produced its declared output". Without this, a caller can mark stage 5
    # complete while stages 1-4 are still pending.
    idx = PIPELINE_STAGES.index(stage)
    for predecessor in PIPELINE_STAGES[:idx]:
        if not data["stages"].get(predecessor, {}).get("complete"):
            raise ManifestError(
                f"cannot mark stage '{stage}' complete: predecessor "
                f"'{predecessor}' is not complete yet"
            )
    last_audit = next(
        (a for a in reversed(data.get("audit_log", [])) if a.get("stage") == stage),
        None,
    )
    if last_audit is None or last_audit.get("verdict") == "fail":
        raise ManifestError(
            f"cannot mark stage '{stage}' complete: needs a non-fail audit verdict first"
        )
    data["stages"][stage] = {
        "complete": True,
        "completed_at": _dt.datetime.utcnow().isoformat(timespec="seconds") + "Z",
    }
    save(challenge_dir, data)
    return data


def append_audit_verdict(
    challenge_dir: Path, stage: str, verdict: str, *, note: str = ""
) -> dict[str, Any]:
    if stage not in PIPELINE_STAGES:
        raise ManifestError(f"unknown stage: {stage}")
    if verdict not in {"pass", "advisory", "fail"}:
        raise ManifestError(f"verdict must be pass | advisory | fail, got {verdict}")
    data = load(challenge_dir)
    data.setdefault("audit_log", []).append(
        {
            "stage": stage,
            "verdict": verdict,
            "at": _dt.datetime.utcnow().isoformat(timespec="seconds") + "Z",
            "note": note,
        }
    )
    save(challenge_dir, data)
    return data


def first_incomplete_stage(challenge_dir: Path) -> str | None:
    data = load(challenge_dir)
    stages = data.get("stages") or {}
    # Refuse to interpret a manifest whose `stages` dict is missing keys; an
    # empty/partial dict would otherwise loop zero times and falsely report
    # "all complete". This is the most dangerous misread possible.
    missing = set(PIPELINE_STAGES) - set(stages.keys())
    if missing:
        raise ManifestError(
            f"manifest's `stages` is missing keys for {sorted(missing)}; "
            "refusing to interpret as 'all complete'"
        )
    for s in PIPELINE_STAGES:
        if not stages.get(s, {}).get("complete"):
            return s
    return None


def _validate(data: dict[str, Any]) -> None:
    required = {"schema_version", "slug", "stack", "recipe_id", "stages", "canonical_flag"}
    missing = required - data.keys()
    if missing:
        raise ManifestError(f"manifest missing required fields: {sorted(missing)}")
    if data["schema_version"] != MANIFEST_SCHEMA_VERSION:
        raise ManifestError(
            f"manifest schema_version is {data['schema_version']!r}; "
            f"expected {MANIFEST_SCHEMA_VERSION!r}"
        )
    if data["stack"] not in SUPPORTED_STACKS:
        raise ManifestError(f"unsupported stack in manifest: {data['stack']}")
