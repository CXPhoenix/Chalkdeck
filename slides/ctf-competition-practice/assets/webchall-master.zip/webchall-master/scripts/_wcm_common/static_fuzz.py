"""Static AST + grep-based per-framework sink detection."""

from __future__ import annotations

import ast
import re
from pathlib import Path

from .reporters import Finding


# Python regex / AST passes ---------------------------------------------------

PY_DANGEROUS_CALLS = {
    "render_template_string",  # Flask SSTI
    "pickle.loads", "loads", "dumps_loads",  # generic pickle
    "yaml.load",  # without SafeLoader
    "eval", "exec", "compile",
    "subprocess.call", "subprocess.run",
    "os.system",
    "os.popen",
}


def _python_ast(src_path: Path) -> list[Finding]:
    findings: list[Finding] = []
    try:
        tree = ast.parse(src_path.read_text(encoding="utf-8"))
    except (SyntaxError, UnicodeDecodeError):
        return findings
    for node in ast.walk(tree):
        if isinstance(node, ast.Call):
            name = _call_name(node.func)
            if name in PY_DANGEROUS_CALLS:
                findings.append(
                    Finding(
                        rule="static_python_sink",
                        severity="warning",
                        location=f"{src_path}:{getattr(node, 'lineno', 0)}",
                        summary=f"call to {name}() — confirm input is not user-controlled",
                    )
                )
            if name == "render_template_string":
                findings.append(
                    Finding(
                        rule="ssti",
                        severity="error" if _has_user_input_arg(node) else "advisory",
                        location=f"{src_path}:{node.lineno}",
                        summary="render_template_string with user input — Flask SSTI",
                    )
                )
            if name in {"pickle.loads", "loads"} and _has_user_input_arg(node):
                findings.append(
                    Finding(
                        rule="deserialization",
                        severity="error",
                        location=f"{src_path}:{node.lineno}",
                        summary="pickle.loads on user input — Python deserialization RCE",
                    )
                )
        if isinstance(node, ast.Call):
            # FastAPI JWT misuse: jwt.decode(..., verify_signature=False) or
            # algorithms=["none"].
            if _call_name(node.func) in {"jwt.decode", "decode"}:
                for kw in node.keywords:
                    if kw.arg == "verify_signature":
                        if isinstance(kw.value, ast.Constant) and kw.value.value is False:
                            findings.append(
                                Finding(
                                    rule="jwt_misuse",
                                    severity="error",
                                    location=f"{src_path}:{node.lineno}",
                                    summary="jwt.decode(verify_signature=False)",
                                )
                            )
                    if kw.arg == "algorithms":
                        if isinstance(kw.value, (ast.List, ast.Tuple)):
                            for item in kw.value.elts:
                                if isinstance(item, ast.Constant) and str(item.value).lower() == "none":
                                    findings.append(
                                        Finding(
                                            rule="jwt_misuse",
                                            severity="error",
                                            location=f"{src_path}:{node.lineno}",
                                            summary="jwt.decode algorithms includes 'none'",
                                        )
                                    )
    return findings


def _call_name(node: ast.AST) -> str:
    if isinstance(node, ast.Name):
        return node.id
    if isinstance(node, ast.Attribute):
        parent = _call_name(node.value)
        return f"{parent}.{node.attr}" if parent else node.attr
    return ""


def _has_user_input_arg(node: ast.Call) -> bool:
    """Heuristic: any arg that mentions request.* or req.body/etc."""
    src = ast.unparse(node)
    return bool(re.search(r"\b(request\.|req\.body|req\.query|req\.params|req\.json)", src))


# PHP grep passes -------------------------------------------------------------

PHP_PATTERNS = [
    # Plain unserialize that ultimately reads from $_GET/$_POST/$_REQUEST/$_COOKIE,
    # possibly through a wrapper like base64_decode().
    ("deserialization-php",
     r"\bunserialize\s*\([^)]*\$_(GET|POST|REQUEST|COOKIE)"),
    # phar:// metadata-deserialization sinks — any of these functions will
    # auto-deserialize phar metadata when invoked on a phar:// stream wrapper
    # path. Reading from a request superglobal is the canonical CTF trigger.
    ("deserialization-php",
     r"\b(file_exists|is_file|is_dir|fopen|file|file_get_contents|filesize|filectime|fileatime|filemtime|stat|md5_file|sha1_file)\s*\(\s*\$_(GET|POST|REQUEST|COOKIE)"),
    ("lfi", r"\b(include|require)(_once)?\s*\(?\s*[^;]*\$_(GET|POST|REQUEST)"),
    ("eval", r"\beval\s*\([^)]*\$_(GET|POST|REQUEST|COOKIE)"),
    ("assert", r"\bassert\s*\([^)]*\$_(GET|POST|REQUEST|COOKIE)"),
    ("command-injection",
     r"\b(system|shell_exec|passthru|exec)\s*\([^)]*\$_(GET|POST|REQUEST|COOKIE)"),
    ("extract-request", r"\bextract\s*\(\s*\$_REQUEST"),
]


def _php(src_path: Path) -> list[Finding]:
    findings: list[Finding] = []
    text = src_path.read_text(encoding="utf-8", errors="replace")
    for rule, pat in PHP_PATTERNS:
        for m in re.finditer(pat, text):
            line = text[: m.start()].count("\n") + 1
            findings.append(
                Finding(
                    rule=rule,
                    severity="error",
                    location=f"{src_path}:{line}",
                    summary=f"PHP sink: {m.group(0)!r}",
                )
            )
    return findings


# JavaScript grep passes ------------------------------------------------------

JS_PATTERNS = [
    # Direct Object.assign into request body.
    ("prototype-pollution",
     r"Object\.assign\s*\(\s*\{\s*\}\s*,\s*req\.(body|query|params)"),
    # Custom merge() / extend() / deepMerge() that recurses through unchecked
    # source-object keys — heuristic: a function body that walks `for (... in src)`
    # and assigns target[k] from src[k]. Matched at the call-site when the call
    # passes `req.body|query|params` directly.
    ("prototype-pollution",
     r"\b(merge|extend|deepMerge|defaultsDeep|set)\s*\(\s*\w+\s*,\s*req\.(body|query|params)"),
    ("vm-eval", r"vm\.runInThisContext\s*\("),
    ("eval", r"\beval\s*\(\s*req\."),
    ("command-injection",
     r"child_process\.(exec|execSync)\s*\(\s*[`'\"]?[^)]*\$\{?(req\.|body\.)"),
    ("nosqli", r"\.find(One)?\s*\(\s*req\.(body|query|params)\)"),
]


def _js(src_path: Path) -> list[Finding]:
    findings: list[Finding] = []
    text = src_path.read_text(encoding="utf-8", errors="replace")
    for rule, pat in JS_PATTERNS:
        for m in re.finditer(pat, text):
            line = text[: m.start()].count("\n") + 1
            findings.append(
                Finding(
                    rule=rule,
                    severity="warning",
                    location=f"{src_path}:{line}",
                    summary=f"Node.js sink: {m.group(0)!r}",
                )
            )
    return findings


# Web server config passes ----------------------------------------------------

NGINX_PATTERNS = [
    ("nginx-alias-no-trailing-slash",
     r"location\s+(/[^\s{]+)\s*\{[^}]*alias\s+([^;]+);",
     "alias directive without trailing slash on location can enable off-by-slash traversal"),
]


def _nginx_conf(src_path: Path) -> list[Finding]:
    text = src_path.read_text(encoding="utf-8", errors="replace")
    findings: list[Finding] = []
    for rule, pat, hint in NGINX_PATTERNS:
        for m in re.finditer(pat, text, re.DOTALL):
            location_path = m.group(1)
            alias_path = m.group(2).strip()
            if not location_path.endswith("/") and not alias_path.endswith("/"):
                line = text[: m.start()].count("\n") + 1
                findings.append(
                    Finding(
                        rule=rule,
                        severity="warning",
                        location=f"{src_path}:{line}",
                        summary=f"location {location_path} alias {alias_path} — {hint}",
                    )
                )
    return findings


APACHE_PATTERNS = [
    ("apache-addhandler-userdir", r"AddHandler\s+php\d?-script\s+\.ph",
     "AddHandler over user-writable dirs enables web-shell upload"),
    ("apache-multiviews-on", r"\bOptions[^\n]*MultiViews\b",
     "MultiViews enabled — content negotiation can leak source"),
]


def _apache_conf(src_path: Path) -> list[Finding]:
    text = src_path.read_text(encoding="utf-8", errors="replace")
    findings: list[Finding] = []
    for rule, pat, hint in APACHE_PATTERNS:
        for m in re.finditer(pat, text):
            line = text[: m.start()].count("\n") + 1
            findings.append(
                Finding(
                    rule=rule,
                    severity="warning",
                    location=f"{src_path}:{line}",
                    summary=f"Apache config: {hint}",
                )
            )
    return findings


# Public entry point ----------------------------------------------------------

def analyze_static(src_dir: Path) -> list[Finding]:
    findings: list[Finding] = []
    for p in src_dir.rglob("*"):
        if not p.is_file():
            continue
        s = p.suffix.lower()
        if s == ".py":
            findings.extend(_python_ast(p))
        elif s == ".php":
            findings.extend(_php(p))
        elif s in {".js", ".mjs", ".ts"}:
            findings.extend(_js(p))
        elif p.name == "nginx.conf" or (s == ".conf" and "nginx" in p.name):
            findings.extend(_nginx_conf(p))
        elif (
            p.name in {"httpd.conf", "apache.conf", ".htaccess"}
            or (s == ".conf" and ("apache" in p.name or "httpd" in p.name))
        ):
            findings.extend(_apache_conf(p))
    return findings
