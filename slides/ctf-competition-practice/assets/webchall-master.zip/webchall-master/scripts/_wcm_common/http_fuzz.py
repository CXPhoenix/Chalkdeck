"""Runtime HTTP fuzz harness — boots the challenge container and probes endpoints."""

from __future__ import annotations

import time
from pathlib import Path
from typing import Iterable

from . import wordlists
from .reporters import Finding


def _http_get(url: str, timeout: float = 5.0) -> tuple[int, bytes, float]:
    import urllib.request
    t0 = time.monotonic()
    try:
        with urllib.request.urlopen(url, timeout=timeout) as r:
            body = r.read()
            return r.status, body, time.monotonic() - t0
    except Exception:
        return 0, b"", time.monotonic() - t0


def _http_post(url: str, data: bytes, timeout: float = 5.0,
               content_type: str = "application/x-www-form-urlencoded") -> tuple[int, bytes, float]:
    import urllib.request
    t0 = time.monotonic()
    req = urllib.request.Request(url, data=data,
                                 headers={"Content-Type": content_type})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            body = r.read()
            return r.status, body, time.monotonic() - t0
    except Exception:
        return 0, b"", time.monotonic() - t0


def baseline(target: str) -> tuple[int, int, float]:
    status, body, elapsed = _http_get(target)
    return status, len(body), elapsed


def fuzz_paths(target: str, paths: Iterable[str] | None = None,
               threshold_bytes: int = 32, threshold_ms: int = 250) -> list[Finding]:
    """Walk a path wordlist; flag responses whose status / length / latency
    differ meaningfully from the baseline."""
    paths = list(paths or wordlists.DIRBUSTER_TOP)
    base_status, base_len, base_elapsed = baseline(target)
    findings: list[Finding] = []
    for path in paths:
        url = target.rstrip("/") + "/" + path.lstrip("/")
        status, body, elapsed = _http_get(url)
        delta_len = abs(len(body) - base_len)
        delta_ms = abs(elapsed - base_elapsed) * 1000
        signal_score = (
            (status != base_status) +
            (delta_len >= threshold_bytes) +
            (delta_ms >= threshold_ms)
        )
        if signal_score >= 2:
            findings.append(
                Finding(
                    rule="http_fuzz_path",
                    severity="warning",
                    location=url,
                    summary=f"anomalous response (status={status}, +{delta_len}B, +{delta_ms:.0f}ms)",
                )
            )
    return findings


def fuzz_ssti_markers(target: str) -> list[Finding]:
    """POST SSTI marker payloads to root and look for evaluation."""
    import urllib.parse
    findings: list[Finding] = []
    base_status, base_len, _ = baseline(target)
    for payload in wordlists.SSTI_MARKERS:
        body = urllib.parse.urlencode({"msg": payload}).encode()
        status, response, _ = _http_post(target, body)
        if status == 0:
            continue
        # If payload is `{{7*7}}` and response contains literal "49" not present
        # in the baseline, that's a strong SSTI signal.
        if b"49" in response and payload == "{{7*7}}":
            findings.append(
                Finding(
                    rule="ssti-runtime",
                    severity="error",
                    location=target,
                    summary=f"SSTI marker {payload!r} evaluated server-side",
                    detail=f"response contains '49' (HTTP {status})",
                )
            )
    return findings


def discover_routes(src_dir: Path) -> list[str]:
    """Best-effort route discovery from source files (Flask @app.route, FastAPI
    @app.get, Express app.METHOD)."""
    import re
    routes: set[str] = {"/"}
    for p in src_dir.rglob("*"):
        if not p.is_file():
            continue
        s = p.suffix.lower()
        if s == ".py":
            text = p.read_text(encoding="utf-8", errors="replace")
            for m in re.finditer(r'@\w+\.(?:route|get|post|put|delete|patch)\s*\(\s*["\']([^"\']+)', text):
                routes.add(m.group(1))
        elif s in {".js", ".mjs", ".ts"}:
            text = p.read_text(encoding="utf-8", errors="replace")
            for m in re.finditer(r'app\.(?:get|post|put|delete|patch|all)\s*\(\s*["\']([^"\']+)', text):
                routes.add(m.group(1))
        elif s == ".php":
            text = p.read_text(encoding="utf-8", errors="replace")
            # Naive: every .php file under www/ is a route.
            if "/www/" in str(p):
                routes.add("/" + p.name)
    return sorted(routes)
