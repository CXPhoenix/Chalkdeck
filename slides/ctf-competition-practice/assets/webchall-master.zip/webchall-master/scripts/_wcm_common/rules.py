"""Hard validation rules for webchall_validate.py."""

from __future__ import annotations

import re
import subprocess
from pathlib import Path
from typing import Callable

import yaml

from . import DEFAULT_FLAG_REGEX, default_flag_regex
from . import manifest as manifest_lib
from . import rules_env as _rules_env
from .reporters import Finding


RuleFn = Callable[[Path, dict], list[Finding]]


def rule_challenge_yml_present(challenge: Path, mfst: dict) -> list[Finding]:
    if not (challenge / "challenge.yml").exists():
        return [Finding(rule="challenge_yml_present", severity="error",
                        location=str(challenge / "challenge.yml"),
                        summary="challenge.yml is missing")]
    return []


CTFCLI_REQUIRED = ("name", "author", "category", "description", "value", "type",
                   "version", "flags")


def rule_challenge_yml_schema(challenge: Path, mfst: dict) -> list[Finding]:
    p = challenge / "challenge.yml"
    if not p.exists():
        return []
    try:
        data = yaml.safe_load(p.read_text(encoding="utf-8")) or {}
    except yaml.YAMLError as e:
        return [Finding(rule="challenge_yml_schema", severity="error",
                        location=str(p), summary=f"YAML parse error: {e}")]
    findings = []
    for f in CTFCLI_REQUIRED:
        if f not in data:
            findings.append(Finding(rule="challenge_yml_schema", severity="error",
                                    location=str(p),
                                    summary=f"missing required field {f!r}"))
    if "value" in data and not (isinstance(data["value"], int) and data["value"] > 0):
        findings.append(Finding(rule="challenge_yml_schema", severity="error",
                                location=str(p),
                                summary="value must be positive integer"))
    if "flags" in data and not data["flags"]:
        findings.append(Finding(rule="challenge_yml_schema", severity="error",
                                location=str(p), summary="flags list is empty"))
    return findings


PLACEHOLDER_FLAG = "FLAG{REPLACE_ME_BEFORE_SHIPPING}"


def rule_flag_format(challenge: Path, mfst: dict) -> list[Finding]:
    # Three-layer lookup: manifest's per-challenge override wins; otherwise
    # consult `.rules.env` at cwd; otherwise fall back to the hardcoded literal.
    rx = mfst.get("flag_regex") or default_flag_regex()
    canonical = mfst.get("canonical_flag", "")
    findings: list[Finding] = []
    # Use fullmatch — re.match anchors only at start, allowing trailing junk
    # like "FLAG{ok}; rm -rf ~" to pass.
    if not re.fullmatch(rx, canonical):
        findings.append(Finding(rule="flag_format", severity="error",
                                location=str(challenge / ".webchall.manifest.yaml"),
                                summary=f"canonical_flag {canonical!r} does not fully match {rx!r}"))
    if canonical == PLACEHOLDER_FLAG:
        findings.append(Finding(rule="flag_format", severity="error",
                                location=str(challenge / ".webchall.manifest.yaml"),
                                summary="canonical_flag is the placeholder sentinel — set a real flag before publish"))
    return findings


def rule_dual_dockerfile_present(challenge: Path, mfst: dict) -> list[Finding]:
    findings = []
    if not (challenge / "src" / "Dockerfile").exists():
        findings.append(Finding(rule="dual_dockerfile_present", severity="error",
                                location=str(challenge / "src" / "Dockerfile"),
                                summary="single Dockerfile (per-user instance form) missing"))
    if not (challenge / "src" / "docker-compose.yml").exists():
        findings.append(Finding(rule="dual_dockerfile_present", severity="error",
                                location=str(challenge / "src" / "docker-compose.yml"),
                                summary="docker-compose.yml (post-event redeploy form) missing"))
    return findings


def rule_src_publish_split(challenge: Path, mfst: dict) -> list[Finding]:
    findings = []
    for sub in ("src", "publish", "solution"):
        if not (challenge / sub).exists():
            findings.append(Finding(rule="src_publish_split", severity="error",
                                    location=str(challenge / sub),
                                    summary=f"required directory {sub}/ missing"))
    if (challenge / "publish" / "solve.py").exists():
        findings.append(Finding(rule="src_publish_split", severity="error",
                                location=str(challenge / "publish" / "solve.py"),
                                summary="solve.py leaked into publish/"))
    if (challenge / "publish" / "solution").exists():
        findings.append(Finding(rule="src_publish_split", severity="error",
                                location=str(challenge / "publish" / "solution"),
                                summary="solution/ directory leaked into publish/"))
    return findings


_BINARY_SUFFIXES = {".zip", ".tar", ".tgz", ".gz", ".bz2", ".xz", ".7z",
                    ".rar", ".jar", ".war", ".pyc", ".pyo", ".so", ".dylib",
                    ".dll", ".exe", ".class"}


def _flag_needles(canonical: str) -> list[tuple[str, bytes]]:
    """Build a list of (form-name, byte-needle) tuples covering common encodings
    of the canonical flag. CTF authors frequently leak flags via base64'd or
    hex-encoded blobs in static assets — pure literal-byte match misses these."""
    import base64
    import binascii
    import urllib.parse as _u

    raw = canonical.encode("utf-8")
    needles: list[tuple[str, bytes]] = [
        ("literal", raw),
        ("base64", base64.b64encode(raw).rstrip(b"=")),
        ("base32", base64.b32encode(raw).rstrip(b"=")),
        ("hex-lower", binascii.hexlify(raw)),
        ("hex-upper", binascii.hexlify(raw).upper()),
        ("urlencoded", _u.quote(canonical, safe="").encode("ascii")),
        ("html-entity", _u.quote_plus(canonical).encode("ascii")),
    ]
    # Reverse-byte (poor-man's obfuscation occasionally seen).
    needles.append(("reversed", raw[::-1]))
    # Drop any duplicates / very short (<6 bytes — too noisy).
    seen = set()
    out = []
    for name, n in needles:
        if len(n) < 6:
            continue
        if n in seen:
            continue
        seen.add(n)
        out.append((name, n))
    return out


def rule_flag_not_in_publish(challenge: Path, mfst: dict) -> list[Finding]:
    canonical = mfst.get("canonical_flag", "")
    if canonical == PLACEHOLDER_FLAG:
        # rule_flag_format already errors on the placeholder. Emit an explicit
        # advisory here too so the leak-scan being skipped is visible to any
        # downstream consumer that disables rule_flag_format.
        return [Finding(rule="flag_not_in_publish", severity="advisory",
                        location=str(challenge / ".webchall.manifest.yaml"),
                        summary="publish leak scan skipped: canonical_flag is the placeholder")]
    if not canonical:
        return [Finding(rule="flag_not_in_publish", severity="error",
                        location=str(challenge / ".webchall.manifest.yaml"),
                        summary="canonical_flag is empty — refuse to certify publish/")]
    pub = challenge / "publish"
    if not pub.exists():
        return []
    needles = _flag_needles(canonical)
    findings = []
    for f in pub.rglob("*"):
        if not f.is_file():
            continue
        # Binary archives can hide a flag inside member files; refuse-on-suspicion.
        if f.suffix.lower() in _BINARY_SUFFIXES:
            findings.append(Finding(
                rule="flag_not_in_publish",
                severity="error",
                location=str(f),
                summary=f"binary archive {f.name} cannot be flag-scanned reliably; "
                        "either move to src-only or unpack into source files",
            ))
            continue
        try:
            data = f.read_bytes()
        except OSError:
            continue
        for form, needle in needles:
            if needle in data:
                findings.append(Finding(
                    rule="flag_not_in_publish",
                    severity="error",
                    location=str(f),
                    summary=f"canonical flag value found ({form} encoding) in publish tree",
                ))
                break
    return findings


def rule_readmes_present(challenge: Path, mfst: dict) -> list[Finding]:
    findings = []
    for name in ("README.author.md", "README.player.md"):
        p = challenge / name
        if not p.exists() or p.stat().st_size == 0:
            findings.append(Finding(rule="readmes_present", severity="error",
                                    location=str(p),
                                    summary=f"{name} missing or empty"))
    return findings


def rule_manifest_wiki_refs_resolve(challenge: Path, mfst: dict) -> list[Finding]:
    skill_dir = Path(__file__).resolve().parent.parent.parent
    wiki_dir = skill_dir / "wiki"
    findings = []
    recipe = mfst.get("recipe_id")
    if recipe and not (wiki_dir / "recipes" / f"{recipe}.md").exists():
        findings.append(Finding(rule="manifest_wiki_refs_resolve", severity="error",
                                location=str(challenge / ".webchall.manifest.yaml"),
                                summary=f"recipe_id {recipe!r} not found in wiki/recipes/"))
    # concept_refs may use either bare ids ("ssti") or prefixed paths
    # ("concepts/ssti", "frameworks/flask"). Resolve each against its declared
    # category, falling back to concepts/ for bare ids.
    safe_name = re.compile(r"^[a-z0-9][a-z0-9-]*[a-z0-9]$")
    wiki_resolved = wiki_dir.resolve()
    for c in mfst.get("concept_refs", []) or []:
        if "/" in c:
            sub, name = c.split("/", 1)
        else:
            sub, name = "concepts", c
        if sub not in {"concepts", "frameworks", "cves", "recipes", "taxonomies"}:
            findings.append(Finding(rule="manifest_wiki_refs_resolve", severity="error",
                                    location=str(challenge / ".webchall.manifest.yaml"),
                                    summary=f"concept_ref {c!r} has unknown category prefix"))
            continue
        if not safe_name.match(name):
            findings.append(Finding(rule="manifest_wiki_refs_resolve", severity="error",
                                    location=str(challenge / ".webchall.manifest.yaml"),
                                    summary=f"concept_ref {c!r} name segment fails kebab-case check"))
            continue
        candidate = (wiki_dir / sub / f"{name}.md").resolve()
        if not str(candidate).startswith(str(wiki_resolved) + "/"):
            findings.append(Finding(rule="manifest_wiki_refs_resolve", severity="error",
                                    location=str(challenge / ".webchall.manifest.yaml"),
                                    summary=f"concept_ref {c!r} resolves outside wiki/"))
            continue
        if not candidate.exists():
            findings.append(Finding(rule="manifest_wiki_refs_resolve", severity="error",
                                    location=str(challenge / ".webchall.manifest.yaml"),
                                    summary=f"concept_ref {c!r} not found at wiki/{sub}/{name}.md"))
    return findings


def rule_healthcheck_passes(challenge: Path, mfst: dict) -> list[Finding]:
    """Runtime probe — only meaningful when the container is up. Skipped here
    by default; the analyzer's runtime phase exercises this. We at least
    confirm the script exists and is executable."""
    p = challenge / "src" / "healthcheck.sh"
    if not p.exists():
        return [Finding(rule="healthcheck_passes", severity="error",
                        location=str(p),
                        summary="healthcheck.sh missing under src/")]
    if not p.stat().st_mode & 0o111:
        return [Finding(rule="healthcheck_passes", severity="warning",
                        location=str(p),
                        summary="healthcheck.sh exists but is not executable")]
    return []


def rule_solver_recovers_flag(challenge: Path, mfst: dict) -> list[Finding]:
    """Static check only — confirm solve.py exists. Full end-to-end runs are the
    responsibility of stage-7 publish verification, behind --runtime."""
    p = challenge / "solution" / "solve.py"
    if not p.exists():
        return [Finding(rule="solver_recovers_flag", severity="error",
                        location=str(p),
                        summary="solution/solve.py missing")]
    return []


def rule_author_not_placeholder(challenge: Path, mfst: dict) -> list[Finding]:
    """challenge.yml's `author` field MUST NOT be the literal placeholder
    `TODO`. Authors are expected to set AUTHOR_NAME / AUTHOR_EMAIL in
    `.rules.env` (or override per challenge) before validate.
    """
    p = challenge / "challenge.yml"
    if not p.exists():
        return []
    try:
        data = yaml.safe_load(p.read_text(encoding="utf-8")) or {}
    except yaml.YAMLError:
        return []
    author = data.get("author")
    if author in (None, "", "TODO"):
        return [Finding(
            rule="author_not_placeholder", severity="error",
            location=str(p),
            summary=(
                f"author={author!r} is empty/placeholder; set AUTHOR_NAME and "
                "AUTHOR_EMAIL in .rules.env or override in challenge.yml before publish"
            ),
        )]
    return []


def rule_category_in_enum(challenge: Path, mfst: dict) -> list[Finding]:
    """challenge.yml's `category` MUST be a member of the event-level
    CATEGORIES enum declared in `.rules.env`. When `.rules.env` is absent
    (archived challenge), this rule is silently skipped — see the spec
    `Tooling MUST treat .rules.env as the source of truth` and the
    fallback semantics for downstream scripts.
    """
    raw = _rules_env.get("CATEGORIES")
    if not raw:
        return []  # archived challenge or .rules.env absent — skip
    allowed = [t.strip() for t in raw.split(",") if t.strip()]
    p = challenge / "challenge.yml"
    if not p.exists():
        return []
    try:
        data = yaml.safe_load(p.read_text(encoding="utf-8")) or {}
    except yaml.YAMLError:
        return []  # other rules report YAML errors; we don't double-report
    cat = data.get("category")
    if cat is None:
        return []
    if cat not in allowed:
        return [Finding(
            rule="category_in_enum", severity="error",
            location=str(p),
            summary=f"category {cat!r} not in .rules.env CATEGORIES {allowed!r}",
        )]
    return []


ALL_RULES: dict[str, RuleFn] = {
    "challenge_yml_present": rule_challenge_yml_present,
    "challenge_yml_schema": rule_challenge_yml_schema,
    "flag_format": rule_flag_format,
    "dual_dockerfile_present": rule_dual_dockerfile_present,
    "src_publish_split": rule_src_publish_split,
    "flag_not_in_publish": rule_flag_not_in_publish,
    "healthcheck_passes": rule_healthcheck_passes,
    "solver_recovers_flag": rule_solver_recovers_flag,
    "manifest_wiki_refs_resolve": rule_manifest_wiki_refs_resolve,
    "readmes_present": rule_readmes_present,
    "category_in_enum": rule_category_in_enum,
    "author_not_placeholder": rule_author_not_placeholder,
}


def run_all(challenge: Path) -> list[Finding]:
    try:
        mfst = manifest_lib.load(challenge)
    except manifest_lib.ManifestError as e:
        return [Finding(rule="manifest_present", severity="error",
                        location=str(challenge),
                        summary=str(e))]
    findings: list[Finding] = []
    for name, fn in ALL_RULES.items():
        # Each rule is isolated in its own try/except so one rule's bug does
        # not silently skip every subsequent rule. A raised exception is
        # itself a finding.
        try:
            findings.extend(fn(challenge, mfst))
        except Exception as e:  # pragma: no cover — defense in depth
            findings.append(Finding(
                rule=name,
                severity="error",
                location=str(challenge),
                summary=f"rule {name!r} raised {type(e).__name__}: {e}",
            ))
    return findings
