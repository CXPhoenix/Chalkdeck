#!/usr/bin/env python3
"""webchall_init — bootstrap a challenge from a stack template + wiki recipe.

Usage:
  webchall_init.py --stack <flask|fastapi|...> --recipe <id> --slug <name>
                   [--difficulty easy|medium|hard] [--force]
"""

from __future__ import annotations

import argparse
import re
import shutil
import sys
from pathlib import Path

SLUG_RE = re.compile(r"^[a-z][a-z0-9-]{0,63}$")

sys.path.insert(0, str(Path(__file__).parent))
from _wcm_common import SUPPORTED_STACKS  # noqa: E402
from _wcm_common import manifest as manifest_lib  # noqa: E402
from _wcm_common import rules_env  # noqa: E402
from _wcm_common import wiki as wiki_lib  # noqa: E402


SKILL_DIR = Path(__file__).resolve().parent.parent
TEMPLATES = SKILL_DIR / "templates"
WIKI = SKILL_DIR / "wiki"


def _author_from_rules_env() -> str:
    """Compose the challenge.yml `author` field from `.rules.env` keys.

    Returns `'Name <email>'` when both are set, just one when partial,
    or the literal `TODO` placeholder when neither is supplied. The
    placeholder preserves prior behavior for events whose authors have
    not yet filled in their identity in `.rules.env`.
    """
    name = (rules_env.get("AUTHOR_NAME", fallback="") or "").strip()
    email = (rules_env.get("AUTHOR_EMAIL", fallback="") or "").strip()
    if name and email:
        return f"{name} <{email}>"
    if name:
        return name
    if email:
        return email
    return "TODO"


def _check_rules_env_precondition() -> int:
    """Stage 1 entry gate: `.rules.env` MUST exist at cwd and parse cleanly.

    Returns 0 if OK, 2 if missing or malformed (the documented exit code).
    Spec: `webchall-master` — Skill MUST verify `.rules.env` precondition
    before Stage 1.
    """
    rules_path = Path.cwd() / rules_env.DEFAULT_FILENAME
    if not rules_path.exists():
        bootstrap_cmd = (
            f"python {Path(__file__).parent / 'webchall_bootstrap.py'}"
        )
        print(
            f".rules.env not found at {Path.cwd()}; "
            f"run 'webchall init-event' first ({bootstrap_cmd})",
            file=sys.stderr,
        )
        return 2
    try:
        parsed = rules_env.load(rules_path)
    except ValueError as e:
        print(f".rules.env at {rules_path} is malformed: {e}", file=sys.stderr)
        return 2
    try:
        rules_env.validate(rules_env.normalize_for_write(parsed))
    except ValueError as e:
        print(f".rules.env at {rules_path} failed validation: {e}",
              file=sys.stderr)
        return 2
    return 0


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(prog="webchall_init", description=__doc__)
    p.add_argument("--stack", required=True, choices=list(SUPPORTED_STACKS))
    p.add_argument("--recipe", required=True, help="recipe id from wiki/recipes/")
    p.add_argument("--slug", required=True, help="kebab-case challenge slug")
    p.add_argument("--difficulty", default="medium",
                   choices=["easy", "medium", "hard"])
    p.add_argument("--out", type=Path, default=Path.cwd(),
                   help="parent directory for the new <slug>/ tree")
    p.add_argument("--force", action="store_true",
                   help="overwrite existing <slug>/ if non-empty")
    args = p.parse_args(argv)

    # Precondition gate runs AFTER argparse so that `--help` and `--version`
    # short-circuit with status 0 (per webchall-tooling spec: "each invocation
    # MUST exit with status 0 and print a usage banner").
    rc = _check_rules_env_precondition()
    if rc != 0:
        return rc

    if not SLUG_RE.match(args.slug):
        print(f"refusing: --slug must match {SLUG_RE.pattern} (got {args.slug!r})",
              file=sys.stderr)
        return 1
    out_dir = Path(args.out).resolve()
    target = (out_dir / args.slug).resolve()
    if not str(target).startswith(str(out_dir) + "/"):
        print(f"refusing: target {target} escapes --out {out_dir}", file=sys.stderr)
        return 1
    if target.exists() and any(target.iterdir()) and not args.force:
        print(f"refusing to overwrite non-empty {target}; pass --force to override",
              file=sys.stderr)
        return 1

    recipe_path = WIKI / "recipes" / f"{args.recipe}.md"
    if not recipe_path.exists():
        print(f"unknown recipe: {args.recipe}", file=sys.stderr)
        return 1
    recipe = wiki_lib.parse(recipe_path)
    vuln_class = recipe.frontmatter.get("vulnerability_class", "unknown")
    concept_refs = recipe.frontmatter.get("concept_refs", []) or []

    template_dir = TEMPLATES / args.stack
    if not template_dir.exists():
        print(f"missing template for stack {args.stack}: {template_dir}", file=sys.stderr)
        return 1

    target.mkdir(parents=True, exist_ok=True)
    src_dst = target / "src"
    if src_dst.exists():
        shutil.rmtree(src_dst)
    shutil.copytree(template_dir / "src", src_dst)
    (target / "publish").mkdir(exist_ok=True)
    (target / "solution").mkdir(exist_ok=True)
    (target / "adapters").mkdir(exist_ok=True)

    # Move solution out of src/ — it must NOT ship in publish/.
    src_sol = src_dst / "solution"
    if src_sol.exists():
        for f in src_sol.iterdir():
            shutil.move(str(f), target / "solution" / f.name)
        src_sol.rmdir()

    title = args.slug.replace("-", " ").title()
    author_str = _author_from_rules_env()
    # Placeholder challenge.yml (CTFd ctfcli format). Author edits during stage 4;
    # publisher consumes and emits adapters during stage 7.
    import yaml as _yaml
    chall = {
        "name": title,
        "author": author_str,
        "category": "web",
        "description": f"{title} — see README.player.md",
        "attribution": "webchall-master",
        "value": 100,
        "type": "standard",
        "version": "0.1",
        "image": ".",
        "protocol": "http",
        "host": "127.0.0.1",
        "flags": ["FLAG{REPLACE_ME_BEFORE_SHIPPING}"],
        "topics": [vuln_class],
        "tags": ["web", args.stack],
    }
    (target / "challenge.yml").write_text(
        _yaml.safe_dump(chall, sort_keys=False), encoding="utf-8"
    )
    (target / "README.author.md").write_text(
        f"# {title} — author notes\n\n"
        f"- Stack: {args.stack}\n"
        f"- Recipe: {args.recipe}\n"
        f"- Vulnerability class: {vuln_class}\n"
        f"- Difficulty: {args.difficulty}\n\n"
        "Replace this file with the intended exploit narrative.\n",
        encoding="utf-8",
    )
    (target / "README.player.md").write_text(
        f"# {title}\n\n"
        f"Category: web · Difficulty: {args.difficulty}\n\n"
        "Find the flag.\n\n"
        "Flag format: `FLAG{...}`\n",
        encoding="utf-8",
    )

    from _wcm_common import DEFAULT_FLAG_REGEX
    flag_regex = rules_env.get("FLAG_REGEX", fallback=DEFAULT_FLAG_REGEX)
    manifest_lib.seed(
        target,
        slug=args.slug,
        stack=args.stack,
        recipe_id=args.recipe,
        vulnerability_class=vuln_class,
        difficulty=args.difficulty,
        flag_regex=flag_regex,
        concept_refs=concept_refs,
    )

    print(f"✓ scaffolded {target}")
    print(f"  recipe: {args.recipe} (concepts: {', '.join(concept_refs) or 'none'})")
    print(f"  TODO:   set canonical_flag in .webchall.manifest.yaml AND src/flag.txt")
    print(f"          before publish — the placeholder MUST NOT ship.")
    print(f"  next:   author src/, write solution/solve.py, then run analyze + validate")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
