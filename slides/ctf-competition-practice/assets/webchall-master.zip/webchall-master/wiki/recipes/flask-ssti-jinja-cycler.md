---
id: flask-ssti-jinja-cycler
title: Flask SSTI via Jinja `cycler` gadget
type: recipe
stack: flask
vulnerability_class: ssti
difficulty: easy
last_compiled: 2026-05-03
concept_refs:
  - concepts/ssti
  - concepts/template-engines
  - frameworks/flask
cve_refs:
  - cves/cve-2024-34069-werkzeug-debugger
sources:
  - raw/ctftime-writeups/lit-ctf-2025-group-chat.md
---

Vulnerable surface: A route renders user input via
`render_template_string`. The intended exploit chains through the
`cycler.__init__.__globals__.os.popen('cat /flag').read()` gadget.

Recommended difficulty: easy → medium (depending on filter strictness).

Plant: ensure /flag is readable by the Flask process. Add a token-gating
layer for medium difficulty.
