---
id: flask-nginx-path-mismatch
title: Flask + nginx path normalization mismatch
type: recipe
stack: flask
vulnerability_class: auth-bypass
difficulty: medium
last_compiled: 2026-05-03
concept_refs:
  - concepts/path-traversal
  - frameworks/flask
  - frameworks/nginx
cve_refs:
  - cves/cve-2024-24990-nginx-http3-uaf
sources:
  - raw/ctftime-writeups/qnqsec-ctf-2025-airspeed.md
---

nginx blocks `/admin` but Flask treats `/admin\x85` (or other Unicode
control chars) identically to `/admin`. Player must discover the
normalization mismatch then chain to a sink behind the gate.
