---
id: nginx-alias-off-by-slash
title: nginx alias off-by-slash path traversal
type: recipe
stack: static-nginx
vulnerability_class: path-traversal
difficulty: easy
last_compiled: 2026-05-03
concept_refs:
  - concepts/path-traversal
  - frameworks/nginx
  - concepts/info-disclosure
cve_refs:
  - cves/cve-2025-23419-nginx-ssl-session
sources:
  - raw/portswigger-all-topics.md
---

Config: `location /static { alias /var/www/static; }` (missing trailing
slash on location). Request `/static../flag.txt` resolves to
`/var/www/static../flag.txt` = `/var/www/flag.txt` (out-of-bounds read).
