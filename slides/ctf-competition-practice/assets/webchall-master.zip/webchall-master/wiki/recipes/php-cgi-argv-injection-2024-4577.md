---
id: php-cgi-argv-injection-2024-4577
title: PHP-CGI argv injection (CVE-2024-4577)
type: recipe
stack: php
vulnerability_class: command-injection
difficulty: easy
last_compiled: 2026-05-03
concept_refs:
  - concepts/command-injection
  - frameworks/php
cve_refs:
  - cves/cve-2024-4577-php-cgi-argv-injection
sources:
  - raw/cve-advisories/cve-2024-4577-php-cgi-argv-injection.md
---

Container runs PHP-CGI on Windows-equivalent CGI mode. Player crafts a
URL with the specific Unicode codepoint that smuggles `-d` directives,
enabling auto_prepend_file to RCE.
