---
id: php-phar-deserialize
title: PHP phar:// deserialization
type: recipe
stack: php
vulnerability_class: deserialization-php
difficulty: medium
last_compiled: 2026-05-03
concept_refs:
  - concepts/deserialization-php
  - concepts/lfi
  - frameworks/php
cve_refs:
  - cves/cve-2025-49113-roundcube-deserialize
sources:
  - raw/ctftime-writeups/n1ctf-2018-easy-php.md
  - raw/cve-advisories/cve-2025-49113-roundcube-deserialize.md
---

Vulnerable code calls `file_exists($user_path)` on attacker-controlled
path. Player uploads a polyglot .phar to a public dir, then accesses
`phar://path/to/file.phar/test`, triggering metadata unserialize and a
`__destruct`/`__wakeup` gadget chain to RCE.
