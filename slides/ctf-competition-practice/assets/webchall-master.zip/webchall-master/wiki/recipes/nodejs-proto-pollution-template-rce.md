---
id: nodejs-proto-pollution-template-rce
title: Node.js prototype pollution → template RCE
type: recipe
stack: nodejs-express
vulnerability_class: prototype-pollution
difficulty: hard
last_compiled: 2026-05-03
concept_refs:
  - concepts/prototype-pollution
  - concepts/deserialization-nodejs
  - frameworks/nodejs-express
cve_refs:
  - cves/proto-pollution-2024-chain
sources:
  - raw/ctftime-writeups/securitymb-2021-prototype-pollution-rce.md
  - raw/cve-advisories/proto-pollution-2024-chain.md
---

Two compatible variants ship under this recipe id. The bundled
`templates/nodejs-express/src/app.js` demonstrates the **simpler auth-bypass
variant**: a deep-merge utility honors `__proto__`, attacker submits
`{"__proto__":{"isAdmin":true}}` to `POST /merge`, every fresh `{}` then
inherits `isAdmin=true`, and `GET /flag` returns the flag.

The **template-RCE variant** (described in
`raw/ctftime-writeups/securitymb-2021-prototype-pollution-rce.md`) extends
the same primitive: combined with a templating engine that compiles its AST
and reads attacker-pollutable fields during compile (e.g., Pug, Handlebars
with EJS templates), attacker pollutes a node-property used by the compile
step and triggers a render to land arbitrary JS execution. To upgrade the
shipped template into the RCE variant, swap the `app.js` for one that calls
a vulnerable templating engine on user input.
