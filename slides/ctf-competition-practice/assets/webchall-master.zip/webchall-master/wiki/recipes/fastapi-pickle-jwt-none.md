---
id: fastapi-pickle-jwt-none
title: FastAPI pickle session + JWT alg=none
type: recipe
stack: fastapi
vulnerability_class: deserialization-python
difficulty: medium
last_compiled: 2026-05-03
concept_refs:
  - concepts/deserialization-python
  - concepts/jwt
  - frameworks/fastapi
cve_refs:
  - cves/cve-2024-47874-starlette-multipart
sources:
  - raw/cve-advisories/cve-2024-47874-starlette-multipart.md
---

Server stores session as pickled blob in JWT body; signature check uses
`algorithms=["none","HS256"]`. Player crafts JWT with `alg=none` and a
pickle payload that runs on deserialization.
