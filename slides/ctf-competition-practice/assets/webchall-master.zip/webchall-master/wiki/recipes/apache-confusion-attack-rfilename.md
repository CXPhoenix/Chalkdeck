---
id: apache-confusion-attack-rfilename
title: Apache Confusion Attack on r->filename
type: recipe
stack: php-apache
vulnerability_class: command-injection
difficulty: hard
last_compiled: 2026-05-03
concept_refs:
  - concepts/command-injection
  - concepts/file-upload
  - frameworks/apache
  - frameworks/php
cve_refs:
  - cves/cve-2024-38474-apache-mod-rewrite-substitution
sources:
  - raw/cve-advisories/cve-2024-38474-apache-mod-rewrite-substitution.md
---

Apache config has a benign-looking RewriteRule. Player exploits Orange
Tsai's r->filename ambiguity: substitution-encoding lets the URL reach
a CGI handler in a directory the operator believed unreachable.
