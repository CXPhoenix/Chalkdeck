---
id: nodejs-nosqli-mongo-bypass
title: Node.js NoSQL injection auth bypass
type: recipe
stack: nodejs-express
vulnerability_class: nosqli
difficulty: easy
last_compiled: 2026-05-03
concept_refs:
  - concepts/nosqli
  - concepts/auth-bypass
  - frameworks/nodejs-express
cve_refs:
  - cves/cve-2024-29041-express-open-redirect
sources:
  - raw/ctftime-writeups/nn8ed-tindermon-nodejs-nosqli.md
---

Login endpoint passes raw `req.body` to a Mongoose `findOne`. Player
submits `{"username": "admin", "password": {"$ne": null}}` as JSON to
bypass auth. Variant uses Unicode parsing inconsistency for blind extract.
