---
id: owasp-api-top10-2023
title: OWASP API Security Top 10 — 2023
type: taxonomy
last_compiled: 2026-05-03
sources:
  - raw/owasp-api-top10-2023.md
---

## API1 Broken Object Level Authorization (BOLA)
- Related: [bola](../concepts/bola.md)

## API2 Broken Authentication
- Related: [auth-bypass](../concepts/auth-bypass.md), [jwt](../concepts/jwt.md), [oauth](../concepts/oauth.md)

## API3 Broken Object Property Level Authorization
- Related: [bopla](../concepts/bopla.md), [mass-assignment](../concepts/mass-assignment.md)

## API4 Unrestricted Resource Consumption
- Related: [business-logic](../concepts/business-logic.md), [race-condition](../concepts/race-condition.md)

## API5 Broken Function Level Authorization
- Related: [access-control](../concepts/access-control.md)

## API6 Unrestricted Access to Sensitive Business Flows
- Related: [business-logic](../concepts/business-logic.md)

## API7 Server-Side Request Forgery (SSRF)
- Related: [ssrf](../concepts/ssrf.md)

## API8 Security Misconfiguration
- Related: [info-disclosure](../concepts/info-disclosure.md), [cors](../concepts/cors.md)

## API9 Improper Inventory Management
- Related: [info-disclosure](../concepts/info-disclosure.md)

## API10 Unsafe Consumption of APIs
- Related: [ssrf](../concepts/ssrf.md), [deserialization-python](../concepts/deserialization-python.md)
