---
id: owasp-top10-2017
title: OWASP Top 10 — 2017
type: taxonomy
last_compiled: 2026-05-03
sources:
  - raw/owasp-top10-2017.md
---

## A1 Injection
- Related: [sqli](../concepts/sqli.md), [command-injection](../concepts/command-injection.md), [ssti](../concepts/ssti.md)

## A2 Broken Authentication
- Related: [auth-bypass](../concepts/auth-bypass.md), [jwt](../concepts/jwt.md)

## A3 Sensitive Data Exposure
- Related: [info-disclosure](../concepts/info-disclosure.md)

## A4 XML External Entities (XXE)
- Related: [xxe](../concepts/xxe.md)

## A5 Broken Access Control
- Related: [access-control](../concepts/access-control.md), [bola](../concepts/bola.md)

## A6 Security Misconfiguration
- Related: [info-disclosure](../concepts/info-disclosure.md)

## A7 Cross-Site Scripting (XSS)
- Related: [xss](../concepts/xss.md), [dom-clobbering](../concepts/dom-clobbering.md)

## A8 Insecure Deserialization
- Related: [deserialization-php](../concepts/deserialization-php.md), [deserialization-python](../concepts/deserialization-python.md), [deserialization-nodejs](../concepts/deserialization-nodejs.md)

## A9 Using Components with Known Vulnerabilities
- Related: see [frameworks/](../frameworks/) and [cves/](../cves/) directories.

## A10 Insufficient Logging & Monitoring
- Related: [info-disclosure](../concepts/info-disclosure.md)
