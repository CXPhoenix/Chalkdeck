---
id: owasp-top10-2021
title: OWASP Top 10:2021
type: taxonomy
last_compiled: 2026-05-03
sources:
  - raw/owasp-top10-2021.md
---

## A01 Broken Access Control
- Related: [access-control](../concepts/access-control.md), [bola](../concepts/bola.md), [bopla](../concepts/bopla.md)

## A02 Cryptographic Failures
- Related: [jwt](../concepts/jwt.md)

## A03 Injection
- Related: [sqli](../concepts/sqli.md), [nosqli](../concepts/nosqli.md), [ssti](../concepts/ssti.md), [command-injection](../concepts/command-injection.md), [xss](../concepts/xss.md)

## A04 Insecure Design
- Related: [business-logic](../concepts/business-logic.md)

## A05 Security Misconfiguration
- Related: [info-disclosure](../concepts/info-disclosure.md), [cors](../concepts/cors.md)

## A06 Vulnerable and Outdated Components
- Related: [deserialization-php](../concepts/deserialization-php.md)

## A07 Identification and Authentication Failures
- Related: [auth-bypass](../concepts/auth-bypass.md), [jwt](../concepts/jwt.md), [oauth](../concepts/oauth.md)

## A08 Software and Data Integrity Failures
- Related: [deserialization-php](../concepts/deserialization-php.md), [deserialization-python](../concepts/deserialization-python.md), [deserialization-nodejs](../concepts/deserialization-nodejs.md), [prototype-pollution](../concepts/prototype-pollution.md)

## A09 Security Logging and Monitoring Failures
- Related: [info-disclosure](../concepts/info-disclosure.md)

## A10 Server-Side Request Forgery (SSRF)
- Related: [ssrf](../concepts/ssrf.md)
