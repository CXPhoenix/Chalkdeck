---
id: cwe-mapping
title: CWE → Concept Cross-Index
type: taxonomy
last_compiled: 2026-05-03
sources:
  - raw/owasp-top10-2025.md
---

## CWE → Concept

| CWE | Title | Concept |
|---|---|---|
| CWE-22 | Path Traversal | [path-traversal](../concepts/path-traversal.md) |
| CWE-77 | Command Injection (general) | [command-injection](../concepts/command-injection.md) |
| CWE-78 | OS Command Injection | [command-injection](../concepts/command-injection.md) |
| CWE-79 | XSS | [xss](../concepts/xss.md) |
| CWE-89 | SQL Injection | [sqli](../concepts/sqli.md) |
| CWE-91 | XML Injection | [xxe](../concepts/xxe.md) |
| CWE-94 | Code Injection | [ssti](../concepts/ssti.md) |
| CWE-352 | CSRF | [csrf](../concepts/csrf.md) |
| CWE-434 | Unrestricted File Upload | [file-upload](../concepts/file-upload.md) |
| CWE-502 | Deserialization of Untrusted Data | [deserialization-php](../concepts/deserialization-php.md), [deserialization-python](../concepts/deserialization-python.md), [deserialization-nodejs](../concepts/deserialization-nodejs.md) |
| CWE-611 | XXE | [xxe](../concepts/xxe.md) |
| CWE-639 | BOLA / IDOR | [bola](../concepts/bola.md) |
| CWE-862 | Missing Authorization | [access-control](../concepts/access-control.md) |
| CWE-915 | Improperly Restricted Property Modification (Mass Assignment) | [mass-assignment](../concepts/mass-assignment.md) |
| CWE-918 | SSRF | [ssrf](../concepts/ssrf.md) |
| CWE-943 | Improper Neutralization of Special Elements in Data Query Logic (NoSQLi) | [nosqli](../concepts/nosqli.md) |
| CWE-1023 | Web Cache Poisoning | [cache-poisoning](../concepts/cache-poisoning.md) |
| CWE-1275 | Sensitive Cookie | [auth-bypass](../concepts/auth-bypass.md) |
| CWE-1321 | Prototype Pollution | [prototype-pollution](../concepts/prototype-pollution.md) |
| CWE-1336 | Improper Neutralization of Special Elements Used in a Template Engine | [ssti](../concepts/ssti.md) |
| CWE-444 | HTTP Request Smuggling | [request-smuggling](../concepts/request-smuggling.md) |
| CWE-601 | Open Redirect | [info-disclosure](../concepts/info-disclosure.md) |
