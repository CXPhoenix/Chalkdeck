---
id: owasp-top10-2025
title: OWASP Top 10:2025 (Release Candidate)
type: taxonomy
last_compiled: 2026-05-03
sources:
  - raw/owasp-top10-2025.md
---

## A01:2025 Broken Access Control
- Related concepts: [access-control](../concepts/access-control.md), [bola](../concepts/bola.md), [bopla](../concepts/bopla.md), [auth-bypass](../concepts/auth-bypass.md)

## A02:2025 Security Misconfiguration
- Related concepts: [info-disclosure](../concepts/info-disclosure.md), [cors](../concepts/cors.md)

## A03:2025 Software Supply Chain Failures (NEW)
- Related concepts: [deserialization-php](../concepts/deserialization-php.md), [deserialization-python](../concepts/deserialization-python.md), [deserialization-nodejs](../concepts/deserialization-nodejs.md)

## A04:2025 Cryptographic Failures
- Related concepts: [jwt](../concepts/jwt.md), [oauth](../concepts/oauth.md)

## A05:2025 Injection
- Related concepts: [sqli](../concepts/sqli.md), [nosqli](../concepts/nosqli.md), [command-injection](../concepts/command-injection.md), [ssti](../concepts/ssti.md), [xss](../concepts/xss.md), [xxe](../concepts/xxe.md), [graphql](../concepts/graphql.md)

## A06:2025 Insecure Design
- Related concepts: [business-logic](../concepts/business-logic.md), [race-condition](../concepts/race-condition.md)

## A07:2025 Authentication Failures
- Related concepts: [auth-bypass](../concepts/auth-bypass.md), [jwt](../concepts/jwt.md), [oauth](../concepts/oauth.md)

## A08:2025 Software and Data Integrity Failures
- Related concepts: [deserialization-php](../concepts/deserialization-php.md), [deserialization-python](../concepts/deserialization-python.md), [deserialization-nodejs](../concepts/deserialization-nodejs.md), [prototype-pollution](../concepts/prototype-pollution.md)

## A09:2025 Security Logging and Alerting Failures
- Related concepts: [info-disclosure](../concepts/info-disclosure.md)

## A10:2025 Mishandling of Exceptional Conditions (NEW)
- Related concepts: [race-condition](../concepts/race-condition.md), [business-logic](../concepts/business-logic.md)
