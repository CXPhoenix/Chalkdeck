---
id: portswigger-academy
title: PortSwigger Web Security Academy — All 31 Topics
type: taxonomy
last_compiled: 2026-05-03
sources:
  - raw/portswigger-all-topics.md
---

## Server-side
- SQL injection → [sqli](../concepts/sqli.md)
- Authentication → [auth-bypass](../concepts/auth-bypass.md)
- Path traversal → [path-traversal](../concepts/path-traversal.md)
- Command injection → [command-injection](../concepts/command-injection.md)
- Business logic vulnerabilities → [business-logic](../concepts/business-logic.md)
- Information disclosure → [info-disclosure](../concepts/info-disclosure.md)
- Access control → [access-control](../concepts/access-control.md)
- File upload vulnerabilities → [file-upload](../concepts/file-upload.md)
- Race conditions → [race-condition](../concepts/race-condition.md)
- SSRF → [ssrf](../concepts/ssrf.md)
- XXE injection → [xxe](../concepts/xxe.md)
- NoSQL injection → [nosqli](../concepts/nosqli.md)
- API testing → [bola](../concepts/bola.md), [bopla](../concepts/bopla.md), [mass-assignment](../concepts/mass-assignment.md)
- Web cache deception → [cache-deception](../concepts/cache-deception.md)

## Client-side
- XSS → [xss](../concepts/xss.md)
- CSRF → [csrf](../concepts/csrf.md)
- CORS → [cors](../concepts/cors.md)
- Clickjacking → [clickjacking](../concepts/clickjacking.md)
- DOM-based vulnerabilities → [dom-clobbering](../concepts/dom-clobbering.md)
- WebSockets → [websockets](../concepts/websockets.md)

## Advanced
- Insecure deserialization → [deserialization-php](../concepts/deserialization-php.md), [deserialization-python](../concepts/deserialization-python.md), [deserialization-nodejs](../concepts/deserialization-nodejs.md)
- Web LLM attacks → [web-llm](../concepts/web-llm.md)
- GraphQL API vulnerabilities → [graphql](../concepts/graphql.md)
- Server-side template injection → [ssti](../concepts/ssti.md), [template-engines](../concepts/template-engines.md)
- Web cache poisoning → [cache-poisoning](../concepts/cache-poisoning.md)
- HTTP Host header attacks → [host-header](../concepts/host-header.md)
- HTTP request smuggling → [request-smuggling](../concepts/request-smuggling.md)
- OAuth authentication → [oauth](../concepts/oauth.md)
- JWT attacks → [jwt](../concepts/jwt.md)
- Prototype pollution → [prototype-pollution](../concepts/prototype-pollution.md)
- Essential skills → see frameworks/ pivot pages
