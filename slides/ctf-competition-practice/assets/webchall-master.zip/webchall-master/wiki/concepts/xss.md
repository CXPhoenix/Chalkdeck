---
id: xss
title: Cross-Site Scripting
type: concept
owasp:
  - A05:2025
  - A03:2021
  - A7:2017
portswigger: cross-site-scripting
cwe:
  - CWE-79
last_compiled: 2026-05-03
sources:
  - raw/portswigger-all-topics.md
related:
  - concepts/csrf
  - concepts/dom-clobbering
  - frameworks/flask
---

Reflected, stored, DOM-based, and self-XSS variants. Modern frameworks
auto-escape; XSS reappears via `|safe`, `dangerouslySetInnerHTML`,
`v-html`, JSON contexts in HTML, and SVG/MathML XSS gadgets.
