---
id: deserialization-nodejs
title: Insecure Deserialization (Node.js)
type: concept
owasp:
  - A03:2025
  - A08:2021
  - A8:2017
portswigger: insecure-deserialization
cwe:
  - CWE-502
last_compiled: 2026-05-03
sources:
  - raw/portswigger-all-topics.md
related:
  - concepts/prototype-pollution
  - frameworks/nodejs-express
---

`node-serialize` and `serialize-javascript` permit IIFE injection.
Modern Node deserialization more often surfaces via JSON.parse with
a reviver, or YAML loaders, combined with prototype pollution.
