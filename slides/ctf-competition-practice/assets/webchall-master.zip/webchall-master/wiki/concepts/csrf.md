---
id: csrf
title: Cross-Site Request Forgery
type: concept
owasp:
  - A01:2025
  - A07:2025
portswigger: cross-site-request-forgery
cwe:
  - CWE-352
last_compiled: 2026-05-03
sources:
  - raw/portswigger-all-topics.md
related:
  - concepts/cors
  - concepts/xss
---

Authenticated state-changing requests triggered by attacker-controlled
cross-site context. SameSite cookie defaults mitigate trivial CSRF;
remaining vectors include subdomain-confused cookie scoping, custom
content-type bypass, and CORS misconfiguration that elevates CSRF to
read access.
