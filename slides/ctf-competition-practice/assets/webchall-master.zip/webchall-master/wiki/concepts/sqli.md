---
id: sqli
title: SQL Injection
type: concept
owasp:
  - A05:2025
  - A03:2021
  - A1:2017
portswigger: sql-injection
cwe:
  - CWE-89
last_compiled: 2026-05-03
sources:
  - raw/portswigger-all-topics.md
related:
  - concepts/nosqli
  - concepts/access-control
  - concepts/auth-bypass
---

User input concatenated into a SQL string allows attackers to control the
query AST. UNION-based, error-based, blind boolean, blind time-based, and
stacked-query variants. Modern web stacks usually expose SQLi only when
authors bypass ORMs (raw `db.engine.execute`, `mysql_query`, `pg.query`).
