---
id: deserialization-php
title: Insecure Deserialization (PHP)
type: concept
owasp:
  - A03:2025
  - A08:2021
  - A8:2017
portswigger: insecure-deserialization
cwe:
  - CWE-502
last_compiled: 2026-05-03
sources:
  - raw/ctftime-writeups/n1ctf-2018-easy-php.md
  - raw/cve-advisories/cve-2025-49113-roundcube-deserialize.md
  - raw/ctftime-writeups/hitcon-2018-one-line-php.md
related:
  - concepts/lfi
  - frameworks/php
  - cves/cve-2025-49113-roundcube-deserialize
---

`unserialize($_GET[...])` or `phar://` metadata deserialization triggers
PHP object injection. `__destruct`, `__wakeup`, `__toString` magic
methods and chained gadgets reach `system`/`include`. Roundcube
CVE-2025-49113 demonstrates a fresh post-auth gadget chain.
