---
id: clickjacking
title: Clickjacking
type: concept
owasp:
  - A02:2025
portswigger: clickjacking
cwe:
  - CWE-1021
last_compiled: 2026-05-03
sources:
  - raw/portswigger-all-topics.md
related:
  - concepts/csrf
---

Iframe overlay tricks user into clicking sensitive controls. Defense
via X-Frame-Options or CSP frame-ancestors. Drag-and-drop variants
bypass naive defenses.
