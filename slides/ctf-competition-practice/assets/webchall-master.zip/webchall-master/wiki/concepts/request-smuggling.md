---
id: request-smuggling
title: HTTP Request Smuggling
type: concept
owasp:
  - A05:2025
portswigger: http-request-smuggling
cwe:
  - CWE-444
last_compiled: 2026-05-03
sources:
  - raw/portswigger-all-topics.md
  - raw/cve-advisories/cve-2023-25690-apache-hrs.md
related:
  - concepts/host-header
  - frameworks/nginx
  - frameworks/apache
---

Front-end and back-end disagree on Content-Length vs. Transfer-Encoding,
allowing prefix injection into the next user's request. CL.TE, TE.CL,
TE.TE variants. Modern variants use HTTP/2 downgrade for TE injection.
