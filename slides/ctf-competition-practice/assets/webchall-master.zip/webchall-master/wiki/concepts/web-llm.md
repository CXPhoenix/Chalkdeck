---
id: web-llm
title: Web LLM Attacks
type: concept
owasp:
  - A06:2025
portswigger: web-llm-attacks
cwe:
  - CWE-77
last_compiled: 2026-05-03
sources:
  - raw/portswigger-all-topics.md
related:
  - concepts/ssrf
  - concepts/info-disclosure
---

Prompt injection via API request, indirect prompt injection through
fetched documents, tool-use hijack, function-call schema confusion,
LLM-driven SSRF when LLM has fetch capability.
