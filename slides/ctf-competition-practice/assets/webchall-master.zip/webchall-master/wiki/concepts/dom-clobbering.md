---
id: dom-clobbering
title: DOM Clobbering
type: concept
owasp:
  - A05:2025
  - A03:2021
portswigger: dom-based-vulnerabilities
cwe:
  - CWE-1284
last_compiled: 2026-05-03
sources:
  - raw/portswigger-all-topics.md
related:
  - concepts/xss
---

Named HTML elements override window globals; `document.body.appendChild`
of attacker-named element clobbers a config object. Combined with
prototype pollution it gates client-side RCE.
