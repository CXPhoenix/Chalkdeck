---
id: access-control
title: Access Control
type: concept
owasp:
  - A01:2025
  - A01:2021
  - A5:2017
portswigger: access-control
cwe:
  - CWE-862
last_compiled: 2026-05-03
sources:
  - raw/portswigger-all-topics.md
related:
  - concepts/bola
  - concepts/auth-bypass
---

Vertical (privilege escalation) and horizontal (peer-data access)
access-control failures. Common surfaces: forced-browsing to admin
URLs, parameter-tampering, JWT/session reuse across roles.
