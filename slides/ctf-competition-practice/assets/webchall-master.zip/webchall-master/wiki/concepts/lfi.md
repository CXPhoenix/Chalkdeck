---
id: lfi
title: Local File Inclusion
type: concept
owasp:
  - A05:2025
  - A05:2021
portswigger: path-traversal
cwe:
  - CWE-22
  - CWE-98
last_compiled: 2026-05-03
sources:
  - raw/portswigger-all-topics.md
  - raw/ctftime-writeups/n1ctf-2018-easy-php.md
related:
  - concepts/path-traversal
  - frameworks/php
  - concepts/deserialization-php
---

`include` / `require` of attacker-controlled path. PHP wrappers
(`php://filter`, `phar://`, `zip://`, `data://`) escalate from file read
to code execution and deserialization gadgets.
