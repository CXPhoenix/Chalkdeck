---
id: bola
title: Broken Object Level Authorization (BOLA)
type: concept
owasp:
  - A01:2025
  - A01:2021
  - A5:2017
portswigger: access-control-vulnerabilities
cwe:
  - CWE-639
last_compiled: 2026-05-03
sources:
  - raw/owasp-api-top10-2023.md
related:
  - concepts/bopla
  - concepts/access-control
---

IDOR-like flaw in API endpoints: `GET /api/orders/123` returns any
user's order because the server only checks authentication, not whether
the order belongs to the authenticated user. The most prevalent API
vulnerability per OWASP API Top 10 2023.
