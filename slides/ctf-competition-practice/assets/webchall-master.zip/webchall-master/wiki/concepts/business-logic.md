---
id: business-logic
title: Business Logic Vulnerabilities
type: concept
owasp:
  - A06:2025
  - A04:2021
portswigger: business-logic-vulnerabilities
cwe:
  - CWE-840
last_compiled: 2026-05-03
sources:
  - raw/portswigger-all-topics.md
related:
  - concepts/race-condition
  - concepts/access-control
---

Application-specific flaws: negative-quantity checkout, currency
mixing, coupon-stacking, sequential-step skipping, role-promotion via
workflow corner cases.
