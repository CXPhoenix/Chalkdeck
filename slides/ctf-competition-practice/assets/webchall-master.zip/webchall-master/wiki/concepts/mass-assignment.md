---
id: mass-assignment
title: Mass Assignment
type: concept
owasp:
  - A01:2025
  - A04:2021
portswigger: api-testing
cwe:
  - CWE-915
last_compiled: 2026-05-03
sources:
  - raw/owasp-api-top10-2023.md
related:
  - concepts/bopla
  - concepts/access-control
---

`User.objects.create(**request.json)` style code lets attackers set
`is_admin=true` or `tenant_id=other`. Defense: explicit whitelist
(Pydantic strict models, Django Form fields enumerated).
