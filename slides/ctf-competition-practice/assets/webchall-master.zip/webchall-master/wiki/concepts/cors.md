---
id: cors
title: Cross-Origin Resource Sharing Misconfiguration
type: concept
owasp:
  - A02:2025
  - A05:2021
portswigger: cross-origin-resource-sharing
cwe:
  - CWE-942
last_compiled: 2026-05-03
sources:
  - raw/portswigger-all-topics.md
related:
  - concepts/csrf
  - concepts/info-disclosure
---

Reflecting `Origin` into `Access-Control-Allow-Origin` with
`Access-Control-Allow-Credentials: true` lets attacker pages read
authenticated responses. Wildcard subdomains, null origin, and
trust-on-first-use of arbitrary origins are common pitfalls.
