---
id: graphql
title: GraphQL API Vulnerabilities
type: concept
owasp:
  - A05:2025
  - A03:2021
portswigger: graphql-api-vulnerabilities
cwe:
  - CWE-209
last_compiled: 2026-05-03
sources:
  - raw/portswigger-all-topics.md
related:
  - concepts/info-disclosure
  - concepts/ssrf
---

Introspection enabled in production, deeply nested queries (DoS),
batching abuse, alias overloading, mutation field injection, IDOR via
hidden fields exposed by introspection.
