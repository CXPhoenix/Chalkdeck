---
id: xxe
title: XML External Entity Injection
type: concept
owasp:
  - A05:2025
  - A03:2021
  - A4:2017
portswigger: xxe-injection
cwe:
  - CWE-611
  - CWE-91
last_compiled: 2026-05-03
sources:
  - raw/portswigger-all-topics.md
  - raw/cve-advisories/cve-2024-34102-magento-xxe.md
related:
  - concepts/ssrf
  - concepts/info-disclosure
---

XML parsers that resolve external entities allow file read, SSRF, and
blind exfiltration via OOB DTDs. Variants on SOAP, SAML, and
office-document parsers are the modern surface.
