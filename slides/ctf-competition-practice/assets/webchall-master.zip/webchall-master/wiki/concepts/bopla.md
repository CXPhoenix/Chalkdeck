---
id: bopla
title: Broken Object Property Level Authorization (BOPLA)
type: concept
owasp:
  - A01:2025
portswigger: api-testing
cwe:
  - CWE-915
last_compiled: 2026-05-03
sources:
  - raw/owasp-api-top10-2023.md
related:
  - concepts/bola
  - concepts/mass-assignment
---

API exposes or accepts object properties without per-property checks.
Excessive Data Exposure (server returns sensitive fields the client
filters out) and Mass Assignment (client sets fields the server
should pin) are subcategories.
