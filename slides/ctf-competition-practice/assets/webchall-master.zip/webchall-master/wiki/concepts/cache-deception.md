---
id: cache-deception
title: Web Cache Deception
type: concept
owasp:
  - A02:2025
portswigger: web-cache-deception
cwe:
  - CWE-200
last_compiled: 2026-05-03
sources:
  - raw/portswigger-all-topics.md
related:
  - concepts/cache-poisoning
  - concepts/info-disclosure
---

Path-confusion between cache and origin: cache treats `/profile.css` as
static and caches it; origin treats it as `/profile` and returns
authenticated content. Public cache stores authenticated PII.
