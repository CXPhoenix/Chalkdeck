---
id: nosqli
title: NoSQL Injection
type: concept
owasp:
  - A05:2025
  - A03:2021
portswigger: nosql-injection
cwe:
  - CWE-943
last_compiled: 2026-05-03
sources:
  - raw/portswigger-all-topics.md
  - raw/ctftime-writeups/nn8ed-tindermon-nodejs-nosqli.md
related:
  - concepts/sqli
  - frameworks/nodejs-express
  - concepts/auth-bypass
---

MongoDB query operators (`$gt`, `$ne`, `$where`, `$regex`) accepted
directly from `req.body` allow auth bypass and exfiltration. JavaScript
`$where` clauses execute on the database; full-width Unicode parsing
differences yield bypass primitives in Node.js Mongo drivers.
