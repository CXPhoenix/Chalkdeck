---
id: path-traversal
title: Path Traversal
type: concept
owasp:
  - A05:2025
  - A01:2021
portswigger: path-traversal
cwe:
  - CWE-22
last_compiled: 2026-05-03
sources:
  - raw/portswigger-all-topics.md
  - raw/cve-advisories/cve-2024-49766-werkzeug-safejoin.md
related:
  - concepts/lfi
  - frameworks/nginx
---

`../` sequences, URL-encoded variants (`%2e%2e%2f`), null-byte truncation
(legacy), UNC paths on Windows. nginx alias misconfiguration enables
off-by-one path-traversal.
