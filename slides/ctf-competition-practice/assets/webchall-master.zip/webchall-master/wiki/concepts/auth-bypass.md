---
id: auth-bypass
title: Authentication Bypass
type: concept
owasp:
  - A07:2025
  - A07:2021
  - A2:2017
portswigger: authentication
cwe:
  - CWE-287
  - CWE-1275
last_compiled: 2026-05-03
sources:
  - raw/portswigger-all-topics.md
related:
  - concepts/jwt
  - concepts/oauth
  - concepts/access-control
---

SQLi in login, JWT `alg=none`, OAuth state-parameter omission, weak
password reset flows, brute-force without rate-limit, hardcoded
debug bypass cookies.
