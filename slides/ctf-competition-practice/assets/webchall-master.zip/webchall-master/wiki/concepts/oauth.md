---
id: oauth
title: OAuth Authentication Vulnerabilities
type: concept
owasp:
  - A07:2025
  - A07:2021
  - A2:2017
portswigger: oauth-authentication
cwe:
  - CWE-287
last_compiled: 2026-05-03
sources:
  - raw/portswigger-all-topics.md
related:
  - concepts/jwt
  - concepts/auth-bypass
---

Implicit-flow + access-token in URL fragment, redirect-uri whitelist
bypass, state parameter omission (CSRF), authorization-code
interception, mixing identity provider tokens, scope upgrade.
