---
id: host-header
title: HTTP Host Header Attacks
type: concept
owasp:
  - A05:2025
  - A07:2025
portswigger: http-host-header-attacks
cwe:
  - CWE-20
last_compiled: 2026-05-03
sources:
  - raw/portswigger-all-topics.md
related:
  - concepts/cache-poisoning
  - concepts/ssrf
---

Host header reflected in password-reset links, in cache keys, or used to
route to virtual hosts. Pollution allows password-reset poisoning, cache
poisoning, and routing bypass.
