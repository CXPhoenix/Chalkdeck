---
id: prototype-pollution
title: Prototype Pollution
type: concept
owasp:
  - A08:2025
  - A08:2021
portswigger: prototype-pollution
cwe:
  - CWE-1321
last_compiled: 2026-05-03
sources:
  - raw/portswigger-all-topics.md
  - raw/ctftime-writeups/securitymb-2021-prototype-pollution-rce.md
related:
  - frameworks/nodejs-express
  - concepts/deserialization-nodejs
  - cves/proto-pollution-2024-chain
---

JavaScript merge / set-by-path utilities that follow `__proto__` or
`constructor.prototype` keys allow attackers to add properties to
`Object.prototype`, affecting downstream auth checks, template engines,
and JSON parsers. Combined with template AST gadgets it escalates to RCE.
