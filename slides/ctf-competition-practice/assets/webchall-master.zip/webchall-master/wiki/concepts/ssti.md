---
id: ssti
title: Server-Side Template Injection
type: concept
owasp:
  - A05:2025
  - A03:2021
  - A1:2017
portswigger: server-side-template-injection
cwe:
  - CWE-94
  - CWE-1336
last_compiled: 2026-05-03
sources:
  - raw/portswigger-all-topics.md
  - raw/ctftime-writeups/lit-ctf-2025-group-chat.md
  - raw/ctftime-writeups/qnqsec-ctf-2025-airspeed.md
related:
  - concepts/template-engines
  - frameworks/flask
  - frameworks/fastapi
  - cves/cve-2024-34069-werkzeug-debugger
---

User input flows into a template renderer that evaluates expressions in the
template language (Jinja2, Twig, Smarty, Velocity, Handlebars).

For Flask/Jinja2 the working modern (Jinja 3.x) RCE gadget is
`{{ lipsum.__globals__.os.popen('id').read() }}` — `lipsum` is exposed as a
template global and lives in `jinja2.utils`, which imports `os` at module
scope. The historically popular `cycler.__init__.__globals__.os` chain no
longer works on Jinja 3.x because `jinja2.runtime` (where cycler is defined)
does not import `os`. Equivalent fallback chains:
`{{ self.__init__.__globals__.__builtins__.__import__('os').popen('id').read() }}`
or `{{ ''.__class__.__mro__[1].__subclasses__()[<n>](...) }}` for
sandboxed Jinja installations.

On Velocity/Airspeed, attribute traversal through `class` yields equivalent
escape. Mitigation: never render attacker-controlled strings as templates;
use `render_template` with named context variables.

Detection signals: response body changes when payload `{{7*7}}` is
submitted (returns `49` if interpreted), `{{config}}` returns Flask config.
