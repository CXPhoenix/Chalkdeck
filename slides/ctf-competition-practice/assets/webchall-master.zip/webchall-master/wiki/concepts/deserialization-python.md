---
id: deserialization-python
title: Insecure Deserialization (Python)
type: concept
owasp:
  - A03:2025
  - A08:2021
  - A8:2017
portswigger: insecure-deserialization
cwe:
  - CWE-502
last_compiled: 2026-05-03
sources:
  - raw/portswigger-all-topics.md
related:
  - frameworks/flask
  - frameworks/fastapi
---

`pickle.loads(request.data)` or `yaml.load` (without SafeLoader) on
untrusted input is direct RCE. FastAPI pickled session cookies are
a frequent CTF surface.
