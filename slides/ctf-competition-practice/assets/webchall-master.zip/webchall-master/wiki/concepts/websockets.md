---
id: websockets
title: WebSockets
type: concept
owasp:
  - A05:2025
portswigger: websockets
cwe:
  - CWE-1385
last_compiled: 2026-05-03
sources:
  - raw/portswigger-all-topics.md
related:
  - concepts/cors
---

Cross-site WebSocket hijacking (CSWSH) when origin is not validated,
message smuggling, JSON injection, and lack of authn on upgrade
handshake.
