---
id: race-condition
title: Race Conditions
type: concept
owasp:
  - A06:2025
  - A04:2021
portswigger: race-conditions
cwe:
  - CWE-362
last_compiled: 2026-05-03
sources:
  - raw/portswigger-all-topics.md
related:
  - concepts/business-logic
---

TOCTOU windows allow double-spend, double-use of one-time tokens,
coupon stacking, and ticket purchase race. Modern variants use HTTP/2
parallel-streams to land >20 requests in a single TCP packet.
