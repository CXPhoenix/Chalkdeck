---
id: cache-poisoning
title: Web Cache Poisoning
type: concept
owasp:
  - A02:2025
  - A05:2021
portswigger: web-cache-poisoning
cwe:
  - CWE-1023
last_compiled: 2026-05-03
sources:
  - raw/portswigger-all-topics.md
  - raw/ctftime-writeups/la-ctf-2025-cache-it-to-win-it.md
related:
  - concepts/host-header
  - concepts/cache-deception
---

Unkeyed input (X-Forwarded-Host, X-Forwarded-Proto, etc.) influences
response, which is then cached under a normal cache key. Subsequent
users are served the poisoned response.
