---
id: jwt
title: JSON Web Token Attacks
type: concept
owasp:
  - A04:2025
  - A02:2021
  - A2:2017
portswigger: jwt-attacks
cwe:
  - CWE-345
  - CWE-347
last_compiled: 2026-05-03
sources:
  - raw/portswigger-all-topics.md
related:
  - concepts/oauth
  - concepts/auth-bypass
---

**Header-trust attacks**

- `alg=none` — server accepts an unsigned token.
- Algorithm confusion — HS256 token verified with the RSA public key as
  the HMAC secret.
- `jwk` header injection — embed a self-generated JWK and the verifier
  trusts the embedded key.
- `jku` URL injection — verifier fetches the JWKS URL from the header,
  attacker hosts a JWKS containing the attacker's public key.
- `x5u` / `x5c` injection — same idea as `jku` / `jwk` but with X.509
  certs/URLs.
- `kid` injection — `kid` value used as a SQL parameter, file path,
  or command argument; classic exploit is `kid: ../../../dev/null` so
  the verifier reads an empty key, then signs with empty key.

**Signature attacks**

- Empty signature — token sent with valid header+payload but a zero-length
  signature; some libraries treat that as success.
- Weak HMAC secret brute-force — short or dictionary HS256 secrets fall to
  hashcat in seconds.
- Expired-token replay — verifier ignores `exp` or accepts tokens beyond
  expiration.

**JWE-specific attacks**

- Key confusion: an RSA-OAEP-encrypted token re-encrypted with a different
  algorithm the verifier accepts (e.g. `dir`).
- Unauthenticated content algorithms (`A128CBC-HS256` without integrity
  binding to header).
