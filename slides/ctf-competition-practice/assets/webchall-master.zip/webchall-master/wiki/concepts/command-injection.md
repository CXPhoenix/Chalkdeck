---
id: command-injection
title: Command Injection
type: concept
owasp:
  - A05:2025
  - A03:2021
  - A1:2017
portswigger: os-command-injection
cwe:
  - CWE-77
  - CWE-78
last_compiled: 2026-05-03
sources:
  - raw/portswigger-all-topics.md
related:
  - concepts/ssti
  - frameworks/php
---

Shell metacharacters (`;`, `|`, `&`, `` ` ``, `$()`) flow into a shell
invocation. PHP `system`, `shell_exec`, `passthru`, `assert`; Node.js
`child_process.exec` of concatenated input; Python `os.system`,
`subprocess(shell=True)`.
