---
id: info-disclosure
title: Information Disclosure
type: concept
owasp:
  - A02:2025
  - A05:2021
  - A6:2017
portswigger: information-disclosure
cwe:
  - CWE-200
last_compiled: 2026-05-03
sources:
  - raw/portswigger-all-topics.md
related:
  - concepts/access-control
---

Verbose error pages, debug endpoints, source-map leakage, public
`.git/`, exposed `.env`, backup-file extensions (`~`, `.bak`),
directory-listing-on, and template-error stack traces.
