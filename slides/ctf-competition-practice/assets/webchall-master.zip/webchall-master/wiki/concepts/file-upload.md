---
id: file-upload
title: File Upload Vulnerabilities
type: concept
owasp:
  - A05:2025
  - A04:2021
portswigger: file-upload-vulnerabilities
cwe:
  - CWE-434
last_compiled: 2026-05-03
sources:
  - raw/portswigger-all-topics.md
related:
  - concepts/path-traversal
  - frameworks/apache
  - frameworks/nginx
---

Allowing executable extensions, polyglot files, content-type
spoofing, AddHandler/MultiViews escalation, and path traversal during
storage all let attacker upload web-shells.
