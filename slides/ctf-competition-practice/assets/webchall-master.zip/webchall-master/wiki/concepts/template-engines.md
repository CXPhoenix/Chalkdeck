---
id: template-engines
title: Template Engine Internals
type: concept
owasp:
  - A05:2025
  - A03:2021
portswigger: server-side-template-injection
cwe:
  - CWE-94
  - CWE-1336
last_compiled: 2026-05-03
sources:
  - raw/portswigger-all-topics.md
related:
  - concepts/ssti
  - concepts/prototype-pollution
---

Most engines compile templates into an AST then evaluate. Attacker
primitives are: AST mutation via prototype pollution, gadget chains
via reflective globals (Jinja `cycler`, Twig `_self`), and direct
evaluation of template strings supplied by user input.
