---
id: ssrf
title: Server-Side Request Forgery
type: concept
owasp:
  - A07:2025
  - A10:2021
portswigger: server-side-request-forgery
cwe:
  - CWE-918
last_compiled: 2026-05-03
sources:
  - raw/portswigger-all-topics.md
related:
  - concepts/info-disclosure
  - concepts/web-llm
---

Server fetches a URL the user supplies. Defenses (allow-list, DNS
pinning) are commonly bypassed via DNS rebinding, IPv6 mapped
addresses, and metadata-service shortcuts (169.254.169.254).
