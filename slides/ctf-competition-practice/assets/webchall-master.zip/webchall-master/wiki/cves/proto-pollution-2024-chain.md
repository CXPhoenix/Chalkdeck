---
id: proto-pollution-2024-chain
title: 2024 prototype-pollution chain (selected)
type: cve
cve_id: CVE-2024-21505/21528/21529/21489
affected_versions:
  - various npm packages 2024
fix_versions:
  - see each package
exploit_primitive: "__proto__ key honored in deep-merge utilities"
last_compiled: 2026-05-03
sources:
  - raw/cve-advisories/proto-pollution-2024-chain.md
related:
  - concepts/prototype-pollution
  - frameworks/nodejs-express
---

## Summary

__proto__ key honored in deep-merge utilities

## Affected

- various npm packages 2024

## Fixed in

- see each package

## See also

- [concepts/prototype-pollution](../concepts/prototype-pollution.md)
- [frameworks/nodejs-express](../frameworks/nodejs-express.md)
