# Wiki ingest / query / lint log

## [2026-05-03] ingest | initial seed of taxonomies, concepts, frameworks, cves, recipes

Seeded 6 taxonomies, 36 concepts, 6 frameworks, 19 CVE pages, 9 recipes from initial Layer-1 condensed-summary sources. Authors may re-ingest
verbose upstream content via `webchall_wiki.py ingest <url>`.
