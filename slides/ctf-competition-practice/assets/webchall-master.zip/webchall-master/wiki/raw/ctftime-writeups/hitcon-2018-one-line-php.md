---
source_url: https://blog.orange.tw/posts/2018-10-hitcon-ctf-2018-one-line-php-challenge/
fetched_date: 2026-05-03
sha256: 4b8da7c42991a7d5c95a0ce587e9d01790b20b858c60ea0d9615a164fd6294b5
ingest_method: condensed-summary
---

# HITCON CTF 2018 — One Line PHP

Famously short challenge. Solved by chaining session.upload_progress
race condition with PHP wrappers (php://filter, zip://) and PHP session
files. Three teams out of 1816 solved it during the event.
