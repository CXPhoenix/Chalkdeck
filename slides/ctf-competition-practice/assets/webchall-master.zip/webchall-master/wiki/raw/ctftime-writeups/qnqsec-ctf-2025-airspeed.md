---
source_url: https://ctftime.org/writeup/40451
fetched_date: 2026-05-03
sha256: 1fb7ad0489ed8df2c36a566d6343fd42359d5f7802fec871dc4de2e20715da49
ingest_method: condensed-summary
---

# QnQSec CTF 2025 — Airspeed (nginx + Flask path normalization mismatch)

Airspeed template engine. nginx blocks `/debug` but Flask treats
`/debug\x85` as equivalent to `/debug`. Then `cycler.__init__.__globals__`
gadget calls `/readflag`. Demonstrates path-normalization bypass plus SSTI.
