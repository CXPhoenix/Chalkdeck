---
source_url: https://ctftime.org/writeup/40022
fetched_date: 2026-05-03
sha256: 5379e6eb94c5d959635d0285270f554a6685d3ffa09e258a8c61df3033276fcc
ingest_method: condensed-summary
---

# LA CTF 2025 — Cache It to Win It! (web cache poisoning)

Web cache caches authenticated responses under unauthenticated keys.
Attacker poisons cache with admin endpoint response, then any user
retrieves the cached response containing the flag.
