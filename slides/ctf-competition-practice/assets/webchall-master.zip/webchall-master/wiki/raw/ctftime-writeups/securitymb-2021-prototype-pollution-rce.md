---
source_url: https://www.creastery.com/blog/securitymb-october-2021-prototype-pollution-challenge/
fetched_date: 2026-05-03
sha256: 87bbf2915b344d76df2572d9fb1182cb4df99391f9991651994be2746f7443f7
ingest_method: condensed-summary
---

# SecurityMB October 2021 — Prototype Pollution RCE

Template engine compiles AST then evaluates. Prototype pollution into
AST node fields yields arbitrary JS execution at compile-time, hence RCE.
Foundational pattern for proto-pollution → template gadget chains.
