---
source_url: https://ctftime.org/writeup/9165
fetched_date: 2026-05-03
sha256: c0f4eeec77f62f3c283fb950e62d15ce3a476b158d4ec563dc3dfc2e0a110ec1
ingest_method: condensed-summary
---

# N1CTF 2018 — easy php

PHP challenge demonstrating phar:// metadata deserialization.
Accessing a controlled .phar file via any phar:// path triggers
unserialize on the metadata, leading to PHP object injection.
