---
source_url: https://ctftime.org/writeup/40378
fetched_date: 2026-05-03
sha256: 18787a8d3b0a5ca17be35184c7cceeb4e16730b0dee861fb2117956f74188cc6
ingest_method: condensed-summary
---

# LIT CTF 2025 — group chat (Flask SSTI via Jinja `cycler`)

Flask app simulating a group chat. Both `username` and `message` fields
flow into `render_template_string`. Payload chains
`{{ cycler.__init__.__globals__.os.popen('cat flag.txt').read() }}` to
execute commands server-side. Variant `group chat 2` adds a token
gating layer the player must bypass first.
