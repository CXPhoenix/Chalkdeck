---
source_url: https://snyk.io/blog/fetch-the-flag-ctf-2022-writeup-moongoose/
fetched_date: 2026-05-03
sha256: ec181448e86af97f43704cc1b79c26bae8d3b955d7a51d4a03687f1f7e9ca757
ingest_method: condensed-summary
---

# Fetch the Flag CTF 2022 — Moongoose

Multi-stage chain: directory traversal to read source, then NoSQL
injection on /api/flags, then prototype-chain abuse to bypass auth.
Demonstrates how a single Mongoose application can layer three
distinct exploit primitives.
