---
source_url: https://owasp.org/API-Security/editions/2023/en/0x11-t10/
fetched_date: 2026-05-03
sha256: f198dec5aa70c9b3b41d411623ba15106964cbb746871dd6ec3acb3f9b5ccaa1
ingest_method: condensed-summary
---

# OWASP API Security Top 10 — 2023 — condensed summary

- **API1 Broken Object Level Authorization (BOLA)** — attacker manipulates
  object IDs to access other users' data.
- **API2 Broken Authentication** — weak token handling, missing MFA.
- **API3 Broken Object Property Level Authorization** — sensitive properties
  (mass-assignment / over-exposure) returned or accepted without checks.
- **API4 Unrestricted Resource Consumption** — no rate limit, no quotas,
  no payload-size guard.
- **API5 Broken Function Level Authorization** — administrative endpoints
  reachable by lower-privilege roles.
- **API6 Unrestricted Access to Sensitive Business Flows** — automatable
  abuse of legitimate flows (ticket buy, comment post, sign-up).
- **API7 Server-Side Request Forgery (SSRF)** — unvalidated user-supplied URLs
  fetched server-side.
- **API8 Security Misconfiguration**
- **API9 Improper Inventory Management** — undocumented "shadow" APIs.
- **API10 Unsafe Consumption of APIs** — trusting third-party API responses.
