---
source_url: https://portswigger.net/web-security/all-topics
fetched_date: 2026-05-03
sha256: ee0b32986206d27ecc2a5c8ac2e8312f8f71eb6464abe27124c6474d16ff5cc7
ingest_method: condensed-summary
---

# PortSwigger Web Security Academy — All Topics (snapshot 2026-05)

## Server-side
- SQL injection (18 labs)
- Authentication (14 labs)
- Path traversal (6 labs)
- Command injection (5 labs)
- Business logic vulnerabilities (11 labs)
- Information disclosure (5 labs)
- Access control (13 labs)
- File upload vulnerabilities (7 labs)
- Race conditions (6 labs)
- Server-side request forgery (SSRF) (7 labs)
- XXE injection (9 labs)
- NoSQL injection (4 labs)
- API testing (5 labs)
- Web cache deception (5 labs)

## Client-side
- Cross-site scripting (XSS) (30 labs)
- Cross-site request forgery (CSRF) (12 labs)
- Cross-origin resource sharing (CORS) (3 labs)
- Clickjacking (5 labs)
- DOM-based vulnerabilities (7 labs)
- WebSockets (3 labs)

## Advanced
- Insecure deserialization (10 labs)
- Web LLM attacks (7 labs)
- GraphQL API vulnerabilities (5 labs)
- Server-side template injection (7 labs)
- Web cache poisoning (13 labs)
- HTTP Host header attacks (7 labs)
- HTTP request smuggling (22 labs)
- OAuth authentication (6 labs)
- JWT attacks (8 labs)
- Prototype pollution (10 labs)
- Essential skills (2 labs)
