---
source_url: https://owasp.org/Top10/2025/
fetched_date: 2026-05-03
sha256: 5aa1b74cc67f0f73d0a2f0588ac5c78516758c364fb09c72d640d5fe88d0ef0c
ingest_method: condensed-summary
---

# OWASP Top 10:2025 (Release Candidate) — condensed summary

- **A01:2025 Broken Access Control** — most serious application risk; remained #1.
- **A02:2025 Security Misconfiguration** — moved up from #5 (2021) to #2.
- **A03:2025 Software Supply Chain Failures** — NEW; covers compromised
  build/distribution/update pipelines and malicious dependency changes.
- **A04:2025 Cryptographic Failures** — lack of crypto, weak crypto, key leakage.
- **A05:2025 Injection** — fell from #3 to #5.
- **A06:2025 Insecure Design** — fell from #4 to #6.
- **A07:2025 Authentication Failures** — held #7.
- **A08:2025 Software and Data Integrity Failures** — same as 2021 A08.
- **A09:2025 Security Logging and Alerting Failures** — same as 2021 A09.
- **A10:2025 Mishandling of Exceptional Conditions** — NEW; 24 CWEs covering
  improper error handling, logical fail-open, abnormal-condition mistakes.
