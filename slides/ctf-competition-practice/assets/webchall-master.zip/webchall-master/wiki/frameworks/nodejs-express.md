---
id: nodejs-express
title: Node.js / Express
type: framework
last_compiled: 2026-05-03
applicable_concepts:
  - concepts/prototype-pollution
  - concepts/nosqli
  - concepts/deserialization-nodejs
  - concepts/ssrf
  - concepts/command-injection
cves:
  - cves/cve-2024-29041-express-open-redirect
  - cves/cve-2024-43796-express-redirect-xss
  - cves/proto-pollution-2024-chain
sources:
  - raw/cve-advisories/cve-2024-29041-express-open-redirect.md
  - raw/ctftime-writeups/nn8ed-tindermon-nodejs-nosqli.md
---

Common sinks: `Object.assign({}, req.body)` into config (proto pollution),
`vm.runInThisContext`, `eval`, `child_process.exec` with concat,
Mongoose queries with raw input, `res.redirect(req.query.url)`.
