---
id: flask
title: Flask / Werkzeug
type: framework
last_compiled: 2026-05-03
applicable_concepts:
  - concepts/ssti
  - concepts/deserialization-python
  - concepts/auth-bypass
  - concepts/info-disclosure
  - concepts/path-traversal
cves:
  - cves/cve-2024-34069-werkzeug-debugger
  - cves/cve-2024-49767-werkzeug-multipart
  - cves/cve-2024-49766-werkzeug-safejoin
sources:
  - raw/cve-advisories/cve-2024-34069-werkzeug-debugger.md
  - raw/ctftime-writeups/lit-ctf-2025-group-chat.md
---

Common authoring sinks: `render_template_string(user_input)`,
`app.config.update(request.json)`, `pickle.loads(session)`,
`debug=True` exposing the Werkzeug debugger, missing `SECRET_KEY`
rotation. The 2024 Werkzeug CVE cluster covers debugger CSRF, multipart
DoS, and Windows UNC traversal.
