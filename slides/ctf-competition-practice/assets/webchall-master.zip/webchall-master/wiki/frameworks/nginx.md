---
id: nginx
title: nginx
type: framework
last_compiled: 2026-05-03
applicable_concepts:
  - concepts/path-traversal
  - concepts/cache-poisoning
  - concepts/request-smuggling
cves:
  - cves/cve-2024-24990-nginx-http3-uaf
  - cves/cve-2025-23419-nginx-ssl-session
  - cves/cve-2025-53859-nginx-smtp-oob
sources:
  - raw/cve-advisories/cve-2024-24990-nginx-http3-uaf.md
---

Common authoring traps: `alias` directive without trailing slash
(off-by-one path traversal), location order mistakes, X-Forwarded-Host
reflected, HTTP/2 / HTTP/3 transport quirks, SSL session reuse.
