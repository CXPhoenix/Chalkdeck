---
id: fastapi
title: FastAPI / Starlette
type: framework
last_compiled: 2026-05-03
applicable_concepts:
  - concepts/ssti
  - concepts/deserialization-python
  - concepts/jwt
  - concepts/bola
  - concepts/mass-assignment
cves:
  - cves/cve-2024-47874-starlette-multipart
  - cves/cve-2025-54121-starlette-multipart-blocking
  - cves/cve-2025-62727-starlette-dos
sources:
  - raw/cve-advisories/cve-2024-47874-starlette-multipart.md
---

Common sinks: `pickle` in routes, `Depends` overrides without auth,
JWT decode with `verify_signature=False` or `algorithms=["none"]`,
missing Pydantic strict mode (mass assignment). Starlette 2024–2025
CVEs are mostly multipart DoS classes.
