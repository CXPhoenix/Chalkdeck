---
id: apache
title: Apache HTTP Server
type: framework
last_compiled: 2026-05-03
applicable_concepts:
  - concepts/file-upload
  - concepts/request-smuggling
  - concepts/lfi
  - concepts/ssrf
cves:
  - cves/cve-2024-38473-apache-mod-proxy-encoding
  - cves/cve-2024-38474-apache-mod-rewrite-substitution
  - cves/cve-2024-39573-apache-mod-rewrite-ssrf
  - cves/cve-2023-25690-apache-hrs
sources:
  - raw/cve-advisories/cve-2024-38473-apache-mod-proxy-encoding.md
  - raw/cve-advisories/cve-2024-38474-apache-mod-rewrite-substitution.md
  - raw/cve-advisories/cve-2024-39573-apache-mod-rewrite-ssrf.md
  - raw/cve-advisories/cve-2023-25690-apache-hrs.md
---

Orange Tsai's 2024 Confusion Attacks unify the cluster: r->filename
ambiguity between modules. `mod_proxy` encoding bypass, `mod_rewrite`
substitution-encoding RCE, RewriteRule unintended SSRF, HRS via
mod_proxy. All resolved in 2.4.64 (July 2025).
