---
id: php
title: PHP
type: framework
last_compiled: 2026-05-03
applicable_concepts:
  - concepts/lfi
  - concepts/deserialization-php
  - concepts/command-injection
  - concepts/file-upload
cves:
  - cves/cve-2024-4577-php-cgi-argv-injection
  - cves/cve-2025-49113-roundcube-deserialize
  - cves/cve-2024-34102-magento-xxe
sources:
  - raw/cve-advisories/cve-2024-4577-php-cgi-argv-injection.md
  - raw/ctftime-writeups/hitcon-2018-one-line-php.md
---

Common sinks: `unserialize($_GET[...])`, `include $_REQUEST[...]`,
`eval($_*)`, `system/shell_exec/passthru` of input, `assert($_*)`,
`extract($_REQUEST)`. phar:// metadata deserialization, php://filter
base64 decoding, session.upload_progress race.
