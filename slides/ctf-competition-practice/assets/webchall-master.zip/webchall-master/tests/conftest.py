import sys
from pathlib import Path

# Make `scripts/` importable so tests can pull `_wcm_common` directly.
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "scripts"))
