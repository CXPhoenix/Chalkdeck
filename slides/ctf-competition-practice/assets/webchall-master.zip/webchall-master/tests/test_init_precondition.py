"""Tests for the Stage 1 (Brief) `.rules.env` precondition gate in
`webchall_init.py`, plus the author-from-rules-env wiring.

Covers tasks 4.1, 4.2, 4.3 of the change `webchall-rules-env-bootstrap`,
and the integration scenario from task 7.3.
"""

from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "scripts"))

import webchall_init  # noqa: E402
from _wcm_common import rules_env  # noqa: E402


VALID_15 = {
    "CTF_EVENT_NAME": "TEST.HSCTF",
    "CTF_EVENT_LONG_NAME": "Test HSCTF",
    "FLAG_REGEX": r"TEST\.HSCTF\{\S+\}",
    "FLAG_FORMAT_LITERAL": "TEST.HSCTF{<text>}",
    "FLAG_TYPE": "static",
    "FLAG_ASSET_VERSION_CONTROLLED": "true",
    "AUTHOR_NAME": "",
    "AUTHOR_EMAIL": "",
    "CATEGORIES": "web,crypto,pwn",
    "DIFFICULTIES": "easy,medium,hard",
    "HOST_PORT_RANGE_START": "8080",
    "HOST_PORT_RANGE_END": "8099",
    "PLAYER_FACING_LOCALE": "zh-Hant-TW",
    "SPEC_LOCALE": "en",
    "BLOCK_PRC_VOCAB": "true",
    "ENFORCE_ANTI_AI_SLOP": "true",
}


# === precondition gate (in-process) =========================================


def test_precondition_passes_when_rules_env_is_valid(tmp_path: Path, monkeypatch):
    rules_env.write(tmp_path / ".rules.env", VALID_15)
    monkeypatch.chdir(tmp_path)
    rc = webchall_init._check_rules_env_precondition()
    assert rc == 0


def test_precondition_fails_when_rules_env_missing(tmp_path: Path, monkeypatch, capsys):
    monkeypatch.chdir(tmp_path)
    rc = webchall_init._check_rules_env_precondition()
    assert rc == 2
    captured = capsys.readouterr()
    assert ".rules.env not found" in captured.err
    assert "webchall init-event" in captured.err


def test_precondition_fails_when_rules_env_malformed(tmp_path: Path, monkeypatch, capsys):
    (tmp_path / ".rules.env").write_text("not a valid line\n", encoding="utf-8")
    monkeypatch.chdir(tmp_path)
    rc = webchall_init._check_rules_env_precondition()
    assert rc == 2
    captured = capsys.readouterr()
    assert "malformed" in captured.err


def test_precondition_fails_when_rules_env_invalid_value(tmp_path: Path, monkeypatch, capsys):
    """Spec scenario: malformed .rules.env blocks Stage 1 entry; message identifies key."""
    bad = dict(VALID_15)
    # Write directly via _render to bypass write() validation.
    bad["HOST_PORT_RANGE_START"] = "80"  # below 1024
    raw = "\n".join(f"{k}={v}" for k, v in bad.items()) + "\n"
    # Quote any value with a space.
    raw_lines = []
    for k, v in bad.items():
        if " " in v or any(c in v for c in r"\{}"):
            raw_lines.append(f"{k}='{v}'")
        else:
            raw_lines.append(f"{k}={v}")
    (tmp_path / ".rules.env").write_text("\n".join(raw_lines) + "\n", encoding="utf-8")
    monkeypatch.chdir(tmp_path)
    rc = webchall_init._check_rules_env_precondition()
    assert rc == 2
    captured = capsys.readouterr()
    # Error message must identify which key failed.
    assert "HOST_PORT_RANGE_START" in captured.err


# === author-from-rules-env (Task 4.3) ========================================


def test_author_from_rules_env_both_keys_present(tmp_path: Path, monkeypatch):
    """Spec scenario: webchall_init populates author from .rules.env.

    Given AUTHOR_NAME='Phoenix Chen' and AUTHOR_EMAIL='phoenix@example.org',
    challenge.yml MUST set author: 'Phoenix Chen <phoenix@example.org>' and
    MUST NOT contain the literal string 'TODO'.
    """
    mapping = dict(VALID_15)
    mapping["AUTHOR_NAME"] = "Phoenix Chen"
    mapping["AUTHOR_EMAIL"] = "phoenix@example.org"
    rules_env.write(tmp_path / ".rules.env", mapping)
    monkeypatch.chdir(tmp_path)
    assert webchall_init._author_from_rules_env() == "Phoenix Chen <phoenix@example.org>"


def test_author_from_rules_env_only_name(tmp_path: Path, monkeypatch):
    mapping = dict(VALID_15)
    mapping["AUTHOR_NAME"] = "Phoenix"
    rules_env.write(tmp_path / ".rules.env", mapping)
    monkeypatch.chdir(tmp_path)
    assert webchall_init._author_from_rules_env() == "Phoenix"


def test_author_from_rules_env_falls_back_to_todo(tmp_path: Path, monkeypatch):
    """When neither AUTHOR_NAME nor AUTHOR_EMAIL is set, falls back to 'TODO'."""
    rules_env.write(tmp_path / ".rules.env", VALID_15)  # AUTHOR_* are empty
    monkeypatch.chdir(tmp_path)
    assert webchall_init._author_from_rules_env() == "TODO"


def test_author_from_rules_env_handles_missing_file(tmp_path: Path, monkeypatch):
    """If .rules.env is absent (downstream / archived contexts), the function
    MUST NOT raise — it falls back to 'TODO'."""
    monkeypatch.chdir(tmp_path)
    assert webchall_init._author_from_rules_env() == "TODO"


# === Integration: subprocess — Stage 1 entry exits code 2 (Task 7.3) =========


def test_subprocess_init_without_rules_env_exits_2(tmp_path: Path):
    """Task 7.3: tmpdir without .rules.env → webchall_init.py exits with 2 +
    the documented error message."""
    script = ROOT / "scripts" / "webchall_init.py"
    proc = subprocess.run(
        [sys.executable, str(script),
         "--stack", "flask", "--recipe", "flask-ssti-jinja-cycler",
         "--slug", "demo", "--difficulty", "easy"],
        cwd=tmp_path,
        capture_output=True, text=True, env=dict(os.environ),
    )
    assert proc.returncode == 2, (
        f"expected exit 2 (.rules.env missing), got {proc.returncode}\n"
        f"stderr: {proc.stderr}"
    )
    assert ".rules.env not found" in proc.stderr
    assert "webchall init-event" in proc.stderr
    # No <slug>/ directory should have been created.
    assert not (tmp_path / "demo").exists()


def test_subprocess_init_with_valid_rules_env_proceeds(tmp_path: Path):
    """Sanity check: when .rules.env is valid, the precondition gate yields
    to argparse, and we get past stage-0 verification (the actual scaffold
    succeeds because we use a real recipe)."""
    rules_env.write(tmp_path / ".rules.env", VALID_15)
    script = ROOT / "scripts" / "webchall_init.py"
    proc = subprocess.run(
        [sys.executable, str(script),
         "--stack", "flask",
         "--recipe", "flask-ssti-jinja-cycler",
         "--slug", "demo", "--difficulty", "easy"],
        cwd=tmp_path,
        capture_output=True, text=True, env=dict(os.environ),
    )
    # Either succeeds, or fails for a reason OTHER than the precondition.
    if proc.returncode != 0:
        # Confirm the failure isn't the precondition gate.
        assert ".rules.env not found" not in proc.stderr
