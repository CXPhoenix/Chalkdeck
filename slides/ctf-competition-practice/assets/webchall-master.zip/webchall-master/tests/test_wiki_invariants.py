"""Wiki invariants — frontmatter schema, dead links, immutability, coverage."""

from __future__ import annotations

import hashlib
from pathlib import Path

import pytest

from _wcm_common import wiki as wiki_lib

ROOT = Path(__file__).resolve().parent.parent
WIKI = ROOT / "wiki"
RAW = WIKI / "raw"


def _profile():
    return wiki_lib.load_profile(WIKI)


def test_required_dirs_present():
    findings = wiki_lib.verify_required_dirs(WIKI, _profile())
    assert findings == [], findings


def test_frontmatter_schema_conforms():
    findings = wiki_lib.verify_frontmatter_schema(WIKI, _profile())
    assert findings == [], findings


def test_no_dead_cross_links():
    findings = wiki_lib.verify_dead_links(WIKI)
    assert findings == [], findings


def test_no_duplicate_ids():
    findings = wiki_lib.verify_duplicate_ids(WIKI)
    assert findings == [], findings


def test_raw_files_are_immutable():
    findings = wiki_lib.verify_raw_immutability(RAW)
    assert findings == [], findings


def test_log_format_strict():
    findings = wiki_lib.verify_log_format(WIKI, _profile())
    assert findings == [], findings


def test_taxonomy_coverage():
    findings = wiki_lib.verify_taxonomy_coverage(WIKI)
    assert findings == [], findings


def test_cve_coverage_per_stack():
    findings = wiki_lib.verify_cve_coverage(WIKI, min_per_stack=3)
    assert findings == [], findings


def test_cross_model_lint_clean():
    findings = wiki_lib.verify_cross_model_lint(ROOT)
    assert findings == [], findings


def test_raw_tampering_detected(tmp_path: Path):
    """Inject a tampered raw file under a sandbox raw dir and assert detection."""
    sandbox = tmp_path / "raw"
    sandbox.mkdir()
    body = "hello\n"
    sha = hashlib.sha256(body.encode()).hexdigest()
    (sandbox / "good.md").write_text(
        f"---\nsource_url: https://x/y\nfetched_date: 2026-05-03\n"
        f"sha256: {sha}\ningest_method: condensed-summary\n---\n\n{body}",
        encoding="utf-8",
    )
    (sandbox / "bad.md").write_text(
        f"---\nsource_url: https://x/y\nfetched_date: 2026-05-03\n"
        f"sha256: {'0' * 64}\ningest_method: condensed-summary\n---\n\n{body}",
        encoding="utf-8",
    )
    findings = wiki_lib.verify_raw_immutability(sandbox)
    assert any("bad.md" in str(f.location) for f in findings)
    assert all("good.md" not in str(f.location) for f in findings)
