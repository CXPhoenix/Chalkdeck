"""Regression tests for fixes applied during /spectra-audit.

Each test references the audit finding ID it locks in. Adding a fix and the
corresponding test in the same change prevents the same trap reappearing.
"""

from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "scripts"))

from _wcm_common import rules, rules_env  # noqa: E402

import webchall_bootstrap as boot  # noqa: E402


VALID_15 = {
    "CTF_EVENT_NAME": "TEST.HSCTF",
    "CTF_EVENT_LONG_NAME": "Test HSCTF",
    "FLAG_REGEX": r"TEST\.HSCTF\{\S+\}",
    "FLAG_FORMAT_LITERAL": "TEST.HSCTF{<text>}",
    "FLAG_TYPE": "static",
    "FLAG_ASSET_VERSION_CONTROLLED": "true",
    "AUTHOR_NAME": "",
    "AUTHOR_EMAIL": "",
    "CATEGORIES": "web,crypto,pwn",
    "DIFFICULTIES": "easy,medium,hard",
    "HOST_PORT_RANGE_START": "8080",
    "HOST_PORT_RANGE_END": "8099",
    "PLAYER_FACING_LOCALE": "zh-Hant-TW",
    "SPEC_LOCALE": "en",
    "BLOCK_PRC_VOCAB": "true",
    "ENFORCE_ANTI_AI_SLOP": "true",
}


# === CRIT-2: webchall_init.py --help must exit 0 (Auditor #1) ================


def test_webchall_init_help_exits_zero_without_rules_env(tmp_path: Path):
    """--help / -h MUST short-circuit before the precondition gate."""
    script = ROOT / "scripts" / "webchall_init.py"
    proc = subprocess.run(
        [sys.executable, str(script), "--help"],
        cwd=tmp_path,  # no .rules.env here
        capture_output=True, text=True, env=dict(os.environ),
    )
    assert proc.returncode == 0, proc.stderr
    assert "webchall_init" in proc.stdout
    assert "--stack" in proc.stdout


# === CRIT-1: ReDoS / stringency floor on FLAG_REGEX (Scoundrel C1, C2) =======


def test_validator_rejects_overpermissive_flag_regex(tmp_path: Path):
    """FLAG_REGEX='.*' must be rejected because it accepts empty string and any single char."""
    bad = dict(VALID_15)
    bad["FLAG_REGEX"] = ".*"
    bad["FLAG_FORMAT_LITERAL"] = "X<text>Y"
    with pytest.raises(ValueError) as exc:
        rules_env.write(tmp_path / ".rules.env", bad)
    assert "too permissive" in str(exc.value)


def test_validator_rejects_match_empty_string(tmp_path: Path):
    """FLAG_REGEX='.{0,}' is functionally '.*' — must also reject."""
    bad = dict(VALID_15)
    bad["FLAG_REGEX"] = ".{0,}"
    bad["FLAG_FORMAT_LITERAL"] = "abc<text>def"
    with pytest.raises(ValueError):
        rules_env.write(tmp_path / ".rules.env", bad)


def test_validator_accepts_strict_anchored_flag_regex(tmp_path: Path):
    """The shipped derive_flag_keys output must satisfy the stringency floor."""
    rx, lit = boot.derive_flag_keys("ISIP.HSCTF")
    mapping = dict(VALID_15)
    mapping["FLAG_REGEX"] = rx
    mapping["FLAG_FORMAT_LITERAL"] = lit
    rules_env.write(tmp_path / ".rules.env", mapping)  # MUST not raise


# === CRIT-4: AUTHOR_NAME / AUTHOR_EMAIL injection-safe charset ===============


def test_validator_rejects_author_email_with_shell_metacharacters(tmp_path: Path):
    bad = dict(VALID_15)
    bad["AUTHOR_EMAIL"] = "@; rm -rf /"
    with pytest.raises(ValueError) as exc:
        rules_env.write(tmp_path / ".rules.env", bad)
    assert "AUTHOR_EMAIL" in str(exc.value)


def test_validator_rejects_author_email_with_backticks(tmp_path: Path):
    bad = dict(VALID_15)
    bad["AUTHOR_EMAIL"] = "user@`uname -a`"
    with pytest.raises(ValueError):
        rules_env.write(tmp_path / ".rules.env", bad)


def test_validator_rejects_author_name_with_angle_brackets(tmp_path: Path):
    """Angle brackets would let an attacker control the `Name <email>` format."""
    bad = dict(VALID_15)
    bad["AUTHOR_NAME"] = "Phoenix <evil@hacker>"
    with pytest.raises(ValueError):
        rules_env.write(tmp_path / ".rules.env", bad)


def test_validator_accepts_normal_author_email(tmp_path: Path):
    mapping = dict(VALID_15)
    mapping["AUTHOR_NAME"] = "Phoenix Chen"
    mapping["AUTHOR_EMAIL"] = "phoenix@example.org"
    rules_env.write(tmp_path / ".rules.env", mapping)  # MUST not raise


# === H-5: Forbid env-poisoning unknown keys =================================


@pytest.mark.parametrize("forbidden_key", [
    "LD_PRELOAD", "LD_LIBRARY_PATH", "DYLD_INSERT_LIBRARIES",
    "PYTHONPATH", "PYTHONSTARTUP",
    "PATH", "HTTP_PROXY", "HTTPS_PROXY",
    "GIT_SSH_COMMAND",
])
def test_validator_rejects_environment_poisoning_keys(tmp_path: Path, forbidden_key):
    bad = dict(VALID_15)
    bad[forbidden_key] = "/tmp/evil"
    with pytest.raises(ValueError) as exc:
        rules_env.write(tmp_path / ".rules.env", bad)
    assert forbidden_key in str(exc.value)


def test_validator_accepts_safe_extra_keys(tmp_path: Path):
    """Author-defined namespaced keys still pass."""
    mapping = dict(VALID_15)
    mapping["MY_TEAM_SLACK_WEBHOOK"] = "https://hooks.slack.com/abc"
    rules_env.write(tmp_path / ".rules.env", mapping)  # MUST not raise


# === H-3: rule_author_not_placeholder fires on TODO ==========================


def test_rule_author_not_placeholder_fires_on_todo(tmp_path: Path):
    challenge = tmp_path / "demo"
    challenge.mkdir()
    (challenge / "challenge.yml").write_text(
        "name: demo\nauthor: TODO\ncategory: web\ndescription: x\n"
        "value: 100\ntype: standard\nversion: '0.1'\nflags:\n  - FLAG{x}\n",
        encoding="utf-8",
    )
    findings = rules.rule_author_not_placeholder(challenge, mfst={})
    assert any(f.rule == "author_not_placeholder" and f.severity == "error"
               for f in findings)


def test_rule_author_not_placeholder_passes_on_real_author(tmp_path: Path):
    challenge = tmp_path / "demo"
    challenge.mkdir()
    (challenge / "challenge.yml").write_text(
        "name: demo\nauthor: Phoenix Chen <p@example.org>\n"
        "category: web\ndescription: x\n"
        "value: 100\ntype: standard\nversion: '0.1'\nflags:\n  - FLAG{x}\n",
        encoding="utf-8",
    )
    findings = rules.rule_author_not_placeholder(challenge, mfst={})
    assert findings == []


# === H-1: --out flag is no longer a public CLI surface ======================


def test_out_flag_is_not_in_help():
    script = ROOT / "scripts" / "webchall_bootstrap.py"
    proc = subprocess.run(
        [sys.executable, str(script), "--help"],
        capture_output=True, text=True,
    )
    assert proc.returncode == 0
    # CLI must NOT advertise an --out flag (was an audit-flagged path-traversal vector).
    assert "--out" not in proc.stdout


def test_out_flag_is_not_accepted_via_argv(tmp_path: Path):
    """Even if a user remembers `--out` from history, argparse must reject it."""
    target = tmp_path / "evil.env"
    with pytest.raises(SystemExit) as exc:
        boot.main([
            "--name", "TEST", "--long-name", "Test", "--flag-prefix", "TEST",
            "--port-range", "8080:8099", "--yes",
            "--out", str(target),
        ])
    assert exc.value.code != 0
    assert not target.exists()


# === H-12 / C1: atomic write — no orphan .tmp on validation failure =========


def test_failed_write_leaves_no_tmp_file(tmp_path: Path):
    """If validate() raises, the tempfile MUST be cleaned up (no `.tmp` debris)."""
    bad = dict(VALID_15)
    bad["FLAG_REGEX"] = ".*"  # stringency floor will reject
    bad["FLAG_FORMAT_LITERAL"] = "X<text>Y"
    with pytest.raises(ValueError):
        rules_env.write(tmp_path / ".rules.env", bad)
    leftovers = list(tmp_path.glob(".rules.env.*"))
    assert leftovers == [], f"unexpected tmp debris: {leftovers}"


# === DoS guard: file size cap ===============================================


def test_load_rejects_oversized_file(tmp_path: Path):
    p = tmp_path / ".rules.env"
    # Write 200 KiB of harmless lines, well over MAX_FILE_BYTES.
    p.write_text("# pad\n" * 50_000, encoding="utf-8")
    with pytest.raises(ValueError) as exc:
        rules_env.load(p)
    assert "DoS guard" in str(exc.value) or "refusing" in str(exc.value)


# === Type-confusion guards on write() ========================================


def test_write_rejects_swapped_args(tmp_path: Path):
    target = tmp_path / ".rules.env"
    with pytest.raises(TypeError) as exc:
        rules_env.write(VALID_15, target)  # type: ignore[arg-type]
    assert "swap" in str(exc.value).lower()


# === Public API now exposes normalize_for_write and render ==================


def test_public_api_normalize_for_write():
    """Public alias must exist and behave identically to historic underscore name."""
    out = rules_env.normalize_for_write({"BLOCK_PRC_VOCAB": "TRUE", "X": "y"})
    assert out["BLOCK_PRC_VOCAB"] == "true"


def test_public_api_render():
    out = rules_env.render(VALID_15)
    assert "CTF_EVENT_NAME=TEST.HSCTF" in out
    assert "# === Event identity ===" in out


# === Aggregated validation errors (M-4) =====================================


def test_validate_aggregates_multiple_errors(tmp_path: Path):
    """When several keys fail, the message MUST list ALL of them in one pass."""
    bad = dict(VALID_15)
    bad["HOST_PORT_RANGE_START"] = "80"  # below 1024
    bad["FLAG_TYPE"] = "rotating"  # not in enum
    bad["BLOCK_PRC_VOCAB"] = "yes"  # not literal true/false
    with pytest.raises(ValueError) as exc:
        rules_env.write(tmp_path / ".rules.env", bad)
    msg = str(exc.value)
    assert "HOST_PORT_RANGE_START" in msg
    assert "FLAG_TYPE" in msg
    assert "BLOCK_PRC_VOCAB" in msg


# === Bootstrap example (Lazy Developer): note printed when AUTHOR_* empty ====


def test_bootstrap_notes_when_author_unset(tmp_path: Path, capsys):
    target = tmp_path / ".rules.env"
    rc = boot.main([
        "--name", "TEST", "--long-name", "Test", "--flag-prefix", "TEST",
        "--port-range", "8080:8099", "--yes",
    ], out_override=target)
    assert rc == 0
    captured = capsys.readouterr()
    assert "AUTHOR_NAME" in captured.err
    assert "TODO" in captured.err


def test_bootstrap_no_note_when_author_set(tmp_path: Path, capsys):
    target = tmp_path / ".rules.env"
    rc = boot.main([
        "--name", "TEST", "--long-name", "Test", "--flag-prefix", "TEST",
        "--port-range", "8080:8099", "--yes",
        "--author-name", "Phoenix",
        "--author-email", "p@example.org",
    ], out_override=target)
    assert rc == 0
    captured = capsys.readouterr()
    assert "TODO" not in captured.err


# === Init error message names the actual python invocation =================


def test_init_error_message_names_real_command(tmp_path: Path):
    script = ROOT / "scripts" / "webchall_init.py"
    proc = subprocess.run(
        [sys.executable, str(script),
         "--stack", "flask", "--recipe", "flask-ssti-jinja-cycler",
         "--slug", "demo", "--difficulty", "easy"],
        cwd=tmp_path,
        capture_output=True, text=True, env=dict(os.environ),
    )
    assert proc.returncode == 2
    assert ".rules.env not found" in proc.stderr
    assert "webchall_bootstrap.py" in proc.stderr  # actual command, not fictional `webchall init-event`
