"""Downstream-loader integration tests: validates that `webchall_validate`
and `webchall_analyze` honor `.rules.env` per the spec scenarios under
`Tooling MUST treat .rules.env as the source of truth for shared constraints`.

Covers:
  - Task 5.1: 3-layer DEFAULT_FLAG_REGEX lookup
  - Task 5.2: webchall_validate uses FLAG_REGEX from .rules.env
  - Task 5.3: webchall_analyze warns on out-of-range host port
  - Task 5.4: lazy reads (no cache across stages)
  - Task 7.1 / 7.4: integration scenarios from the spec
  - Task 7.5: extra unknown key preserved silently
"""

from __future__ import annotations

import shutil
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "scripts"))

from _wcm_common import DEFAULT_FLAG_REGEX, default_flag_regex  # noqa: E402
from _wcm_common import manifest as manifest_lib  # noqa: E402
from _wcm_common import rules, rules_env  # noqa: E402

import webchall_analyze  # noqa: E402

TEMPLATES = ROOT / "templates"


VALID_15 = {
    "CTF_EVENT_NAME": "ISIP.HSCTF",
    "CTF_EVENT_LONG_NAME": "ISIP HSCTF",
    "FLAG_REGEX": r"^ISIP\.HSCTF\{\S+\}$",
    "FLAG_FORMAT_LITERAL": "ISIP.HSCTF{<text>}",
    "FLAG_TYPE": "static",
    "FLAG_ASSET_VERSION_CONTROLLED": "true",
    "AUTHOR_NAME": "Test Author",
    "AUTHOR_EMAIL": "t@example.org",
    "CATEGORIES": "web,crypto,pwn",
    "DIFFICULTIES": "easy,medium,hard",
    "HOST_PORT_RANGE_START": "8080",
    "HOST_PORT_RANGE_END": "8099",
    "PLAYER_FACING_LOCALE": "zh-Hant-TW",
    "SPEC_LOCALE": "en",
    "BLOCK_PRC_VOCAB": "true",
    "ENFORCE_ANTI_AI_SLOP": "true",
}


def _scaffold(tmp_path: Path, *, canonical_flag: str, flag_regex: str | None = None,
              category: str = "web") -> Path:
    """Minimal challenge scaffold used by validator + analyzer tests.
    Mirrors the pattern in test_validate_and_analyze.py.
    """
    target = tmp_path / "demo"
    target.mkdir()
    shutil.copytree(TEMPLATES / "flask" / "src", target / "src")
    (target / "publish").mkdir()
    sol = target / "src" / "solution"
    if sol.exists():
        shutil.move(str(sol), target / "solution")
    else:
        (target / "solution").mkdir()
    (target / "README.author.md").write_text("# author\n", encoding="utf-8")
    (target / "README.player.md").write_text("# player\n", encoding="utf-8")
    seed_kwargs = dict(
        slug="demo",
        stack="flask",
        recipe_id="flask-ssti-jinja-cycler",
        vulnerability_class="ssti",
        canonical_flag=canonical_flag,
    )
    if flag_regex is not None:
        seed_kwargs["flag_regex"] = flag_regex
    manifest_lib.seed(target, **seed_kwargs)
    (target / "challenge.yml").write_text(
        f"name: demo\nauthor: t\ncategory: {category}\ndescription: t\n"
        f"value: 100\ntype: standard\nversion: '0.1'\nflags:\n  - {canonical_flag}\n",
        encoding="utf-8",
    )
    return target


# === Task 5.1: 3-layer FLAG_REGEX lookup =====================================


def test_default_flag_regex_falls_back_to_constant_when_no_rules_env(
    tmp_path: Path, monkeypatch
):
    monkeypatch.chdir(tmp_path)
    assert default_flag_regex() == DEFAULT_FLAG_REGEX


def test_default_flag_regex_reads_rules_env_when_present(tmp_path: Path, monkeypatch):
    rules_env.write(tmp_path / ".rules.env", VALID_15)
    monkeypatch.chdir(tmp_path)
    assert default_flag_regex() == VALID_15["FLAG_REGEX"]


# === Task 5.2 / 7.1: validator uses FLAG_REGEX from .rules.env ===============


def test_validate_uses_rules_env_flag_regex_when_manifest_lacks_it(
    tmp_path: Path, monkeypatch
):
    """Manifest's flag_regex absent → 3-layer lookup picks up .rules.env.

    Spec scenario (paraphrased): given .rules.env declares
    FLAG_REGEX='ISIP\\.HSCTF\\{\\S+\\}', a challenge whose canonical_flag is
    'ISIP.HSCTF{ok}' MUST validate; FLAG{ok} MUST be rejected.
    """
    rules_env.write(tmp_path / ".rules.env", VALID_15)
    monkeypatch.chdir(tmp_path)
    # Build challenge whose manifest has the matching flag_regex (seed default
    # at init-time would have picked up .rules.env; we simulate that here).
    challenge = _scaffold(
        tmp_path,
        canonical_flag="ISIP.HSCTF{ok}",
        flag_regex=VALID_15["FLAG_REGEX"],
    )
    findings = rules.run_all(challenge)
    flag_errors = [f for f in findings if f.rule == "flag_format" and f.severity == "error"]
    assert flag_errors == [], f"flag should validate, got {flag_errors}"


def test_validate_rejects_old_format_when_event_uses_new_prefix(
    tmp_path: Path, monkeypatch
):
    """The reverse case: event sets FLAG_REGEX to ISIP\\.HSCTF\\{\\S+\\} but
    a challenge still uses canonical_flag 'FLAG{ok}' → flag_format must error.
    """
    rules_env.write(tmp_path / ".rules.env", VALID_15)
    monkeypatch.chdir(tmp_path)
    challenge = _scaffold(
        tmp_path,
        canonical_flag="FLAG{ok}",
        flag_regex=VALID_15["FLAG_REGEX"],
    )
    findings = rules.run_all(challenge)
    flag_errors = [f for f in findings if f.rule == "flag_format" and f.severity == "error"]
    assert flag_errors, "flag should be rejected under event-level FLAG_REGEX"


def test_validate_uses_categories_enum_from_rules_env(tmp_path: Path, monkeypatch):
    """Task 5.2 (categories): challenge.yml category MUST be in .rules.env CATEGORIES."""
    rules_env.write(tmp_path / ".rules.env", VALID_15)
    monkeypatch.chdir(tmp_path)
    # 'reverse-engineering' is NOT in VALID_15's CATEGORIES (web,crypto,pwn).
    challenge = _scaffold(
        tmp_path,
        canonical_flag="ISIP.HSCTF{ok}",
        flag_regex=VALID_15["FLAG_REGEX"],
        category="rev",
    )
    findings = rules.run_all(challenge)
    cat_errors = [f for f in findings if f.rule == "category_in_enum"]
    assert cat_errors, "category 'rev' should be flagged (not in enum)"


def test_validate_skips_category_check_when_rules_env_absent(
    tmp_path: Path, monkeypatch
):
    """Task 7.4 (paraphrased): archived challenge w/o .rules.env → category
    rule silently skipped (does not error)."""
    monkeypatch.chdir(tmp_path)
    challenge = _scaffold(tmp_path, canonical_flag="FLAG{ok}", category="rev")
    findings = rules.run_all(challenge)
    cat_errors = [f for f in findings if f.rule == "category_in_enum"]
    assert cat_errors == [], "category rule MUST be skipped when .rules.env is absent"


# === Task 5.3: analyzer warns on out-of-range host port ======================


def test_analyzer_emits_warning_for_out_of_range_port(tmp_path: Path, monkeypatch):
    """Spec scenario: HOST_PORT_RANGE 8080..8099, target binding host port 3000
    → warning finding."""
    rules_env.write(tmp_path / ".rules.env", VALID_15)
    monkeypatch.chdir(tmp_path)
    finding = webchall_analyze._check_port_against_rules_env("http://127.0.0.1:3000")
    assert finding is not None
    assert finding.severity == "warning"
    assert finding.rule == "host_port_out_of_range"
    assert "3000" in finding.summary


def test_analyzer_no_warning_for_in_range_port(tmp_path: Path, monkeypatch):
    rules_env.write(tmp_path / ".rules.env", VALID_15)
    monkeypatch.chdir(tmp_path)
    assert webchall_analyze._check_port_against_rules_env("http://127.0.0.1:8081") is None


def test_analyzer_skips_check_when_rules_env_absent(tmp_path: Path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    assert webchall_analyze._check_port_against_rules_env("http://127.0.0.1:3000") is None


# === Task 5.4: lazy reads / no cross-stage cache =============================


def test_rules_env_get_rereads_after_change(tmp_path: Path, monkeypatch):
    """Spec: consumers MUST read .rules.env lazily at use-site."""
    p = tmp_path / ".rules.env"
    rules_env.write(p, VALID_15)
    first = rules_env.get("CTF_EVENT_NAME", path=p)
    altered = dict(VALID_15)
    altered["CTF_EVENT_NAME"] = "CHANGED.CTF"
    rules_env.write(p, altered, force=True)
    second = rules_env.get("CTF_EVENT_NAME", path=p)
    assert first == "ISIP.HSCTF"
    assert second == "CHANGED.CTF"


# === Task 7.5: extra unknown key preserved =====================================


def test_unknown_key_preserved_on_round_trip(tmp_path: Path):
    """Spec: tooling MUST ignore unknown keys without warning; round-trip preserves them."""
    p = tmp_path / ".rules.env"
    extended = dict(VALID_15)
    extended["MY_TEAM_SLACK_WEBHOOK"] = "https://hooks.slack.com/abc"
    rules_env.write(p, extended)
    # Round trip via load.
    parsed = rules_env.load(p)
    assert parsed["MY_TEAM_SLACK_WEBHOOK"] == "https://hooks.slack.com/abc"
    # And rules_env.get reaches it without warning.
    assert rules_env.get("MY_TEAM_SLACK_WEBHOOK", path=p) == "https://hooks.slack.com/abc"


# === Task 7.4 explicit: archived challenge w/o .rules.env, validator falls back ====


def test_archived_challenge_validates_with_fallback(tmp_path: Path, monkeypatch):
    """The cwd does not contain .rules.env (archived challenge); webchall_validate
    rules use the fallback DEFAULT_FLAG_REGEX without exiting non-zero on missing file.
    """
    monkeypatch.chdir(tmp_path)
    # Manifest carries the original DEFAULT_FLAG_REGEX (what the archive snapshot
    # would look like for an old challenge).
    challenge = _scaffold(
        tmp_path,
        canonical_flag="FLAG{archived_test}",
        flag_regex=DEFAULT_FLAG_REGEX,
    )
    findings = rules.run_all(challenge)
    flag_errors = [f for f in findings if f.rule == "flag_format" and f.severity == "error"]
    assert flag_errors == [], (
        f"archived challenge should pass with fallback DEFAULT_FLAG_REGEX, "
        f"got {flag_errors}"
    )
