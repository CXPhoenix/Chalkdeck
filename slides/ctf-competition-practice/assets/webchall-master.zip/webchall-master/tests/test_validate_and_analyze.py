"""Validator + analyzer tests using minimal per-stack fixtures."""

from __future__ import annotations

import shutil
from pathlib import Path

import pytest

from _wcm_common import manifest as manifest_lib
from _wcm_common import rules, static_fuzz


ROOT = Path(__file__).resolve().parent.parent
TEMPLATES = ROOT / "templates"


def _scaffold(tmp_path: Path, stack: str, slug: str = "demo") -> Path:
    target = tmp_path / slug
    target.mkdir()
    shutil.copytree(TEMPLATES / stack / "src", target / "src")
    (target / "publish").mkdir()
    sol = target / "src" / "solution"
    if sol.exists():
        shutil.move(str(sol), target / "solution")
    else:
        (target / "solution").mkdir()
    (target / "README.author.md").write_text("# author\n", encoding="utf-8")
    (target / "README.player.md").write_text("# player\n", encoding="utf-8")
    manifest_lib.seed(
        target,
        slug=slug,
        stack=stack,
        recipe_id={
            "flask": "flask-ssti-jinja-cycler",
            "fastapi": "fastapi-pickle-jwt-none",
            "php-apache": "apache-confusion-attack-rfilename",
            "php-nginx-fpm": "php-phar-deserialize",
            "nodejs-express": "nodejs-proto-pollution-template-rce",
            "static-nginx": "nginx-alias-off-by-slash",
        }[stack],
        vulnerability_class="ssti",
        canonical_flag="FLAG{test_flag_for_unit_tests}",
    )
    # Minimal challenge.yml.
    (target / "challenge.yml").write_text(
        "name: demo\nauthor: t\ncategory: web\ndescription: t\n"
        "value: 100\ntype: standard\nversion: '0.1'\nflags:\n  - FLAG{test_flag_for_unit_tests}\n",
        encoding="utf-8",
    )
    return target


@pytest.mark.parametrize("stack", [
    "flask", "fastapi", "php-apache", "php-nginx-fpm",
    "nodejs-express", "static-nginx",
])
def test_validate_passes_on_clean_scaffold(tmp_path: Path, stack: str):
    challenge = _scaffold(tmp_path, stack)
    findings = rules.run_all(challenge)
    errors = [f for f in findings if f.severity == "error"]
    assert errors == [], f"{stack}: {errors}"


def test_validate_flags_dual_dockerfile_missing(tmp_path: Path):
    challenge = _scaffold(tmp_path, "flask")
    (challenge / "src" / "docker-compose.yml").unlink()
    findings = rules.run_all(challenge)
    rule_ids = {f.rule for f in findings if f.severity == "error"}
    assert "dual_dockerfile_present" in rule_ids


def test_validate_catches_leaked_flag_in_publish(tmp_path: Path):
    """Negative-case fixture: deliberately leak the flag into publish/ and
    confirm `flag_not_in_publish` fires."""
    challenge = _scaffold(tmp_path, "flask")
    real_flag = "FLAG{TEST_LEAK_DETECTED}"
    mfst = manifest_lib.load(challenge)
    mfst["canonical_flag"] = real_flag
    manifest_lib.save(challenge, mfst)
    (challenge / "publish" / "config.txt").write_text(
        f"# accidentally committed\nflag = {real_flag}\n", encoding="utf-8"
    )
    findings = rules.run_all(challenge)
    rule_ids = {f.rule for f in findings if f.severity == "error"}
    assert "flag_not_in_publish" in rule_ids


def test_validate_catches_unresolved_recipe_ref(tmp_path: Path):
    challenge = _scaffold(tmp_path, "flask")
    mfst = manifest_lib.load(challenge)
    mfst["recipe_id"] = "nonexistent-recipe-xyz"
    manifest_lib.save(challenge, mfst)
    findings = rules.run_all(challenge)
    rule_ids = {f.rule for f in findings if f.severity == "error"}
    assert "manifest_wiki_refs_resolve" in rule_ids


def test_static_fuzz_finds_flask_ssti(tmp_path: Path):
    challenge = _scaffold(tmp_path, "flask")
    findings = static_fuzz.analyze_static(challenge / "src")
    rule_ids = {f.rule for f in findings}
    assert "ssti" in rule_ids, f"static fuzz did not detect Flask SSTI: {rule_ids}"


def test_static_fuzz_finds_php_unserialize(tmp_path: Path):
    challenge = _scaffold(tmp_path, "php-apache")
    findings = static_fuzz.analyze_static(challenge / "src")
    rule_ids = {f.rule for f in findings}
    assert "deserialization-php" in rule_ids


def test_static_fuzz_finds_nodejs_proto_pollution(tmp_path: Path):
    challenge = _scaffold(tmp_path, "nodejs-express")
    findings = static_fuzz.analyze_static(challenge / "src")
    rule_ids = {f.rule for f in findings}
    assert "prototype-pollution" in rule_ids


def test_soft_mode_downgrades_errors(tmp_path: Path):
    """Validator with --soft converts errors to warnings."""
    challenge = _scaffold(tmp_path, "flask")
    (challenge / "src" / "Dockerfile").unlink()
    findings = rules.run_all(challenge)
    # Simulate --soft downgrade
    for f in findings:
        if f.severity == "error":
            f.severity = "warning"
    assert all(f.severity != "error" for f in findings)
    assert any(f.rule == "dual_dockerfile_present" for f in findings)


def test_validate_catches_base64_encoded_flag_leak(tmp_path: Path):
    """Encoding-aware: base64-encoded flag in publish/ must trigger."""
    import base64
    challenge = _scaffold(tmp_path, "flask")
    real_flag = "FLAG{ENCODED_LEAK}"
    mfst = manifest_lib.load(challenge)
    mfst["canonical_flag"] = real_flag
    manifest_lib.save(challenge, mfst)
    encoded = base64.b64encode(real_flag.encode()).decode()
    (challenge / "publish" / "asset.txt").write_text(
        f"hint: {encoded}\n", encoding="utf-8")
    findings = rules.run_all(challenge)
    rules_ids = {f.rule for f in findings if f.severity == "error"}
    assert "flag_not_in_publish" in rules_ids


def test_validate_rejects_archive_in_publish(tmp_path: Path):
    """Binary archives are flagged because they can hide a flag opaquely."""
    challenge = _scaffold(tmp_path, "flask")
    mfst = manifest_lib.load(challenge)
    mfst["canonical_flag"] = "FLAG{archive_test}"
    manifest_lib.save(challenge, mfst)
    (challenge / "publish" / "bundle.zip").write_bytes(b"PK\x03\x04...")
    findings = rules.run_all(challenge)
    archive_finds = [f for f in findings if f.rule == "flag_not_in_publish"
                     and "binary archive" in f.summary]
    assert archive_finds, "archive should have been flagged"


def test_mark_stage_complete_requires_predecessor_complete(tmp_path: Path):
    """Out-of-order stage advancement must be rejected per spec."""
    challenge = _scaffold(tmp_path, "flask")
    manifest_lib.append_audit_verdict(challenge, "scaffold", "pass")
    # Try to mark scaffold complete WITHOUT brief or design done.
    import pytest
    with pytest.raises(manifest_lib.ManifestError, match="predecessor"):
        manifest_lib.mark_stage_complete(challenge, "scaffold")


def test_first_incomplete_stage_rejects_partial_stages_dict(tmp_path: Path):
    """An incomplete stages dict must NOT be misread as 'all complete'."""
    challenge = _scaffold(tmp_path, "flask")
    mfst = manifest_lib.load(challenge)
    mfst["stages"] = {"brief": {"complete": True, "completed_at": None}}  # missing 6 stages
    manifest_lib.save(challenge, mfst)
    import pytest
    with pytest.raises(manifest_lib.ManifestError, match="missing keys"):
        manifest_lib.first_incomplete_stage(challenge)


def test_finding_severity_must_be_valid():
    """Finding constructor rejects typo'd severities so reporters can't
    silently coerce them to 'note'."""
    from _wcm_common.reporters import Finding
    import pytest
    Finding(rule="ok", severity="error", location="x", summary="y")  # OK
    with pytest.raises(ValueError, match="severity"):
        Finding(rule="bad", severity="errror", location="x", summary="y")


def test_placeholder_emits_advisory_not_silent_skip(tmp_path: Path):
    """When canonical_flag is the placeholder, the leak-scan rule must emit
    at least an advisory rather than silently returning no findings."""
    challenge = _scaffold(tmp_path, "flask")
    mfst = manifest_lib.load(challenge)
    mfst["canonical_flag"] = "FLAG{REPLACE_ME_BEFORE_SHIPPING}"
    manifest_lib.save(challenge, mfst)
    findings = rules.run_all(challenge)
    leak_advisories = [f for f in findings
                       if f.rule == "flag_not_in_publish" and f.severity == "advisory"]
    assert leak_advisories, "placeholder should produce advisory, not silent pass"


def test_dead_link_category_enforcement(tmp_path: Path):
    """A page that points a `cves` field at a non-cve target must error."""
    from _wcm_common import wiki as wiki_lib
    from _wcm_common.reporters import Finding
    sandbox = tmp_path / "wiki"
    (sandbox / "concepts").mkdir(parents=True)
    (sandbox / "frameworks").mkdir(parents=True)
    (sandbox / "cves").mkdir(parents=True)
    (sandbox / "recipes").mkdir(parents=True)
    (sandbox / "taxonomies").mkdir(parents=True)
    (sandbox / "concepts" / "ssti.md").write_text(
        "---\nid: ssti\ntitle: T\ntype: concept\nlast_compiled: 2026-01-01\n"
        "sources:\n  - x\n---\n", encoding="utf-8")
    (sandbox / "frameworks" / "flask.md").write_text(
        "---\nid: flask\ntitle: F\ntype: framework\nlast_compiled: 2026-01-01\n"
        "sources:\n  - x\n"
        "applicable_concepts:\n  - ssti\n"
        "cves:\n  - ssti\n"  # WRONG: cves field points at concept
        "---\n", encoding="utf-8")
    findings = wiki_lib.verify_dead_links(sandbox)
    assert any("expected" in f.summary for f in findings if f.rule == "dead_link")
