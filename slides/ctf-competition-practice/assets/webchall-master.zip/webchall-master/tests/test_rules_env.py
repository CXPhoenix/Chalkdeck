"""Unit tests for `_wcm_common/rules_env.py` — covers parse/write round-trip,
15-key schema enforcement, and per-key validation rules from
`webchall-rules-env` spec."""

from __future__ import annotations

from pathlib import Path

import pytest

from _wcm_common import rules_env


# Canonical 15-key mapping reused across many tests. Mirrors the
# `webchall-rules-env` spec example values.
VALID_15 = {
    "CTF_EVENT_NAME": "ISIP.HSCTF",
    "CTF_EVENT_LONG_NAME": "ISIP HSCTF",
    "FLAG_REGEX": r"ISIP\.HSCTF\{\S+\}",
    "FLAG_FORMAT_LITERAL": "ISIP.HSCTF{<text>}",
    "FLAG_TYPE": "static",
    "FLAG_ASSET_VERSION_CONTROLLED": "true",
    "AUTHOR_NAME": "Phoenix Chen",
    "AUTHOR_EMAIL": "phoenix@example.org",
    "CATEGORIES": "web,crypto,pwn,rev,forensics,misc,osint",
    "DIFFICULTIES": "beginner,easy,medium,hard,expert",
    "HOST_PORT_RANGE_START": "8080",
    "HOST_PORT_RANGE_END": "8099",
    "PLAYER_FACING_LOCALE": "zh-Hant-TW",
    "SPEC_LOCALE": "en",
    "BLOCK_PRC_VOCAB": "true",
    "ENFORCE_ANTI_AI_SLOP": "true",
}


def test_load_returns_empty_dict_for_missing_file(tmp_path: Path):
    p = tmp_path / ".rules.env"
    assert rules_env.load(p) == {}


def test_round_trip_preserves_all_15_keys(tmp_path: Path):
    p = tmp_path / ".rules.env"
    rules_env.write(p, VALID_15)
    parsed = rules_env.load(p)
    for k, v in VALID_15.items():
        assert parsed[k] == v, f"{k}: {parsed[k]!r} != {v!r}"


def test_parser_preserves_quoted_value_with_regex_escapes(tmp_path: Path):
    """Spec scenario: parser accepts quoted values with shell-special characters."""
    p = tmp_path / ".rules.env"
    p.write_text("FLAG_REGEX='ISIP\\.HSCTF\\{\\S+\\}'\n", encoding="utf-8")
    # Parser MUST yield the literal string with backslashes preserved.
    # load() returns just the parsed pairs — schema validation happens elsewhere.
    parsed = rules_env._parse_text(p.read_text(encoding="utf-8"))
    assert parsed["FLAG_REGEX"] == r"ISIP\.HSCTF\{\S+\}"


def test_parser_ignores_comments_and_blank_lines(tmp_path: Path):
    p = tmp_path / ".rules.env"
    p.write_text(
        "# === Event identity ===\n"
        "\n"
        "CTF_EVENT_NAME=ISIP.HSCTF\n"
        "\n"
        "# trailing comment line\n",
        encoding="utf-8",
    )
    parsed = rules_env._parse_text(p.read_text(encoding="utf-8"))
    assert parsed == {"CTF_EVENT_NAME": "ISIP.HSCTF"}


def test_parser_handles_quoted_long_name_with_space(tmp_path: Path):
    parsed = rules_env._parse_text("CTF_EVENT_LONG_NAME='ISIP HSCTF'\n")
    assert parsed["CTF_EVENT_LONG_NAME"] == "ISIP HSCTF"


def test_load_raises_value_error_on_malformed_line(tmp_path: Path):
    """Spec scenario: load raises on malformed line."""
    p = tmp_path / ".rules.env"
    p.write_text("CTF_EVENT_NAME=ok\nnot a valid declaration\n", encoding="utf-8")
    with pytest.raises(ValueError) as exc:
        rules_env.load(p)
    # Error MUST name the offending line number.
    assert "2" in str(exc.value)


def test_load_rejects_variable_expansion(tmp_path: Path):
    """Spec: format SHALL NOT use variable expansion ($VAR)."""
    p = tmp_path / ".rules.env"
    p.write_text("FOO=$BAR\n", encoding="utf-8")
    with pytest.raises(ValueError):
        rules_env.load(p)


def test_load_rejects_export_prefix(tmp_path: Path):
    """Spec: format SHALL NOT use `export` prefixes."""
    p = tmp_path / ".rules.env"
    p.write_text("export FOO=bar\n", encoding="utf-8")
    with pytest.raises(ValueError):
        rules_env.load(p)


# ----------- write() refusal & overwrite semantics -----------


def test_write_refuses_to_overwrite_without_force(tmp_path: Path):
    p = tmp_path / ".rules.env"
    rules_env.write(p, VALID_15)
    with pytest.raises(FileExistsError):
        rules_env.write(p, VALID_15)


def test_write_does_not_modify_existing_when_refusing(tmp_path: Path):
    p = tmp_path / ".rules.env"
    rules_env.write(p, VALID_15)
    original = p.read_text(encoding="utf-8")
    altered = dict(VALID_15)
    altered["CTF_EVENT_NAME"] = "OTHER.CTF"
    with pytest.raises(FileExistsError):
        rules_env.write(p, altered)
    assert p.read_text(encoding="utf-8") == original


def test_write_with_force_replaces_existing(tmp_path: Path):
    p = tmp_path / ".rules.env"
    rules_env.write(p, VALID_15)
    altered = dict(VALID_15)
    altered["CTF_EVENT_NAME"] = "OTHER.CTF"
    rules_env.write(p, altered, force=True)
    assert rules_env.load(p)["CTF_EVENT_NAME"] == "OTHER.CTF"


# ----------- 15-key schema enforcement -----------


def test_write_rejects_when_required_key_missing(tmp_path: Path):
    """Spec scenario: missing required key fails validation."""
    p = tmp_path / ".rules.env"
    incomplete = dict(VALID_15)
    del incomplete["CTF_EVENT_NAME"]
    with pytest.raises(ValueError) as exc:
        rules_env.write(p, incomplete)
    assert "CTF_EVENT_NAME" in str(exc.value)


def test_write_preserves_extra_unknown_keys_silently(tmp_path: Path):
    """Spec scenario: extra unknown key is preserved silently."""
    p = tmp_path / ".rules.env"
    extended = dict(VALID_15)
    extended["MY_TEAM_SLACK_WEBHOOK"] = "https://hooks.slack.com/abc"
    rules_env.write(p, extended)
    parsed = rules_env.load(p)
    assert parsed["MY_TEAM_SLACK_WEBHOOK"] == "https://hooks.slack.com/abc"


# ----------- Per-key validation matrix (spec scenarios + Example: matrix) -----------


@pytest.mark.parametrize(
    "key,value,reason",
    [
        ("FLAG_TYPE", "rotating", "not in enum static|dynamic"),
        ("BLOCK_PRC_VOCAB", "yes", "not literal true/false"),
        ("ENFORCE_ANTI_AI_SLOP", "1", "not literal true/false"),
        ("HOST_PORT_RANGE_START", "80", "below 1024"),
        ("HOST_PORT_RANGE_END", "70000", "above 65535"),
        ("PLAYER_FACING_LOCALE", "taiwanese", "not BCP-47 form"),
        ("SPEC_LOCALE", "ENGLISH", "uppercase tag"),
        ("CTF_EVENT_NAME", "", "empty"),
        ("CTF_EVENT_NAME", "has space", "contains space"),
        ("AUTHOR_EMAIL", "no-at-sign", "no @ in non-empty value"),
        ("CATEGORIES", "", "empty list"),
        ("CATEGORIES", "Web,crypto", "uppercase token"),
    ],
)
def test_write_rejects_invalid_value(tmp_path: Path, key, value, reason):
    p = tmp_path / ".rules.env"
    bad = dict(VALID_15)
    bad[key] = value
    with pytest.raises(ValueError) as exc:
        rules_env.write(p, bad)
    assert key in str(exc.value), f"error must name the failing key ({reason})"


def test_write_rejects_port_range_inverted(tmp_path: Path):
    """Spec scenario: invalid port range rejected."""
    p = tmp_path / ".rules.env"
    bad = dict(VALID_15)
    bad["HOST_PORT_RANGE_START"] = "9000"
    bad["HOST_PORT_RANGE_END"] = "8000"
    with pytest.raises(ValueError) as exc:
        rules_env.write(p, bad)
    assert "HOST_PORT_RANGE_END must be >= HOST_PORT_RANGE_START" in str(exc.value)


def test_write_rejects_flag_format_literal_inconsistent_with_regex(tmp_path: Path):
    """Spec scenario: FLAG_FORMAT_LITERAL inconsistent with FLAG_REGEX rejected."""
    p = tmp_path / ".rules.env"
    bad = dict(VALID_15)
    bad["FLAG_REGEX"] = r"ISIP\.HSCTF\{\S+\}"
    bad["FLAG_FORMAT_LITERAL"] = "FLAG{<text>}"
    with pytest.raises(ValueError) as exc:
        rules_env.write(p, bad)
    msg = str(exc.value)
    assert "FLAG_FORMAT_LITERAL" in msg


def test_write_rejects_flag_regex_uncompilable(tmp_path: Path):
    p = tmp_path / ".rules.env"
    bad = dict(VALID_15)
    bad["FLAG_REGEX"] = "[unterminated"
    with pytest.raises(ValueError):
        rules_env.write(p, bad)


def test_write_normalizes_boolean_to_lowercase(tmp_path: Path):
    """Spec scenario: writer normalizes to lowercase."""
    p = tmp_path / ".rules.env"
    mixed = dict(VALID_15)
    mixed["BLOCK_PRC_VOCAB"] = "True"
    rules_env.write(p, mixed)
    text = p.read_text(encoding="utf-8")
    assert "BLOCK_PRC_VOCAB=true" in text
    assert "BLOCK_PRC_VOCAB=True" not in text


def test_load_accepts_case_insensitive_boolean(tmp_path: Path):
    p = tmp_path / ".rules.env"
    rules_env.write(p, VALID_15)
    # Now mutate one boolean to uppercase form on disk to confirm case-insensitive read.
    text = p.read_text(encoding="utf-8")
    p.write_text(text.replace("BLOCK_PRC_VOCAB=true", "BLOCK_PRC_VOCAB=TRUE"),
                 encoding="utf-8")
    parsed = rules_env.load(p)
    assert parsed["BLOCK_PRC_VOCAB"].lower() == "true"


def test_get_returns_fallback_when_file_missing(tmp_path: Path):
    p = tmp_path / ".rules.env"
    assert rules_env.get("FLAG_REGEX", fallback="DEFAULT", path=p) == "DEFAULT"


def test_get_returns_fallback_when_key_absent(tmp_path: Path):
    p = tmp_path / ".rules.env"
    rules_env.write(p, VALID_15)
    assert rules_env.get("NOT_A_KEY", fallback="X", path=p) == "X"


def test_get_returns_value_when_present(tmp_path: Path):
    p = tmp_path / ".rules.env"
    rules_env.write(p, VALID_15)
    assert rules_env.get("CTF_EVENT_NAME", path=p) == "ISIP.HSCTF"


def test_load_lazy_each_call_rereads(tmp_path: Path):
    """Spec: consumers MUST read .rules.env lazily at use-site, no cross-stage cache."""
    p = tmp_path / ".rules.env"
    rules_env.write(p, VALID_15)
    first = rules_env.load(p)
    altered = dict(VALID_15)
    altered["CTF_EVENT_NAME"] = "CHANGED"
    rules_env.write(p, altered, force=True)
    second = rules_env.load(p)
    assert first["CTF_EVENT_NAME"] == "ISIP.HSCTF"
    assert second["CTF_EVENT_NAME"] == "CHANGED"
