"""Tests for `webchall_bootstrap.py` CLI.

Covers the `webchall_bootstrap.py MUST materialize a valid .rules.env`
requirement: flag handling, default-value behavior, force-confirmation
flow, and flag-prefix derivation.
"""

from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path

import pytest

# Make scripts/ importable so we can call main() in-process.
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "scripts"))

import webchall_bootstrap as boot  # noqa: E402
from _wcm_common import rules_env  # noqa: E402


# === flag-prefix derivation (Task 3.4 / spec example) ========================


def test_derive_flag_keys_isip_hsctf():
    rx, lit = boot.derive_flag_keys("ISIP.HSCTF")
    assert rx == r"ISIP\.HSCTF\{\S+\}"
    assert lit == "ISIP.HSCTF{<text>}"


def test_derive_flag_keys_round_trips_through_validation(tmp_path: Path):
    """The derived pair MUST satisfy rules_env.validate() — i.e. the literal
    with `<text>` substituted must match the regex."""
    rx, lit = boot.derive_flag_keys("TEST.HSCTF")
    sample = lit.replace("<text>", "EXAMPLE_FLAG")
    import re
    assert re.fullmatch(rx, sample)


# === parse_port_range =========================================================


def test_parse_port_range_basic():
    assert boot.parse_port_range("8080:8099") == (8080, 8099)


def test_parse_port_range_rejects_missing_colon():
    with pytest.raises(ValueError):
        boot.parse_port_range("8080-8099")


# === main() with flags (non-interactive) ======================================


def test_main_writes_15_keys_with_flags(tmp_path: Path):
    """Spec scenario: bootstrap with flags produces all 15 keys."""
    target = tmp_path / ".rules.env"
    rc = boot.main([
        "--name", "TEST.HSCTF",
        "--long-name", "Test HSCTF",
        "--flag-prefix", "TEST.HSCTF",
        "--port-range", "8080:8099",
        "--yes",
    ], out_override=target)
    assert rc == 0
    parsed = rules_env.load(target)
    for k in rules_env.REQUIRED_KEYS:
        assert k in parsed, f"missing key: {k}"
    # Defaults applied:
    assert parsed["FLAG_TYPE"] == "static"
    assert parsed["BLOCK_PRC_VOCAB"] == "true"
    assert parsed["PLAYER_FACING_LOCALE"] == "zh-Hant-TW"


def test_main_derives_flag_regex_from_prefix(tmp_path: Path):
    """Spec example: --flag-prefix ISIP.HSCTF derives FLAG_REGEX and FLAG_FORMAT_LITERAL."""
    target = tmp_path / ".rules.env"
    rc = boot.main([
        "--name", "ISIP.HSCTF",
        "--long-name", "ISIP HSCTF",
        "--flag-prefix", "ISIP.HSCTF",
        "--port-range", "8080:8099",
        "--yes",
    ], out_override=target)
    assert rc == 0
    parsed = rules_env.load(target)
    assert parsed["FLAG_REGEX"] == r"ISIP\.HSCTF\{\S+\}"
    assert parsed["FLAG_FORMAT_LITERAL"] == "ISIP.HSCTF{<text>}"


def test_main_fails_on_invalid_port_range(tmp_path: Path, capsys):
    """Spec scenario: bootstrap fails fast on invalid port range.

    --port-range 80:8000 should be rejected (80 < PORT_MIN=1024).
    """
    target = tmp_path / ".rules.env"
    rc = boot.main([
        "--name", "TEST",
        "--long-name", "Test",
        "--flag-prefix", "TEST",
        "--port-range", "80:8000",
        "--yes",
    ], out_override=target)
    assert rc != 0
    assert not target.exists(), "no file MUST be written when validation fails"


def test_main_fails_on_inverted_port_range(tmp_path: Path):
    target = tmp_path / ".rules.env"
    rc = boot.main([
        "--name", "TEST",
        "--long-name", "Test",
        "--flag-prefix", "TEST",
        "--port-range", "9000:8000",
        "--yes",
    ], out_override=target)
    assert rc != 0
    assert not target.exists()


# === Refuse-to-overwrite + --force semantics =================================


def test_main_refuses_to_overwrite_without_force(tmp_path: Path, capsys):
    target = tmp_path / ".rules.env"
    # First write succeeds.
    rc = boot.main([
        "--name", "FIRST.CTF", "--long-name", "First CTF",
        "--flag-prefix", "FIRST.CTF", "--port-range", "8080:8099",
        "--yes",
    ], out_override=target)
    assert rc == 0
    original = target.read_text(encoding="utf-8")
    # Second invocation without --force must refuse and not modify.
    rc2 = boot.main([
        "--name", "SECOND.CTF", "--long-name", "Second CTF",
        "--flag-prefix", "SECOND.CTF", "--port-range", "8080:8099",
        "--yes",
    ], out_override=target)
    assert rc2 != 0
    assert target.read_text(encoding="utf-8") == original


def test_main_force_in_non_tty_requires_yes(tmp_path: Path):
    """Spec scenario: --force in non-interactive mode requires --yes.

    pytest's stdin is not a TTY, so --force without --yes must refuse.
    """
    target = tmp_path / ".rules.env"
    rc = boot.main([
        "--name", "FIRST.CTF", "--long-name", "First CTF",
        "--flag-prefix", "FIRST.CTF", "--port-range", "8080:8099",
        "--yes",
    ], out_override=target)
    assert rc == 0
    original = target.read_text(encoding="utf-8")
    rc2 = boot.main([
        "--name", "SECOND.CTF", "--long-name", "Second CTF",
        "--flag-prefix", "SECOND.CTF", "--port-range", "8080:8099",
        "--force",  # but no --yes
    ], out_override=target)
    assert rc2 != 0
    assert target.read_text(encoding="utf-8") == original


def test_main_force_with_yes_overwrites(tmp_path: Path):
    target = tmp_path / ".rules.env"
    boot.main([
        "--name", "FIRST.CTF", "--long-name", "First CTF",
        "--flag-prefix", "FIRST.CTF", "--port-range", "8080:8099",
        "--yes",
    ], out_override=target)
    rc = boot.main([
        "--name", "SECOND.CTF", "--long-name", "Second CTF",
        "--flag-prefix", "SECOND.CTF", "--port-range", "8080:8099",
        "--force", "--yes",
    ], out_override=target)
    assert rc == 0
    parsed = rules_env.load(target)
    assert parsed["CTF_EVENT_NAME"] == "SECOND.CTF"


# === Integration: subprocess invocation (Task 7.2 / 25) ======================


def test_subprocess_clean_tmpdir_writes_15_keys(tmp_path: Path):
    """Task 7.2: clean tmpdir → bootstrap writes .rules.env with 15 keys;
    re-running without --force exits non-zero."""
    script = ROOT / "scripts" / "webchall_bootstrap.py"
    env = dict(os.environ)
    # First invocation
    proc1 = subprocess.run(
        [sys.executable, str(script),
         "--name", "TEST.HSCTF", "--long-name", "Test HSCTF",
         "--flag-prefix", "TEST.HSCTF",
         "--port-range", "8080:8099", "--yes"],
        cwd=tmp_path,
        capture_output=True, text=True, env=env,
    )
    assert proc1.returncode == 0, proc1.stderr
    rules_file = tmp_path / ".rules.env"
    assert rules_file.exists()
    parsed = rules_env.load(rules_file)
    for k in rules_env.REQUIRED_KEYS:
        assert k in parsed
    # Second invocation without --force must refuse.
    proc2 = subprocess.run(
        [sys.executable, str(script),
         "--name", "OTHER.CTF", "--long-name", "Other CTF",
         "--flag-prefix", "OTHER.CTF",
         "--port-range", "8080:8099", "--yes"],
        cwd=tmp_path,
        capture_output=True, text=True, env=env,
    )
    assert proc2.returncode != 0


def test_subprocess_help_works():
    """Spec: 'All entry points respond to --help'."""
    script = ROOT / "scripts" / "webchall_bootstrap.py"
    proc = subprocess.run(
        [sys.executable, str(script), "--help"],
        capture_output=True, text=True,
    )
    assert proc.returncode == 0
    assert "webchall_bootstrap" in proc.stdout
