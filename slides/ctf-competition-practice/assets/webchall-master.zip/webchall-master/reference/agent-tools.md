# Cross-runtime tool mapping

This is the **only** file in `webchall-master/` allowed to name specific
host-agent tools. SKILL.md, SKILL.zhTW.md, and AGENTS.md keep tool names out
of their normative text so the skill stays portable. When a runtime needs to
launch an audit sub-agent or read a file, look up the equivalent here.

## Tool equivalence table

| Concept | Claude Code | Codex CLI | Gemini CLI | Copilot CLI |
|---|---|---|---|---|
| Read a file | `Read` | `read_file` | `read_file` | `read` |
| Write a file | `Write` | `write_file` | `write_file` | `write` |
| Edit a file | `Edit` | `edit_file` (str-replace) | `replace` | `edit` |
| List files via glob | `Glob` | `list_files` (glob) | `glob` | `glob` |
| Search file contents | `Grep` | `search_text` | `search_file_content` | `grep` |
| Run a shell command | `Bash` | `run_shell` | `run_shell_command` | `shell` |
| Spawn a sub-agent | `Agent` (Task) | `spawn_agent` | `task` (subagent) | `task` |
| Ask the user a question | `AskUserQuestion` | (text prompt) | (text prompt) | (text prompt) |
| Fetch a web page | `WebFetch` | `web_fetch` | `web_fetch` | `web` |
| Web search | `WebSearch` | `web_search` | `google_web_search` | `web --search` |

## Audit sub-agent invocation by runtime

Each stage of the seven-stage pipeline ends with a sub-agent that loads one of
the three persona prompts under `reference/audit-personas/`. The persona file
is the agent's only instruction; the host runtime supplies the diff or
challenge directory as context.

### Claude Code

```
Agent({
  description: "<Stage> audit",
  subagent_type: "general-purpose",
  prompt: "<read reference/audit-personas/<persona>.md verbatim, then audit
   the challenge at <slug>/. Report PASS / ADVISORY / FAIL with reasoning.>"
})
```

### Codex / Copilot / Gemini

Spawn a fresh agent (or task) with the persona prompt content as the system
instruction; pass the challenge path as the user message. The Python helper
`scripts/webchall_manifest.py append-audit-verdict` records the result.

## Why this file matters

The `webchall-cross-model-lint` validator extension (registered in
`profile.yaml`) refuses to run if `SKILL*.md` or `AGENTS.md` mention any of
the tool names listed in this file's left two columns. This is enforced at
`webchall_wiki.py verify --cross-model-lint`. Mentions are allowed here
because this file is a reference, not a directive.
