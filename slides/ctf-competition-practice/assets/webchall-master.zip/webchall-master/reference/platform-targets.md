# Platform target adapters

`webchall_publish.py` emits a primary `challenge.yml` (CTFd ctfcli format) plus
two adapter files: `adapters/rctf.yml` and `adapters/picoctf.yml`. This file
documents the field mapping and the differences between platforms so authors
understand what is dropped or transformed.

## CTFd ctfcli (primary)

The canonical format. Every other adapter is derived from it.

Required: `name`, `author`, `category`, `description`, `attribution`, `value`,
`type`, `version`. Container fields: `image`, `protocol`, `host`. Content
arrays: `flags`, `topics`, `tags`, `files`, `hints`, `requirements`. Optional:
`connection_info`, `healthcheck`, `solution`, `attempts`, `logic`, `state`,
`next`, `extra` (for dynamic challenges).

## rCTF

rCTF uses a flatter schema centered on `name`, `category`, `description`,
`points`, `flag`. It does NOT support per-flag `data` / `type` objects, NOR
the CTFd `extra` block, NOR `requirements`. The publisher MUST:

- Map `value` → `points`.
- Collapse `flags[].content` into a single `flag` string when the manifest's
  `flag_logic` is `any`. If `flag_logic` is `all`, emit a warning and pick
  the canonical flag (the first one).
- Drop `topics`, `hints`, `requirements`. Record each dropped field in the
  publisher's run report.

## picoCTF

picoCTF challenges use a directory layout with a `problem.json` (or
`problem.md` with frontmatter) carrying `name`, `description`, `flag`,
`category`, `points`, `hints`, and an `author`. picoCTF does NOT support the
`type: dynamic` decay model out of the box. The publisher MUST:

- Map `value` → `points`.
- Map ctfcli `extra.initial`/`extra.minimum`/`extra.decay` → drop with a
  warning if `type: dynamic`. Static value is preserved.
- Translate `attempts` → `instance.max_attempts` if non-default.

## Field mapping table

| ctfcli field | rCTF field | picoCTF field | Notes |
|---|---|---|---|
| `name` | `name` | `name` | Identical |
| `author` | `author` | `author` | Identical |
| `category` | `category` | `category` | Free-form string in all three |
| `description` | `description` | `description` | Markdown allowed everywhere |
| `value` | `points` | `points` | Integer rename |
| `type` | (none) | (none) | Adapters drop; `dynamic` decay loses fidelity |
| `flags[].content` | `flag` (single) | `flag` (single) | Collapsed; first flag wins on `all` |
| `topics` | (dropped) | `tags` (merged with `tags`) | rCTF drops; picoCTF merges into single tag list |
| `tags` | `tags` | `tags` | Merged with `topics` for picoCTF |
| `hints[]` | (dropped) | `hints[]` | rCTF drops |
| `files[]` | `files[]` | `files[]` | Identical semantics |
| `attempts` | (dropped) | `instance.max_attempts` | rCTF drops |
| `requirements` | (dropped) | (dropped) | Both drop |
| `state` | (dropped) | (dropped) | Both drop |
| `extra.initial` etc. | (dropped) | (dropped) | Both drop with warning |

## Validator behavior

`webchall_validate.py` checks that the primary `challenge.yml` parses against
the CTFd ctfcli schema. The two adapter files are validated against their own
minimal schemas (name + flag + points + category required). A drop with a
recorded warning never fails strict mode; a missing required field in any
adapter does.
