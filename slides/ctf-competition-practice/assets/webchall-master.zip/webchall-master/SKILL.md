---
name: webchall-master
description: "Author production-grade Web Exploitation CTF challenges. Use when the user asks to 出 web ctf 題、create a web exploitation challenge, scaffold a Flask/FastAPI/PHP/Node.js/nginx/apache CTF, design a SSTI/SQLi/SSRF/RCE challenge, validate or analyze an existing challenge for unintended solves, publish a challenge bundle for CTFd/rCTF/picoCTF. Drives a fixed seven-stage pipeline (Brief → Design → Scaffold → Implement → Analyze → Validate → Publish) with a sub-agent audit gate after every stage. Do NOT trigger when the user is only reading or explaining the bundled scripts, only inspecting the wiki, or asking conceptual questions without intent to author or operate on a challenge."
license: MIT
compatibility:
  system_packages:
    - "Python 3.10+"
    - "Docker (only required for the runtime fuzz phase of webchall_analyze.py)"
  python_packages:
    - "pyyaml>=6.0"
    - "jinja2>=3.1"
    - "httpx>=0.27"
metadata:
  author: webchall-master
  version: "0.1"
  generatedBy: "Spectra"
---

> **English** | [繁體中文](SKILL.zhTW.md)

# Overview

`webchall-master` is a user-skill that authors Web Exploitation CTF challenges
end-to-end. It bundles:

- A seven-stage authoring pipeline (Brief → Design → Scaffold → Implement →
  Analyze → Validate → Publish), with a mandatory adversary audit at every stage
  boundary.
- A Karpathy-style three-layer LLM Wiki under `wiki/` covering OWASP Top 10
  (2025 RC, 2021, 2017), OWASP API Top 10 2023, all 31 PortSwigger Web Security
  Academy topics, and a 2024–2025 sweep of framework CVEs (Flask/Werkzeug,
  FastAPI/Starlette, PHP, Node.js/Express, nginx, Apache HTTP Server).
- Seven Python CLI entry points under `scripts/`: `webchall_init`,
  `webchall_analyze` (static AST + runtime HTTP fuzz), `webchall_validate`
  (strict rule catalog with `--soft` downgrade), `webchall_publish`,
  `webchall_manifest`, `webchall_wiki`, and `webchall_bootstrap` (event
  setup — generates `.rules.env`).
- Per-stack templates that ship BOTH a single `Dockerfile` (per-user dynamic
  instance launch during the live event) AND a `docker-compose.yml` (post-event
  redeploy).

The skill is host-agent-neutral: this file contains only imperative-mood prose
and references CLIs by shell-invocation form. See `reference/agent-tools.md`
for the cross-runtime tool mapping (Claude Code ⇄ Codex ⇄ Gemini ⇄ Copilot CLI).

# When to use

Activate this skill when the author wants to:

- Scaffold a new web challenge for a CTF event.
- Run static + fuzz analysis against an existing challenge directory.
- Validate that a challenge is shippable (CTFd ctfcli + rCTF + picoCTF schema).
- Build a redacted `publish/` tree for distribution.
- Query the bundled vulnerability wiki (lookup by OWASP id, PortSwigger topic,
  framework, or CVE).

Do NOT activate when:

- The user is reading source code without intent to author.
- The user is asking conceptual questions about web vulnerabilities (the wiki
  alone can answer those — point them at it).

# Prerequisites

Run from the project where the challenge will live (any workspace). Python 3.10+
with `pyyaml`, `jinja2`, and `httpx`. Docker is only required for the runtime
fuzz phase; pass `--no-runtime` to skip it.

# Stage 0 precondition: `.rules.env` at the event repo root

Before any pipeline stage runs, verify that `.rules.env` exists at the CTF
event repository root (the working directory the skill is invoked from). The
file is event-scoped — one per CTF event, shared by all `<slug>/` challenges
in that event — and declares the 15-key schema defined by the
`webchall-rules-env` capability.

If the file is missing or malformed, Stage 1 (Brief) MUST exit with status
code 2 and instruct the author to bootstrap it:

```sh
python <skill-dir>/scripts/webchall_bootstrap.py \
    --name TEST.HSCTF --long-name 'Test HSCTF' \
    --flag-prefix TEST.HSCTF --port-range 8080:8099 --yes
```

The host agent (Claude or any other supported runtime) MUST read `.rules.env`
at the start of each skill session and use its values for the four downstream
decision points:

1. **Player-facing text** — apply `PLAYER_FACING_LOCALE`, `BLOCK_PRC_VOCAB`,
   and `ENFORCE_ANTI_AI_SLOP` when generating problem pages, hints, README
   content, and any other text shown to players.
2. **Flag formats** — use `FLAG_REGEX` and `FLAG_FORMAT_LITERAL` whenever
   crafting or validating canonical flags; do not invent ad-hoc flag formats.
3. **Host port allocation** — keep new challenge port assignments inside
   `[HOST_PORT_RANGE_START, HOST_PORT_RANGE_END]` to avoid collisions with
   sibling challenges in the same event.
4. **Validation hints** — surface `CATEGORIES`, `DIFFICULTIES`, `FLAG_TYPE`,
   and `FLAG_ASSET_VERSION_CONTROLLED` when prompting the author to fill in
   `challenge.yml` and the manifest.

Downstream stage entry points (`webchall_analyze.py`, `webchall_validate.py`,
`webchall_publish.py`) accept a missing `.rules.env` and fall back to
documented defaults, preserving operability for previously archived
challenges.

# Seven-stage pipeline

Each stage takes input from `.webchall.manifest.yaml` (the per-challenge state
file) and writes its output back to disk before yielding control. Every stage
ends with a sub-agent audit gate using one of the three personas in
`reference/audit-personas/`. The skill MUST NOT advance to stage N+1 until
stage N's audit verdict is `pass` or `advisory`.

| Stage | Input | CLI | Output | Audit persona |
|---|---|---|---|---|
| 1. Brief | author intent | (interactive) | manifest seeded with stack, vuln class, difficulty, theme, flag format | Confused Player |
| 2. Design | brief manifest | `webchall_wiki.py find` | manifest's `recipe_id` + `concept_refs` populated | Unintended Solver |
| 3. Scaffold | manifest | `webchall_init.py --stack <s> --recipe <r> --slug <slug>` | `<slug>/src/`, `<slug>/publish/`, `<slug>/solution/`, `.webchall.manifest.yaml` | Confused Player |
| 4. Implement | scaffolded tree | (author edits source + writes `solution/solve.py`) | working vulnerable challenge + reference exploit | All three personas |
| 5. Analyze | challenge dir | `webchall_analyze.py <slug>/` | static + runtime findings JSON / SARIF | Unintended Solver |
| 6. Validate | challenge dir | `webchall_validate.py <slug>/` | strict rule pass; non-zero exit on any failure | Brute-Forcer |
| 7. Publish | challenge dir | `webchall_publish.py <slug>/` | `<slug>/publish/` + `<slug>/adapters/{ctfcli,rctf,picoctf}.yml` | Unintended Solver |

After every stage, run:

```sh
python <skill-dir>/scripts/webchall_manifest.py mark-stage-complete <slug>/ <stage>
python <skill-dir>/scripts/webchall_manifest.py append-audit-verdict <slug>/ <stage> <pass|advisory|fail>
```

A `fail` verdict blocks advancement until the issue is remediated and a
follow-up audit returns `pass` or `advisory`.

# Cross-context / cross-session / cross-model

- **Per-challenge state** lives in `<slug>/.webchall.manifest.yaml`. Re-entering
  the skill against an existing slug detects the manifest, summarizes completed
  stages, and resumes from the first incomplete one.
- **Cross-challenge memory** lives in `wiki/log.md` (append-only ingest log).
- **Cross-model**: this file plus `SKILL.zhTW.md` and `AGENTS.md` use only
  imperative Markdown and shell-invocation references. See
  `reference/agent-tools.md` for the cross-runtime tool map.

# Wiki contract (Karpathy three-layer)

- `wiki/raw/` — Layer 1, immutable raw sources. Never edit; ingest a new
  fetched-date file when upstream changes.
- `wiki/{taxonomies,concepts,frameworks,cves,recipes}/` — Layer 2, agent-maintained
  compiled pages. Frontmatter schema enforced by `profile.yaml`.
- `AGENTS.md` — Layer 3, the discipline document that binds the wiki together.

Run `webchall_wiki.py verify` to enforce all invariants (schema conformance,
dead cross-link detection, raw-file SHA-256 immutability, CVE coverage,
cross-model lint).

# Quick reference

```sh
# Bootstrap a new challenge
python <skill-dir>/scripts/webchall_init.py --stack flask --recipe flask-ssti-jinja-cycler --slug demo-ssti

# Wiki lookup
python <skill-dir>/scripts/webchall_wiki.py find --portswigger server-side-template-injection

# Analyze + validate
python <skill-dir>/scripts/webchall_analyze.py demo-ssti/
python <skill-dir>/scripts/webchall_validate.py demo-ssti/

# Publish
python <skill-dir>/scripts/webchall_publish.py demo-ssti/
```
