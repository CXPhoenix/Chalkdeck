# Cross-runtime tool mapping

This is the **only** file in `bluechall-master/` allowed to name specific
host-agent tools. SKILL.md, SKILL.zhTW.md, and AGENTS.md keep tool names out
of their normative text so the skill stays portable. When a runtime needs to
launch an audit sub-agent or read a file, look up the equivalent here.

## Tool equivalence table

| Concept | Claude Code | Codex CLI | Gemini CLI | Copilot CLI |
|---|---|---|---|---|
| Read a file | `Read` | `read_file` | `read_file` | `read` |
| Write a file | `Write` | `write_file` | `write_file` | `write` |
| Edit a file | `Edit` | `edit_file` (str-replace) | `replace` | `edit` |
| List files via glob | `Glob` | `list_files` (glob) | `glob` | `glob` |
| Search file contents | `Grep` | `search_text` | `search_file_content` | `grep` |
| Run a shell command | `Bash` | `run_shell` | `run_shell_command` | `shell` |
| Spawn a sub-agent | `Agent` (Task) | `spawn_agent` | `task` (subagent) | `task` |
| Ask the user a question | `AskUserQuestion` | (text prompt) | (text prompt) | (text prompt) |
| Fetch a web page | `WebFetch` | `web_fetch` | `web_fetch` | `web` |
| Web search | `WebSearch` | `web_search` | `google_web_search` | `web --search` |

## Audit sub-agent invocation by runtime

Each stage of the seven-stage pipeline ends with a sub-agent that loads one or
more of the six persona prompts under `reference/audit-personas/`. The persona
file is the agent's only instruction; the host runtime supplies the diff or
challenge directory as context.

The six personas are:

- `confused-player.md` — unfamiliarity-driven blockers (inherited from webchall)
- `unintended-solver.md` — leak surface scanning (inherited)
- `brute-forcer.md` — enumeration / default credentials / public PoC (inherited)
- `tool-grep-solver.md` — strings / binwalk -e / zsteg -a one-shot defeat (new)
- `decompiler-trust.md` — un-stripped binary, debug printf, F5-readable logic (new)
- `attack-skipper.md` — blue-team multi-question chain shortcut (new)

### Claude Code

```
Agent({
  description: "<Stage> audit",
  subagent_type: "general-purpose",
  prompt: "<read reference/audit-personas/<persona>.md verbatim, then audit
   the challenge at <slug>/. Report PASS / ADVISORY / FAIL with reasoning.>"
})
```

### Codex / Copilot / Gemini

Spawn a fresh agent (or task) with the persona prompt content as the system
instruction; pass the challenge path as the user message. The Python helper
`scripts/bluechall_manifest.py append-audit-verdict` records the result.

## Why this file matters

The `bluechall-cross-model-lint` validator extension (registered in
`profile.yaml`) refuses to run if `SKILL*.md` or `AGENTS.md` mention any of
the tool names listed in this file's left-most data column (the Concept ⇄
Claude Code mapping). This is enforced at
`bluechall_wiki.py verify --cross-model-lint`. Mentions are allowed here
because this file is a reference, not a directive.

## Note on bluechall-specific divergence from webchall

Both `webchall-master` and `bluechall-master` use the same cross-runtime tool
mapping. The skills are sister skills sharing the same authoring discipline.
The only structural difference is that bluechall has six audit personas
(webchall has three): the new three (`tool-grep-solver`, `decompiler-trust`,
`attack-skipper`) target attack surfaces unique to forensics, reverse, and
blue-team challenges respectively, and have no analogue in offensive web
challenges.
