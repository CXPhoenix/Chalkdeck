# bluechall-master — Platform Targets reference

This document is the canonical mapping reference for the four publish
adapters emitted by `bluechall_publish.py`. Each section names the target
platform, the canonical → adapter field mapping, the documented schema
(where applicable), and the Sherlocks YAML schema in full.

`bluechall_publish.py <slug>/` derives all four outputs from a single
canonical CTFd ctfcli form. Do **not** hand-edit `<slug>/adapters/*.yml`
— regenerate from manifest changes.

---

## CTFd ctfcli (canonical reference)

**Output:** `<slug>/adapters/ctfcli.yml`

**Source:** the manifest plus, for `flag_emission: questions-as-flags`,
the per-question entries from `<slug>/solution/questions.yaml`.

**Single-static / service-derived / multi-stage-pivot** emit a single
top-level mapping. **questions-as-flags** emit a YAML *list* with one
entry per question (each entry is a complete CTFd challenge in its own
right; see "Sub-challenge flattening" below).

Field reference (single mapping form):

| CTFd ctfcli field    | Source                                                    |
| -------------------- | --------------------------------------------------------- |
| `name`               | derived from `manifest.slug` (kebab → Title Case)         |
| `author`             | `manifest.author` (default `bluechall-master`)            |
| `category`           | `manifest.category` (one of forensics / reverse / blue-team / misc) |
| `description`        | `manifest.description` (or fallback to README pointer)    |
| `value`              | `manifest.value` (default 100)                            |
| `type`               | `manifest.type` (default `standard`; can be `dynamic`)    |
| `version`            | `manifest.version` (default `0.1`)                        |
| `state`              | `manifest.state` (default `visible`)                      |
| `topics`             | `manifest.topics` (free-form list)                        |
| `tags`               | `manifest.tags`                                           |
| `hints`              | `manifest.hints` (list of strings)                        |
| `requirements`       | `manifest.requirements` (challenge prerequisites)         |
| `flags`              | `[manifest.canonical_flag]` (single-element list)         |
| `connection_info`    | `manifest.connection_info` (only when emission=service-derived) |

### Sub-challenge flattening (questions-as-flags)

When `manifest.flag_emission == "questions-as-flags"`, each entry in
`solution/questions.yaml` becomes a separate ctfcli challenge entry:

| Per-question field        | Mapping                                                       |
| ------------------------- | ------------------------------------------------------------- |
| `name`                    | `<base name> — q1`                                            |
| `description`             | base description + `\n\n**Question:** <question text>`        |
| `flags`                   | `[answer]`                                                    |
| `value`                   | `points` (per-question; falls back to base `value`)           |
| `tags`                    | base tags + `attack:T<NNNN>` + `nist:<phase>`                 |

5 questions → 5 ctfcli entries → 5 sub-challenges in CTFd.

---

## rCTF

**Output:** `<slug>/adapters/rctf.yml`

**Derivation:** from CTFd canonical, with the following transforms:

- `flags` (list) → `flag` (single string; first element wins)
- `hints` → **dropped** (rCTF has no native hints field)
- `requirements` → **dropped** (rCTF has no requirement chain)
- `topics` → **dropped** (rCTF only uses `tags`)
- `type`, `version`, `state` → **dropped** (rCTF has no equivalents)
- `connection_info` → **dropped**

The publisher emits one stderr advisory line per dropped field type so
authors see what got lost in translation. Multi-question challenges
emit one rCTF entry per question.

| rCTF field    | Source from CTFd canonical |
| ------------- | -------------------------- |
| `name`        | `name`                     |
| `category`    | `category`                 |
| `description` | `description`              |
| `value`       | `value`                    |
| `tags`        | `tags`                     |
| `flag`        | `flags[0]`                 |

---

## picoCTF

**Output:** `<slug>/adapters/picoctf.yml`

**Derivation:** from CTFd canonical, with picoCTF-specific transforms:

- `type: dynamic` + `value_decay` → **stripped**; emit static `value` only
- `attempts` (manifest-level) → `instance.max_attempts`
- Layout convention: published bundle expected at
  `<slug>/{problem.json, description.md, handout/}` (the publish CLI
  writes the YAML form; renaming + restructuring is downstream tooling).

| picoCTF field         | Source from CTFd canonical            |
| --------------------- | ------------------------------------- |
| `name`                | `name`                                |
| `category`            | `category`                            |
| `description`         | `description`                         |
| `value`               | `value` (int; never `dynamic`)        |
| `flag`                | `flags[0]`                            |
| `author`              | `author`                              |
| `hints`               | `hints` (picoCTF DOES support hints)  |
| `tags`                | `tags`                                |
| `instance.max_attempts` | `manifest.attempts` if set          |

---

## Sherlocks-Q YAML

**Output:** `<slug>/adapters/sherlocks.yml` — emitted **only when**
`manifest.flag_emission == "questions-as-flags"`. For all other emission
modes the publisher emits a stderr advisory and skips the file.

This is bluechall-master's documented Sherlocks-style multi-question
schema, modeled after HackTheBox Sherlocks but normalized for cross-
platform use:

```yaml
name: <Title Cased slug>
category: blue-team
scenario: |
  <multi-line player-facing narrative paragraph>
objectives:
  - id: q1
    question: <question text>
    answer: <FLAG{...}>
    attack_technique: <TNNNN[.NNN]>
    points: <int>
    nist_phase: <collection|examination|analysis|reporting>
  - id: q2
    ...
artifacts:
  - <relative path to handout file>
```

### Schema field-by-field

| Field                              | Type    | Required | Notes                                                   |
| ---------------------------------- | ------- | -------- | ------------------------------------------------------- |
| `name`                             | string  | yes      | Derived from manifest.slug                              |
| `category`                         | string  | yes      | Always `blue-team` (Sherlocks-flavored)                 |
| `scenario`                         | string  | yes      | Player-facing narrative; no flag references             |
| `objectives`                       | list    | yes      | One entry per question                                  |
| `objectives[].id`                  | string  | yes      | Stable identifier (`q1`, `q2`, ...)                     |
| `objectives[].question`            | string  | yes      | Player-facing question                                  |
| `objectives[].answer`              | string  | yes      | Canonical answer matching FLAG_REGEX                    |
| `objectives[].attack_technique`    | string  | yes      | MITRE ATT&CK technique id (e.g. `T1055`, `T1071.001`)   |
| `objectives[].points`              | int     | yes      | Per-question score weight                               |
| `objectives[].nist_phase`          | string  | yes      | One of `collection|examination|analysis|reporting`      |
| `artifacts`                        | list    | yes      | List of relative paths to handout files                 |

### Validation contract

Per the spec `bluechall-flag-emission`:

- Every `objectives[].attack_technique` MUST exist in the MITRE ATT&CK
  version pinned by `.rules.env` `MITRE_ATTACK_VERSION`.
- The number of objectives MUST be ≤ `BLUE_TEAM_QUESTION_LIMIT`.
- Per-question `points` MUST be > 0.

Validation is performed by `bluechall_validate.py` before `publish` is
allowed to run; the publisher does not re-check these invariants.

---

## Flag redaction (applies to all 4 adapters)

Before each adapter file is written, the publisher walks the parsed YAML
payload and replaces the canonical flag (and its base64 / base32 / hex /
urlencoded / rot13 encodings, length ≥ 6 chars) with `FLAG{REDACTED}` in
every string value EXCEPT under `flag` / `flags` / `answer` keys (which
are *supposed* to contain the flag). On any non-flag-field hit the
publisher emits a stderr CRITICAL line naming the file and the encoding,
and exits 1 — the adapter is still written with redaction applied, but
the author MUST fix the source so the next run is clean.

This is enforced by `_bcm_common/publish.py::redact_flag_in_payload`.

---

## Adding a new platform target (process)

1. Add the field mapping table to this document under a new heading.
2. Implement `build_<platform>(canonical, manifest)` in
   `_bcm_common/publish.py`.
3. Wire the new file into `bluechall_publish.py main`.
4. Add a test in `tests/test_publish.py` covering at minimum:
   the field mapping, any dropped/transformed fields with stderr
   signal, and a flag-leak redaction case.
5. Update `bluechall-publish-adapters/spec.md` with the new adapter's
   normative requirements before merging.
