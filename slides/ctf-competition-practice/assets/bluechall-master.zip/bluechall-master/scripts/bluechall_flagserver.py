#!/usr/bin/env python3
"""bluechall_flagserver — generate an HMAC per-team flag-server stub for a
challenge with `flag_emission: service-derived`.

The generated stub is a small Flask HTTP server (default) or asyncio TCP
socket server (`--variant tcp`) that accepts a `team_id` token, derives the
per-team flag via HMAC-SHA256(secret_key, team_id), formats it according to
`FLAG_FORMAT_LITERAL`, and returns it. The stub ships with a Dockerfile and
healthcheck so the lab orchestrator can wait-for-ready.

Generated artifacts (under `<slug>/service/`):
  - server.py        Flask or asyncio TCP server
  - Dockerfile       Python:3.12-slim base
  - healthcheck.sh   Probes the configured endpoint
  - service_meta.yaml  Records port, variant, hmac_key_source for validate
"""

from __future__ import annotations

import argparse
import re
import secrets
import sys
import textwrap
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from _bcm_common import rules_env  # noqa: E402


EXIT_OK = 0
EXIT_USER_ERROR = 1

# Strict allowlist for FLAG_FORMAT_LITERAL: a short prefix made of
# identifier-safe characters, then the literal `{<text>}` placeholder.
# This blocks template-injection payloads that, prior to the regex,
# could embed quotes / Python source / shell metacharacters into the
# generated `server.py`.
_FLAG_FORMAT_LITERAL_RE = re.compile(r"^[A-Za-z0-9._-]{1,32}\{<text>\}$")
# Slug name regex (defence in depth for the rendered SLUG comment).
_SLUG_RE = re.compile(r"^[a-z0-9][a-z0-9-]*[a-z0-9]$")


FLASK_SERVER_TEMPLATE = '''\
"""Per-team flag service for {SLUG}.

Listens on PORT and exposes:
  GET /flag?team_id=<token>   -> returns HMAC(secret, team_id) formatted flag.
  GET /healthz                -> 200 OK once startup completes.

Note: this stub provides NO authentication and NO rate limiting. Front it
with a reverse proxy that enforces both before exposing it publicly.
"""

import hashlib
import hmac
import os
import sys

try:
    from flask import Flask, request, jsonify
except ImportError:
    print("error: Flask not installed; pip install flask", file=sys.stderr)
    sys.exit(1)

# Cap team_id length to bound the HMAC input and prevent trivial DoS via
# multi-megabyte query strings.
TEAM_ID_MAX_LEN = 128

app = Flask(__name__)
PORT = int(os.environ.get("FLAG_SERVER_PORT", "{PORT}"))
SECRET = os.environ.get("FLAG_SERVER_SECRET", "").encode("utf-8")
FLAG_FORMAT_LITERAL = os.environ.get("FLAG_FORMAT_LITERAL", {FLAG_FORMAT_LITERAL_REPR})
TRUNCATE_TO = int(os.environ.get("HMAC_TRUNCATE_TO", "{TRUNCATE_TO}"))

if not SECRET:
    print("error: FLAG_SERVER_SECRET environment variable is required", file=sys.stderr)
    sys.exit(2)


def derive_flag(team_id: str) -> str:
    digest = hmac.new(SECRET, team_id.encode("utf-8"), hashlib.sha256).hexdigest()
    truncated = digest[:TRUNCATE_TO]
    return FLAG_FORMAT_LITERAL.replace("<text>", truncated)


@app.route("/flag")
def flag():
    team_id = request.args.get("team_id", "").strip()
    if not team_id:
        return jsonify({{"error": "team_id query parameter is required"}}), 400
    if len(team_id) > TEAM_ID_MAX_LEN:
        return jsonify({{"error": f"team_id exceeds {{TEAM_ID_MAX_LEN}} bytes"}}), 400
    return jsonify({{"flag": derive_flag(team_id)}}), 200


@app.route("/healthz")
def healthz():
    return "ok\\n", 200


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=PORT)
'''

ASYNCIO_TCP_SERVER_TEMPLATE = '''\
"""Per-team TCP flag service for {SLUG}.

Listens on PORT. Each connection sends a single line containing the team id;
the server replies with the derived flag and closes the connection.

Note: this stub provides NO authentication and NO rate limiting. Front it
with a reverse proxy that enforces both before exposing it publicly.
"""

import asyncio
import hashlib
import hmac
import os

# Cap team_id read so a single connection cannot exhaust memory or block
# the event loop with a multi-megabyte unterminated line.
TEAM_ID_MAX_BYTES = 256

PORT = int(os.environ.get("FLAG_SERVER_PORT", "{PORT}"))
SECRET = os.environ.get("FLAG_SERVER_SECRET", "").encode("utf-8")
FLAG_FORMAT_LITERAL = os.environ.get("FLAG_FORMAT_LITERAL", {FLAG_FORMAT_LITERAL_REPR})
TRUNCATE_TO = int(os.environ.get("HMAC_TRUNCATE_TO", "{TRUNCATE_TO}"))


def derive_flag(team_id: str) -> str:
    digest = hmac.new(SECRET, team_id.encode("utf-8"), hashlib.sha256).hexdigest()
    truncated = digest[:TRUNCATE_TO]
    return FLAG_FORMAT_LITERAL.replace("<text>", truncated)


async def handle(reader: asyncio.StreamReader, writer: asyncio.StreamWriter) -> None:
    try:
        try:
            line = await reader.readuntil(b"\\n")
        except asyncio.IncompleteReadError as e:
            line = e.partial
        except asyncio.LimitOverrunError:
            writer.write(b"error: team_id exceeds line length limit\\n")
            await writer.drain()
            return
        if len(line) > TEAM_ID_MAX_BYTES:
            writer.write(b"error: team_id exceeds size cap\\n")
            await writer.drain()
            return
        team_id = line.decode("utf-8", errors="replace").strip()
        if not team_id:
            writer.write(b"error: empty team_id\\n")
        else:
            writer.write((derive_flag(team_id) + "\\n").encode("utf-8"))
        await writer.drain()
    finally:
        writer.close()


async def main() -> None:
    if not SECRET:
        raise SystemExit("error: FLAG_SERVER_SECRET environment variable is required")
    server = await asyncio.start_server(handle, "0.0.0.0", PORT)
    async with server:
        await server.serve_forever()


if __name__ == "__main__":
    asyncio.run(main())
'''

DOCKERFILE_TEMPLATE = """\
# bluechall-master flag service for {SLUG} ({VARIANT})
FROM python:3.12-slim
WORKDIR /srv

# Run as non-root for safety.
RUN useradd --create-home --shell /usr/sbin/nologin svc
{EXTRA_INSTALL}
COPY server.py /srv/server.py
COPY healthcheck.sh /srv/healthcheck.sh
RUN chmod +x /srv/healthcheck.sh && chown -R svc /srv
USER svc

ENV FLAG_SERVER_PORT={PORT}
EXPOSE {PORT}

HEALTHCHECK --interval=10s --timeout=3s --retries=5 CMD /srv/healthcheck.sh

CMD ["python", "server.py"]
"""

HEALTHCHECK_HTTP = """\
#!/bin/sh
# HTTP /healthz probe.
PORT="${FLAG_SERVER_PORT:-{PORT}}"
exec python -c "
import urllib.request, sys
try:
    r = urllib.request.urlopen(f'http://127.0.0.1:{PORT}/healthz', timeout=2)
    sys.exit(0 if r.status == 200 else 1)
except Exception:
    sys.exit(1)
"
"""

HEALTHCHECK_TCP = """\
#!/bin/sh
# TCP banner probe — open a connection and accept any reply (or non-error close).
PORT="${FLAG_SERVER_PORT:-{PORT}}"
exec python -c "
import socket, sys
try:
    s = socket.create_connection(('127.0.0.1', {PORT}), timeout=2)
    s.close()
    sys.exit(0)
except Exception:
    sys.exit(1)
"
"""


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(prog="bluechall_flagserver", description=__doc__)
    p.add_argument("slug_dir", help="path to the challenge slug directory")
    p.add_argument("--variant", choices=("http", "tcp"), default="http",
                   help="server variant (default: http via Flask)")
    p.add_argument("--port", type=int, required=True,
                   help="port to bind (must be inside EXTERNAL_FLAG_SERVICE port range)")
    p.add_argument("--secret-key", dest="secret_key", default=None,
                   help="HMAC secret (default: 64-byte secrets.token_hex())")
    p.add_argument("--flag-format-literal", dest="flag_format_literal",
                   default=None,
                   help="FLAG_FORMAT_LITERAL override (default: from .rules.env)")
    p.add_argument("--truncate-to", dest="truncate_to", type=int, default=16,
                   help="HMAC hex digest truncation length (default: 16)")
    p.add_argument("--force", action="store_true",
                   help="overwrite an existing service/ directory")
    args = p.parse_args(argv)

    slug_dir = Path(args.slug_dir).resolve()
    if not slug_dir.exists():
        print(f"error: slug directory {slug_dir} does not exist", file=sys.stderr)
        return EXIT_USER_ERROR
    # The slug name lands inside the rendered server.py docstring; reject
    # any value that doesn't match the canonical kebab-case slug regex so
    # an attacker can't smuggle Python source via `Path("foo'); ...")`.
    if not _SLUG_RE.match(slug_dir.name):
        print(
            f"error: slug name {slug_dir.name!r} must match "
            "^[a-z0-9][a-z0-9-]*[a-z0-9]$",
            file=sys.stderr,
        )
        return EXIT_USER_ERROR

    # Discover .rules.env for flag-format and external port range validation.
    rules_path = slug_dir.parent / rules_env.DEFAULT_FILENAME
    rules: dict[str, str] = {}
    if rules_path.exists():
        try:
            rules = rules_env.load(rules_path)
        except ValueError as e:
            print(f"warning: .rules.env at {rules_path} did not parse: {e}",
                  file=sys.stderr)

    flag_format_literal = (
        args.flag_format_literal
        or rules.get("FLAG_FORMAT_LITERAL")
        or "FLAG{<text>}"
    )
    # The literal is rendered verbatim into a generated Python source file,
    # so values containing quotes / parens / interpreter directives must
    # not be allowed even after the `<text>` substring requirement is met.
    # Limit to the canonical CTF flag-prefix grammar: `<prefix>{<text>}`
    # where prefix is a moderately-sized identifier-ish string.
    if not _FLAG_FORMAT_LITERAL_RE.match(flag_format_literal):
        print(
            f"error: --flag-format-literal {flag_format_literal!r} must "
            "match ^[A-Za-z0-9._-]{1,32}\\{<text>\\}$ "
            "(prefix plus literal `<text>` placeholder, no quoting)",
            file=sys.stderr,
        )
        return EXIT_USER_ERROR

    if rules:
        try:
            ext_start = int(rules.get("EXTERNAL_FLAG_SERVICE_PORT_RANGE_START", "0"))
            ext_end = int(rules.get("EXTERNAL_FLAG_SERVICE_PORT_RANGE_END", "0"))
        except ValueError:
            ext_start = ext_end = 0
        if ext_start > 0 and not (ext_start <= args.port <= ext_end):
            print(
                f"error: --port {args.port} is outside "
                f".rules.env EXTERNAL_FLAG_SERVICE port range "
                f"[{ext_start}, {ext_end}]",
                file=sys.stderr,
            )
            return EXIT_USER_ERROR

    secret_key = args.secret_key or secrets.token_hex(32)

    service_dir = slug_dir / "service"
    if service_dir.exists() and not args.force:
        print(
            f"error: {service_dir} already exists; pass --force to overwrite",
            file=sys.stderr,
        )
        return EXIT_USER_ERROR
    service_dir.mkdir(parents=True, exist_ok=True)

    # Render server.py. flag_format_literal lands inside a Python string
    # literal; route it through `repr()` so any embedded quotes / escapes
    # are correctly encoded — a defence in depth atop the regex check
    # above. The rendered template uses `{FLAG_FORMAT_LITERAL_REPR}` to
    # interpolate the repr() output verbatim.
    flag_format_literal_repr = repr(flag_format_literal)
    if args.variant == "http":
        server_text = FLASK_SERVER_TEMPLATE.format(
            SLUG=slug_dir.name,
            PORT=args.port,
            FLAG_FORMAT_LITERAL_REPR=flag_format_literal_repr,
            TRUNCATE_TO=args.truncate_to,
        )
        extra_install = "RUN pip install --no-cache-dir flask"
        healthcheck_text = HEALTHCHECK_HTTP.replace("{PORT}", str(args.port))
    else:
        server_text = ASYNCIO_TCP_SERVER_TEMPLATE.format(
            SLUG=slug_dir.name,
            PORT=args.port,
            FLAG_FORMAT_LITERAL_REPR=flag_format_literal_repr,
            TRUNCATE_TO=args.truncate_to,
        )
        extra_install = ""
        healthcheck_text = HEALTHCHECK_TCP.replace("{PORT}", str(args.port))

    (service_dir / "server.py").write_text(server_text, encoding="utf-8")
    (service_dir / "healthcheck.sh").write_text(healthcheck_text, encoding="utf-8")
    (service_dir / "Dockerfile").write_text(
        DOCKERFILE_TEMPLATE.format(
            SLUG=slug_dir.name,
            VARIANT=args.variant,
            PORT=args.port,
            EXTRA_INSTALL=extra_install,
        ),
        encoding="utf-8",
    )

    # Service meta declared for validate. The HMAC secret is NOT written
    # into solution/service_meta.yaml because that path is checked into
    # version control alongside solve.py / questions.yaml. Instead the
    # generated server.py reads it from `FLAG_SERVER_SECRET` at runtime,
    # and the freshly-generated value is dropped into a sibling
    # `service/.flag-server.secret` file gitignored by the bundled
    # `.gitignore` so the operator can supply it via Docker `--env-file`.
    solution_dir = slug_dir / "solution"
    solution_dir.mkdir(parents=True, exist_ok=True)
    meta_text = textwrap.dedent(f"""\
        service_port: {args.port}
        variant: {args.variant}
        hmac_key_source: env:FLAG_SERVER_SECRET
        # The HMAC secret is loaded from the FLAG_SERVER_SECRET environment
        # variable at runtime; it is NEVER persisted in this file. The
        # newly generated value lives in `service/.flag-server.secret`
        # (gitignored) so the operator can re-export it for local lab use.
        flag_format_literal: {flag_format_literal!r}
        truncate_to: {args.truncate_to}
    """)
    (solution_dir / "service_meta.yaml").write_text(meta_text, encoding="utf-8")

    secret_path = service_dir / ".flag-server.secret"
    # Write under tightened mode 0600 so casual `cp -r` does not leak.
    secret_path.write_text(
        f"FLAG_SERVER_SECRET={secret_key}\n", encoding="utf-8",
    )
    try:
        secret_path.chmod(0o600)
    except OSError:
        pass

    gitignore = service_dir / ".gitignore"
    if not gitignore.exists():
        gitignore.write_text(
            ".flag-server.secret\n", encoding="utf-8",
        )

    print(f"✓ wrote {service_dir}/{{server.py,Dockerfile,healthcheck.sh}}")
    print(f"✓ wrote {solution_dir / 'service_meta.yaml'}")
    print(f"✓ wrote {secret_path} (gitignored; mode 0600)")
    print(
        "note: load the secret at deploy time via "
        "`docker run --env-file service/.flag-server.secret …`. "
        "Do NOT commit the secret file or copy it into solution/."
    )
    return EXIT_OK


if __name__ == "__main__":
    sys.exit(main())
