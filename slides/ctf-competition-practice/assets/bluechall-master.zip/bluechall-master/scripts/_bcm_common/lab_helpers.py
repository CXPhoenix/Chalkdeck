"""Lab orchestration context managers shared by Docker / OrbStack / QEMU.

Each session manager is responsible for:

- Provisioning the lab on `__enter__` (or recording dry-run intent).
- Returning a session object exposing endpoint URLs, hostnames, and IDs.
- Tearing the lab down on `__exit__` (best-effort, even on exceptions).
- Appending a provenance entry to the challenge's `.bluechall.manifest.yaml`
  recording the backend, mode (live/dry-run), entry timestamp, exit timestamp,
  and a SHA-256 digest of the source files referenced (compose YAML,
  cloud-init YAML, qemu monitor script).

`compose_session(slug_dir, mode='analyze', *, dry_run=False)` for Docker.
`vm_session(slug_dir, profile, *, dry_run=False)` for OrbStack.
`qemu_session(slug_dir, profile, *, dry_run=False)` for QEMU.

The `dry_run` parameter is set by `--no-runtime` in downstream CLIs. When
true, no subprocess is invoked and the manifest still records the entry
with `mode: dry-run`.
"""

from __future__ import annotations

import contextlib
import hashlib
import shutil
import subprocess
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterable, Iterator

import yaml


MANIFEST_FILENAME = ".bluechall.manifest.yaml"


@dataclass
class LabSession:
    """Returned by each session context manager. Live values are populated by
    the orchestrator on enter; dry-run sessions leave them at defaults.
    """
    backend: str
    mode: str  # 'live' | 'dry-run'
    slug_dir: Path
    endpoints: dict[str, str] = field(default_factory=dict)
    container_ids: list[str] = field(default_factory=list)
    started_at: str = ""
    ended_at: str = ""
    provenance_sha256: str = ""
    extra: dict = field(default_factory=dict)


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _hash_files(paths: Iterable[Path]) -> str:
    """Combined SHA-256 of file paths in order. Missing files contribute a
    constant marker byte so the digest still distinguishes presence/absence.
    """
    h = hashlib.sha256()
    for p in paths:
        if p.exists():
            h.update(b"PRESENT|")
            h.update(p.read_bytes())
        else:
            h.update(b"ABSENT|")
        h.update(b"|")
    return h.hexdigest()


def _append_provenance(slug_dir: Path, session: LabSession) -> None:
    """Append a `lab_provenance` entry to `<slug>/.bluechall.manifest.yaml`."""
    manifest_path = slug_dir / MANIFEST_FILENAME
    if manifest_path.exists():
        try:
            data = yaml.safe_load(manifest_path.read_text(encoding="utf-8")) or {}
        except yaml.YAMLError:
            data = {}
    else:
        data = {}
    if not isinstance(data, dict):
        data = {}
    provenance = data.setdefault("lab_provenance", [])
    if not isinstance(provenance, list):
        provenance = []
        data["lab_provenance"] = provenance
    entry = {
        "backend": session.backend,
        "mode": session.mode,
        "started_at": session.started_at,
        "ended_at": session.ended_at,
        "sha256": session.provenance_sha256,
    }
    if session.endpoints:
        entry["endpoints"] = dict(session.endpoints)
    if session.extra:
        entry["extra"] = dict(session.extra)
    provenance.append(entry)
    manifest_path.parent.mkdir(parents=True, exist_ok=True)
    manifest_path.write_text(
        yaml.safe_dump(data, default_flow_style=False, sort_keys=False),
        encoding="utf-8",
    )


# === Docker Compose session =================================================


@contextlib.contextmanager
def compose_session(
    slug_dir: Path,
    mode: str = "analyze",
    *,
    dry_run: bool = False,
    healthcheck_timeout_s: int = 60,
) -> Iterator[LabSession]:
    """Manage a docker-compose-driven lab.

    On enter (live mode):
      - Renders/uses `<slug>/src/docker-compose.yml` and any service stubs.
      - Runs `docker compose up -d` (cwd=src/).
      - Waits up to `healthcheck_timeout_s` for service health.
    On exit:
      - Runs `docker compose down -v` best-effort.
      - Writes provenance to manifest.
    """
    slug_dir = Path(slug_dir)
    src = slug_dir / "src"
    compose_yml = src / "docker-compose.yml"
    relevant = [compose_yml, src / "Dockerfile"]
    digest = _hash_files(relevant)

    session = LabSession(
        backend="docker",
        mode="dry-run" if dry_run else "live",
        slug_dir=slug_dir,
        provenance_sha256=digest,
        extra={"compose_mode": mode},
    )
    session.started_at = _now_iso()
    failure: BaseException | None = None
    try:
        if not dry_run:
            if not shutil.which("docker"):
                raise RuntimeError(
                    "docker CLI not found; pass --no-runtime to skip lab fuzz"
                )
            if not compose_yml.exists():
                raise FileNotFoundError(f"{compose_yml} does not exist")
            subprocess.run(
                ["docker", "compose", "up", "-d", "--wait",
                 f"--wait-timeout={healthcheck_timeout_s}"],
                cwd=src, check=True, capture_output=True,
            )
            ps = subprocess.run(
                ["docker", "compose", "ps", "--format", "json"],
                cwd=src, check=True, capture_output=True, text=True,
            )
            session.extra["compose_ps"] = ps.stdout
        yield session
    except BaseException as e:
        failure = e
        raise
    finally:
        if not dry_run:
            with contextlib.suppress(Exception):
                subprocess.run(
                    ["docker", "compose", "down", "-v"],
                    cwd=src, check=False, capture_output=True,
                )
        session.ended_at = _now_iso()
        if failure is not None:
            session.extra["error"] = type(failure).__name__
        _append_provenance(slug_dir, session)


# === OrbStack VM session ====================================================


@contextlib.contextmanager
def vm_session(
    slug_dir: Path,
    profile: str = "artifact-generation",
    *,
    dry_run: bool = False,
) -> Iterator[LabSession]:
    """Manage an OrbStack Linux VM for either artifact-generation or
    interactive forensics. Cloud-init template lives at
    `<slug>/src/orbstack.cloud-init.yaml` (rendered before this call).

    The `profile` parameter is one of 'artifact-generation' (build attacked
    host then dump memory/disk) or 'interactive' (provision and print SSH key
    for live forensics).
    """
    slug_dir = Path(slug_dir)
    cloud_init = slug_dir / "src" / "orbstack.cloud-init.yaml"
    digest = _hash_files([cloud_init])
    vm_name = f"bluechall-{slug_dir.name}"

    session = LabSession(
        backend="orbstack",
        mode="dry-run" if dry_run else "live",
        slug_dir=slug_dir,
        provenance_sha256=digest,
        extra={"profile": profile, "vm_name": vm_name},
    )
    session.started_at = _now_iso()
    failure: BaseException | None = None
    try:
        if not dry_run:
            if not shutil.which("orb"):
                raise RuntimeError(
                    "orb CLI (OrbStack) not found; pass --no-runtime "
                    "or use --backend docker to skip the OrbStack lab"
                )
            if not cloud_init.exists():
                raise FileNotFoundError(f"{cloud_init} does not exist")
            subprocess.run(
                ["orb", "create", "ubuntu:24.04", vm_name,
                 "--user-data", str(cloud_init)],
                check=True, capture_output=True,
            )
            session.endpoints["ssh"] = f"orb@{vm_name}"
        yield session
    except BaseException as e:
        failure = e
        raise
    finally:
        if not dry_run:
            with contextlib.suppress(Exception):
                subprocess.run(
                    ["orb", "delete", "-f", vm_name],
                    check=False, capture_output=True,
                )
        session.ended_at = _now_iso()
        if failure is not None:
            session.extra["error"] = type(failure).__name__
        _append_provenance(slug_dir, session)


def dump_memory(session: LabSession, out_path: Path) -> None:
    """Capture memory from the running OrbStack VM. Requires orbstack
    `vm_session` to be live; raises if dry-run.
    """
    if session.backend != "orbstack" or session.mode != "live":
        raise RuntimeError(
            "dump_memory requires a live OrbStack vm_session; "
            f"got backend={session.backend!r}, mode={session.mode!r}"
        )
    vm_name = session.extra.get("vm_name")
    out_path.parent.mkdir(parents=True, exist_ok=True)
    # Implementation note: OrbStack does not expose a direct memory-dump CLI;
    # production deployments use `orb run -m <vm> -- LiME` or a similar
    # in-VM tool. This wrapper documents the contract; concrete sub-class is
    # delegated to the bluechall_orbstack.py CLI.
    # Open the destination via a context manager so the file descriptor is
    # released even if subprocess.run raises, and stream `/proc/kcore`
    # directly without staging through `/tmp/memdump` (which previously
    # left a copy of the dump inside the analysed VM).
    with open(out_path, "wb") as fh:
        subprocess.run(
            ["orb", "run", "-m", vm_name, "--",
             "sudo", "cat", "/proc/kcore"],
            check=False, stdout=fh,
        )


# === QEMU session ===========================================================


@contextlib.contextmanager
def qemu_session(
    slug_dir: Path,
    profile: str = "user-mode",
    *,
    dry_run: bool = False,
    arch: str = "mips",
    binary: Path | None = None,
    args: list[str] | None = None,
    gdb_port: int | None = None,
) -> Iterator[LabSession]:
    """Manage a QEMU emulator session. Two profiles:
      - `user-mode`: runs `qemu-<arch>-static <binary> <args>`.
      - `system-mode`: boots a QEMU virtual machine; used for firmware reverse.
    """
    slug_dir = Path(slug_dir)
    artefacts = []
    if binary is not None:
        artefacts.append(Path(binary))
    digest = _hash_files(artefacts)

    session = LabSession(
        backend="qemu",
        mode="dry-run" if dry_run else "live",
        slug_dir=slug_dir,
        provenance_sha256=digest,
        extra={"profile": profile, "arch": arch, "gdb_port": gdb_port},
    )
    session.started_at = _now_iso()
    proc: subprocess.Popen | None = None
    failure: BaseException | None = None
    try:
        if not dry_run:
            if profile == "user-mode":
                qemu_bin = f"qemu-{arch}-static"
                if not shutil.which(qemu_bin):
                    raise RuntimeError(
                        f"{qemu_bin} not found; pass --no-runtime to skip "
                        f"or install the qemu-user-static package"
                    )
                if binary is None or not binary.exists():
                    raise FileNotFoundError(
                        f"binary path {binary!r} does not exist"
                    )
                cmd = [qemu_bin]
                if gdb_port is not None:
                    cmd.append(f"-g")
                    cmd.append(str(gdb_port))
                cmd.append(str(binary))
                cmd.extend(args or [])
                proc = subprocess.Popen(cmd)
            elif profile == "system-mode":
                qemu_bin = f"qemu-system-{arch}"
                if not shutil.which(qemu_bin):
                    raise RuntimeError(
                        f"{qemu_bin} not found; pass --no-runtime to skip"
                    )
                # Concrete `-M virt` / `-M raspi3` invocation is delegated to
                # bluechall_qemu.py CLI, which knows the per-recipe board.
            else:
                raise ValueError(f"unknown qemu profile {profile!r}")
            session.extra["pid"] = proc.pid if proc else None
        yield session
    except BaseException as e:
        failure = e
        raise
    finally:
        if proc is not None:
            with contextlib.suppress(Exception):
                proc.terminate()
                proc.wait(timeout=5)
        session.ended_at = _now_iso()
        if failure is not None:
            session.extra["error"] = type(failure).__name__
        _append_provenance(slug_dir, session)
