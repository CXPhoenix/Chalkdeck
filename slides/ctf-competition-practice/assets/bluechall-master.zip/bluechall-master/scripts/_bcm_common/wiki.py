"""Wiki ingest / compile / find / verify primitives for bluechall-master.

Implements the contract laid out in `bluechall-defensive-wiki-profile`:

- Layer 1 (`wiki/raw/`) is immutable. Files carry frontmatter recording fetch
  URL, fetch date, and SHA-256 of the body. `verify` rejects in-place edits.
- Layer 2 (`wiki/{taxonomies,concepts,frameworks,cves,recipes}/`) is
  agent-maintained. Each page declares a `type` in frontmatter and carries
  the fields required for that type per `profile.yaml`.
- Layer 3 (`AGENTS.md`) MUST contain four mandatory sections; cross-model lint
  enforces this and forbids host-agent tool names from `SKILL*.md` and
  `AGENTS.md`.

Pure stdlib (re, hashlib, pathlib, datetime). YAML is parsed with `yaml`
(third-party, declared in `compatibility:`).
"""

from __future__ import annotations

import hashlib
import re
from dataclasses import dataclass, field
from datetime import date
from pathlib import Path
from typing import Iterable

import yaml


# === Constants ===============================================================

PROFILE_FILENAME = "profile.yaml"
AGENTS_FILENAME = "AGENTS.md"
RAW_DIRNAME = "raw"

# Tool names from `reference/agent-tools.md` left-most data column. Mentions
# in normative files break cross-model parity. Must stay in sync with the
# Concept ⇄ Claude Code mapping.
CROSS_MODEL_FORBIDDEN_TOKENS = (
    "Read(", "Write(", "Edit(", "Glob(", "Grep(", "Bash(",
    "Agent(", "AskUserQuestion(", "WebFetch(", "WebSearch(",
)

# AGENTS.md must declare exactly these four sections (per
# `bluechall-defensive-wiki-profile` Requirement: AGENTS.md MUST be the
# Layer-3 discipline document).
AGENTS_REQUIRED_SECTIONS = (
    "Layout",
    "Page frontmatter schema",
    "Operations",
    "Cross-model contract",
)

# Page type → field set lookup is loaded from profile.yaml at runtime.

_FRONTMATTER_RE = re.compile(r"^---\s*\n(.*?)\n---\s*\n(.*)\Z", re.DOTALL)
_AGENTS_HEADING_RE = re.compile(r"^##+\s+(?:\d+\.\s*)?(.+?)\s*$", re.MULTILINE)


# === Findings ================================================================


from .reporters import Finding  # noqa: E402

ENGINE = "wiki"


def _finding(
    *,
    severity: str,
    rule_id: str,
    location: Path | str,
    message: str,
    remediation_hint: str = "",
) -> Finding:
    """Construct a `reporters.Finding` from the historical 4-tuple shape.

    Older versions of this module shipped a parallel `@dataclass class Finding`
    with `location` (Path | str) instead of `reporters.Finding.path` (str).
    This wrapper is the lone bridge so call sites can keep their existing
    keyword-argument style while emitting canonical findings.
    """
    return Finding(
        severity=severity,
        engine=ENGINE,
        rule_id=rule_id,
        path=str(location),
        message=message,
        remediation_hint=remediation_hint,
    )


# === Profile loading =========================================================


@dataclass
class Profile:
    name: str
    version: str
    raw_subtypes: tuple[str, ...]
    required_dirs: tuple[str, ...]
    required_fields: dict[str, tuple[str, ...]]
    page_frontmatter_schema: dict
    survey_subdomains: dict[str, tuple[str, ...]]

    @classmethod
    def load(cls, root: Path) -> "Profile":
        path = root / PROFILE_FILENAME
        data = yaml.safe_load(path.read_text(encoding="utf-8"))
        return cls(
            name=data["name"],
            version=data["version"],
            raw_subtypes=tuple(data.get("raw_subtypes") or ()),
            required_dirs=tuple(data.get("required_dirs") or ()),
            required_fields={
                k: tuple(v) for k, v in (data.get("required_fields") or {}).items()
            },
            page_frontmatter_schema=data.get("page_frontmatter_schema") or {},
            survey_subdomains={
                k: tuple(v)
                for k, v in (data.get("survey_coverage_subdomains") or {}).items()
            },
        )


# === Frontmatter parser ======================================================


def parse_frontmatter(text: str) -> tuple[dict, str] | None:
    """Return (meta_dict, body) or None if no frontmatter."""
    m = _FRONTMATTER_RE.match(text)
    if not m:
        return None
    meta = yaml.safe_load(m.group(1)) or {}
    return meta, m.group(2)


def sha256_of_body(body: str) -> str:
    return hashlib.sha256(body.encode("utf-8")).hexdigest()


# === Verify =================================================================


def verify(
    root: Path,
    *,
    profile: Profile | None = None,
    max_age_days: int | None = None,
    cross_model_lint: bool = False,
    check_cve_coverage: bool = False,
    check_survey_coverage: bool = False,
) -> list[Finding]:
    """Run wiki invariants. Returns a list of findings (may be empty).

    Caller decides exit code: any `severity == 'critical'` finding implies
    failure. `advisory` and `warning` findings are informational.
    """
    if profile is None:
        profile = Profile.load(root)
    findings: list[Finding] = []
    findings.extend(_verify_raw_immutability(root))
    findings.extend(_verify_layer2_frontmatter(root, profile))
    if max_age_days is not None:
        findings.extend(_verify_max_age(root, profile, max_age_days))
    if cross_model_lint:
        findings.extend(_verify_cross_model_lint(root))
    if check_survey_coverage:
        findings.extend(_verify_survey_coverage(root, profile))
    if check_cve_coverage:
        findings.extend(_verify_cve_coverage(root, profile))
    return findings


def _verify_raw_immutability(root: Path) -> list[Finding]:
    """Every file under `wiki/raw/` carrying a `sha256:` frontmatter field
    must hash to the declared digest. Body changes after ingest are rejected.
    """
    findings: list[Finding] = []
    raw_root = root / RAW_DIRNAME
    if not raw_root.exists():
        return findings
    for path in sorted(raw_root.rglob("*.md")):
        text = path.read_text(encoding="utf-8")
        parsed = parse_frontmatter(text)
        if parsed is None:
            findings.append(_finding(
                severity="warning",
                rule_id="raw-no-frontmatter",
                location=path,
                message="raw file has no YAML frontmatter; cannot verify SHA-256",
                remediation_hint="ingest via bluechall_wiki.py ingest <url-or-path>",
            ))
            continue
        meta, body = parsed
        declared = meta.get("sha256")
        if declared is None:
            findings.append(_finding(
                severity="warning",
                rule_id="raw-missing-sha256",
                location=path,
                message="raw file frontmatter omits sha256 digest",
                remediation_hint="re-ingest via bluechall_wiki.py ingest",
            ))
            continue
        actual = sha256_of_body(body)
        if actual != declared:
            findings.append(_finding(
                severity="critical",
                rule_id="raw-tampered",
                location=path,
                message=(
                    f"raw body SHA-256 {actual!r} does not match declared "
                    f"{declared!r}; in-place edits are forbidden"
                ),
                remediation_hint=(
                    "ingest a new file with a different fetch-date suffix; "
                    "do not edit Layer-1 in place"
                ),
            ))
    return findings


def _verify_layer2_frontmatter(root: Path, profile: Profile) -> list[Finding]:
    """Each Layer-2 page declares `type` and the fields required for that type.
    Every page MUST appear under one of the `required_dirs`.
    """
    findings: list[Finding] = []
    seen_ids: dict[str, Path] = {}
    for sub in profile.required_dirs:
        sub_root = root / sub
        if not sub_root.exists():
            findings.append(_finding(
                severity="warning",
                rule_id="layer2-missing-dir",
                location=sub_root,
                message=f"required Layer-2 directory {sub!r} is absent",
                remediation_hint=f"mkdir -p {sub_root}",
            ))
            continue
        for path in sorted(sub_root.rglob("*.md")):
            if path.name == "index.md" or path.name == "log.md":
                continue
            text = path.read_text(encoding="utf-8")
            parsed = parse_frontmatter(text)
            if parsed is None:
                findings.append(_finding(
                    severity="critical",
                    rule_id="layer2-no-frontmatter",
                    location=path,
                    message="Layer-2 page lacks YAML frontmatter",
                ))
                continue
            meta, _ = parsed
            page_type = meta.get("type")
            if page_type is None:
                findings.append(_finding(
                    severity="critical",
                    rule_id="layer2-no-type",
                    location=path,
                    message="Layer-2 page frontmatter omits required `type` field",
                ))
                continue
            required = profile.required_fields.get(page_type)
            if required is None:
                findings.append(_finding(
                    severity="critical",
                    rule_id="layer2-unknown-type",
                    location=path,
                    message=f"page declares unknown type {page_type!r}",
                ))
                continue
            for field_name in required:
                if field_name not in meta:
                    findings.append(_finding(
                        severity="critical",
                        rule_id="layer2-missing-field",
                        location=path,
                        message=(
                            f"page of type {page_type!r} omits required field "
                            f"{field_name!r}"
                        ),
                    ))
            page_id = meta.get("id")
            if page_id is not None:
                if page_id in seen_ids:
                    findings.append(_finding(
                        severity="critical",
                        rule_id="layer2-duplicate-id",
                        location=path,
                        message=(
                            f"id {page_id!r} also declared at "
                            f"{seen_ids[page_id]}"
                        ),
                    ))
                else:
                    seen_ids[page_id] = path
    return findings


def _verify_max_age(
    root: Path, profile: Profile, max_age_days: int
) -> list[Finding]:
    """Flag pages whose `last_compiled` is older than `max_age_days`."""
    findings: list[Finding] = []
    today = date.today()
    for sub in profile.required_dirs:
        sub_root = root / sub
        if not sub_root.exists():
            continue
        for path in sorted(sub_root.rglob("*.md")):
            if path.name in ("index.md", "log.md"):
                continue
            text = path.read_text(encoding="utf-8")
            parsed = parse_frontmatter(text)
            if parsed is None:
                continue
            meta, _ = parsed
            stamp = meta.get("last_compiled")
            if stamp is None:
                continue
            try:
                last = date.fromisoformat(str(stamp))
            except ValueError:
                continue
            age = (today - last).days
            if age > max_age_days:
                findings.append(_finding(
                    severity="advisory",
                    rule_id="layer2-stale",
                    location=path,
                    message=(
                        f"last_compiled {last.isoformat()} is {age} days old "
                        f"(max-age threshold {max_age_days} days)"
                    ),
                    remediation_hint=(
                        "re-run bluechall_wiki.py compile --concept "
                        f"{meta.get('id', '<id>')}"
                    ),
                ))
    return findings


def _verify_cross_model_lint(root: Path) -> list[Finding]:
    """Forbid host-agent tool names in normative files. Verify AGENTS.md
    declares all four mandatory sections.

    SKILL*.md and AGENTS.md live at the skill root (the parent of `wiki/`),
    not inside the wiki itself.
    """
    findings: list[Finding] = []
    skill_root = root.parent
    skill_files = sorted(skill_root.glob("SKILL*.md"))
    agents = skill_root / AGENTS_FILENAME
    if agents.exists():
        skill_files.append(agents)
    for path in skill_files:
        text = path.read_text(encoding="utf-8")
        for token in CROSS_MODEL_FORBIDDEN_TOKENS:
            if token in text:
                findings.append(_finding(
                    severity="critical",
                    rule_id="cross-model-tool-name",
                    location=path,
                    message=(
                        f"file mentions host-agent tool {token!r} in normative "
                        "text; tool names belong only in reference/agent-tools.md"
                    ),
                    remediation_hint=(
                        "rephrase the line as imperative shell-invocation prose"
                    ),
                ))
    if agents.exists():
        text = agents.read_text(encoding="utf-8")
        headings = {h.strip() for h in _AGENTS_HEADING_RE.findall(text)}
        for required in AGENTS_REQUIRED_SECTIONS:
            if not any(required.lower() in h.lower() for h in headings):
                findings.append(_finding(
                    severity="critical",
                    rule_id="agents-missing-section",
                    location=agents,
                    message=(
                        f"AGENTS.md missing required section heading "
                        f"{required!r}"
                    ),
                    remediation_hint=(
                        f"add a top-level section heading containing "
                        f"{required!r}"
                    ),
                ))
    return findings


def _verify_survey_coverage(root: Path, profile: Profile) -> list[Finding]:
    """For each forensics and reverse subdomain, ensure at least one paper
    under `wiki/raw/papers/` is tagged `survey: true` AND covers the subdomain
    via its `subdomains` field. Missing coverage is advisory, not critical.
    """
    findings: list[Finding] = []
    papers_dir = root / RAW_DIRNAME / "papers"
    covered: set[str] = set()
    if papers_dir.exists():
        for path in sorted(papers_dir.rglob("*.md")):
            text = path.read_text(encoding="utf-8")
            parsed = parse_frontmatter(text)
            if parsed is None:
                continue
            meta, _ = parsed
            if not meta.get("survey"):
                continue
            for sub in (meta.get("subdomains") or []):
                covered.add(str(sub))
    for category, subdomains in profile.survey_subdomains.items():
        for sub in subdomains:
            if sub not in covered:
                findings.append(_finding(
                    severity="advisory",
                    rule_id="survey-coverage-gap",
                    location=papers_dir,
                    message=(
                        f"{category} subdomain {sub!r} is not covered by any "
                        "paper tagged `survey: true` under wiki/raw/papers/"
                    ),
                    remediation_hint=(
                        "ingest a survey/SoK paper for this subdomain via "
                        "bluechall_wiki.py ingest --academic --paper-doi <doi>"
                    ),
                ))
    return findings


def _verify_cve_coverage(root: Path, profile: Profile) -> list[Finding]:
    """Each framework page MUST reference at least three CVE pages."""
    findings: list[Finding] = []
    fw_dir = root / "frameworks"
    cves_dir = root / "cves"
    if not fw_dir.exists() or not cves_dir.exists():
        return findings
    cve_ids = set()
    for path in cves_dir.glob("*.md"):
        text = path.read_text(encoding="utf-8")
        parsed = parse_frontmatter(text)
        if parsed is None:
            continue
        meta, _ = parsed
        if meta.get("id") is not None:
            cve_ids.add(str(meta["id"]))
    for path in fw_dir.glob("*.md"):
        text = path.read_text(encoding="utf-8")
        parsed = parse_frontmatter(text)
        if parsed is None:
            continue
        meta, _ = parsed
        cves = meta.get("cves") or []
        valid = [c for c in cves if str(c) in cve_ids]
        if len(valid) < 3:
            findings.append(_finding(
                severity="advisory",
                rule_id="cve-coverage-gap",
                location=path,
                message=(
                    f"framework references {len(valid)} CVE pages; "
                    "at least 3 are required by --check-cve-coverage"
                ),
            ))
    return findings


# === Ingest =================================================================


def ingest(source_text: str, *, fetch_url: str, fetch_date: str) -> str:
    """Return the source_text wrapped with bluechall raw-layer frontmatter.

    The body is hashed with SHA-256 before frontmatter is prepended; verify()
    later re-hashes the same body to detect tampering.
    """
    digest = sha256_of_body(source_text)
    meta = {
        "fetch_url": fetch_url,
        "fetch_date": fetch_date,
        "sha256": digest,
    }
    fm_body = yaml.safe_dump(meta, default_flow_style=False, sort_keys=False).strip()
    return f"---\n{fm_body}\n---\n{source_text}"


# === Find ===================================================================


def find(
    root: Path,
    *,
    owasp: str | None = None,
    mitre_attack: str | None = None,
    nist_phase: str | None = None,
    framework: str | None = None,
    category: str | None = None,
    subdomain: str | None = None,
    cve: str | None = None,
) -> list[Path]:
    """Return Layer-2 page paths matching the given filters (AND-combined)."""
    matches: list[Path] = []
    for sub in ("concepts", "frameworks", "recipes", "cves"):
        sub_root = root / sub
        if not sub_root.exists():
            continue
        for path in sorted(sub_root.rglob("*.md")):
            text = path.read_text(encoding="utf-8")
            parsed = parse_frontmatter(text)
            if parsed is None:
                continue
            meta, _ = parsed
            if owasp and owasp not in (meta.get("owasp") or []):
                continue
            if mitre_attack and mitre_attack not in (meta.get("mitre_attack") or []):
                continue
            if nist_phase and meta.get("nist_phase") != nist_phase:
                continue
            if framework and meta.get("id") != framework and meta.get("framework") != framework:
                continue
            if category and meta.get("category") != category:
                continue
            if subdomain and meta.get("subdomain") != subdomain:
                continue
            if cve and cve != meta.get("cve_id") and cve not in (meta.get("cve_refs") or []):
                continue
            matches.append(path)
    return matches
