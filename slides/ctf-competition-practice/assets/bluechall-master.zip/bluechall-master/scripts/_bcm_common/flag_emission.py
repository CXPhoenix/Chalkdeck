"""Flag emission modes for bluechall-master.

Four modes are first-class enum values:

- `single-static`           — Flare-On style: one flag in solution/flag.txt.
- `questions-as-flags`      — HTB Sherlocks style: list of ATT&CK-tagged Q/A.
- `service-derived`         — HMAC per-team flag emitted by an external service.
- `multi-stage-pivot`       — directed acyclic graph of stages, terminal stage
                              produces the canonical flag.

This module enforces the consistency contract:
- The mode declared in `recipe.yaml` MUST match `.bluechall.manifest.yaml`.
- `single-static`: solution/flag.txt MUST match FLAG_REGEX.
- `questions-as-flags`: solution/questions.yaml MUST be a list of dicts with
  required fields, count <= BLUE_TEAM_QUESTION_LIMIT, attack_technique IDs
  consistent with MITRE_ATTACK_VERSION format.
- `service-derived`: solution/service_meta.yaml MUST declare a `service_port`
  inside [EXTERNAL_FLAG_SERVICE_PORT_RANGE_START, ..._END].
- `multi-stage-pivot`: solution/stages.yaml MUST be a DAG; exactly one stage
  must declare `terminal: true`.
"""

from __future__ import annotations

import re
from pathlib import Path
from typing import Any

import yaml

from .reporters import Finding


# === Mode enum ==============================================================

MODE_SINGLE_STATIC = "single-static"
MODE_QUESTIONS_AS_FLAGS = "questions-as-flags"
MODE_SERVICE_DERIVED = "service-derived"
MODE_MULTI_STAGE_PIVOT = "multi-stage-pivot"

ALL_MODES = (
    MODE_SINGLE_STATIC,
    MODE_QUESTIONS_AS_FLAGS,
    MODE_SERVICE_DERIVED,
    MODE_MULTI_STAGE_PIVOT,
)

ENGINE = "flag-emission"

_MITRE_ID_RE = re.compile(r"^T\d{4}(\.\d{3})?$")


# === Findings ===============================================================


def _finding(
    *,
    severity: str,
    rule_id: str,
    location: Path | str,
    message: str,
    remediation_hint: str = "",
) -> Finding:
    """Construct a `reporters.Finding` from the historical 4-tuple shape.

    Older versions of this module shipped a parallel `@dataclass class Finding`
    with `location` (Path | str) instead of `reporters.Finding.path` (str).
    This wrapper is the lone bridge so call sites can keep their existing
    keyword-argument style while emitting canonical findings.
    """
    return Finding(
        severity=severity,
        engine=ENGINE,
        rule_id=rule_id,
        path=str(location),
        message=message,
        remediation_hint=remediation_hint,
    )


# === Public API =============================================================


def validate_consistency(
    recipe_mode: str | None,
    manifest_mode: str | None,
) -> list[Finding]:
    """Recipe and manifest must agree on mode."""
    findings: list[Finding] = []
    if recipe_mode is None:
        findings.append(_finding(
            severity="critical",
            rule_id="flag-emission-recipe-missing",
            location="recipe.yaml",
            message="recipe.yaml does not declare flag_emission",
        ))
    elif recipe_mode not in ALL_MODES:
        findings.append(_finding(
            severity="critical",
            rule_id="flag-emission-unknown",
            location="recipe.yaml",
            message=f"unknown flag_emission {recipe_mode!r}; allowed: {list(ALL_MODES)}",
        ))
    if manifest_mode is None:
        findings.append(_finding(
            severity="critical",
            rule_id="flag-emission-manifest-missing",
            location=".bluechall.manifest.yaml",
            message="manifest.yaml does not declare flag_emission",
        ))
    if recipe_mode and manifest_mode and recipe_mode != manifest_mode:
        findings.append(_finding(
            severity="critical",
            rule_id="flag-emission-mismatch",
            location="recipe.yaml vs .bluechall.manifest.yaml",
            message=(
                f"recipe declares {recipe_mode!r} but manifest declares "
                f"{manifest_mode!r}; both files must agree"
            ),
        ))
    return findings


def validate_single_static(
    flag_file: Path,
    *,
    flag_regex: str,
) -> list[Finding]:
    """Flag file must exist and its content must match FLAG_REGEX."""
    findings: list[Finding] = []
    if not flag_file.exists():
        findings.append(_finding(
            severity="critical",
            rule_id="single-static-missing-flag",
            location=flag_file,
            message="solution/flag.txt does not exist",
        ))
        return findings
    content = flag_file.read_text(encoding="utf-8").strip()
    try:
        if not re.fullmatch(flag_regex, content):
            findings.append(_finding(
                severity="critical",
                rule_id="single-static-flag-regex-mismatch",
                location=flag_file,
                message=(
                    f"flag content {content!r} does not match "
                    f"FLAG_REGEX {flag_regex!r}"
                ),
            ))
    except re.error as e:
        findings.append(_finding(
            severity="critical",
            rule_id="single-static-flag-regex-invalid",
            location=flag_file,
            message=f"FLAG_REGEX failed to compile: {e}",
        ))
    return findings


def validate_questions_as_flags(
    questions_file: Path,
    *,
    flag_regex: str,
    blue_team_question_limit: int,
    mitre_attack_version: str,
) -> list[Finding]:
    """questions.yaml must be a list of well-formed entries within the limit."""
    findings: list[Finding] = []
    if not questions_file.exists():
        findings.append(_finding(
            severity="critical",
            rule_id="questions-as-flags-missing",
            location=questions_file,
            message="solution/questions.yaml does not exist",
        ))
        return findings
    try:
        data = yaml.safe_load(questions_file.read_text(encoding="utf-8"))
    except yaml.YAMLError as e:
        findings.append(_finding(
            severity="critical",
            rule_id="questions-as-flags-invalid-yaml",
            location=questions_file,
            message=f"YAML parse error: {e}",
        ))
        return findings
    if not isinstance(data, list):
        findings.append(_finding(
            severity="critical",
            rule_id="questions-as-flags-not-a-list",
            location=questions_file,
            message=f"top-level must be a YAML list, got {type(data).__name__}",
        ))
        return findings
    if len(data) > blue_team_question_limit:
        findings.append(_finding(
            severity="critical",
            rule_id="questions-as-flags-over-limit",
            location=questions_file,
            message=(
                f"declares {len(data)} entries; BLUE_TEAM_QUESTION_LIMIT is "
                f"{blue_team_question_limit}"
            ),
        ))
    seen_ids: set[str] = set()
    for idx, entry in enumerate(data):
        if not isinstance(entry, dict):
            findings.append(_finding(
                severity="critical",
                rule_id="questions-as-flags-entry-not-mapping",
                location=questions_file,
                message=f"entry {idx} is not a mapping",
            ))
            continue
        for required in ("id", "question", "answer", "attack_technique", "points"):
            if required not in entry:
                findings.append(_finding(
                    severity="critical",
                    rule_id="questions-as-flags-missing-field",
                    location=questions_file,
                    message=f"entry {idx} omits required field {required!r}",
                ))
        qid = entry.get("id")
        if isinstance(qid, str):
            if qid in seen_ids:
                findings.append(_finding(
                    severity="critical",
                    rule_id="questions-as-flags-duplicate-id",
                    location=questions_file,
                    message=f"entry {idx} reuses id {qid!r}",
                ))
            seen_ids.add(qid)
        attack = entry.get("attack_technique")
        if isinstance(attack, str) and not _MITRE_ID_RE.match(attack):
            findings.append(_finding(
                severity="warning",
                rule_id="questions-as-flags-attack-technique-format",
                location=questions_file,
                message=(
                    f"entry {idx} attack_technique {attack!r} does not match "
                    "MITRE ATT&CK technique id format ^T\\d{4}(\\.\\d{3})?$"
                ),
            ))
        points = entry.get("points")
        # Reject `bool` first — Python treats `True`/`False` as
        # `isinstance(_, int) == True`, so `points: yes` (YAML truthy)
        # would otherwise sneak past as integer 1.
        if isinstance(points, bool) or not isinstance(points, int) or points <= 0:
            findings.append(_finding(
                severity="critical",
                rule_id="questions-as-flags-points-invalid",
                location=questions_file,
                message=(
                    f"entry {idx} points must be a positive integer, "
                    f"got {points!r}"
                ),
            ))
        answer = entry.get("answer")
        freeform = bool(entry.get("freeform_answer"))
        if not freeform and isinstance(answer, str):
            try:
                if not re.fullmatch(flag_regex, answer):
                    findings.append(_finding(
                        severity="critical",
                        rule_id="questions-as-flags-answer-regex-mismatch",
                        location=questions_file,
                        message=(
                            f"entry {idx} answer {answer!r} does not match "
                            f"FLAG_REGEX {flag_regex!r}; declare "
                            "freeform_answer: true to skip this check"
                        ),
                    ))
            except re.error:
                pass
    # MITRE_ATTACK_VERSION sanity check (advisory).
    if not re.match(r"^v\d+\.\d+$", mitre_attack_version):
        findings.append(_finding(
            severity="advisory",
            rule_id="questions-as-flags-mitre-version-format",
            location=questions_file,
            message=(
                f"MITRE_ATTACK_VERSION {mitre_attack_version!r} from .rules.env "
                "does not match v<major>.<minor>"
            ),
        ))
    return findings


def validate_service_derived(
    service_meta_file: Path,
    *,
    external_port_start: int,
    external_port_end: int,
) -> list[Finding]:
    """service_meta.yaml must declare a port inside the external range."""
    findings: list[Finding] = []
    if not service_meta_file.exists():
        findings.append(_finding(
            severity="critical",
            rule_id="service-derived-missing-meta",
            location=service_meta_file,
            message="solution/service_meta.yaml does not exist",
        ))
        return findings
    try:
        data = yaml.safe_load(service_meta_file.read_text(encoding="utf-8"))
    except yaml.YAMLError as e:
        findings.append(_finding(
            severity="critical",
            rule_id="service-derived-invalid-yaml",
            location=service_meta_file,
            message=f"YAML parse error: {e}",
        ))
        return findings
    if not isinstance(data, dict):
        findings.append(_finding(
            severity="critical",
            rule_id="service-derived-not-a-mapping",
            location=service_meta_file,
            message="top-level must be a YAML mapping",
        ))
        return findings
    port = data.get("service_port")
    if not isinstance(port, int):
        findings.append(_finding(
            severity="critical",
            rule_id="service-derived-port-missing",
            location=service_meta_file,
            message="service_port must be an integer",
        ))
    elif not (external_port_start <= port <= external_port_end):
        findings.append(_finding(
            severity="critical",
            rule_id="service-derived-port-out-of-range",
            location=service_meta_file,
            message=(
                f"service_port {port} is outside the configured range "
                f"[{external_port_start}, {external_port_end}]"
            ),
        ))
    if "hmac_key_source" not in data:
        findings.append(_finding(
            severity="warning",
            rule_id="service-derived-hmac-key-source-missing",
            location=service_meta_file,
            message="service_meta.yaml omits hmac_key_source documentation",
        ))
    return findings


def validate_multi_stage_pivot(
    stages_file: Path,
    *,
    flag_regex: str,
) -> list[Finding]:
    """stages.yaml must declare a DAG with exactly one terminal stage."""
    findings: list[Finding] = []
    if not stages_file.exists():
        findings.append(_finding(
            severity="critical",
            rule_id="multi-stage-pivot-missing-stages",
            location=stages_file,
            message="solution/stages.yaml does not exist",
        ))
        return findings
    try:
        data = yaml.safe_load(stages_file.read_text(encoding="utf-8"))
    except yaml.YAMLError as e:
        findings.append(_finding(
            severity="critical",
            rule_id="multi-stage-pivot-invalid-yaml",
            location=stages_file,
            message=f"YAML parse error: {e}",
        ))
        return findings
    if not isinstance(data, list):
        findings.append(_finding(
            severity="critical",
            rule_id="multi-stage-pivot-not-a-list",
            location=stages_file,
            message=f"top-level must be a YAML list, got {type(data).__name__}",
        ))
        return findings

    ids: list[str] = []
    requires: dict[str, list[str]] = {}
    terminals: list[str] = []
    for idx, entry in enumerate(data):
        if not isinstance(entry, dict):
            findings.append(_finding(
                severity="critical",
                rule_id="multi-stage-pivot-entry-not-mapping",
                location=stages_file,
                message=f"entry {idx} is not a mapping",
            ))
            continue
        sid = entry.get("id")
        if not isinstance(sid, str):
            findings.append(_finding(
                severity="critical",
                rule_id="multi-stage-pivot-missing-id",
                location=stages_file,
                message=f"entry {idx} omits required field 'id'",
            ))
            continue
        if sid in ids:
            findings.append(_finding(
                severity="critical",
                rule_id="multi-stage-pivot-duplicate-id",
                location=stages_file,
                message=f"entry {idx} reuses stage id {sid!r}",
            ))
            continue
        ids.append(sid)
        deps = entry.get("requires") or []
        if not isinstance(deps, list):
            deps = []
        requires[sid] = [str(d) for d in deps]
        if entry.get("terminal"):
            terminals.append(sid)
        for required_field in ("output_artifact", "unlock_token_format"):
            if required_field not in entry:
                findings.append(_finding(
                    severity="critical",
                    rule_id="multi-stage-pivot-missing-field",
                    location=stages_file,
                    message=(
                        f"entry {idx} (id={sid!r}) omits required field "
                        f"{required_field!r}"
                    ),
                ))

    # Each requires entry must point to a known stage id.
    for sid, deps in requires.items():
        for dep in deps:
            if dep not in ids:
                findings.append(_finding(
                    severity="critical",
                    rule_id="multi-stage-pivot-unknown-dependency",
                    location=stages_file,
                    message=(
                        f"stage {sid!r} requires unknown stage {dep!r}"
                    ),
                ))

    # Cycle detection (DFS).
    if _has_cycle(requires):
        findings.append(_finding(
            severity="critical",
            rule_id="multi-stage-pivot-cycle",
            location=stages_file,
            message="stages graph contains a cycle; must be a DAG",
        ))

    # Exactly one terminal stage.
    if len(terminals) == 0:
        findings.append(_finding(
            severity="critical",
            rule_id="multi-stage-pivot-no-terminal",
            location=stages_file,
            message="no stage declares 'terminal: true'",
        ))
    elif len(terminals) > 1:
        findings.append(_finding(
            severity="critical",
            rule_id="multi-stage-pivot-multiple-terminals",
            location=stages_file,
            message=f"multiple terminal stages declared: {terminals}",
        ))

    return findings


def _has_cycle(graph: dict[str, list[str]]) -> bool:
    WHITE, GRAY, BLACK = 0, 1, 2
    color = {node: WHITE for node in graph}

    def dfs(node: str) -> bool:
        if color.get(node, WHITE) == GRAY:
            return True
        if color.get(node, WHITE) == BLACK:
            return False
        color[node] = GRAY
        for nxt in graph.get(node, ()):
            if dfs(nxt):
                return True
        color[node] = BLACK
        return False

    return any(dfs(n) for n in list(graph))


# === HMAC helpers (used by service-derived flag stub) =======================


def hmac_per_team_flag(
    secret_key: bytes,
    team_id: str,
    *,
    flag_format_literal: str,
    truncate_to: int = 16,
) -> str:
    """Derive a per-team flag via HMAC-SHA256.

    The output is `<flag_prefix>{<truncated_hex>}` where `<flag_prefix>` is
    everything before `<text>` in `flag_format_literal`.
    """
    import hashlib
    import hmac
    digest = hmac.new(secret_key, team_id.encode("utf-8"), hashlib.sha256).hexdigest()
    truncated = digest[:truncate_to]
    return flag_format_literal.replace("<text>", truncated)
