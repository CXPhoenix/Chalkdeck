"""bluechall-master shared utilities.

This package is the single source of truth for bluechall logic that crosses
multiple CLI entry points. Other CLIs in `bluechall-master/scripts/` MUST
import from here rather than duplicating logic. Cross-skill imports from
`webchall-master/scripts/_wcm_common/` are forbidden at runtime — when logic
is reused, copy it into this package at change time so the two skills can
evolve independently.
"""
