"""Lab-fuzz engine — third engine of `bluechall_analyze.py`.

Provisions the manifest-declared `lab_backend` via `lab_helpers` and emits
findings describing what was attempted. With `--no-runtime`, the CLI passes
`dry_run=True` so no daemon is started; lab_helpers still appends a
`lab_provenance` entry with `mode: dry-run` so the analyze trail is
preserved.

v0.1 surface: this engine is informational. v0.2 will add active probing
of flag-server endpoints with malformed inputs to detect bypass paths.
"""

from __future__ import annotations

import traceback
from pathlib import Path

from . import lab_helpers
from .reporters import Finding


ENGINE = "lab-fuzz"


def run(slug_dir: Path, manifest: dict, *, dry_run: bool = False) -> list[Finding]:
    findings: list[Finding] = []
    backend = manifest.get("lab_backend")
    if backend in (None, "none"):
        findings.append(Finding(
            severity="info",
            engine=ENGINE,
            rule_id="lab-fuzz-skipped",
            path=str(slug_dir),
            message="lab_backend is `none`; lab-fuzz engine has nothing to probe",
        ))
        return findings

    mode_label = "dry-run" if dry_run else "live"
    try:
        if backend == "docker":
            with lab_helpers.compose_session(slug_dir, mode="analyze", dry_run=dry_run) as sess:
                _ok_finding(findings, slug_dir, backend, mode_label, sess)
        elif backend == "orbstack":
            with lab_helpers.vm_session(slug_dir, profile="artifact-generation", dry_run=dry_run) as sess:
                _ok_finding(findings, slug_dir, backend, mode_label, sess)
        elif backend == "qemu":
            with lab_helpers.qemu_session(slug_dir, profile="virt", dry_run=dry_run) as sess:
                _ok_finding(findings, slug_dir, backend, mode_label, sess)
        else:
            findings.append(Finding(
                severity="warning",
                engine=ENGINE,
                rule_id="lab-fuzz-unknown-backend",
                path=str(slug_dir),
                message=f"unknown lab_backend {backend!r}; expected docker|orbstack|qemu|none",
            ))
    except Exception as e:
        findings.append(Finding(
            severity="warning",
            engine=ENGINE,
            rule_id="lab-fuzz-provision-error",
            path=str(slug_dir),
            message=f"{backend} provisioning ({mode_label}) raised: {type(e).__name__}: {e}",
            remediation_hint=(
                "rerun with --no-runtime to bypass the live backend and rely "
                "on artifact_fuzz / binary_fuzz only"
            ),
            extra={"traceback": traceback.format_exc()},
        ))
    return findings


def _ok_finding(findings: list[Finding], slug_dir: Path, backend: str,
                mode_label: str, session) -> None:
    findings.append(Finding(
        severity="info",
        engine=ENGINE,
        rule_id="lab-fuzz-probed",
        path=str(slug_dir),
        message=(
            f"lab-fuzz probed {backend} backend in {mode_label} mode "
            "(v0.1: provenance recorded; v0.2 will add endpoint probing)"
        ),
        extra={
            "backend": backend,
            "mode": mode_label,
            "started_at": getattr(session, "started_at", ""),
        },
    ))
