"""Adapter builders + flag-redaction helpers for `bluechall_publish.py`.

Architecture:
  CTFd canonical (build_ctfd_canonical) → rCTF / picoCTF / Sherlocks derivations
  Flag redaction (redact_flag_in_text) runs over every adapter's serialized
  bytes BEFORE writing, scanning for the canonical flag in literal / base64
  / hex / rot13 / urlencoded encodings.

The publish CLI keeps `flag` / `flags` / `answer` field VALUES intact
(those are *supposed* to contain the flag). Redaction targets every other
location — most notably the `description`, `hints`, and free-form prose
inside the YAML serialization.
"""

from __future__ import annotations

import base64
import binascii
import codecs
import urllib.parse as _u
from typing import Iterable


# Smallest encoded-flag substring length that triggers the redactor. Below
# this, false-positive risk (random short alphanumeric runs) outweighs
# leak-detection value.
NEEDLE_MIN_LEN = 6


def flag_needles(canonical: str) -> list[tuple[str, str]]:
    """Return (encoding-name, needle-string) pairs covering common
    encodings of the canonical flag. Each needle ≥ NEEDLE_MIN_LEN; shorter
    candidates are dropped to keep false-positive rate down.

    Encodings covered: literal, base64 (with and without `=` padding),
    base32 (with and without padding), hex (lower+upper), urlencoded,
    rot13. Reverse-byte is intentionally omitted from text-stream
    scanning (would require iterating every reversal length; binary
    scanners under `_copy_filtered` style logic handle that case).
    """
    raw = canonical.encode("utf-8")
    b64_padded = base64.b64encode(raw).decode("ascii")
    b32_padded = base64.b32encode(raw).decode("ascii")
    needles: list[tuple[str, str]] = [
        ("literal", canonical),
        ("base64-unpadded", b64_padded.rstrip("=")),
        ("base64-padded", b64_padded),
        ("base32-unpadded", b32_padded.rstrip("=")),
        ("base32-padded", b32_padded),
        ("hex-lower", binascii.hexlify(raw).decode("ascii")),
        ("hex-upper", binascii.hexlify(raw).decode("ascii").upper()),
        ("urlencoded", _u.quote(canonical, safe="")),
        ("rot13", codecs.encode(canonical, "rot_13")),
    ]
    out: list[tuple[str, str]] = []
    seen: set[str] = set()
    for name, n in needles:
        if len(n) < NEEDLE_MIN_LEN:
            continue
        if n in seen:
            continue
        seen.add(n)
        out.append((name, n))
    return out


FLAG_FIELD_KEYS = ("flag", "flags", "answer")

VALID_NIST_PHASES = ("collection", "examination", "analysis", "reporting")


class InvalidQuestionError(ValueError):
    """Raised when a question dict fails publish-time validation.

    The publish CLI converts this to a user error (exit code 1) rather
    than letting it bubble up as an internal error.
    """


def validate_questions(questions: list[dict]) -> None:
    """Reject questions missing required fields or carrying invalid enum
    values. Called by `build_ctfd_canonical` before flattening into
    sub-challenges so a typo like `nist_phase: triage` cannot ship.
    """
    for i, q in enumerate(questions):
        qid = q.get("id", f"<index {i}>")
        at = q.get("attack_technique")
        if not at:
            raise InvalidQuestionError(
                f"question {qid!r}: `attack_technique` is required (MITRE ATT&CK id)"
            )
        np = q.get("nist_phase")
        if not np:
            raise InvalidQuestionError(
                f"question {qid!r}: `nist_phase` is required "
                f"(one of {list(VALID_NIST_PHASES)})"
            )
        if np not in VALID_NIST_PHASES:
            raise InvalidQuestionError(
                f"question {qid!r}: `nist_phase` {np!r} not in "
                f"{list(VALID_NIST_PHASES)}"
            )
        ans = q.get("answer")
        if not ans:
            raise InvalidQuestionError(
                f"question {qid!r}: `answer` is required"
            )


def redact_flag_in_text(text: str, *, canonical: str) -> tuple[str, list[str]]:
    """Replace each known encoding of the canonical flag in `text` with
    `FLAG{REDACTED}`. Returns (redacted_text, encodings_hit).

    Used for textual scans on free-form strings that should NEVER contain
    the flag (description, scenario, hints). Callers who need to keep
    legitimate `flag`/`flags`/`answer` field values intact should use
    `redact_flag_in_payload` (structural walk) instead.

    Empty / falsy `canonical` raises ValueError: silently returning the
    input unchanged would let any caller that forgets to populate
    `canonical` ship unredacted output.
    """
    if not canonical:
        raise ValueError(
            "redact_flag_in_text: canonical must be a non-empty string; "
            "an empty value would silently leave the text unredacted"
        )
    encodings_hit: list[str] = []
    for name, needle in flag_needles(canonical):
        if needle in text:
            text = text.replace(needle, "FLAG{REDACTED}")
            encodings_hit.append(name)
    return text, encodings_hit


def redact_flag_in_payload(payload, *, canonical: str) -> tuple[object, list[str]]:
    """Walk a parsed YAML payload (dict / list / scalar) and redact the
    canonical flag (and its encodings) in every string value EXCEPT
    those under `flag` / `flags` / `answer` keys. Returns
    (new_payload, encodings_hit_anywhere).

    This is the structural alternative to text-level redaction and is
    correct in the face of flag values that legitimately appear in the
    adapter (e.g., `flags: [FLAG{...}]` MUST keep the literal flag).
    """
    encodings_hit: list[str] = []

    def _walk(node, *, in_flag_field: bool):
        if isinstance(node, dict):
            return {k: _walk(v, in_flag_field=k in FLAG_FIELD_KEYS) for k, v in node.items()}
        if isinstance(node, list):
            return [_walk(item, in_flag_field=in_flag_field) for item in node]
        if isinstance(node, str):
            if in_flag_field:
                return node
            redacted, hits = redact_flag_in_text(node, canonical=canonical)
            for h in hits:
                if h not in encodings_hit:
                    encodings_hit.append(h)
            return redacted
        return node

    return _walk(payload, in_flag_field=False), encodings_hit


# === Adapter builders =======================================================


def _title_from_slug(slug: str) -> str:
    return slug.replace("-", " ").replace("_", " ").title()


def build_ctfd_canonical(manifest: dict, *, questions: list[dict] | None = None) -> dict | list[dict]:
    """Build the CTFd ctfcli canonical form from the manifest.

    For `questions-as-flags`, returns a *list* of ctfcli entries (one
    per question). For all other emission modes, returns a single dict.
    """
    slug = manifest["slug"]
    base = {
        "name": _title_from_slug(slug),
        "author": manifest.get("author", "bluechall-master"),
        "category": manifest.get("category", "misc"),
        "description": manifest.get(
            "description",
            f"{_title_from_slug(slug)} — see README.player.md",
        ),
        "value": manifest.get("value", 100),
        "type": manifest.get("type", "standard"),
        "version": manifest.get("version", "0.1"),
        "state": manifest.get("state", "visible"),
        "topics": manifest.get("topics", []),
        "tags": manifest.get("tags", []),
        "hints": list(manifest.get("hints", [])),
        "requirements": list(manifest.get("requirements", [])),
        "flags": [manifest.get("canonical_flag", "")],
    }
    if manifest.get("flag_emission") == "service-derived":
        base["connection_info"] = manifest.get("connection_info", "")

    if manifest.get("flag_emission") == "questions-as-flags" and questions:
        validate_questions(questions)
        out: list[dict] = []
        for q in questions:
            entry = dict(base)
            entry["name"] = f"{base['name']} — {q.get('id', '?')}"
            qtxt = q.get("question", "")
            entry["description"] = (
                f"{base['description']}\n\n**Question:** {qtxt}"
            )
            entry["flags"] = [q.get("answer", "")]
            entry["value"] = q.get("points", base["value"])
            entry["tags"] = list(base.get("tags") or []) + [
                f"attack:{q.get('attack_technique', '')}",
                f"nist:{q.get('nist_phase', '')}",
            ]
            out.append(entry)
        return out
    return base


def build_rctf(canonical: dict | list[dict]) -> tuple[dict | list[dict], list[str]]:
    """Derive the rCTF form from the CTFd canonical. Returns
    (rctf_payload, list_of_dropped_field_names). `flags` collapses to
    a single `flag` string (first flag wins). `hints` and `requirements`
    are dropped. `tags` retained.
    """
    dropped: list[str] = []

    def _one(entry: dict) -> dict:
        out = {
            "name": entry["name"],
            "category": entry["category"],
            "description": entry["description"],
            "value": entry["value"],
            "tags": list(entry.get("tags") or []),
            "flag": (entry.get("flags") or [""])[0],
        }
        for f in ("hints", "requirements", "topics", "type", "version", "state",
                  "connection_info"):
            if entry.get(f):
                if f not in dropped:
                    dropped.append(f)
        return out

    if isinstance(canonical, list):
        return [_one(e) for e in canonical], dropped
    return _one(canonical), dropped


def build_picoctf(canonical: dict | list[dict], manifest: dict) -> dict | list[dict]:
    """Derive picoCTF form: drop `type: dynamic` decay, remap `attempts`
    to `instance.max_attempts`, restructure layout to picoCTF's expected
    keys (problem.json-shaped). Static value retained as int.
    """
    def _one(entry: dict) -> dict:
        out = {
            "name": entry["name"],
            "category": entry["category"],
            "description": entry["description"],
            "value": int(entry.get("value") or 100),
            "flag": (entry.get("flags") or [""])[0],
            "author": entry.get("author", "bluechall-master"),
            "hints": list(entry.get("hints") or []),
            "tags": list(entry.get("tags") or []),
        }
        # Remap attempts → instance.max_attempts (manifest-level field).
        attempts = manifest.get("attempts")
        if attempts is not None:
            out["instance"] = {"max_attempts": int(attempts)}
        return out

    if isinstance(canonical, list):
        return [_one(e) for e in canonical]
    return _one(canonical)


def build_sherlocks(manifest: dict, questions: list[dict],
                    *, scenario: str = "") -> dict:
    """Build the multi-question Sherlocks YAML. Schema documented in
    `bluechall-master/reference/platform-targets.md`.

    Required fields: name, category=blue-team, scenario, objectives
    (id/question/answer/attack_technique/points/nist_phase), artifacts.

    Question well-formedness is enforced here too (not only in
    `build_ctfd_canonical`) so a future caller importing build_sherlocks
    standalone cannot bypass `validate_questions`.
    """
    validate_questions(questions)
    objectives = []
    for q in questions:
        objectives.append({
            "id": q.get("id", ""),
            "question": q.get("question", ""),
            "answer": q.get("answer", ""),
            "attack_technique": q.get("attack_technique", ""),
            "points": q.get("points", 0),
            "nist_phase": q.get("nist_phase", "analysis"),
        })
    return {
        "name": _title_from_slug(manifest.get("slug", "demo")),
        "category": "blue-team",
        "scenario": scenario or manifest.get(
            "description", "See README.player.md for the incident scenario."),
        "objectives": objectives,
        "artifacts": list(manifest.get("artifacts", [])),
    }
