"""Anti-reverse-engineering static checks for compiled binaries.

Each rule scans `<slug>/publish/` (and `dist/` / `handout/`) for binary
artefacts and surfaces conditions that make the challenge trivially
defeatable by IDA F5, Ghidra Decompiler, or Frida-style hooks. The rules
emit `warning` (not `critical`) — some challenges legitimately ship
unstripped binaries (educational), and the recipe author must opt in via
manifest tag (handled by recipe linter, not here).

Rules:
  rule_strip_check          flag ELF binaries that ship `.symtab` etc.
  rule_debug_info           flag ELF binaries that ship DWARF
  rule_panic_string_leak    flag Rust binaries that leak `panicked at` paths
"""

from __future__ import annotations

import re
import traceback
from pathlib import Path

from .reporters import Finding


ENGINE = "binary-fuzz"
PUBLISH_CANDIDATES = ("publish", "dist", "handout")
SYMBOL_SECTIONS = (".symtab", ".strtab")
DWARF_SECTIONS_PREFIX = (".debug_",)
PANIC_PATTERNS = (
    re.compile(rb"panicked at"),
    re.compile(rb"library/std/src/"),
    re.compile(rb"src/[a-zA-Z0-9_/.-]+\.rs"),
)


# pyelftools is declared in `compatibility:` but optional at runtime; if it
# is missing, the strip / debug-info rules emit a single advisory and skip.
try:
    from elftools.elf.elffile import ELFFile  # type: ignore
    _HAS_PYELFTOOLS = True
except ImportError:
    ELFFile = None  # type: ignore
    _HAS_PYELFTOOLS = False


def _publish_files(slug_dir: Path) -> list[Path]:
    out: list[Path] = []
    for name in PUBLISH_CANDIDATES:
        d = slug_dir / name
        if d.is_dir():
            for p in sorted(d.rglob("*")):
                if p.is_file():
                    out.append(p)
    return out


def _is_elf(path: Path) -> bool:
    try:
        with path.open("rb") as fh:
            return fh.read(4) == b"\x7fELF"
    except OSError:
        return False


def _elf_section_names(path: Path) -> list[str]:
    """Return the list of ELF section names. Requires pyelftools."""
    if not _HAS_PYELFTOOLS:
        return []
    with path.open("rb") as fh:
        elf = ELFFile(fh)
        return [s.name for s in elf.iter_sections()]


def _missing_pyelftools_finding(slug_dir: Path) -> Finding:
    return Finding(
        severity="advisory",
        engine=ENGINE,
        rule_id="pyelftools-missing",
        path=str(slug_dir),
        message="pyelftools not installed; ELF section inspection skipped",
        remediation_hint="`pip install pyelftools` to enable strip/debug checks",
    )


# === rule: strip-check ======================================================


def rule_strip_check(slug_dir: Path) -> list[Finding]:
    findings: list[Finding] = []
    elfs = [p for p in _publish_files(slug_dir) if _is_elf(p)]
    if not elfs:
        return findings
    if not _HAS_PYELFTOOLS:
        findings.append(_missing_pyelftools_finding(slug_dir))
        return findings
    for fpath in elfs:
        try:
            sections = _elf_section_names(fpath)
        except Exception as e:
            findings.append(Finding(
                severity="advisory",
                engine=ENGINE,
                rule_id="elf-parse-error",
                path=str(fpath.relative_to(slug_dir)),
                message=f"could not parse ELF: {type(e).__name__}: {e}",
            ))
            continue
        leaks = [s for s in sections if s in SYMBOL_SECTIONS or s.startswith(".debug_")]
        if leaks:
            findings.append(Finding(
                severity="warning",
                engine=ENGINE,
                rule_id="unstripped-binary",
                path=str(fpath.relative_to(slug_dir)),
                message=(
                    f"ELF retains symbol/debug sections {leaks!r}; IDA / "
                    "Ghidra will produce a clean decompilation revealing "
                    "function names and types"
                ),
                remediation_hint=(
                    "build with `-s` (strip) or run `strip --strip-all <bin>` "
                    "before publishing"
                ),
            ))
    return findings


# === rule: debug-info =======================================================


def rule_debug_info(slug_dir: Path) -> list[Finding]:
    findings: list[Finding] = []
    elfs = [p for p in _publish_files(slug_dir) if _is_elf(p)]
    if not elfs:
        return findings
    if not _HAS_PYELFTOOLS:
        findings.append(_missing_pyelftools_finding(slug_dir))
        return findings
    for fpath in elfs:
        try:
            sections = _elf_section_names(fpath)
        except Exception:
            continue
        dwarf = [s for s in sections if s.startswith(DWARF_SECTIONS_PREFIX)]
        if dwarf:
            findings.append(Finding(
                severity="warning",
                engine=ENGINE,
                rule_id="dwarf-debug-info-present",
                path=str(fpath.relative_to(slug_dir)),
                message=(
                    f"ELF ships DWARF debug info {dwarf!r}; decompiler types "
                    "and source-line mapping will be available to the player"
                ),
                remediation_hint=(
                    "build with `-Cdebuginfo=0` (Rust) or `-g0` (C/C++) and "
                    "strip the binary"
                ),
            ))
    return findings


# === rule: panic-string-leak ================================================


def rule_panic_string_leak(slug_dir: Path) -> list[Finding]:
    findings: list[Finding] = []
    for fpath in _publish_files(slug_dir):
        try:
            data = fpath.read_bytes()
        except OSError:
            continue
        # Don't waste time on non-binaries: require an ELF/PE/Mach-O header.
        head = data[:4]
        if head not in (b"\x7fELF", b"MZ\x90\x00") and head[:3] not in (b"MZ\x90", b"\xfe\xed\xfa"):
            # Heuristic: only scan if it looks like a binary; ASCII files
            # legitimately contain "panicked at" in source code.
            if not any(c < 9 or (13 < c < 32) for c in data[:512]):
                continue
        for pat in PANIC_PATTERNS:
            m = pat.search(data)
            if m:
                findings.append(Finding(
                    severity="warning",
                    engine=ENGINE,
                    rule_id="rust-panic-leak",
                    path=str(fpath.relative_to(slug_dir)),
                    message=(
                        f"binary contains Rust panic-string evidence "
                        f"{m.group(0)[:80]!r}; player can grep for `panicked at` "
                        "to locate the bounds-check predicate"
                    ),
                    remediation_hint=(
                        "set `RUSTFLAGS='-Cpanic=abort'` and "
                        "`-Cstrip=symbols`; consider `panic_immediate_abort` "
                        "feature for `core` to remove the formatter machinery"
                    ),
                ))
                break
    return findings


# === Batch dispatcher =======================================================


_ALL_RULES = (
    "rule_strip_check",
    "rule_debug_info",
    "rule_panic_string_leak",
)


def run(slug_dir: Path) -> list[Finding]:
    findings: list[Finding] = []
    import sys as _sys
    me = _sys.modules[__name__]
    for name in _ALL_RULES:
        rule = getattr(me, name, None)
        if rule is None:
            continue
        try:
            findings.extend(rule(slug_dir))
        except Exception as e:
            findings.append(Finding(
                severity="warning",
                engine=ENGINE,
                rule_id="internal-error",
                path=str(slug_dir),
                message=f"rule {name!r} raised: {type(e).__name__}: {e}",
                extra={"traceback": traceback.format_exc()},
            ))
    return findings
