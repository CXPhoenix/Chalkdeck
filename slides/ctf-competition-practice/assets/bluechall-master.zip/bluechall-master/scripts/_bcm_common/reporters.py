"""Finding dataclass and report formatters for analyze / validate output.

Severity scheme follows the bluechall-tooling spec: `info` | `advisory` |
`warning` | `critical`. The dataclass rejects unknown severities at
construction so a typo cannot silently produce a finding the validator
treats as low-severity.

`--soft` mode in the validator downgrades `critical` to `warning`. The JSON
output preserves both `effective_severity` and `original_severity` so
downstream tools cannot lose the underlying severity through pretty-print
truncation.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field, asdict
from typing import Iterable


# Strip terminal-injection / display-mangling characters from any string
# field that flows out of the reporter. The escape rendering uses
# `\xHH` (8-bit) or `\uHHHH` (Unicode) so the operator can SEE that
# suspicious bytes exist — silent stripping would help an attacker hide
# the filename. Tab (`\x09`), line feed (`\x0a`), and carriage return
# (`\x0d`) pass through unchanged so multi-line messages render normally.
#
# Coverage:
#   - C0 controls (ASCII 0x00-0x08, 0x0b, 0x0c, 0x0e-0x1f) and DEL (0x7f)
#   - C1 controls (0x80-0x9f) — these are real terminal escapes in
#     8-bit mode (e.g. U+009B = CSI introducer ≡ ESC `[`)
#   - Unicode bidi / RTLO (U+202A-U+202E, U+2066-U+2069) —
#     visually reorder displayed text to mask file extensions
#   - Zero-width chars (U+200B-U+200F, U+2060-U+2064, U+FEFF) — hide
#     content inside identifiers and paths
#   - Line/paragraph separators (U+2028, U+2029) — break naive log
#     parsers and JSON-in-JS contexts
_CONTROL_BYTE_RE = re.compile(
    r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f-\x9f"
    r"​-‏ -‮⁠-⁤⁦-⁩﻿]"
)


def _escape_control(ch: str) -> str:
    cp = ord(ch)
    if cp <= 0xff:
        return f"\\x{cp:02x}"
    return f"\\u{cp:04x}"


# Recursion safety: deep nested `Finding.extra` (e.g. an attacker-supplied
# YAML doc parsed into the field) must not raise RecursionError. The
# limit is well below Python's default `sys.getrecursionlimit() == 1000`.
_SANITIZE_MAX_DEPTH = 64
_SANITIZE_OVERFLOW_SENTINEL = "<sanitize-depth-exceeded>"


def _sanitize(value, *, _depth: int = 0):
    """Replace ANSI / Unicode display-injection characters with `\\xHH`
    or `\\uHHHH` literals.

    Recurses into list / tuple / set / frozenset / dict containers so
    `Finding.extra` string values nested inside any of these are also
    cleaned. Non-string scalars (int / bool / None / Path / dataclass /
    custom types) pass through unchanged. Recursion depth is capped at
    64 levels — beyond that, a sentinel string replaces the value to
    prevent RecursionError on a maliciously deep structure.
    """
    if _depth > _SANITIZE_MAX_DEPTH:
        return _SANITIZE_OVERFLOW_SENTINEL
    if isinstance(value, str):
        return _CONTROL_BYTE_RE.sub(lambda m: _escape_control(m.group(0)), value)
    if isinstance(value, list):
        return [_sanitize(v, _depth=_depth + 1) for v in value]
    if isinstance(value, tuple):
        return tuple(_sanitize(v, _depth=_depth + 1) for v in value)
    if isinstance(value, (set, frozenset)):
        return type(value)(_sanitize(v, _depth=_depth + 1) for v in value)
    if isinstance(value, dict):
        return {k: _sanitize(v, _depth=_depth + 1) for k, v in value.items()}
    return value


VALID_SEVERITIES = ("info", "advisory", "warning", "critical")
VALID_ENGINES = (
    "artifact-fuzz",
    "binary-fuzz",
    "lab-fuzz",
    "rule-catalog",
    # `flag-emission` and `wiki` were unified into reporters.Finding so
    # `flag_emission.validate_*` and `wiki.verify` can flow through the
    # same to_sarif / to_json pipeline as the other engines.
    "flag-emission",
    "wiki",
)
SARIF_LEVEL_MAP = {
    "info": "note",
    "advisory": "note",
    "warning": "warning",
    "critical": "error",
}


@dataclass(kw_only=True)
class Finding:
    """A single analysis or validation finding.

    `engine` distinguishes analyze findings (artifact-fuzz / binary-fuzz /
    lab-fuzz) from validate findings (`rule-catalog`). `rule_id` identifies
    the specific check. `path` and `line` locate the offending artefact.

    Both `severity` and `engine` are validated at construction so a typo
    (e.g., `severity="error"` from a copy-pasted webchall rule, or
    `engine="artifact_fuzz"` with the wrong separator) cannot silently
    produce a finding that downstream filters miss. Validation lives here
    rather than at module import so test fixtures can construct findings
    with explicit values; runtime callers that surface ValueError get an
    `internal-error` Finding via `run()` dispatchers in each engine.

    If `line is None`, SARIF emission omits the `region` field rather
    than serialising `null` (which is invalid per SARIF 2.1.0 spec).
    """

    severity: str  # info | advisory | warning | critical
    engine: str    # artifact-fuzz | binary-fuzz | lab-fuzz | rule-catalog
    rule_id: str
    path: str
    message: str
    line: int | None = None
    remediation_hint: str = ""
    extra: dict = field(default_factory=dict)

    def __post_init__(self) -> None:
        if self.severity not in VALID_SEVERITIES:
            raise ValueError(
                f"Finding.severity must be one of {VALID_SEVERITIES}; "
                f"got {self.severity!r} (rule_id={self.rule_id!r})"
            )
        if self.engine not in VALID_ENGINES:
            raise ValueError(
                f"Finding.engine must be one of {VALID_ENGINES}; "
                f"got {self.engine!r} (rule_id={self.rule_id!r})"
            )

    def to_dict(self, *, soft_mode: bool = False) -> dict:
        d = asdict(self)
        # Sanitize every string field (including string values nested
        # inside `extra`) so terminal-injection bytes never reach the
        # operator's stdout / output file.
        d["path"] = _sanitize(d["path"])
        d["message"] = _sanitize(d["message"])
        d["remediation_hint"] = _sanitize(d["remediation_hint"])
        d["extra"] = _sanitize(d["extra"])
        if soft_mode:
            original = self.extra.get("original_severity", self.severity)
            d["effective_severity"] = self.severity
            d["original_severity"] = original
        return d


def downgrade_for_soft(findings: Iterable[Finding]) -> list[Finding]:
    """Downgrade `critical` findings to `warning` while preserving the
    original severity in `extra.original_severity`. Idempotent: applying
    twice does not double-record.
    """
    out: list[Finding] = []
    for f in findings:
        if f.severity == "critical":
            if "original_severity" not in f.extra:
                f.extra["original_severity"] = "critical"
            f.severity = "warning"
        out.append(f)
    return out


def to_json(findings: Iterable[Finding], *, soft_mode: bool = False) -> str:
    items = [f.to_dict(soft_mode=soft_mode) for f in findings]
    return json.dumps(items, indent=2, ensure_ascii=False)


def to_sarif(findings: Iterable[Finding], *, tool_name: str) -> str:
    findings = list(findings)
    rules: dict[str, dict] = {}
    results = []
    for f in findings:
        level = SARIF_LEVEL_MAP.get(f.severity, "none")
        rules.setdefault(
            f.rule_id,
            {
                "id": f.rule_id,
                "shortDescription": {"text": f.rule_id},
                "defaultConfiguration": {"level": level},
            },
        )
        # Sanitize every string field that flows into SARIF output so
        # downstream viewers (CodeQL UI, GitHub annotations) cannot be
        # tricked by terminal-escape bytes carried in artefact paths.
        loc: dict = {"artifactLocation": {"uri": _sanitize(f.path)}}
        if f.line is not None:
            loc["region"] = {"startLine": f.line}
        properties = {"engine": f.engine}
        if f.remediation_hint:
            properties["remediation_hint"] = _sanitize(f.remediation_hint)
        results.append(
            {
                "ruleId": f.rule_id,
                "level": level,
                "message": {"text": _sanitize(f.message)},
                "locations": [{"physicalLocation": loc}],
                "properties": properties,
            }
        )
    sarif = {
        "$schema": "https://json.schemastore.org/sarif-2.1.0",
        "version": "2.1.0",
        "runs": [
            {
                "tool": {
                    "driver": {
                        "name": tool_name,
                        "rules": list(rules.values()),
                    }
                },
                "results": results,
            }
        ],
    }
    return json.dumps(sarif, indent=2, ensure_ascii=False)


def to_pretty(findings: Iterable[Finding]) -> str:
    findings = list(findings)
    if not findings:
        return "no findings.\n"
    glyph = {"info": "·", "advisory": "ℹ", "warning": "⚠", "critical": "✗"}
    lines = []
    for f in findings:
        g = glyph.get(f.severity, "?")
        # Sanitize every string field before formatting so an attacker-
        # controlled artefact path cannot inject ANSI escapes into the
        # operator's terminal output.
        path = _sanitize(f.path)
        message = _sanitize(f.message)
        loc = path if f.line is None else f"{path}:{f.line}"
        lines.append(f"{g} [{f.severity:8}] [{f.engine:13}] {f.rule_id}: {message}")
        lines.append(f"    @ {loc}")
        if f.remediation_hint:
            lines.append(f"    → {_sanitize(f.remediation_hint)}")
    return "\n".join(lines) + "\n"
