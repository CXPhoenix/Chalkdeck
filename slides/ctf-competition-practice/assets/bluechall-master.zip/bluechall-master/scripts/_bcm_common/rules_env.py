"""`.rules.env` parser, validator, and writer for bluechall-master.

Single source of truth for the 23-key event-scoped CTF authoring schema:
the 15 keys defined by `webchall-rules-env` plus 8 bluechall-specific keys
that govern toolchain whitelists, lab backends, flag emission, and ATT&CK
versioning.

Pure stdlib (re, pathlib, shlex, tempfile, os) — no third-party dependencies.

Public API:
    load(path)                 -> dict[str, str]
    get(key, fallback, *, path) -> str | None
    write(path, mapping, *, force) -> None
    validate(mapping)          -> None  (raises ValueError on failure)
    render(mapping)            -> str
    normalize_for_write(mapping) -> dict[str, str]
"""

from __future__ import annotations

import os
import re
import shlex
import tempfile
from pathlib import Path
from typing import Iterable

# === Schema ==================================================================

# 15 webchall keys (preserved verbatim from `webchall-rules-env`) +
# 8 bluechall keys = 23 total.
WEBCHALL_KEYS: tuple[str, ...] = (
    "CTF_EVENT_NAME",
    "CTF_EVENT_LONG_NAME",
    "FLAG_REGEX",
    "FLAG_FORMAT_LITERAL",
    "FLAG_TYPE",
    "FLAG_ASSET_VERSION_CONTROLLED",
    "AUTHOR_NAME",
    "AUTHOR_EMAIL",
    "CATEGORIES",
    "DIFFICULTIES",
    "HOST_PORT_RANGE_START",
    "HOST_PORT_RANGE_END",
    "PLAYER_FACING_LOCALE",
    "SPEC_LOCALE",
    "BLOCK_PRC_VOCAB",
    "ENFORCE_ANTI_AI_SLOP",
)

BLUECHALL_KEYS: tuple[str, ...] = (
    "FORENSICS_TOOLCHAIN_PROFILE",
    "REVERSE_TOOLCHAIN_PROFILE",
    "BLUE_TEAM_QUESTION_LIMIT",
    "LAB_BACKEND_DEFAULT",
    "FLAG_EMISSION_DEFAULT",
    "EXTERNAL_FLAG_SERVICE_PORT_RANGE_START",
    "EXTERNAL_FLAG_SERVICE_PORT_RANGE_END",
    "MITRE_ATTACK_VERSION",
)

REQUIRED_KEYS: tuple[str, ...] = WEBCHALL_KEYS + BLUECHALL_KEYS

PRIMARY_CATEGORIES = ("forensics", "reverse", "blue-team")
LAB_BACKEND_ENUM = ("docker", "orbstack", "qemu", "none")
FLAG_EMISSION_ENUM = ("single-static", "questions-as-flags", "service-derived", "multi-stage-pivot")
FLAG_TYPE_ENUM = ("static", "dynamic")
BOOL_KEYS = ("FLAG_ASSET_VERSION_CONTROLLED", "BLOCK_PRC_VOCAB", "ENFORCE_ANTI_AI_SLOP")
LOCALE_KEYS = ("PLAYER_FACING_LOCALE", "SPEC_LOCALE")
PORT_MIN, PORT_MAX = 1024, 65535
QUESTION_LIMIT_MIN, QUESTION_LIMIT_MAX = 1, 50
DEFAULT_FILENAME = ".rules.env"

# DoS guard: cap on file size we agree to read. The 23-key schema renders to
# under 2 KiB; anything beyond a few KiB is either malicious or a runaway tool.
MAX_FILE_BYTES = 64 * 1024

# Optional schema keys: permitted but not required. Currently empty —
# the schema is a strict required set. Reserved for future additions
# that should not break existing `.rules.env` files.
OPTIONAL_KEYS: tuple[str, ...] = ()

# Representative env-poison vectors enumerated in the validator's error
# message so an operator who hits the allowlist understands the
# rationale. The list is illustrative, not exhaustive — the rule is
# "any key not in REQUIRED_KEYS or OPTIONAL_KEYS is rejected", which
# closes the door on every variable an attacker might dream up.
_ENV_POISON_HINT_VECTORS = (
    "LD_PRELOAD", "LD_AUDIT", "LD_LIBRARY_PATH",
    "DYLD_INSERT_LIBRARIES",
    "PYTHONPATH", "PYTHONSTARTUP",
    "BASH_ENV", "ENV", "IFS", "PROMPT_COMMAND",
    "NODE_OPTIONS", "JAVA_TOOL_OPTIONS", "RUBYOPT", "PERL5OPT",
    "KUBECONFIG", "DOCKER_HOST",
    "PATH", "HTTP_PROXY", "HTTPS_PROXY", "NO_PROXY", "GIT_SSH_COMMAND",
)

# Regexes --------------------------------------------------------------------

_KEY_RE = re.compile(r"^[A-Z][A-Z0-9_]*$")
_LINE_RE = re.compile(r"^([A-Z][A-Z0-9_]*)=(.*)$")
_EVENT_NAME_RE = re.compile(r"^[A-Za-z0-9._-]+$")
_LOCALE_RE = re.compile(r"^[a-z]{2,3}(-[A-Z][a-z]{3})?(-[A-Z]{2})?$")
_LOWER_TOKEN_RE = re.compile(r"^[a-z]+$")
_CATEGORY_TOKEN_RE = re.compile(r"^[a-z]+(-[a-z]+)?$")  # allows blue-team, white-box
_TOOL_TOKEN_RE = re.compile(r"^[a-z][a-z0-9.+\-]*$")
_MITRE_VERSION_RE = re.compile(r"^v\d+\.\d+$")


# === Parsing =================================================================


def _parse_text(text: str) -> dict[str, str]:
    """Parse the dotenv subset; raises ValueError on malformed lines."""
    out: dict[str, str] = {}
    for lineno, raw in enumerate(text.splitlines(), start=1):
        line = raw.rstrip("\r")
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            continue
        if stripped.startswith("export "):
            raise ValueError(
                f"line {lineno}: `export` prefix is not permitted in .rules.env"
            )
        m = _LINE_RE.match(stripped)
        if not m:
            raise ValueError(
                f"line {lineno}: malformed declaration {stripped!r} "
                "(expected KEY=VALUE with KEY matching ^[A-Z][A-Z0-9_]*$)"
            )
        key, raw_value = m.group(1), m.group(2)
        value = _decode_value(raw_value, lineno=lineno)
        if "$" in value and _looks_like_expansion(value):
            raise ValueError(
                f"line {lineno}: variable expansion ($VAR) is not permitted in .rules.env"
            )
        out[key] = value
    return out


def _decode_value(raw: str, *, lineno: int) -> str:
    raw = raw.strip()
    if not raw:
        return ""
    try:
        lexer = shlex.shlex(raw, posix=True)
        lexer.whitespace_split = True
        lexer.commenters = "#"
        tokens = list(lexer)
    except ValueError as e:
        raise ValueError(f"line {lineno}: cannot tokenize value {raw!r}: {e}") from e
    if not tokens:
        return ""
    if len(tokens) > 1:
        raise ValueError(
            f"line {lineno}: value contains unquoted whitespace; "
            "wrap multi-word values in single or double quotes"
        )
    return tokens[0]


def _looks_like_expansion(value: str) -> bool:
    return bool(re.search(r"\$\{?[A-Za-z_]\w*\}?", value))


# === Public read API =========================================================


def load(path: Path) -> dict[str, str]:
    """Parse `.rules.env` at `path`. Returns `{}` if the file does not exist."""
    p = Path(path)
    if not p.exists():
        return {}
    if p.is_dir():
        raise ValueError(f"{p} is a directory, not a regular file")
    size = p.stat().st_size
    if size > MAX_FILE_BYTES:
        raise ValueError(
            f"{p} is {size} bytes; refusing to parse files larger than "
            f"{MAX_FILE_BYTES} bytes (DoS guard)"
        )
    return _parse_text(p.read_text(encoding="utf-8"))


def get(
    key: str,
    fallback: str | None = None,
    *,
    path: Path | None = None,
) -> str | None:
    target = Path(path) if path is not None else Path.cwd() / DEFAULT_FILENAME
    try:
        data = load(target)
    except ValueError:
        return fallback
    return data.get(key, fallback)


# === Validation ==============================================================


def validate(mapping: dict[str, str]) -> None:
    """Validate `mapping` against the 23-key schema. Raises ValueError on
    any failure; the message names the offending key(s).
    """
    missing = [k for k in REQUIRED_KEYS if k not in mapping]
    if missing:
        raise ValueError(f"missing required keys: {missing}")
    errors: list[str] = []
    for key in REQUIRED_KEYS:
        try:
            _validate_key(key, mapping[key])
        except ValueError as e:
            errors.append(str(e))

    # Cross-key invariants ----------------------------------------------------

    if "HOST_PORT_RANGE_START" in mapping and "HOST_PORT_RANGE_END" in mapping:
        try:
            start = int(mapping["HOST_PORT_RANGE_START"])
            end = int(mapping["HOST_PORT_RANGE_END"])
            if end < start:
                errors.append(
                    "HOST_PORT_RANGE_END must be >= HOST_PORT_RANGE_START"
                )
        except ValueError:
            pass

    if (
        "EXTERNAL_FLAG_SERVICE_PORT_RANGE_START" in mapping
        and "EXTERNAL_FLAG_SERVICE_PORT_RANGE_END" in mapping
    ):
        try:
            ext_start = int(mapping["EXTERNAL_FLAG_SERVICE_PORT_RANGE_START"])
            ext_end = int(mapping["EXTERNAL_FLAG_SERVICE_PORT_RANGE_END"])
            if ext_end < ext_start:
                errors.append(
                    "EXTERNAL_FLAG_SERVICE_PORT_RANGE_END must be >= "
                    "EXTERNAL_FLAG_SERVICE_PORT_RANGE_START"
                )
            # No overlap with HOST_PORT_RANGE.
            try:
                host_start = int(mapping["HOST_PORT_RANGE_START"])
                host_end = int(mapping["HOST_PORT_RANGE_END"])
                if not (ext_end < host_start or ext_start > host_end):
                    errors.append(
                        f"EXTERNAL_FLAG_SERVICE port range "
                        f"[{ext_start},{ext_end}] must NOT overlap with "
                        f"HOST_PORT_RANGE [{host_start},{host_end}]"
                    )
            except (KeyError, ValueError):
                pass
        except ValueError:
            pass

    if "FLAG_REGEX" in mapping and "FLAG_FORMAT_LITERAL" in mapping:
        flag_re = mapping["FLAG_REGEX"]
        flag_lit = mapping["FLAG_FORMAT_LITERAL"]
        if "<text>" not in flag_lit:
            errors.append(
                "FLAG_FORMAT_LITERAL must contain the substring '<text>'"
            )
        else:
            sample = flag_lit.replace("<text>", "EXAMPLE_FLAG")
            try:
                if not re.fullmatch(flag_re, sample):
                    errors.append(
                        f"FLAG_FORMAT_LITERAL inconsistent with FLAG_REGEX: "
                        f"sample {sample!r} does not match {flag_re!r}"
                    )
                if re.fullmatch(flag_re, "") or re.fullmatch(flag_re, "a"):
                    errors.append(
                        f"FLAG_REGEX {flag_re!r} is too permissive: must reject "
                        "empty string and single-character input"
                    )
            except re.error:
                pass

    # Allowlist: any key not in the documented schema is rejected. The
    # blocklist (`_FORBIDDEN_EXTRA_KEY_PATTERNS`) was replaced because it
    # kept missing newly-discovered env-poison vectors (BASH_ENV, ENV,
    # NODE_OPTIONS, JAVA_TOOL_OPTIONS, etc.). Schema growth requires an
    # explicit edit to REQUIRED_KEYS or OPTIONAL_KEYS.
    schema = set(REQUIRED_KEYS) | set(OPTIONAL_KEYS)
    extras = sorted(k for k in mapping if k not in schema)
    if extras:
        hint = (
            "extra key(s) not in documented schema: "
            f"{extras}. Schema growth requires editing "
            "REQUIRED_KEYS or OPTIONAL_KEYS in _bcm_common/rules_env.py. "
            "Common env-poison vectors that would also be rejected here: "
            f"{list(_ENV_POISON_HINT_VECTORS)}"
        )
        errors.append(hint)

    if errors:
        raise ValueError("validation failed:\n  - " + "\n  - ".join(errors))


def _validate_key(key: str, value: str) -> None:
    if not _KEY_RE.match(key):
        raise ValueError(f"invalid key name: {key!r}")

    # === 15 webchall keys ===================================================

    if key == "CTF_EVENT_NAME":
        if not value:
            raise ValueError("CTF_EVENT_NAME must be non-empty")
        if not _EVENT_NAME_RE.match(value):
            raise ValueError(
                f"CTF_EVENT_NAME {value!r} must match ^[A-Za-z0-9._-]+$"
            )
    elif key == "CTF_EVENT_LONG_NAME":
        if not value:
            raise ValueError("CTF_EVENT_LONG_NAME must be non-empty")
    elif key == "FLAG_REGEX":
        try:
            re.compile(value)
        except re.error as e:
            raise ValueError(f"FLAG_REGEX does not compile as Python regex: {e}") from e
    elif key == "FLAG_FORMAT_LITERAL":
        if not value:
            raise ValueError("FLAG_FORMAT_LITERAL must be non-empty")
    elif key == "FLAG_TYPE":
        if value not in FLAG_TYPE_ENUM:
            raise ValueError(
                f"FLAG_TYPE {value!r} not in enum {list(FLAG_TYPE_ENUM)}"
            )
    elif key in BOOL_KEYS:
        if value.lower() not in ("true", "false"):
            raise ValueError(
                f"{key} must be literal 'true' or 'false', got {value!r}"
            )
    elif key == "AUTHOR_NAME":
        if value and not re.fullmatch(r"[\w .+\-]{1,128}", value):
            raise ValueError(
                f"AUTHOR_NAME {value!r} must match [\\w .+\\-]{{1,128}}"
            )
    elif key == "AUTHOR_EMAIL":
        if value and not re.fullmatch(
            r"[A-Za-z0-9._%+\-]{1,64}@[A-Za-z0-9.\-]{1,253}", value
        ):
            raise ValueError(
                f"AUTHOR_EMAIL {value!r} must be a plain RFC-5322-lite address"
            )
    elif key == "CATEGORIES":
        tokens = [t.strip() for t in value.split(",")] if value else []
        if not tokens or tokens == [""]:
            raise ValueError("CATEGORIES must be a non-empty comma-separated list")
        for t in tokens:
            if not _CATEGORY_TOKEN_RE.match(t):
                raise ValueError(
                    f"CATEGORIES token {t!r} must match ^[a-z]+(-[a-z]+)?$"
                )
        # bluechall-specific: must include at least one of forensics/reverse/blue-team.
        if not any(t in PRIMARY_CATEGORIES for t in tokens):
            raise ValueError(
                f"CATEGORIES {tokens} must include at least one of "
                f"{list(PRIMARY_CATEGORIES)} (bluechall primary-category constraint)"
            )
    elif key == "DIFFICULTIES":
        tokens = [t.strip() for t in value.split(",")] if value else []
        if not tokens or tokens == [""]:
            raise ValueError("DIFFICULTIES must be a non-empty comma-separated list")
        for t in tokens:
            if not _LOWER_TOKEN_RE.match(t):
                raise ValueError(
                    f"DIFFICULTIES token {t!r} must match ^[a-z]+$"
                )
    elif key in ("HOST_PORT_RANGE_START", "HOST_PORT_RANGE_END"):
        try:
            port = int(value)
        except ValueError as e:
            raise ValueError(f"{key} must be an integer, got {value!r}") from e
        if not (PORT_MIN <= port <= PORT_MAX):
            raise ValueError(f"{key}={port} must be in [{PORT_MIN}, {PORT_MAX}]")
    elif key in LOCALE_KEYS:
        if not _LOCALE_RE.match(value):
            raise ValueError(
                f"{key} {value!r} must match BCP-47 form"
            )

    # === 8 bluechall keys ===================================================

    elif key == "FORENSICS_TOOLCHAIN_PROFILE":
        tokens = [t.strip() for t in value.split(",")] if value else []
        if not tokens or tokens == [""]:
            raise ValueError(
                "FORENSICS_TOOLCHAIN_PROFILE must be a non-empty comma-separated list"
            )
        for t in tokens:
            if not _TOOL_TOKEN_RE.match(t):
                raise ValueError(
                    f"FORENSICS_TOOLCHAIN_PROFILE token {t!r} must match "
                    "^[a-z][a-z0-9.+\\-]*$"
                )
    elif key == "REVERSE_TOOLCHAIN_PROFILE":
        tokens = [t.strip() for t in value.split(",")] if value else []
        if not tokens or tokens == [""]:
            raise ValueError(
                "REVERSE_TOOLCHAIN_PROFILE must be a non-empty comma-separated list"
            )
        for t in tokens:
            if not _TOOL_TOKEN_RE.match(t):
                raise ValueError(
                    f"REVERSE_TOOLCHAIN_PROFILE token {t!r} must match "
                    "^[a-z][a-z0-9.+\\-]*$"
                )
    elif key == "BLUE_TEAM_QUESTION_LIMIT":
        try:
            n = int(value)
        except ValueError as e:
            raise ValueError(
                f"BLUE_TEAM_QUESTION_LIMIT must be an integer, got {value!r}"
            ) from e
        if not (QUESTION_LIMIT_MIN <= n <= QUESTION_LIMIT_MAX):
            raise ValueError(
                f"BLUE_TEAM_QUESTION_LIMIT={n} must be in "
                f"[{QUESTION_LIMIT_MIN}, {QUESTION_LIMIT_MAX}]"
            )
    elif key == "LAB_BACKEND_DEFAULT":
        if value not in LAB_BACKEND_ENUM:
            raise ValueError(
                f"LAB_BACKEND_DEFAULT {value!r} not in enum {list(LAB_BACKEND_ENUM)}"
            )
    elif key == "FLAG_EMISSION_DEFAULT":
        if value not in FLAG_EMISSION_ENUM:
            raise ValueError(
                f"FLAG_EMISSION_DEFAULT {value!r} not in enum {list(FLAG_EMISSION_ENUM)}"
            )
    elif key in (
        "EXTERNAL_FLAG_SERVICE_PORT_RANGE_START",
        "EXTERNAL_FLAG_SERVICE_PORT_RANGE_END",
    ):
        try:
            port = int(value)
        except ValueError as e:
            raise ValueError(f"{key} must be an integer, got {value!r}") from e
        if not (PORT_MIN <= port <= PORT_MAX):
            raise ValueError(f"{key}={port} must be in [{PORT_MIN}, {PORT_MAX}]")
    elif key == "MITRE_ATTACK_VERSION":
        if not _MITRE_VERSION_RE.match(value):
            raise ValueError(
                f"MITRE_ATTACK_VERSION {value!r} must match ^v\\d+\\.\\d+$"
            )


# === Public write API ========================================================


def write(
    path: Path,
    mapping: dict[str, str],
    *,
    force: bool = False,
) -> None:
    """Persist `mapping` to `path` as dotenv. Validates the schema first.

    Refuses to overwrite an existing file unless `force=True`. Atomic write
    via tempfile + os.replace.
    """
    if not isinstance(path, (str, os.PathLike)):
        raise TypeError(
            f"write(path, mapping): path must be str|PathLike, "
            f"got {type(path).__name__}; did you swap arguments?"
        )
    if not isinstance(mapping, dict):
        raise TypeError(
            f"write(path, mapping): mapping must be dict, "
            f"got {type(mapping).__name__}; did you swap arguments?"
        )
    p = Path(path)
    if p.exists() and not force:
        raise FileExistsError(
            f"{p} already exists; pass force=True to overwrite"
        )
    normalized = normalize_for_write(mapping)
    validate(normalized)
    text = render(normalized)

    tmp_path: Path | None = None
    try:
        with tempfile.NamedTemporaryFile(
            mode="w",
            encoding="utf-8",
            dir=p.parent,
            prefix=p.name + ".",
            suffix=".tmp",
            delete=False,
        ) as fh:
            tmp_path = Path(fh.name)
            fh.write(text)
        os.replace(tmp_path, p)
        tmp_path = None
    finally:
        if tmp_path is not None and tmp_path.exists():
            tmp_path.unlink()


def normalize_for_write(mapping: dict[str, str]) -> dict[str, str]:
    """Return a copy with BOOL_KEYS lowercased and stripped, others coerced to str."""
    out: dict[str, str] = {k: str(v) for k, v in mapping.items()}
    for k in BOOL_KEYS:
        if k in out:
            out[k] = out[k].strip().lower()
    return out


def render(mapping: dict[str, str]) -> str:
    """Render the mapping as a sectioned dotenv file with 7 labeled sections."""
    sections: list[tuple[str, Iterable[str]]] = [
        ("Event identity", ("CTF_EVENT_NAME", "CTF_EVENT_LONG_NAME")),
        ("Flag", (
            "FLAG_REGEX",
            "FLAG_FORMAT_LITERAL",
            "FLAG_TYPE",
            "FLAG_ASSET_VERSION_CONTROLLED",
        )),
        ("Author (per-developer override)", ("AUTHOR_NAME", "AUTHOR_EMAIL")),
        ("Categories / Difficulty enums", ("CATEGORIES", "DIFFICULTIES")),
        ("Port allocation", ("HOST_PORT_RANGE_START", "HOST_PORT_RANGE_END")),
        ("Locale / Content rules", (
            "PLAYER_FACING_LOCALE",
            "SPEC_LOCALE",
            "BLOCK_PRC_VOCAB",
            "ENFORCE_ANTI_AI_SLOP",
        )),
        ("Bluechall toolchain whitelists", (
            "FORENSICS_TOOLCHAIN_PROFILE",
            "REVERSE_TOOLCHAIN_PROFILE",
        )),
        ("Bluechall lab and flag emission defaults", (
            "BLUE_TEAM_QUESTION_LIMIT",
            "LAB_BACKEND_DEFAULT",
            "FLAG_EMISSION_DEFAULT",
            "EXTERNAL_FLAG_SERVICE_PORT_RANGE_START",
            "EXTERNAL_FLAG_SERVICE_PORT_RANGE_END",
            "MITRE_ATTACK_VERSION",
        )),
    ]
    lines: list[str] = []
    emitted: set[str] = set()
    for header, keys in sections:
        lines.append(f"# === {header} ===")
        for k in keys:
            if k in mapping:
                lines.append(f"{k}={_quote_if_needed(mapping[k])}")
                emitted.add(k)
        lines.append("")
    extras = [k for k in mapping if k not in emitted]
    if extras:
        lines.append("# === Custom author keys ===")
        for k in extras:
            lines.append(f"{k}={_quote_if_needed(mapping[k])}")
        lines.append("")
    return "\n".join(lines).rstrip("\n") + "\n"


def _quote_if_needed(value: str) -> str:
    if value == "":
        return ""
    if re.fullmatch(r"[A-Za-z0-9._:/=,@+-]+", value):
        return value
    if "'" in value:
        return '"' + value.replace('"', '\\"') + '"'
    return f"'{value}'"
