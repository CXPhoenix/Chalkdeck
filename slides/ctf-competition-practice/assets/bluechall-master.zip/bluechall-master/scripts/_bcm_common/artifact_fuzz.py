"""Anti-grep one-shot detectors for forensics challenge artefacts.

Each rule simulates an attacker running a low-effort tool against the
challenge's player-facing files (under `<slug>/publish/` or, fallback,
`<slug>/dist/` and `<slug>/handout/`). If the tool surfaces the canonical
flag literal, the challenge has an unintended-solve path and the rule
emits a `critical` Finding.

Tools targeted (each rule isolates one):

  rule_strings_one_shot     `strings <file>` (stdlib, always available)
  rule_binwalk_one_shot     `binwalk -e <file>` then grep extracted output
  rule_zsteg_one_shot       `zsteg -a <file>` over PNG/BMP carriers
  rule_exiftool_one_shot    `exiftool <file>` over media metadata
  rule_oletools_one_shot    `olevba` / `oledump.py` over Office files

Missing tools emit an `advisory` Finding with rule_id ending in
`-tool-missing` so a CI operator sees the gap rather than a silent pass.
A rule that raises emits an `internal-error` Finding (engine preserved)
so a single bug does not abort the entire batch.
"""

from __future__ import annotations

import re
import shutil
import subprocess
import tempfile
import traceback
from pathlib import Path

from .reporters import Finding


ENGINE = "artifact-fuzz"
PUBLISH_CANDIDATES = ("publish", "dist", "handout")
DEFAULT_FLAG_REGEX = r"^FLAG\{[!-~]+\}$"

# How many bytes per artefact to scan with `strings`. Anti-DoS for huge dumps.
STRINGS_SCAN_BYTES = 64 * 1024 * 1024  # 64 MiB
STRINGS_MIN_LEN = 4

# Extensions for which each external tool is plausibly relevant.
ZSTEG_EXTS = {".png", ".bmp"}
EXIFTOOL_EXTS = {".jpg", ".jpeg", ".png", ".tiff", ".heic", ".mp4", ".mov", ".pdf"}
OLETOOLS_EXTS = {".doc", ".docx", ".docm", ".xls", ".xlsx", ".xlsm", ".xlsb", ".ppt", ".pptx", ".pptm"}


def _publish_files(slug_dir: Path) -> list[Path]:
    """Return all regular files under any publish-style directory at the slug root."""
    out: list[Path] = []
    for name in PUBLISH_CANDIDATES:
        d = slug_dir / name
        if d.is_dir():
            for p in sorted(d.rglob("*")):
                if p.is_file():
                    out.append(p)
    return out


def _scan_for_flag(text: str, flag_regex: str) -> str | None:
    """Return the first substring in `text` that fully matches `flag_regex`,
    or None.

    The user-supplied `flag_regex` is expected to be anchored (`^...$`). We
    strip those anchors to derive a substring search pattern; full-match is
    re-applied to each candidate so the original anchored semantics still
    hold. This makes the scanner work for any prefix (FLAG, picoCTF,
    HTB, ...) without the rule needing to know which event the challenge
    was authored for.
    """
    # Strip leading ^ and trailing $ for substring search; preserve the
    # original anchored regex for the full-match validation pass.
    body = flag_regex
    if body.startswith("^"):
        body = body[1:]
    if body.endswith("$") and not body.endswith(r"\$"):
        body = body[:-1]
    try:
        substr = re.compile(body)
        full = re.compile(flag_regex)
    except re.error:
        return None
    for m in substr.finditer(text):
        if full.fullmatch(m.group(0)):
            return m.group(0)
    return None


# === rule: strings-one-shot =================================================


def rule_strings_one_shot(slug_dir: Path, *, flag_regex: str = DEFAULT_FLAG_REGEX) -> list[Finding]:
    """Pure-Python `strings`: extract printable runs and search for the flag.

    No external dependency — this rule must always run, since `strings` is
    the most basic anti-grep check and its absence would defeat the skill.
    """
    findings: list[Finding] = []
    for fpath in _publish_files(slug_dir):
        try:
            data = fpath.read_bytes()[:STRINGS_SCAN_BYTES]
        except OSError as e:
            findings.append(Finding(
                severity="advisory",
                engine=ENGINE,
                rule_id="strings-read-error",
                path=str(fpath.relative_to(slug_dir)),
                message=f"could not read artefact: {e}",
            ))
            continue
        # Extract runs of >=STRINGS_MIN_LEN printable ASCII.
        runs = re.findall(rb"[\x20-\x7e]{%d,}" % STRINGS_MIN_LEN, data)
        text = "\n".join(r.decode("ascii", errors="ignore") for r in runs)
        hit = _scan_for_flag(text, flag_regex)
        if hit:
            findings.append(Finding(
                severity="critical",
                engine=ENGINE,
                rule_id="strings-one-shot",
                path=str(fpath.relative_to(slug_dir)),
                message=(
                    f"`strings` surfaced the canonical flag {hit!r}; "
                    "challenge is solvable with a single grep"
                ),
                remediation_hint=(
                    "encode/encrypt the flag at rest or split it across the "
                    "challenge's solve-path so it never appears in plain ASCII"
                ),
            ))
    return findings


# === rule: binwalk-one-shot =================================================


def _binwalk_extract(src: Path, dst: Path) -> list[Path]:
    """Extract `src` with `binwalk -e --directory=<dst>` and return the list
    of extracted regular files. Used in tests via monkeypatch.
    """
    # `--` terminates option parsing so a `publish/` filename starting with
    # `-` cannot be reinterpreted as a binwalk flag (argument injection).
    # `--run-as=root` is intentionally NOT passed; binwalk's `-e` extractor
    # spawns external decoders against attacker-supplied input and forcing
    # root-mode disables the only built-in safety net binwalk ships with.
    # Operators who legitimately need root-mode extraction must invoke
    # binwalk separately inside an isolated container.
    subprocess.run(
        ["binwalk", "-e", f"--directory={dst}", "--", str(src)],
        check=False, capture_output=True, timeout=60,
    )
    return [p for p in dst.rglob("*") if p.is_file()]


def rule_binwalk_one_shot(slug_dir: Path, *, flag_regex: str = DEFAULT_FLAG_REGEX) -> list[Finding]:
    findings: list[Finding] = []
    if not shutil.which("binwalk"):
        findings.append(Finding(
            severity="advisory",
            engine=ENGINE,
            rule_id="binwalk-tool-missing",
            path=str(slug_dir),
            message="binwalk not in PATH; anti-`binwalk -e` check skipped",
            remediation_hint="install `binwalk` to enable this anti-grep check",
        ))
        return findings
    for fpath in _publish_files(slug_dir):
        with tempfile.TemporaryDirectory() as td:
            extracted = _binwalk_extract(fpath, Path(td))
            for ex in extracted:
                try:
                    text = ex.read_bytes()[:STRINGS_SCAN_BYTES].decode("latin-1", errors="ignore")
                except OSError:
                    continue
                hit = _scan_for_flag(text, flag_regex)
                if hit:
                    findings.append(Finding(
                        severity="critical",
                        engine=ENGINE,
                        rule_id="binwalk-one-shot",
                        path=str(fpath.relative_to(slug_dir)),
                        message=(
                            f"binwalk -e extraction of {fpath.name} yields a "
                            f"file containing the canonical flag {hit!r}"
                        ),
                        remediation_hint=(
                            "use a non-standard partition layout, encrypted "
                            "container, or steganographic envelope so binwalk "
                            "alone cannot surface the flag"
                        ),
                    ))
                    break
    return findings


# === rule: zsteg-one-shot ===================================================


def _zsteg_run(path: Path) -> str:
    # `--` blocks filename argument-injection (e.g. a `-Sample.png` file).
    r = subprocess.run(
        ["zsteg", "-a", "--", str(path)],
        check=False, capture_output=True, text=True, timeout=120,
    )
    return r.stdout + r.stderr


def rule_zsteg_one_shot(slug_dir: Path, *, flag_regex: str = DEFAULT_FLAG_REGEX) -> list[Finding]:
    findings: list[Finding] = []
    if not shutil.which("zsteg"):
        findings.append(Finding(
            severity="advisory",
            engine=ENGINE,
            rule_id="zsteg-tool-missing",
            path=str(slug_dir),
            message="zsteg not in PATH; anti-`zsteg -a` check skipped",
            remediation_hint="install `zsteg` (gem install zsteg) to enable this check",
        ))
        return findings
    for fpath in _publish_files(slug_dir):
        if fpath.suffix.lower() not in ZSTEG_EXTS:
            continue
        text = _zsteg_run(fpath)
        hit = _scan_for_flag(text, flag_regex)
        if hit:
            findings.append(Finding(
                severity="critical",
                engine=ENGINE,
                rule_id="zsteg-one-shot",
                path=str(fpath.relative_to(slug_dir)),
                message=(
                    f"`zsteg -a {fpath.name}` surfaces the canonical flag "
                    f"{hit!r}"
                ),
                remediation_hint=(
                    "rotate the LSB carrier across non-contiguous coordinate "
                    "regions or layer with a permutation key so zsteg's "
                    "linear scan misses the payload"
                ),
            ))
    return findings


# === rule: exiftool-one-shot ================================================


def _exiftool_run(path: Path) -> str:
    # exiftool honours `--` for end-of-options to block filename injection.
    r = subprocess.run(
        ["exiftool", "-a", "-G1", "--", str(path)],
        check=False, capture_output=True, text=True, timeout=30,
    )
    return r.stdout


def rule_exiftool_one_shot(slug_dir: Path, *, flag_regex: str = DEFAULT_FLAG_REGEX) -> list[Finding]:
    findings: list[Finding] = []
    if not shutil.which("exiftool"):
        findings.append(Finding(
            severity="advisory",
            engine=ENGINE,
            rule_id="exiftool-tool-missing",
            path=str(slug_dir),
            message="exiftool not in PATH; anti-metadata check skipped",
            remediation_hint="install `exiftool` to enable this check",
        ))
        return findings
    for fpath in _publish_files(slug_dir):
        if fpath.suffix.lower() not in EXIFTOOL_EXTS:
            continue
        text = _exiftool_run(fpath)
        hit = _scan_for_flag(text, flag_regex)
        if hit:
            findings.append(Finding(
                severity="critical",
                engine=ENGINE,
                rule_id="exiftool-one-shot",
                path=str(fpath.relative_to(slug_dir)),
                message=(
                    f"`exiftool {fpath.name}` exposes the canonical flag "
                    f"{hit!r} in a metadata tag"
                ),
                remediation_hint=(
                    "strip metadata (`exiftool -all=`) or move the flag into "
                    "pixel/audio data so metadata inspection alone fails"
                ),
            ))
    return findings


# === rule: oletools-one-shot ================================================


def _olevba_run(path: Path) -> str:
    # Prepend `./` (rather than `--`) so even older olevba builds without
    # GNU end-of-options support can't reinterpret a leading-dash filename
    # as a flag.
    rel = str(path) if str(path).startswith(("/", "./")) else f"./{path}"
    r = subprocess.run(
        ["olevba", rel],
        check=False, capture_output=True, text=True, timeout=60,
    )
    return r.stdout


def rule_oletools_one_shot(slug_dir: Path, *, flag_regex: str = DEFAULT_FLAG_REGEX) -> list[Finding]:
    findings: list[Finding] = []
    if not shutil.which("olevba"):
        findings.append(Finding(
            severity="advisory",
            engine=ENGINE,
            rule_id="oletools-tool-missing",
            path=str(slug_dir),
            message="olevba (oletools) not in PATH; anti-Office-macro check skipped",
            remediation_hint="`pip install oletools` to enable this check",
        ))
        return findings
    for fpath in _publish_files(slug_dir):
        if fpath.suffix.lower() not in OLETOOLS_EXTS:
            continue
        text = _olevba_run(fpath)
        hit = _scan_for_flag(text, flag_regex)
        if hit:
            findings.append(Finding(
                severity="critical",
                engine=ENGINE,
                rule_id="oletools-one-shot",
                path=str(fpath.relative_to(slug_dir)),
                message=(
                    f"`olevba {fpath.name}` extracts a macro/string containing "
                    f"the canonical flag {hit!r}"
                ),
                remediation_hint=(
                    "obfuscate macro strings via runtime decode, or move the "
                    "flag computation into a non-static branch oletools cannot "
                    "trace"
                ),
            ))
    return findings


# === Batch dispatcher =======================================================


_ALL_RULES = (
    "rule_strings_one_shot",
    "rule_binwalk_one_shot",
    "rule_zsteg_one_shot",
    "rule_exiftool_one_shot",
    "rule_oletools_one_shot",
)

# When this fraction of rules can't run because external tools are missing,
# the engine emits a single aggregate `warning` so a CI operator skimming
# the report can't ship a challenge with degraded anti-grep coverage.
# Threshold of 3/5 = 60% missing escalates to warning.
_MISSING_TOOL_THRESHOLD = 3


def run(slug_dir: Path, *, flag_regex: str = DEFAULT_FLAG_REGEX) -> list[Finding]:
    """Run every rule. A rule that raises produces an `internal-error`
    Finding so the batch continues. The order of rules matches `_ALL_RULES`.

    If `_MISSING_TOOL_THRESHOLD` or more rules emit a `*-tool-missing`
    advisory, an aggregate `coverage-degraded` warning is appended so a
    Lazy Developer scanning for `critical` count alone still notices the
    coverage gap.
    """
    findings: list[Finding] = []
    import sys as _sys
    me = _sys.modules[__name__]
    for name in _ALL_RULES:
        rule = getattr(me, name, None)
        if rule is None:
            continue
        try:
            findings.extend(rule(slug_dir, flag_regex=flag_regex))
        except Exception as e:
            findings.append(Finding(
                severity="warning",
                engine=ENGINE,
                rule_id="internal-error",
                path=str(slug_dir),
                message=f"rule {name!r} raised: {type(e).__name__}: {e}",
                remediation_hint="file a bug; rule failures should not happen",
                extra={"traceback": traceback.format_exc()},
            ))
    # Aggregate missing-tool count: escalate to warning when too many
    # anti-grep tools are unavailable.
    missing = sum(1 for f in findings if f.rule_id.endswith("-tool-missing"))
    if missing >= _MISSING_TOOL_THRESHOLD:
        findings.append(Finding(
            severity="warning",
            engine=ENGINE,
            rule_id="coverage-degraded",
            path=str(slug_dir),
            message=(
                f"{missing} of {len(_ALL_RULES)} anti-grep tools are missing; "
                "artifact-fuzz coverage is significantly degraded"
            ),
            remediation_hint=(
                "install missing tools (binwalk / zsteg / exiftool / olevba) "
                "before claiming the challenge is unintended-solve safe"
            ),
        ))
    return findings
