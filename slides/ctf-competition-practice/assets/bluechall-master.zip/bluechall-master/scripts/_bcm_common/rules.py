"""Strict validation rule catalog for `bluechall_validate.py`.

The catalog is a tuple of `RuleFn`s. `run_all` invokes each rule and
catches per-rule exceptions so that one bug does not abort the batch —
the failing rule's exception is surfaced as an `internal-error` Finding.

Severity policy:
  critical — the challenge violates a normative spec rule and MUST NOT ship
  warning  — the challenge violates a strong convention; reviewer judgement
  advisory — soft improvement suggestion; informational
  info     — rule ran cleanly (rare; usually omitted to keep output terse)

The catalog is exposed as `CATALOG` so that test harnesses can verify
non-emptiness and discover individual rule names without importing each.
"""

from __future__ import annotations

import re
import traceback
from pathlib import Path
from typing import Callable

import yaml

from . import flag_emission, rules_env
from .reporters import Finding


ENGINE = "rule-catalog"
MANIFEST_FILENAME = ".bluechall.manifest.yaml"

# Documented defaults used when `.rules.env` cannot be located. These
# match the values in `_bcm_common/rules_env.py:WEBCHALL_KEYS` and
# `BLUECHALL_KEYS` defaults so a challenge auditor running validate
# outside an event-repo working directory still gets useful checks.
_DEFAULT_FLAG_REGEX = r"^FLAG\{[!-~]+\}$"
_DEFAULT_BLUE_TEAM_QUESTION_LIMIT = 10
_DEFAULT_MITRE_ATTACK_VERSION = "v15.0"
_DEFAULT_EXTERNAL_PORT_START = 8500
_DEFAULT_EXTERNAL_PORT_END = 8599

CATEGORIES = ("forensics", "reverse", "blue-team", "misc")
FLAG_EMISSIONS = ("single-static", "questions-as-flags", "service-derived", "multi-stage-pivot")
LAB_BACKENDS = ("docker", "orbstack", "qemu", "none")

# Pipeline stage numbers, centralised so analyze and validate CLIs share
# one source of truth; manifest stages are stored under str(N) keys.
STAGE_BRIEF = 1
STAGE_DESIGN = 2
STAGE_SCAFFOLD = 3
STAGE_IMPLEMENT = 4
STAGE_ANALYZE = 5
STAGE_VALIDATE = 6
STAGE_PUBLISH = 7

REQUIRED_MANIFEST_FIELDS = (
    "slug", "category", "recipe_id", "flag_emission", "lab_backend",
    "concept_refs", "cve_refs", "stages", "lab_provenance",
    "canonical_flag",
)

# Placeholder sentinels Scoundrel/Lazy authors are likely to ship
# inadvertently. Patterns are case-insensitive and accept hyphen or
# underscore separators (so `CHANGE-ME` / `CHANGE_ME` both match).
# Includes the empty-braces literal `FLAG{}` since it can pass casual
# review but obviously fails to validate against any real FLAG_REGEX.
# Also catches per-template demo-flag fingerprints (`_demo_`, `_test_`,
# `_example_` substrings) so a Lazy author who copies a template and
# never edits `solution/flag.txt` cannot ship the template's hardcoded
# placeholder as a real challenge flag.
PLACEHOLDER_PATTERNS = (
    re.compile(r"FLAG\{(REPLACE[_-]?ME|REPLACEME)[A-Z0-9_-]*\}", re.IGNORECASE),
    re.compile(r"FLAG\{CHANGE[_-]?ME[A-Z0-9_-]*\}", re.IGNORECASE),
    re.compile(r"FLAG\{TODO\}", re.IGNORECASE),
    re.compile(r"FLAG\{TBD\}", re.IGNORECASE),
    re.compile(r"FLAG\{XXX+\}", re.IGNORECASE),
    re.compile(r"FLAG\{INSERT[_-]?HERE\}", re.IGNORECASE),
    re.compile(r"FLAG\{PLACEHOLDER\}", re.IGNORECASE),
    re.compile(r"FLAG\{EXAMPLE\}", re.IGNORECASE),
    re.compile(r"FLAG\{TEST\}", re.IGNORECASE),
    re.compile(r"FLAG\{\}"),  # empty braces; case-sensitive (canonical FLAG{} only)
    # Demo-flag fingerprints: any FLAG{} value containing _demo_ or _test_
    # or _example_ as a substring is treated as a placeholder. Authors who
    # ship template defaults will be caught.
    re.compile(r"FLAG\{[a-z0-9_-]*_demo_[a-z0-9_-]*\}", re.IGNORECASE),
    re.compile(r"FLAG\{[a-z0-9_-]*_test_[a-z0-9_-]*\}", re.IGNORECASE),
    re.compile(r"FLAG\{[a-z0-9_-]*_example_[a-z0-9_-]*\}", re.IGNORECASE),
)


RuleFn = Callable[[Path, dict], list[Finding]]


# === manifest gate rules ====================================================


def rule_manifest_present(challenge: Path, manifest: dict) -> list[Finding]:
    path = challenge / MANIFEST_FILENAME
    if not path.exists():
        return [Finding(
            severity="critical",
            engine=ENGINE,
            rule_id="manifest-missing",
            path=str(path),
            message=f"{MANIFEST_FILENAME} not found at challenge root",
            remediation_hint="run bluechall_init.py to scaffold the manifest",
        )]
    return []


def rule_manifest_schema(challenge: Path, manifest: dict) -> list[Finding]:
    findings: list[Finding] = []
    if not isinstance(manifest, dict):
        findings.append(Finding(
            severity="critical", engine=ENGINE, rule_id="manifest-schema",
            path=str(challenge / MANIFEST_FILENAME),
            message="manifest is not a YAML mapping",
        ))
        return findings
    for f in REQUIRED_MANIFEST_FIELDS:
        if f not in manifest:
            findings.append(Finding(
                severity="critical", engine=ENGINE, rule_id="manifest-schema",
                path=str(challenge / MANIFEST_FILENAME),
                message=f"manifest missing required field {f!r}",
            ))
    # Empty concept_refs: present but useless. Advisory keeps the ship
    # gate open while telling the operator the audit trail is thin.
    cr = manifest.get("concept_refs")
    if isinstance(cr, list) and len(cr) == 0:
        findings.append(Finding(
            severity="advisory", engine=ENGINE, rule_id="manifest-empty-concept-refs",
            path=str(challenge / MANIFEST_FILENAME),
            message=("concept_refs is empty; cross-reference to wiki "
                     "concepts recommended for audit trail"),
            remediation_hint=(
                "set concept_refs to one or more wiki concept ids "
                "(see bluechall-master/wiki/concepts/)"
            ),
        ))
    cat = manifest.get("category")
    if cat is not None and cat not in CATEGORIES:
        findings.append(Finding(
            severity="critical", engine=ENGINE, rule_id="manifest-schema",
            path=str(challenge / MANIFEST_FILENAME),
            message=f"category {cat!r} not in {list(CATEGORIES)}",
        ))
    em = manifest.get("flag_emission")
    if em is not None and em not in FLAG_EMISSIONS:
        findings.append(Finding(
            severity="critical", engine=ENGINE, rule_id="manifest-schema",
            path=str(challenge / MANIFEST_FILENAME),
            message=f"flag_emission {em!r} not in {list(FLAG_EMISSIONS)}",
        ))
    lb = manifest.get("lab_backend")
    if lb is not None and lb not in LAB_BACKENDS:
        findings.append(Finding(
            severity="critical", engine=ENGINE, rule_id="manifest-schema",
            path=str(challenge / MANIFEST_FILENAME),
            message=f"lab_backend {lb!r} not in {list(LAB_BACKENDS)}",
        ))
    return findings


def rule_recipe_yaml_present(challenge: Path, manifest: dict) -> list[Finding]:
    p = challenge / "recipe.yaml"
    if not p.exists():
        return [Finding(
            severity="warning", engine=ENGINE, rule_id="recipe-yaml-missing",
            path=str(p),
            message=("recipe.yaml not found at challenge root; "
                     "publish adapters cannot derive challenge metadata"),
        )]
    return []


def rule_solution_dir_present(challenge: Path, manifest: dict) -> list[Finding]:
    s = challenge / "solution"
    if not s.is_dir():
        return [Finding(
            severity="critical", engine=ENGINE, rule_id="solution-dir-missing",
            path=str(s),
            message="solution/ directory not found at challenge root",
            remediation_hint="mkdir solution && create solve.py / flag.txt etc.",
        )]
    solve_candidates = [s / "solve.py", s / "solve.sh"]
    if not any(c.exists() for c in solve_candidates):
        return [Finding(
            severity="warning", engine=ENGINE, rule_id="solve-script-missing",
            path=str(s),
            message="solution/ has no solve.py or solve.sh entry point",
        )]
    return []


def rule_flag_emission_consistency(challenge: Path, manifest: dict) -> list[Finding]:
    """Each flag-emission mode requires a distinct on-disk shape under solution/.

    Confused-Developer trap: misreading the mode produces wrong files. The
    catalog must catch every mismatch loudly.
    """
    findings: list[Finding] = []
    em = manifest.get("flag_emission")
    s = challenge / "solution"
    if not s.is_dir():
        return findings  # rule_solution_dir_present handles the missing-dir case
    if em == "single-static":
        if not (s / "flag.txt").exists():
            findings.append(Finding(
                severity="critical", engine=ENGINE, rule_id="flag-emission-mismatch",
                path=str(s),
                message=("flag_emission=single-static requires solution/flag.txt; "
                         "file not found"),
            ))
    elif em == "questions-as-flags":
        if not (s / "questions.yaml").exists():
            findings.append(Finding(
                severity="critical", engine=ENGINE, rule_id="flag-emission-mismatch",
                path=str(s),
                message=("flag_emission=questions-as-flags requires "
                         "solution/questions.yaml; file not found"),
            ))
    elif em == "multi-stage-pivot":
        if not (s / "stages.yaml").exists():
            findings.append(Finding(
                severity="critical", engine=ENGINE, rule_id="flag-emission-mismatch",
                path=str(s),
                message=("flag_emission=multi-stage-pivot requires "
                         "solution/stages.yaml; file not found"),
            ))
    elif em == "service-derived":
        # service/ lives at challenge root, not under solution/, but the
        # challenge MUST ship one or the other so cross-check both.
        if not (challenge / "service").is_dir() and not (s / "service").is_dir():
            findings.append(Finding(
                severity="critical", engine=ENGINE, rule_id="flag-emission-mismatch",
                path=str(challenge),
                message=("flag_emission=service-derived requires a service/ "
                         "directory (at challenge root or under solution/); "
                         "directory not found"),
            ))
    return findings


_PLACEHOLDER_SCAN_EXTENSIONS = (
    # Python / C / C++ / headers
    ".py", ".pyi", ".c", ".cpp", ".cc", ".h", ".hpp",
    # Plain text / config
    ".txt", ".yaml", ".yml", ".md", ".toml", ".json", ".env", ".ini", ".cfg",
    # Go / Rust / JVM / .NET / Ruby / PHP / Swift / Kotlin / Scala
    ".go", ".rs", ".java", ".kt", ".kts", ".scala", ".cs", ".rb", ".php",
    ".swift",
    # JavaScript / TypeScript family
    ".js", ".jsx", ".ts", ".tsx", ".mjs", ".cjs",
    # Shell / scripting
    ".sh", ".bash", ".zsh", ".fish", ".ps1", ".bat", ".cmd",
    # Web / styling / templates
    ".html", ".htm", ".css", ".scss", ".sass", ".vue", ".svelte",
    ".j2", ".jinja", ".jinja2", ".tpl",
    # Infra / DSLs
    ".tf", ".hcl", ".sql", ".dockerfile",
)
_PLACEHOLDER_EXCLUDE_DIRS = frozenset((
    "__pycache__", ".pytest_cache", "node_modules", ".git",
    ".venv", "venv", ".tox", "target", "build", "dist",
))
# Cap per-file content read at 2 MiB so a stray binary that slipped past
# the extension filter cannot stall the scan.
_PLACEHOLDER_MAX_BYTES = 2 * 1024 * 1024


def _placeholder_scan_candidates(challenge: Path) -> list[Path]:
    """Walk `solution/**` and `src/**` plus the manifest, return all
    files whose suffix is in the scan whitelist and whose path does not
    cross an excluded directory.

    Symlinks are skipped to prevent (a) attacker-supplied symlinks from
    redirecting the scan outside the challenge tree and (b) infinite
    cycles via `solution/loop -> ..`.
    """
    out: list[Path] = []
    challenge_resolved = Path(challenge).resolve()
    for sub in ("solution", "src"):
        root = challenge / sub
        if not root.is_dir():
            continue
        for p in sorted(root.rglob("*")):
            if p.is_symlink():
                continue
            if not p.is_file():
                continue
            if any(part in _PLACEHOLDER_EXCLUDE_DIRS for part in p.parts):
                continue
            if p.suffix.lower() not in _PLACEHOLDER_SCAN_EXTENSIONS:
                continue
            # Belt-and-braces: confirm the resolved path stays inside the
            # challenge tree even after symlink resolution.
            try:
                p.resolve(strict=False).relative_to(challenge_resolved)
            except ValueError:
                continue
            out.append(p)
    manifest = challenge / ".bluechall.manifest.yaml"
    if manifest.exists() and not manifest.is_symlink():
        out.append(manifest)
    return out


def rule_no_placeholder_flag(challenge: Path, manifest: dict) -> list[Finding]:
    """Scoundrel/Lazy-Developer trap: a placeholder sentinel flag must
    never ship. Walk `solution/**` and `src/**` (plus the manifest) and
    reject any file containing a `PLACEHOLDER_PATTERNS` match.

    Extension whitelist filters out build artefacts (binary blobs, packed
    archives) so the rule does not need to recurse arbitrary file types
    — that is `artifact_fuzz`'s job at Stage 5 Analyze.
    """
    findings: list[Finding] = []
    for p in _placeholder_scan_candidates(challenge):
        try:
            data = p.read_bytes()[:_PLACEHOLDER_MAX_BYTES]
        except OSError:
            continue
        try:
            text = data.decode("utf-8")
        except UnicodeDecodeError:
            text = data.decode("utf-8", errors="ignore")
        for pat in PLACEHOLDER_PATTERNS:
            m = pat.search(text)
            if m:
                findings.append(Finding(
                    severity="critical", engine=ENGINE, rule_id="placeholder-flag",
                    path=str(p.relative_to(challenge) if p.is_relative_to(challenge) else p),
                    message=(
                        f"placeholder sentinel {m.group(0)!r} present; "
                        "set the real canonical flag before publishing"
                    ),
                    remediation_hint=(
                        "replace with a real flag matching .rules.env FLAG_REGEX"
                    ),
                ))
                break  # one finding per file is enough
    return findings


# === flag_emission content rules ============================================


def _resolve_rules_env(challenge: Path) -> tuple[dict, list[Finding]]:
    """Locate `.rules.env` for `challenge`.

    Search order: cwd, then `challenge` directory itself, then `challenge.parent`.
    On hit, the returned mapping is REQUIRED to pass `rules_env.validate()` —
    a malformed or attacker-controlled file (e.g. `FLAG_REGEX=.*` placed
    inside a downloaded challenge bundle) is rejected and the resolver
    falls back to the documented defaults with a `warning` finding so the
    operator can see that the supplied config was unsafe. On miss, an
    `advisory` finding cites the missing file but does not block the run.
    """
    candidates = (
        Path.cwd() / rules_env.DEFAULT_FILENAME,
        Path(challenge) / rules_env.DEFAULT_FILENAME,
        Path(challenge).parent / rules_env.DEFAULT_FILENAME,
    )
    for c in candidates:
        if not c.exists():
            continue
        try:
            mapping = rules_env.load(c)
        except (ValueError, OSError):
            continue
        # Schema enforcement: the parser only converts dotenv text → dict;
        # `validate` is the gate that rejects unknown keys, out-of-range
        # values, and supply-chain `.rules.env` files containing dangerous
        # values (e.g. permissive FLAG_REGEX, oversize question limits).
        try:
            rules_env.validate(mapping)
        except ValueError as e:
            warning = Finding(
                severity="warning",
                engine=ENGINE,
                rule_id="rules-env-invalid",
                path=str(c),
                message=(
                    f".rules.env at {c} failed schema validation; "
                    "falling back to documented defaults instead of "
                    f"trusting the file. Reason: {e}"
                ),
                remediation_hint=(
                    "fix .rules.env per the schema or remove it to use "
                    "documented defaults; do NOT trust .rules.env from "
                    "untrusted challenge bundles"
                ),
            )
            return {}, [warning]
        return mapping, []
    advisory = Finding(
        severity="advisory",
        engine=ENGINE,
        rule_id="rules-env-missing",
        path=str(challenge),
        message=(
            f".rules.env not found in cwd={Path.cwd()!s} or near {challenge!s}; "
            "flag_emission content rules fall back to documented defaults "
            "(FLAG_REGEX, BLUE_TEAM_QUESTION_LIMIT, EXTERNAL_FLAG_SERVICE_PORT_RANGE_*)"
        ),
        remediation_hint=(
            "run bluechall_bootstrap.py at the event-repo root to generate "
            ".rules.env"
        ),
    )
    return {}, [advisory]


def rule_flag_emission_format_compliance(
    challenge: Path, manifest: dict,
) -> list[Finding]:
    """Dispatch to `flag_emission.validate_*` based on `manifest.flag_emission`.

    Findings emitted by the validators already carry `engine="flag-emission"`
    via `flag_emission._finding`; this rule simply forwards them, plus an
    optional advisory when `.rules.env` was not located.
    """
    em = manifest.get("flag_emission")
    if em not in flag_emission.ALL_MODES:
        # rule_manifest_schema already reports unknown modes; no double-report.
        return []
    rules_map, advisories = _resolve_rules_env(challenge)
    flag_regex = rules_map.get("FLAG_REGEX", _DEFAULT_FLAG_REGEX)
    blue_team_limit_raw = rules_map.get(
        "BLUE_TEAM_QUESTION_LIMIT", str(_DEFAULT_BLUE_TEAM_QUESTION_LIMIT))
    try:
        blue_team_limit = int(blue_team_limit_raw)
    except (TypeError, ValueError):
        blue_team_limit = _DEFAULT_BLUE_TEAM_QUESTION_LIMIT
    mitre_version = rules_map.get(
        "MITRE_ATTACK_VERSION", _DEFAULT_MITRE_ATTACK_VERSION)
    try:
        ext_start = int(rules_map.get(
            "EXTERNAL_FLAG_SERVICE_PORT_RANGE_START",
            str(_DEFAULT_EXTERNAL_PORT_START)))
        ext_end = int(rules_map.get(
            "EXTERNAL_FLAG_SERVICE_PORT_RANGE_END",
            str(_DEFAULT_EXTERNAL_PORT_END)))
    except (TypeError, ValueError):
        ext_start = _DEFAULT_EXTERNAL_PORT_START
        ext_end = _DEFAULT_EXTERNAL_PORT_END

    sol = Path(challenge) / "solution"
    findings: list[Finding] = list(advisories)
    if em == flag_emission.MODE_SINGLE_STATIC:
        findings.extend(flag_emission.validate_single_static(
            sol / "flag.txt", flag_regex=flag_regex,
        ))
    elif em == flag_emission.MODE_QUESTIONS_AS_FLAGS:
        # questions-as-flags is canonically a top-level dict with `questions:`
        # key (matches every shipped template and the publisher); legacy list
        # shape is also accepted by extracting via _normalize_questions_yaml.
        qfile = sol / "questions.yaml"
        normalised = _normalise_questions_yaml(qfile)
        if normalised is _QUESTIONS_MALFORMED:
            # dict-shape carrier with `questions:` set to non-list — refuse
            # to silently coerce. Emit a critical finding so a malformed
            # bundle does not pass validation by accident.
            findings.append(Finding(
                severity="critical", engine="flag-emission",
                rule_id="questions-as-flags-questions-not-a-list",
                path=str(qfile),
                message=(
                    "solution/questions.yaml: top-level `questions:` value "
                    "must be a YAML list; a non-list value was silently "
                    "coerced to empty by older builds. Refuse to pass."
                ),
            ))
        elif normalised is None:
            findings.extend(flag_emission.validate_questions_as_flags(
                qfile,
                flag_regex=flag_regex,
                blue_team_question_limit=blue_team_limit,
                mitre_attack_version=mitre_version,
            ))
        else:
            # `validate_questions_as_flags` reads the file directly; if we
            # already normalised, write a temp shadow into a sibling so the
            # validator sees a list-shape file. Simpler path: just call the
            # validator and let it handle dict shape via the catalog rule's
            # own list extraction.
            findings.extend(_validate_questions_as_flags_shape_aware(
                qfile, normalised,
                flag_regex=flag_regex,
                blue_team_question_limit=blue_team_limit,
                mitre_attack_version=mitre_version,
            ))
    elif em == flag_emission.MODE_SERVICE_DERIVED:
        findings.extend(flag_emission.validate_service_derived(
            sol / "service_meta.yaml",
            external_port_start=ext_start,
            external_port_end=ext_end,
        ))
    elif em == flag_emission.MODE_MULTI_STAGE_PIVOT:
        findings.extend(flag_emission.validate_multi_stage_pivot(
            sol / "stages.yaml", flag_regex=flag_regex,
        ))
    else:
        # Unreachable while ALL_MODES stays in sync with the dispatch
        # branches above. If a future contributor adds a mode to ALL_MODES
        # but forgets the elif, surface it loudly so the bug is caught
        # in CI rather than silently shipping zero validator coverage.
        raise AssertionError(
            f"unhandled flag_emission mode {em!r}; ALL_MODES and "
            "rule_flag_emission_format_compliance dispatcher are out of sync"
        )
    return findings


_QUESTIONS_MALFORMED = object()  # sentinel for `questions:` value not a list


def _normalise_questions_yaml(qfile: Path):
    """Return a list[dict] of questions if the file is dict-shape; the
    `_QUESTIONS_MALFORMED` sentinel if the file is dict-shape but
    `questions:` is not a list (so the dispatcher can emit a critical
    finding); or `None` to signal "let the existing list-shape validator
    handle this".

    Previously a non-list `questions:` value (string, dict, int) was
    silently coerced to `[]`, causing the shape-aware validator to emit
    zero findings on a clearly malformed file — a Scoundrel-class bypass.
    """
    if not qfile.exists():
        return None
    try:
        data = yaml.safe_load(qfile.read_text(encoding="utf-8"))
    except yaml.YAMLError:
        return None
    if isinstance(data, dict) and "questions" in data:
        qs = data.get("questions")
        if qs is None:
            return []  # explicit empty
        if isinstance(qs, list):
            return list(qs)
        return _QUESTIONS_MALFORMED
    return None


def _validate_questions_as_flags_shape_aware(
    qfile: Path,
    questions: list,
    *,
    flag_regex: str,
    blue_team_question_limit: int,
    mitre_attack_version: str,
) -> list[Finding]:
    """Validate questions-as-flags entries when they were extracted from the
    canonical dict-shape YAML. Mirrors `flag_emission.validate_questions_as_flags`
    on the per-entry checks but skips the "must be a top-level list" check
    because the dict-shape carrier is allowed in the publisher pipeline.
    """
    out: list[Finding] = []
    if len(questions) > blue_team_question_limit:
        out.append(Finding(
            severity="critical", engine="flag-emission",
            rule_id="questions-as-flags-over-limit",
            path=str(qfile),
            message=(
                f"declares {len(questions)} entries; BLUE_TEAM_QUESTION_LIMIT is "
                f"{blue_team_question_limit}"
            ),
        ))
    seen_ids: set[str] = set()
    _MITRE_ID_RE = re.compile(r"^T\d{4}(\.\d{3})?$")
    for idx, entry in enumerate(questions):
        if not isinstance(entry, dict):
            out.append(Finding(
                severity="critical", engine="flag-emission",
                rule_id="questions-as-flags-entry-not-mapping",
                path=str(qfile),
                message=f"entry {idx} is not a mapping",
            ))
            continue
        for required in ("id", "question", "answer", "attack_technique", "points"):
            if required not in entry:
                out.append(Finding(
                    severity="critical", engine="flag-emission",
                    rule_id="questions-as-flags-missing-field",
                    path=str(qfile),
                    message=f"entry {idx} omits required field {required!r}",
                ))
        qid = entry.get("id")
        if isinstance(qid, str):
            if qid in seen_ids:
                out.append(Finding(
                    severity="critical", engine="flag-emission",
                    rule_id="questions-as-flags-duplicate-id",
                    path=str(qfile),
                    message=f"entry {idx} reuses id {qid!r}",
                ))
            seen_ids.add(qid)
        attack = entry.get("attack_technique")
        if isinstance(attack, str) and not _MITRE_ID_RE.match(attack):
            out.append(Finding(
                severity="warning", engine="flag-emission",
                rule_id="questions-as-flags-attack-technique-format",
                path=str(qfile),
                message=(
                    f"entry {idx} attack_technique {attack!r} does not match "
                    "MITRE ATT&CK technique id format ^T\\d{4}(\\.\\d{3})?$"
                ),
            ))
        points = entry.get("points")
        if isinstance(points, bool) or not isinstance(points, int) or points <= 0:
            out.append(Finding(
                severity="critical", engine="flag-emission",
                rule_id="questions-as-flags-points-invalid",
                path=str(qfile),
                message=(
                    f"entry {idx} points must be a positive integer, "
                    f"got {points!r}"
                ),
            ))
        answer = entry.get("answer")
        freeform = bool(entry.get("freeform_answer"))
        if not freeform and isinstance(answer, str):
            try:
                if not re.fullmatch(flag_regex, answer):
                    out.append(Finding(
                        severity="critical", engine="flag-emission",
                        rule_id="questions-as-flags-answer-regex-mismatch",
                        path=str(qfile),
                        message=(
                            f"entry {idx} answer {answer!r} does not match "
                            f"FLAG_REGEX {flag_regex!r}; declare "
                            "freeform_answer: true to skip this check"
                        ),
                    ))
            except re.error:
                pass
    if not re.match(r"^v\d+\.\d+$", mitre_attack_version):
        out.append(Finding(
            severity="advisory", engine="flag-emission",
            rule_id="questions-as-flags-mitre-version-format",
            path=str(qfile),
            message=(
                f"MITRE_ATTACK_VERSION {mitre_attack_version!r} from .rules.env "
                "does not match v<major>.<minor>"
            ),
        ))
    return out


def rule_flag_emission_recipe_manifest_match(
    challenge: Path, manifest: dict,
) -> list[Finding]:
    """Compare `recipe.yaml` flag_emission with manifest's, emit critical
    finding via flag_emission.validate_consistency on disagreement.
    """
    recipe_path = Path(challenge) / "recipe.yaml"
    if not recipe_path.exists():
        # rule_recipe_yaml_present already reports the missing recipe.
        return []
    text = recipe_path.read_text(encoding="utf-8")
    # recipe.yaml uses `--- ... ---` frontmatter; extract.
    m = re.match(r"^---\s*\n(.*?)\n---", text, re.DOTALL)
    recipe_data: dict = {}
    if m:
        try:
            parsed = yaml.safe_load(m.group(1)) or {}
            if isinstance(parsed, dict):
                recipe_data = parsed
        except yaml.YAMLError:
            pass
    else:
        try:
            parsed = yaml.safe_load(text) or {}
            if isinstance(parsed, dict):
                recipe_data = parsed
        except yaml.YAMLError:
            pass
    return flag_emission.validate_consistency(
        recipe_mode=recipe_data.get("flag_emission"),
        manifest_mode=manifest.get("flag_emission"),
    )


# === Catalog and dispatcher =================================================


CATALOG: tuple[tuple[str, RuleFn], ...] = (
    ("rule_manifest_present", rule_manifest_present),
    ("rule_manifest_schema", rule_manifest_schema),
    ("rule_recipe_yaml_present", rule_recipe_yaml_present),
    ("rule_solution_dir_present", rule_solution_dir_present),
    ("rule_flag_emission_consistency", rule_flag_emission_consistency),
    ("rule_no_placeholder_flag", rule_no_placeholder_flag),
    ("rule_flag_emission_format_compliance", rule_flag_emission_format_compliance),
    ("rule_flag_emission_recipe_manifest_match", rule_flag_emission_recipe_manifest_match),
)


def load_manifest(challenge: Path) -> dict:
    p = challenge / MANIFEST_FILENAME
    if not p.exists():
        return {}
    try:
        data = yaml.safe_load(p.read_text(encoding="utf-8")) or {}
    except yaml.YAMLError:
        return {}
    return data if isinstance(data, dict) else {}


def run_all(challenge: Path, manifest: dict | None = None) -> list[Finding]:
    """Run every rule in CATALOG. Lookup is by name on the module so
    monkeypatched rules are honored in tests.
    """
    if manifest is None:
        manifest = load_manifest(challenge)
    findings: list[Finding] = []
    import sys as _sys
    me = _sys.modules[__name__]
    for name, _default in CATALOG:
        rule = getattr(me, name, None)
        if rule is None:
            continue
        try:
            findings.extend(rule(challenge, manifest))
        except Exception as e:
            findings.append(Finding(
                severity="warning",
                engine=ENGINE,
                rule_id="internal-error",
                path=str(challenge),
                message=f"rule {name!r} raised: {type(e).__name__}: {e}",
                remediation_hint="file a bug; rule failures should not happen",
                extra={"traceback": traceback.format_exc()},
            ))
    return findings
