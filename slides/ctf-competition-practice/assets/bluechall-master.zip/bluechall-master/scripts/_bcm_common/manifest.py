"""`.bluechall.manifest.yaml` schema and operations.

The manifest is the per-challenge state file at `<slug>/.bluechall.manifest.yaml`.

Schema:
    slug: str (kebab-case)
    category: forensics | reverse | blue-team | misc
    recipe_id: str
    flag_emission: single-static | questions-as-flags | service-derived | multi-stage-pivot
    lab_backend: docker | orbstack | qemu | none
    concept_refs: list[str]
    cve_refs: list[str]
    stages:
        "1": { complete: bool, audit_verdict: pass|advisory|fail|null,
               audit_persona: str|null, timestamp: ISO8601|null }
        ...
        "7": { ... }
    lab_provenance: list[ {backend, mode, started_at, ended_at, sha256, ...} ]

Operations:
- create(slug, **fields) -> Manifest
- load(slug_dir) -> Manifest
- write(slug_dir, manifest) -> None
- mark_stage_complete(slug_dir, stage_n)
- append_audit_verdict(slug_dir, stage_n, verdict, persona)
- next_incomplete_stage(slug_dir) -> int | None
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import yaml


MANIFEST_FILENAME = ".bluechall.manifest.yaml"
STAGES = (1, 2, 3, 4, 5, 6, 7)
VERDICTS = ("pass", "advisory", "fail")


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _empty_stages() -> dict[str, dict[str, Any]]:
    return {
        str(s): {
            "complete": False,
            "audit_verdict": None,
            "audit_persona": None,
            "timestamp": None,
        }
        for s in STAGES
    }


def create(
    slug: str,
    *,
    category: str,
    recipe_id: str,
    flag_emission: str,
    lab_backend: str,
    concept_refs: list[str] | None = None,
    cve_refs: list[str] | None = None,
) -> dict[str, Any]:
    """Build a new manifest dict with the seven stages stubbed."""
    return {
        "slug": slug,
        "category": category,
        "recipe_id": recipe_id,
        "flag_emission": flag_emission,
        "lab_backend": lab_backend,
        "concept_refs": list(concept_refs or []),
        "cve_refs": list(cve_refs or []),
        "stages": _empty_stages(),
        "lab_provenance": [],
    }


def load(slug_dir: Path) -> dict[str, Any]:
    path = Path(slug_dir) / MANIFEST_FILENAME
    if not path.exists():
        raise FileNotFoundError(f"manifest not found at {path}")
    data = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    if not isinstance(data, dict):
        raise ValueError(f"manifest at {path} is not a YAML mapping")
    # Heal missing stages key for older manifests.
    if "stages" not in data:
        data["stages"] = _empty_stages()
    if "lab_provenance" not in data:
        data["lab_provenance"] = []
    return data


def write(slug_dir: Path, manifest: dict[str, Any]) -> None:
    path = Path(slug_dir) / MANIFEST_FILENAME
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        yaml.safe_dump(manifest, default_flow_style=False, sort_keys=False),
        encoding="utf-8",
    )


def mark_stage_complete(slug_dir: Path, stage_n: int) -> dict[str, Any]:
    if stage_n not in STAGES:
        raise ValueError(f"stage {stage_n} not in {STAGES}")
    m = load(slug_dir)
    stage = m["stages"][str(stage_n)]
    stage["complete"] = True
    stage["timestamp"] = _now_iso()
    write(slug_dir, m)
    return m


def append_audit_verdict(
    slug_dir: Path, stage_n: int, verdict: str, persona: str | None = None,
) -> dict[str, Any]:
    if stage_n not in STAGES:
        raise ValueError(f"stage {stage_n} not in {STAGES}")
    if verdict not in VERDICTS:
        raise ValueError(f"verdict {verdict!r} not in {list(VERDICTS)}")
    m = load(slug_dir)
    stage = m["stages"][str(stage_n)]
    stage["audit_verdict"] = verdict
    stage["audit_persona"] = persona
    stage["timestamp"] = _now_iso()
    write(slug_dir, m)
    return m


def next_incomplete_stage(slug_dir: Path) -> int | None:
    """Return the smallest stage number whose `complete` is False, or None
    if all seven stages have been completed.
    """
    m = load(slug_dir)
    for n in STAGES:
        stage = m["stages"][str(n)]
        if not stage.get("complete"):
            return n
    return None


def can_advance_past(slug_dir: Path, stage_n: int) -> tuple[bool, str]:
    """Return (allowed, reason). Stage N+1 may begin only if stage N is
    complete AND its audit_verdict is one of pass/advisory.
    """
    if stage_n < 1 or stage_n > 7:
        return False, f"stage {stage_n} out of range"
    m = load(slug_dir)
    stage = m["stages"][str(stage_n)]
    if not stage.get("complete"):
        return False, f"stage {stage_n} is not marked complete"
    verdict = stage.get("audit_verdict")
    if verdict == "fail":
        return False, f"stage {stage_n} audit verdict is fail"
    if verdict not in ("pass", "advisory"):
        return False, f"stage {stage_n} audit verdict is missing"
    return True, "ok"
