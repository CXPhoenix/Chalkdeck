#!/usr/bin/env python3
"""bluechall_bootstrap — generate a 23-key `.rules.env` for a CTF event repo root.

Generates the event-scoped `.rules.env` defined by the `bluechall-rules-env`
capability — 16 webchall keys plus 8 bluechall-specific keys covering
toolchain whitelists, lab backend defaults, flag emission defaults, external
flag-server port range, and MITRE ATT&CK version. Without flags, runs
interactively; with flags, runs non-interactively. Refuses to overwrite an
existing file unless `--force` is passed.
"""

from __future__ import annotations

import argparse
import difflib
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from _bcm_common import rules_env  # noqa: E402


# Defaults for keys that have a sensible non-author default.
DEFAULTS: dict[str, str] = {
    # 16 webchall keys (those with defaults)
    "FLAG_TYPE": "static",
    "FLAG_ASSET_VERSION_CONTROLLED": "true",
    "AUTHOR_NAME": "",
    "AUTHOR_EMAIL": "",
    "CATEGORIES": "forensics,reverse,blue-team,misc",
    "DIFFICULTIES": "beginner,easy,medium,hard,expert",
    "HOST_PORT_RANGE_START": "8080",
    "HOST_PORT_RANGE_END": "8099",
    "PLAYER_FACING_LOCALE": "zh-Hant-TW",
    "SPEC_LOCALE": "en",
    "BLOCK_PRC_VOCAB": "true",
    "ENFORCE_ANTI_AI_SLOP": "true",
    # 8 bluechall keys
    "FORENSICS_TOOLCHAIN_PROFILE": "volatility3,wireshark,binwalk,exiftool,zsteg,oletools,scapy,yara,autopsy",
    "REVERSE_TOOLCHAIN_PROFILE": "ghidra,angr,qiling,unicorn,frida,radare2,pyelftools,capstone",
    "BLUE_TEAM_QUESTION_LIMIT": "10",
    "LAB_BACKEND_DEFAULT": "docker",
    "FLAG_EMISSION_DEFAULT": "single-static",
    "EXTERNAL_FLAG_SERVICE_PORT_RANGE_START": "8500",
    "EXTERNAL_FLAG_SERVICE_PORT_RANGE_END": "8599",
    "MITRE_ATTACK_VERSION": "v15.0",
}


def derive_flag_keys(prefix: str) -> tuple[str, str]:
    r"""Derive (FLAG_REGEX, FLAG_FORMAT_LITERAL) from a flag prefix."""
    escaped = re.escape(prefix)
    flag_regex = escaped + r"\{\S+\}"
    flag_literal = f"{prefix}{{<text>}}"
    return flag_regex, flag_literal


def parse_port_range(spec: str) -> tuple[int, int]:
    """Parse 'start:end' into (start, end). Raises ValueError on bad input."""
    if ":" not in spec:
        raise ValueError(f"port-range must be 'start:end', got {spec!r}")
    s, e = spec.split(":", 1)
    return int(s), int(e)


def main(argv: list[str] | None = None, *, out_override: Path | None = None) -> int:
    """Entry point. `out_override` is a programmatic-only escape hatch for tests
    that need to write to a tmpdir; intentionally NOT a CLI flag.
    """
    p = argparse.ArgumentParser(prog="bluechall_bootstrap", description=__doc__)
    # Required identity / flag
    p.add_argument("--name", help="CTF_EVENT_NAME (e.g. TEST.HSCTF)")
    p.add_argument("--long-name", dest="long_name",
                   help="CTF_EVENT_LONG_NAME (e.g. 'Test HSCTF')")
    p.add_argument("--flag-prefix", dest="flag_prefix",
                   help="prefix for FLAG_REGEX/FLAG_FORMAT_LITERAL (e.g. TEST.HSCTF)")
    p.add_argument("--port-range", dest="port_range",
                   help="HOST_PORT_RANGE_START:HOST_PORT_RANGE_END (e.g. 8080:8099)")
    # Optional author overrides
    p.add_argument("--author-name", dest="author_name", default=None)
    p.add_argument("--author-email", dest="author_email", default=None)
    p.add_argument("--flag-type", dest="flag_type", default=None,
                   choices=list(rules_env.FLAG_TYPE_ENUM))
    # Bluechall-specific flags (all 8 new keys)
    p.add_argument("--categories", dest="categories", default=None,
                   help="CATEGORIES csv (must include >=1 of forensics/reverse/blue-team)")
    p.add_argument("--forensics-toolchain", dest="forensics_toolchain", default=None,
                   help="FORENSICS_TOOLCHAIN_PROFILE csv whitelist")
    p.add_argument("--reverse-toolchain", dest="reverse_toolchain", default=None,
                   help="REVERSE_TOOLCHAIN_PROFILE csv whitelist")
    p.add_argument("--question-limit", dest="question_limit", type=int, default=None,
                   help="BLUE_TEAM_QUESTION_LIMIT int (1..50)")
    p.add_argument("--lab-backend-default", dest="lab_backend_default", default=None,
                   choices=list(rules_env.LAB_BACKEND_ENUM),
                   help="LAB_BACKEND_DEFAULT enum")
    p.add_argument("--flag-emission-default", dest="flag_emission_default", default=None,
                   choices=list(rules_env.FLAG_EMISSION_ENUM),
                   help="FLAG_EMISSION_DEFAULT enum")
    p.add_argument("--external-flag-port-range", dest="external_flag_port_range", default=None,
                   help="EXTERNAL_FLAG_SERVICE_PORT_RANGE_START:END (e.g. 8500:8599)")
    p.add_argument("--mitre-version", dest="mitre_version", default=None,
                   help="MITRE_ATTACK_VERSION (e.g. v15.0)")
    # Mode
    p.add_argument("--force", action="store_true",
                   help="overwrite existing .rules.env (requires --yes in non-TTY)")
    p.add_argument("--yes", action="store_true",
                   help="skip confirmation prompts in non-TTY mode")
    args = p.parse_args(argv)

    target = (
        out_override if out_override is not None
        else Path.cwd() / rules_env.DEFAULT_FILENAME
    )

    interactive = sys.stdin.isatty() and (
        not args.name or not args.long_name or not args.flag_prefix or not args.port_range
    )

    if not sys.stdin.isatty():
        missing = [
            flag for flag, val in [
                ("--name", args.name),
                ("--long-name", args.long_name),
                ("--flag-prefix", args.flag_prefix),
                ("--port-range", args.port_range),
            ] if not val
        ]
        if missing:
            print(
                f"error: required in non-TTY mode: {', '.join(missing)}",
                file=sys.stderr,
            )
            return 1

    try:
        mapping = _build_mapping(args, interactive=interactive)
    except ValueError as e:
        print(f"error: {e}", file=sys.stderr)
        return 1

    try:
        rules_env.validate(rules_env.normalize_for_write(mapping))
    except ValueError as e:
        print(f"error: {e}", file=sys.stderr)
        return 1

    if target.exists():
        if not args.force:
            print(".rules.env already exists; pass --force to overwrite",
                  file=sys.stderr)
            return 1
        if not _confirm_overwrite(target, mapping, yes=args.yes):
            print("aborted", file=sys.stderr)
            return 1

    try:
        rules_env.write(target, mapping, force=True)
    except FileExistsError:
        print(
            f"refusing: {target} appeared between check and write; "
            "another author may have just written it. Re-run to confirm.",
            file=sys.stderr,
        )
        return 1
    print(f"✓ wrote {target}")
    if not (args.author_name or args.author_email or mapping.get("AUTHOR_NAME") or mapping.get("AUTHOR_EMAIL")):
        print(
            "note: AUTHOR_NAME and AUTHOR_EMAIL are empty; challenge.yml will "
            "ship with author placeholder. Set them via --author-name / --author-email "
            f"or edit {target} directly.",
            file=sys.stderr,
        )
    return 0


def _build_mapping(args: argparse.Namespace, *, interactive: bool) -> dict[str, str]:
    """Compose the 24-key mapping from flags, defaults, and prompts."""
    mapping = dict(DEFAULTS)

    name = args.name or (_prompt("CTF_EVENT_NAME (e.g. TEST.HSCTF): ")
                         if interactive else None)
    if not name:
        raise ValueError("CTF_EVENT_NAME is required (--name)")
    if not re.fullmatch(r"[A-Za-z0-9._-]+", name):
        raise ValueError(
            f"CTF_EVENT_NAME {name!r} must match ^[A-Za-z0-9._-]+$"
        )
    mapping["CTF_EVENT_NAME"] = name

    long_name = args.long_name or (_prompt(
        f"CTF_EVENT_LONG_NAME [{name}]: ", default=name
    ) if interactive else name)
    mapping["CTF_EVENT_LONG_NAME"] = long_name

    flag_prefix = args.flag_prefix or (_prompt(
        f"flag prefix [{name}]: ", default=name,
    ) if interactive else name)
    if not re.fullmatch(r"[A-Za-z0-9._-]+", flag_prefix):
        raise ValueError(
            f"--flag-prefix {flag_prefix!r} must match ^[A-Za-z0-9._-]+$"
        )
    flag_regex, flag_literal = derive_flag_keys(flag_prefix)
    mapping["FLAG_REGEX"] = flag_regex
    mapping["FLAG_FORMAT_LITERAL"] = flag_literal

    if args.port_range:
        start, end = parse_port_range(args.port_range)
        mapping["HOST_PORT_RANGE_START"] = str(start)
        mapping["HOST_PORT_RANGE_END"] = str(end)
    elif interactive:
        rng = _prompt(
            f"HOST_PORT_RANGE_START:END [{DEFAULTS['HOST_PORT_RANGE_START']}:"
            f"{DEFAULTS['HOST_PORT_RANGE_END']}]: ",
            default=f"{DEFAULTS['HOST_PORT_RANGE_START']}:{DEFAULTS['HOST_PORT_RANGE_END']}",
        )
        start, end = parse_port_range(rng)
        mapping["HOST_PORT_RANGE_START"] = str(start)
        mapping["HOST_PORT_RANGE_END"] = str(end)

    if args.author_name is not None:
        mapping["AUTHOR_NAME"] = args.author_name
    if args.author_email is not None:
        mapping["AUTHOR_EMAIL"] = args.author_email
    if args.flag_type is not None:
        mapping["FLAG_TYPE"] = args.flag_type

    # Bluechall-specific overrides
    if args.categories is not None:
        mapping["CATEGORIES"] = args.categories
    if args.forensics_toolchain is not None:
        mapping["FORENSICS_TOOLCHAIN_PROFILE"] = args.forensics_toolchain
    if args.reverse_toolchain is not None:
        mapping["REVERSE_TOOLCHAIN_PROFILE"] = args.reverse_toolchain
    if args.question_limit is not None:
        mapping["BLUE_TEAM_QUESTION_LIMIT"] = str(args.question_limit)
    if args.lab_backend_default is not None:
        mapping["LAB_BACKEND_DEFAULT"] = args.lab_backend_default
    if args.flag_emission_default is not None:
        mapping["FLAG_EMISSION_DEFAULT"] = args.flag_emission_default
    if args.external_flag_port_range is not None:
        ext_start, ext_end = parse_port_range(args.external_flag_port_range)
        mapping["EXTERNAL_FLAG_SERVICE_PORT_RANGE_START"] = str(ext_start)
        mapping["EXTERNAL_FLAG_SERVICE_PORT_RANGE_END"] = str(ext_end)
    if args.mitre_version is not None:
        mapping["MITRE_ATTACK_VERSION"] = args.mitre_version

    return mapping


def _prompt(message: str, *, default: str | None = None) -> str:
    raw = input(message).strip()
    if not raw and default is not None:
        return default
    return raw


def _confirm_overwrite(
    target: Path,
    new_mapping: dict[str, str],
    *,
    yes: bool,
) -> bool:
    """Print a unified diff and require confirmation."""
    existing = target.read_text(encoding="utf-8").splitlines(keepends=True)
    proposed = rules_env.render(
        rules_env.normalize_for_write(new_mapping)
    ).splitlines(keepends=True)
    diff = "".join(difflib.unified_diff(
        existing, proposed,
        fromfile=str(target),
        tofile=str(target) + " (proposed)",
    ))
    print(diff, end="")
    is_tty = sys.stdin.isatty()
    if not is_tty:
        if not yes:
            print(
                "\nrefusing: --force in non-TTY mode requires --yes",
                file=sys.stderr,
            )
            return False
        return True
    answer = input("\nType 'yes' to overwrite: ").strip()
    return answer == "yes"


if __name__ == "__main__":
    sys.exit(main())
