#!/usr/bin/env python3
"""bluechall_analyze — chain artifact-fuzz, binary-fuzz, lab-fuzz engines.

Usage:
  bluechall_analyze.py <challenge-dir> [--no-runtime] [--flag-regex REGEX]
                       [--json | --sarif] [--allow-stage-skip]

Exit codes (per bluechall-tooling spec):
  0 — success (no critical findings)
  1 — user error (bad arguments, OR critical finding emitted)
  2 — missing precondition (manifest absent, Stage 4 incomplete)
  3 — internal error (unhandled exception in runner)

`--no-runtime` short-circuits the lab-fuzz engine into dry-run mode.
The challenge's `.bluechall.manifest.yaml` still receives a
`lab_provenance` entry with `mode: dry-run`.

`--flag-regex` overrides the canonical FLAG_REGEX used by artifact-fuzz
rules. The default `^FLAG\\{[!-~]+\\}$` matches the canonical bluechall
prefix; pass `--flag-regex` for events with custom prefixes (e.g.,
`picoCTF\\{[!-~]+\\}`). When omitted, the value of FLAG_REGEX from the
challenge's resolved `.rules.env` (if available) is preferred over the
hardcoded default.
"""

from __future__ import annotations

import argparse
import os
import sys
import traceback
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from _bcm_common import (  # noqa: E402
    artifact_fuzz, binary_fuzz, lab_fuzz, rules as rules_lib, rules_env,
)
from _bcm_common.reporters import to_json, to_pretty, to_sarif  # noqa: E402


EXIT_OK = 0
EXIT_USER_ERROR = 1
EXIT_PRECONDITION = 2
EXIT_INTERNAL = 3


def _resolve_flag_regex(args, challenge: Path) -> str:
    """Resolution order: explicit --flag-regex > .rules.env at cwd >
    .rules.env at challenge dir > artifact_fuzz.DEFAULT_FLAG_REGEX.
    """
    if args.flag_regex:
        return args.flag_regex
    for candidate in (Path.cwd() / rules_env.DEFAULT_FILENAME,
                      challenge / rules_env.DEFAULT_FILENAME):
        if candidate.exists():
            try:
                m = rules_env.load(candidate)
            except (ValueError, OSError):
                continue
            rx = m.get("FLAG_REGEX")
            if rx:
                return rx
    return artifact_fuzz.DEFAULT_FLAG_REGEX


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(prog="bluechall_analyze", description=__doc__)
    p.add_argument("challenge_dir", type=Path, help="path to challenge slug directory")
    p.add_argument("--no-runtime", action="store_true",
                   help=("skip live lab provisioning; lab-fuzz still runs in "
                         "dry-run and the manifest records `mode: dry-run` "
                         "provenance. A reminder line is printed to stderr "
                         "so CI logs show coverage was reduced."))
    p.add_argument("--flag-regex", default=None, type=str,
                   help=("override canonical flag regex used by artifact-fuzz "
                         "(default resolves from .rules.env FLAG_REGEX, then "
                         "falls back to ^FLAG\\{[!-~]+\\}$)"))
    fmt = p.add_mutually_exclusive_group()
    fmt.add_argument("--json", action="store_true", help="emit JSON findings")
    fmt.add_argument("--sarif", action="store_true", help="emit SARIF 2.1.0 findings")
    p.add_argument("--allow-stage-skip", action="store_true",
                   help=("UNSAFE: bypass the Stage-4-complete precondition. "
                         "Debug only — emits a loud stderr warning so CI "
                         "logs show the gate was disabled. MUST NOT be used "
                         "by ship-time pipelines."))
    args = p.parse_args(argv)

    challenge = Path(args.challenge_dir).resolve()
    if not challenge.is_dir():
        print(f"error: {challenge} is not a directory", file=sys.stderr)
        return EXIT_USER_ERROR

    manifest = rules_lib.load_manifest(challenge)
    if not manifest:
        print(
            f"precondition: {challenge}/.bluechall.manifest.yaml absent or unparseable; "
            "run bluechall_init.py to scaffold",
            file=sys.stderr,
        )
        return EXIT_PRECONDITION

    if args.allow_stage_skip:
        print(
            "⚠ DANGER: --allow-stage-skip active; Stage-4 precondition bypassed. "
            "This flag is for developer debugging ONLY and must not be used in "
            "shipping pipelines.",
            file=sys.stderr,
        )
    else:
        # Delegate to `manifest.can_advance_past` for unified gate logic.
        from _bcm_common import manifest as manifest_lib  # noqa: E402
        # Defensive coerce: a malformed manifest may set `stages` to a
        # non-dict (list / string), which would crash can_advance_past
        # with AttributeError before the gate could reject it.
        stages = manifest.get("stages")
        if not isinstance(stages, dict):
            print(
                "precondition: manifest 'stages' is not a YAML mapping; "
                "manifest is malformed and cannot be analyzed",
                file=sys.stderr,
            )
            return EXIT_PRECONDITION
        try:
            allowed, reason = manifest_lib.can_advance_past(
                challenge, rules_lib.STAGE_IMPLEMENT,
            )
        except (FileNotFoundError, ValueError) as e:
            print(f"precondition: manifest gate failed: {e}", file=sys.stderr)
            return EXIT_PRECONDITION
        if not allowed:
            stage4 = stages.get(str(rules_lib.STAGE_IMPLEMENT))
            stage4 = stage4 if isinstance(stage4, dict) else {}
            persona = stage4.get("audit_persona") or "<unknown>"
            print(
                f"precondition: Stage 4 (Implement) {reason} "
                f"(persona {persona!r}); record `pass` or `advisory` via "
                "bluechall_manifest.py append-audit-verdict before "
                "analyzing (or pass --allow-stage-skip for debugging)",
                file=sys.stderr,
            )
            return EXIT_PRECONDITION

    flag_regex = _resolve_flag_regex(args, challenge)

    if args.no_runtime and (manifest.get("lab_backend") or "none") != "none":
        print(
            f"⚠ --no-runtime active; lab-fuzz running in dry-run mode against "
            f"backend {manifest.get('lab_backend')!r}; live endpoint probing skipped.",
            file=sys.stderr,
        )

    findings = []
    try:
        findings.extend(artifact_fuzz.run(challenge, flag_regex=flag_regex))
        findings.extend(binary_fuzz.run(challenge))
        findings.extend(lab_fuzz.run(challenge, manifest, dry_run=args.no_runtime))
    except Exception as e:
        print(f"internal: analyze runner raised {type(e).__name__}: {e}", file=sys.stderr)
        traceback.print_exc(file=sys.stderr)
        return EXIT_INTERNAL

    if args.sarif:
        sys.stdout.write(to_sarif(findings, tool_name="bluechall_analyze"))
    elif args.json:
        sys.stdout.write(to_json(findings))
    else:
        sys.stdout.write(to_pretty(findings))

    has_critical = any(f.severity == "critical" for f in findings)
    return EXIT_USER_ERROR if has_critical else EXIT_OK


if __name__ == "__main__":
    raise SystemExit(main())
