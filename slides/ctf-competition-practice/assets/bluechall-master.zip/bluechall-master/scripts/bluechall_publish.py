#!/usr/bin/env python3
"""bluechall_publish — emit four platform-specific adapter files.

Usage:
  bluechall_publish.py <challenge-dir>

Outputs four files under `<challenge-dir>/adapters/`:
  - ctfcli.yml    — CTFd canonical reference format
  - rctf.yml      — rCTF (collapses `flags` → `flag`, drops unsupported fields)
  - picoctf.yml   — picoCTF (drops dynamic decay, remaps attempts)
  - sherlocks.yml — multi-question YAML (only when flag_emission=questions-as-flags)

Exit codes:
  0 — all four (or three, when single-static skips Sherlocks) adapters emitted cleanly
  1 — placeholder flag, missing canonical_flag, OR flag leaked into a non-flag field
  2 — missing precondition (manifest absent, etc.)
  3 — internal error
"""

from __future__ import annotations

import argparse
import sys
import traceback
from pathlib import Path

import yaml

sys.path.insert(0, str(Path(__file__).parent))
from _bcm_common import publish, rules as rules_lib  # noqa: E402


EXIT_OK = 0
EXIT_USER_ERROR = 1
EXIT_PRECONDITION = 2
EXIT_INTERNAL = 3


def _is_placeholder_flag(canonical: str) -> bool:
    """Single source of truth for placeholder-flag detection: delegates to
    `rules.PLACEHOLDER_PATTERNS` so validate and publish reject the same
    set of demo / placeholder flags.
    """
    if not canonical:
        return True
    for pat in rules_lib.PLACEHOLDER_PATTERNS:
        if pat.search(canonical):
            return True
    return False


def _validate_artifact_paths(manifest: dict, challenge: Path) -> str | None:
    """Reject `..` path traversal and absolute paths in `manifest.artifacts`
    so a malicious manifest cannot smuggle out-of-tree paths into the
    Sherlocks adapter. Returns an error message string on rejection,
    or None if all paths are safe.
    """
    arts = manifest.get("artifacts") or []
    challenge_resolved = challenge.resolve()
    for a in arts:
        if not isinstance(a, str):
            return f"artifact path {a!r} is not a string"
        if a.startswith("/"):
            return f"artifact path {a!r} is absolute; only relative paths allowed"
        if ".." in Path(a).parts:
            return f"artifact path {a!r} contains `..`; path traversal forbidden"
        # Resolve and confirm it stays within the challenge dir.
        resolved = (challenge / a).resolve()
        try:
            resolved.relative_to(challenge_resolved)
        except ValueError:
            return f"artifact path {a!r} resolves outside challenge directory"
    return None


def _load_questions(challenge: Path) -> list[dict]:
    """Accept BOTH on-disk shapes that have appeared in templates and
    fixtures across iterations of bluechall-master:

    - Top-level mapping with `questions:` key (preferred; matches every
      shipped template and the unit tests).
    - Top-level YAML list (legacy; older `bluechall_init` scaffolds).

    Returning the same list[dict] for both shapes avoids the "publish
    sees zero questions" trap that previously bit users whose scaffold
    or template happened to use the other shape.
    """
    qpath = challenge / "solution" / "questions.yaml"
    if not qpath.exists():
        return []
    data = yaml.safe_load(qpath.read_text(encoding="utf-8"))
    if isinstance(data, dict):
        return list(data.get("questions") or [])
    if isinstance(data, list):
        return list(data)
    return []


def _serialize_with_redaction(payload, canonical: str) -> tuple[str, list[str]]:
    """Structural redaction: walk the parsed payload, redact flag in every
    string value EXCEPT under `flag` / `flags` / `answer` keys, then
    serialize. Returns (yaml_text, encodings_hit).
    """
    redacted_payload, hits = publish.redact_flag_in_payload(payload, canonical=canonical)
    text = yaml.safe_dump(redacted_payload, default_flow_style=False,
                          sort_keys=False, allow_unicode=True)
    return text, hits


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(prog="bluechall_publish", description=__doc__)
    p.add_argument("challenge_dir", type=Path, help="path to challenge slug directory")
    p.add_argument(
        "--allow-stage-skip", action="store_true",
        help=("UNSAFE: bypass the Stage-6 (Validate) audit_verdict precondition. "
              "Debug only — emits a loud stderr warning. MUST NOT be used by "
              "ship-time pipelines."),
    )
    args = p.parse_args(argv)

    challenge = Path(args.challenge_dir).resolve()
    if not challenge.is_dir():
        print(f"error: {challenge} is not a directory", file=sys.stderr)
        return EXIT_USER_ERROR

    manifest = rules_lib.load_manifest(challenge)
    if not manifest:
        print(
            f"precondition: {challenge}/.bluechall.manifest.yaml absent or unparseable",
            file=sys.stderr,
        )
        return EXIT_PRECONDITION

    if args.allow_stage_skip:
        print(
            "⚠ DANGER: --allow-stage-skip active; Stage-6 (Validate) audit_verdict "
            "precondition bypassed. This flag is for developer debugging ONLY "
            "and must not be used in shipping pipelines.",
            file=sys.stderr,
        )
    else:
        # Stage-6 audit-verdict gate: publish refuses to ship until the
        # validate stage has been run AND its audit recorded as
        # `pass`/`advisory`. Delegating to `manifest.can_advance_past`
        # keeps the verdict-allowlist semantics in one place; the Stage-4
        # and Stage-5 gates in `bluechall_analyze` / `bluechall_validate`
        # follow the same pattern.
        from _bcm_common import manifest as manifest_lib  # noqa: E402
        # Defensive coerce: a malicious manifest with `stages: ["x"]`
        # (truthy non-dict) would otherwise crash `can_advance_past` with
        # AttributeError before the gate could reject it.
        stages = manifest.get("stages")
        if not isinstance(stages, dict):
            print(
                "precondition: manifest 'stages' is not a YAML mapping; "
                "manifest is malformed and cannot be validated",
                file=sys.stderr,
            )
            return EXIT_PRECONDITION
        try:
            allowed, reason = manifest_lib.can_advance_past(challenge, 6)
        except (FileNotFoundError, ValueError) as e:
            print(f"precondition: manifest gate failed: {e}", file=sys.stderr)
            return EXIT_PRECONDITION
        if not allowed:
            stage6 = stages.get("6") if isinstance(stages.get("6"), dict) else {}
            persona = stage6.get("audit_persona") or "<unknown>"
            print(
                f"precondition: Stage 6 (Validate) {reason} "
                f"(persona {persona!r}); record `pass` or `advisory` via "
                "bluechall_manifest.py append-audit-verdict before "
                "publishing (or pass --allow-stage-skip for debugging)",
                file=sys.stderr,
            )
            return EXIT_PRECONDITION

    canonical = manifest.get("canonical_flag")
    if not canonical:
        print(
            "refusing to publish: manifest is missing `canonical_flag`. "
            "Set the real canonical flag before publishing.",
            file=sys.stderr,
        )
        return EXIT_USER_ERROR
    if _is_placeholder_flag(canonical):
        print(
            f"refusing to publish: canonical_flag {canonical!r} matches a "
            "placeholder / demo / template-default pattern. Set a real "
            "challenge-specific flag before publishing (this check is "
            "shared with bluechall_validate.py — both stages reject the "
            "same set).",
            file=sys.stderr,
        )
        return EXIT_USER_ERROR

    art_err = _validate_artifact_paths(manifest, challenge)
    if art_err:
        print(f"refusing to publish: {art_err}", file=sys.stderr)
        return EXIT_USER_ERROR

    emission = manifest.get("flag_emission")
    questions: list[dict] = []
    if emission == "questions-as-flags":
        questions = _load_questions(challenge)
        if not questions:
            print(
                "refusing to publish: flag_emission=questions-as-flags but "
                "solution/questions.yaml is empty or absent.",
                file=sys.stderr,
            )
            return EXIT_USER_ERROR

    try:
        ctfd = publish.build_ctfd_canonical(manifest, questions=questions)
        rctf, dropped = publish.build_rctf(ctfd)
        pico = publish.build_picoctf(ctfd, manifest)
    except publish.InvalidQuestionError as e:
        print(f"refusing to publish: {e}", file=sys.stderr)
        return EXIT_USER_ERROR
    except (ValueError, TypeError) as e:
        # Author-supplied manifest produced bad input (e.g., attempts is
        # a non-numeric string). Surface as user error, not internal.
        print(f"refusing to publish: manifest field caused build failure: "
              f"{type(e).__name__}: {e}", file=sys.stderr)
        return EXIT_USER_ERROR
    except Exception as e:
        print(f"internal: adapter build raised {type(e).__name__}: {e}",
              file=sys.stderr)
        traceback.print_exc(file=sys.stderr)
        return EXIT_INTERNAL

    adapters_dir = challenge / "adapters"
    adapters_dir.mkdir(exist_ok=True)

    # Track redaction hits across all adapters; if any encoding got hit, we
    # refuse to ship even though we already redacted the file content (the
    # author MUST notice and remove the leak from source).
    leaks: list[tuple[str, list[str]]] = []

    def _write(path: Path, payload, label: str) -> None:
        text, hits = _serialize_with_redaction(payload, canonical)
        if hits:
            leaks.append((label, hits))
        path.write_text(text, encoding="utf-8")

    _write(adapters_dir / "ctfcli.yml", ctfd, "ctfcli.yml")
    _write(adapters_dir / "rctf.yml", rctf, "rctf.yml")
    _write(adapters_dir / "picoctf.yml", pico, "picoctf.yml")

    if dropped:
        print(
            f"⚠ rCTF adapter dropped fields not supported by rCTF: {sorted(dropped)!r}",
            file=sys.stderr,
        )

    if emission == "questions-as-flags":
        sherlocks = publish.build_sherlocks(manifest, questions)
        _write(adapters_dir / "sherlocks.yml", sherlocks, "sherlocks.yml")
    else:
        print(
            f"ℹ Sherlocks adapter not emitted: flag_emission is {emission!r} "
            "(Sherlocks requires `questions-as-flags`)",
            file=sys.stderr,
        )

    if leaks:
        for label, encodings in leaks:
            print(
                f"✗ CRITICAL: canonical flag leaked into {label} via "
                f"encodings {encodings!r}; substituted FLAG{{REDACTED}} in "
                f"output. Fix the source manifest/recipe so the flag does "
                f"not appear in description/hints/free-form fields.",
                file=sys.stderr,
            )
        return EXIT_USER_ERROR

    print(f"✓ published {challenge.name}: 4 adapter files written to "
          f"{adapters_dir.relative_to(challenge.parent)}/")
    print(
        "  note: bluechall_publish only writes adapters/. The publish/ tree "
        "is author-managed; Stage 5 Analyze (bluechall_analyze.py) is the "
        "gate that scans publish/ for canonical-flag leakage.",
        file=sys.stderr,
    )
    return EXIT_OK


if __name__ == "__main__":
    raise SystemExit(main())
