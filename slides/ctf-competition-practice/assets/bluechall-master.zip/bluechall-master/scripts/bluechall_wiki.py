#!/usr/bin/env python3
"""bluechall_wiki — wiki maintenance CLI.

Subcommands:
  ingest   Copy a raw source into wiki/raw/<subtype>/ with SHA-256 frontmatter.
  compile  (Layer 1 → Layer 2) Re-derive Layer-2 pages from Layer-1 sources.
  find     Layer-2 lookup by OWASP id, MITRE ATT&CK technique, NIST phase,
           framework, category, subdomain, or CVE.
  verify   Run all wiki invariants (schema, SHA-256 immutability, dead links,
           cross-model lint, CVE coverage, survey coverage, max-age).
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from _bcm_common import wiki  # noqa: E402


EXIT_OK = 0
EXIT_USER_ERROR = 1
EXIT_PRECONDITION = 2
EXIT_INTERNAL = 3


def cmd_verify(args: argparse.Namespace) -> int:
    root = Path(args.wiki_root or _resolve_wiki_root())
    profile = wiki.Profile.load(root.parent)
    findings = wiki.verify(
        root,
        profile=profile,
        max_age_days=args.max_age_days,
        cross_model_lint=args.cross_model_lint,
        check_cve_coverage=args.check_cve_coverage,
        check_survey_coverage=args.check_survey_coverage,
    )
    critical = [f for f in findings if f.severity == "critical"]
    if args.json:
        print(json.dumps([f.to_dict() for f in findings], indent=2))
    else:
        for f in findings:
            sym = {"critical": "✗", "warning": "⚠", "advisory": "i", "info": "·"}.get(f.severity, "?")
            print(f"{sym} [{f.severity.upper()}] {f.rule_id} @ {f.location}: {f.message}")
            if f.remediation_hint:
                print(f"    → {f.remediation_hint}")
        print(f"\n{len(findings)} finding(s); {len(critical)} critical")
    return EXIT_USER_ERROR if critical else EXIT_OK


def cmd_find(args: argparse.Namespace) -> int:
    root = Path(args.wiki_root or _resolve_wiki_root())
    matches = wiki.find(
        root,
        owasp=args.owasp,
        mitre_attack=args.mitre_attack,
        nist_phase=args.nist_phase,
        framework=args.framework,
        category=args.category,
        subdomain=args.subdomain,
        cve=args.cve,
    )
    if args.json:
        print(json.dumps([str(p) for p in matches], indent=2))
    else:
        for p in matches:
            print(p)
    return EXIT_OK


def cmd_ingest(args: argparse.Namespace) -> int:
    root = Path(args.wiki_root or _resolve_wiki_root())
    src_path = Path(args.source)
    if not src_path.exists():
        print(f"error: source {src_path} not found", file=sys.stderr)
        return EXIT_USER_ERROR
    if args.subtype not in ("papers", "tools", "flare-on-solutions", "ctf-writeups", "owasp", "nist", "mitre"):
        print(
            f"error: unknown raw subtype {args.subtype!r}; allowed: "
            "papers, tools, flare-on-solutions, ctf-writeups, owasp, nist, mitre",
            file=sys.stderr,
        )
        return EXIT_USER_ERROR

    target_dir = root / "raw" / (args.subtype if args.subtype in ("papers", "tools", "flare-on-solutions", "ctf-writeups") else ".")
    target_dir.mkdir(parents=True, exist_ok=True)

    body = src_path.read_text(encoding="utf-8")
    wrapped = wiki.ingest(
        body,
        fetch_url=args.fetch_url or src_path.resolve().as_uri(),
        fetch_date=args.fetch_date or _today(),
    )
    target = target_dir / src_path.name
    if target.exists() and not args.force:
        print(
            f"error: {target} already exists; pass --force or use a "
            "different fetch-date suffix",
            file=sys.stderr,
        )
        return EXIT_USER_ERROR
    target.write_text(wrapped, encoding="utf-8")
    print(f"✓ ingested {target}")
    return EXIT_OK


def cmd_compile(args: argparse.Namespace) -> int:
    """Compile is a stub for v0.1: it documents that Layer-2 pages should be
    re-derived from Layer-1 sources, but in v0.1 the Layer-2 pages are
    authored manually so this is a no-op that prints guidance.
    """
    print(
        "compile is a v0.1 stub: Layer-2 pages are authored manually for "
        "the initial seed wiki. Re-run bluechall_wiki.py verify to confirm "
        "all invariants hold after edits."
    )
    return EXIT_OK


def _resolve_wiki_root() -> Path:
    """Find the wiki/ directory adjacent to the calling skill root."""
    here = Path(__file__).resolve().parent.parent
    candidate = here / "wiki"
    if not candidate.exists():
        raise SystemExit(
            f"error: wiki root not found at {candidate}; "
            f"pass --wiki-root explicitly"
        )
    return candidate


def _today() -> str:
    from datetime import date
    return date.today().isoformat()


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(prog="bluechall_wiki", description=__doc__)
    p.add_argument("--wiki-root", help="path to the wiki/ root (defaults to skill-relative)")
    sub = p.add_subparsers(dest="command", required=True)

    pv = sub.add_parser("verify", help="run wiki invariants")
    pv.add_argument("--max-age-days", type=int, default=None,
                    help="advisory threshold for stale last_compiled timestamps")
    pv.add_argument("--cross-model-lint", action="store_true",
                    help="check SKILL*.md and AGENTS.md for forbidden tool names "
                         "and required section headings")
    pv.add_argument("--check-cve-coverage", action="store_true",
                    help="advisory: each framework references >=3 CVE pages")
    pv.add_argument("--check-survey-coverage", action="store_true",
                    help="advisory: each forensics/reverse subdomain has >=1 survey paper")
    pv.add_argument("--json", action="store_true", help="emit JSON findings")
    pv.set_defaults(func=cmd_verify)

    pf = sub.add_parser("find", help="Layer-2 lookup")
    pf.add_argument("--owasp", help="OWASP Top 10 id (e.g. A03)")
    pf.add_argument("--mitre-attack", dest="mitre_attack", help="ATT&CK technique id (e.g. T1059)")
    pf.add_argument("--nist-phase", dest="nist_phase",
                    choices=("collection", "examination", "analysis", "reporting"))
    pf.add_argument("--framework", help="framework id (e.g. volatility3)")
    pf.add_argument("--category", choices=("forensics", "reverse", "blue-team"))
    pf.add_argument("--subdomain", help="subdomain id (e.g. lsb-stego)")
    pf.add_argument("--cve", help="CVE id (e.g. CVE-2024-1234)")
    pf.add_argument("--json", action="store_true", help="emit JSON list of paths")
    pf.set_defaults(func=cmd_find)

    pi = sub.add_parser("ingest", help="copy a raw source into wiki/raw/")
    pi.add_argument("source", help="path to the raw file to ingest")
    pi.add_argument("--subtype", required=True,
                    choices=("papers", "tools", "flare-on-solutions",
                             "ctf-writeups", "owasp", "nist", "mitre"))
    pi.add_argument("--fetch-url", dest="fetch_url",
                    help="URL the raw file was fetched from (default: source path as file URI)")
    pi.add_argument("--fetch-date", dest="fetch_date",
                    help="ISO date the raw was fetched (default: today)")
    pi.add_argument("--force", action="store_true", help="overwrite an existing target file")
    pi.set_defaults(func=cmd_ingest)

    pc = sub.add_parser("compile", help="(v0.1 stub) re-derive Layer-2 from Layer-1")
    pc.add_argument("--all", action="store_true")
    pc.add_argument("--concept", help="single concept id to recompile")
    pc.set_defaults(func=cmd_compile)

    args = p.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
