#!/usr/bin/env python3
"""bluechall_validate — strict rule catalog with --soft downgrade.

Usage:
  bluechall_validate.py <challenge-dir> [--soft] [--no-runtime] [--json | --sarif]

Behavior:
  - Loads manifest from <challenge-dir>/.bluechall.manifest.yaml.
  - If manifest is absent: exit 2 with stderr precondition message.
  - If Stage 5 (Analyze) recorded `audit_verdict: fail` (per the
    bluechall-master spec): exit 2 with stderr message naming the failed
    audit AND its persona (so the operator knows which audit gate to fix).
  - Runs the rule catalog from `_bcm_common/rules.py`.
  - With `--soft`: downgrade `critical` findings to `warning` and exit 0;
    JSON output preserves both `effective_severity` and `original_severity`.
  - Without `--soft`: exit non-zero (1) on any critical finding.

`--no-runtime` is accepted for parity with `bluechall_analyze.py`. In v0.1
the validate catalog does not invoke any lab backend, so the flag is a
no-op here, but accepting it keeps the cross-CLI surface uniform and lets
CI scripts pass the same flag to both commands without conditional logic.
"""

from __future__ import annotations

import argparse
import sys
import traceback
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from _bcm_common import rules as rules_lib  # noqa: E402
from _bcm_common.reporters import (  # noqa: E402
    downgrade_for_soft, to_json, to_pretty, to_sarif,
)


EXIT_OK = 0
EXIT_USER_ERROR = 1
EXIT_PRECONDITION = 2
EXIT_INTERNAL = 3


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(prog="bluechall_validate", description=__doc__)
    p.add_argument("challenge_dir", type=Path, help="path to challenge slug directory")
    p.add_argument("--soft", action="store_true",
                   help=("downgrade critical findings to warning AND exit 0; "
                         "JSON/SARIF preserve original severity in "
                         "`original_severity` field. A loud stderr warning "
                         "is printed on every invocation so CI logs cannot "
                         "miss that the gate was relaxed."))
    p.add_argument("--no-runtime", action="store_true",
                   help=("accepted for parity with bluechall_analyze.py; v0.1 "
                         "no-op (the rule catalog never invokes a lab backend)"))
    p.add_argument("--allow-stage-skip", action="store_true",
                   help=("UNSAFE: bypass Stage-5 audit-verdict precondition. "
                         "Debug only — emits a loud stderr warning. MUST NOT "
                         "be used by ship-time pipelines."))
    fmt = p.add_mutually_exclusive_group()
    fmt.add_argument("--json", action="store_true", help="emit JSON findings")
    fmt.add_argument("--sarif", action="store_true", help="emit SARIF 2.1.0 findings")
    args = p.parse_args(argv)

    challenge = Path(args.challenge_dir).resolve()
    if not challenge.is_dir():
        print(f"error: {challenge} is not a directory", file=sys.stderr)
        return EXIT_USER_ERROR

    manifest = rules_lib.load_manifest(challenge)
    if not manifest:
        print(
            f"precondition: {challenge}/.bluechall.manifest.yaml absent or unparseable",
            file=sys.stderr,
        )
        return EXIT_PRECONDITION

    if args.allow_stage_skip:
        print(
            "⚠ DANGER: --allow-stage-skip active; Stage-5 audit-verdict "
            "precondition bypassed. This flag is for developer debugging "
            "ONLY and must not be used in shipping pipelines.",
            file=sys.stderr,
        )
    else:
        # Delegate to `manifest.can_advance_past` so the verdict-allowlist
        # semantics live in one place across analyze/validate/publish.
        from _bcm_common import manifest as manifest_lib  # noqa: E402
        # Defensive coerce: malicious manifest may set `stages` to a
        # non-dict (list / string), which would crash can_advance_past
        # with AttributeError before the gate could reject it.
        stages = manifest.get("stages")
        if not isinstance(stages, dict):
            print(
                "precondition: manifest 'stages' is not a YAML mapping; "
                "manifest is malformed and cannot be validated",
                file=sys.stderr,
            )
            return EXIT_PRECONDITION
        try:
            allowed, reason = manifest_lib.can_advance_past(
                challenge, rules_lib.STAGE_ANALYZE,
            )
        except (FileNotFoundError, ValueError) as e:
            print(f"precondition: manifest gate failed: {e}", file=sys.stderr)
            return EXIT_PRECONDITION
        if not allowed:
            stage5 = stages.get(str(rules_lib.STAGE_ANALYZE))
            stage5 = stage5 if isinstance(stage5, dict) else {}
            persona = stage5.get("audit_persona") or "<unknown>"
            print(
                f"precondition: Stage 5 (Analyze) {reason} "
                f"(persona {persona!r}); record `pass` or `advisory` via "
                "bluechall_manifest.py append-audit-verdict before "
                "validating (or pass --allow-stage-skip for debugging)",
                file=sys.stderr,
            )
            return EXIT_PRECONDITION

    if args.soft:
        print(
            "⚠ --soft active; critical findings will be downgraded to warning "
            "and the CLI will exit 0. JSON/SARIF preserve original_severity. "
            "DO NOT ship a challenge whose validate run required --soft.",
            file=sys.stderr,
        )

    try:
        findings = rules_lib.run_all(challenge, manifest)
    except Exception as e:
        print(f"internal: validate runner raised {type(e).__name__}: {e}", file=sys.stderr)
        traceback.print_exc(file=sys.stderr)
        return EXIT_INTERNAL

    has_real_critical = any(f.severity == "critical" for f in findings)
    if args.soft:
        downgrade_for_soft(findings)

    if args.sarif:
        sys.stdout.write(to_sarif(findings, tool_name="bluechall_validate"))
    elif args.json:
        sys.stdout.write(to_json(findings, soft_mode=args.soft))
    else:
        sys.stdout.write(to_pretty(findings))
        if args.soft and has_real_critical:
            sys.stdout.write(
                "\n⚠ --soft active — critical findings downgraded to warning. "
                "Real criticals MUST be fixed before publishing; --soft is for "
                "draft iteration only.\n"
            )

    if args.soft:
        return EXIT_OK
    return EXIT_USER_ERROR if has_real_critical else EXIT_OK


if __name__ == "__main__":
    raise SystemExit(main())
