#!/usr/bin/env python3
"""bluechall_qemu — QEMU emulator wrapper.

Two profiles:

  --user-mode   qemu-{mips,arm,aarch64}-static <binary> <args>
  --system-mode qemu-system-{arm,aarch64} -M <virt|raspi3> ...

  bluechall_qemu.py user-mode <slug>/ --arch mips --binary <path> [--args "..."]
                                       [--gdb-port N] [--no-runtime]
  bluechall_qemu.py system-mode <slug>/ --arch arm --machine virt
                                         [--no-runtime]
"""

from __future__ import annotations

import argparse
import shlex
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from _bcm_common import lab_helpers  # noqa: E402


def cmd_user_mode(args: argparse.Namespace) -> int:
    slug_dir = Path(args.slug_dir).resolve()
    binary = Path(args.binary) if args.binary else None
    extra = shlex.split(args.args) if args.args else []
    with lab_helpers.qemu_session(
        slug_dir, profile="user-mode", dry_run=args.no_runtime,
        arch=args.arch, binary=binary, args=extra, gdb_port=args.gdb_port,
    ) as session:
        print(f"backend={session.backend} mode={session.mode} profile=user-mode")
        print(f"started_at={session.started_at}")
        if session.extra.get("pid"):
            print(f"pid={session.extra['pid']}")
    return 0


def cmd_system_mode(args: argparse.Namespace) -> int:
    slug_dir = Path(args.slug_dir).resolve()
    with lab_helpers.qemu_session(
        slug_dir, profile="system-mode", dry_run=args.no_runtime,
        arch=args.arch, gdb_port=args.gdb_port,
    ) as session:
        print(f"backend={session.backend} mode={session.mode} profile=system-mode")
        print(f"started_at={session.started_at}")
    return 0


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(prog="bluechall_qemu", description=__doc__)
    sub = p.add_subparsers(dest="command", required=True)

    pu = sub.add_parser("user-mode", help="qemu-<arch>-static binary execution")
    pu.add_argument("slug_dir")
    pu.add_argument("--arch", choices=("mips", "arm", "aarch64"), required=True)
    pu.add_argument("--binary", help="path to the target binary")
    pu.add_argument("--args", help="quoted argument string for the binary")
    pu.add_argument("--gdb-port", dest="gdb_port", type=int, default=None)
    pu.add_argument("--no-runtime", action="store_true")
    pu.set_defaults(func=cmd_user_mode)

    ps = sub.add_parser("system-mode", help="qemu-system-<arch> board boot")
    ps.add_argument("slug_dir")
    ps.add_argument("--arch", choices=("arm", "aarch64"), required=True)
    ps.add_argument("--machine", choices=("virt", "raspi3"), default="virt")
    ps.add_argument("--gdb-port", dest="gdb_port", type=int, default=None)
    ps.add_argument("--no-runtime", action="store_true")
    ps.set_defaults(func=cmd_system_mode)

    args = p.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
