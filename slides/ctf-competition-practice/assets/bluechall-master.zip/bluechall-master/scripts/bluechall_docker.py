#!/usr/bin/env python3
"""bluechall_docker — Docker Compose lab orchestrator.

Wraps `_bcm_common.lab_helpers.compose_session` for direct CLI use:

  bluechall_docker.py up   <slug>/  [--no-runtime] [--mode analyze|live]
  bluechall_docker.py down <slug>/
  bluechall_docker.py ps   <slug>/
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from _bcm_common import lab_helpers  # noqa: E402


def cmd_up(args: argparse.Namespace) -> int:
    slug_dir = Path(args.slug_dir).resolve()
    with lab_helpers.compose_session(
        slug_dir, mode=args.mode, dry_run=args.no_runtime,
        healthcheck_timeout_s=args.healthcheck_timeout_s,
    ) as session:
        print(f"backend={session.backend} mode={session.mode}")
        print(f"started_at={session.started_at}")
        if session.endpoints:
            print(f"endpoints={session.endpoints}")
    return 0


def cmd_down(args: argparse.Namespace) -> int:
    """Best-effort `docker compose down -v` against an existing src/ tree."""
    import shutil
    import subprocess
    src = Path(args.slug_dir).resolve() / "src"
    if not (src / "docker-compose.yml").exists():
        print(f"error: {src}/docker-compose.yml not found", file=sys.stderr)
        return 1
    if not shutil.which("docker"):
        print("error: docker CLI not found", file=sys.stderr)
        return 2
    proc = subprocess.run(
        ["docker", "compose", "down", "-v"],
        cwd=src, capture_output=True, text=True,
    )
    sys.stdout.write(proc.stdout)
    sys.stderr.write(proc.stderr)
    return proc.returncode


def cmd_ps(args: argparse.Namespace) -> int:
    import shutil
    import subprocess
    src = Path(args.slug_dir).resolve() / "src"
    if not shutil.which("docker"):
        print("error: docker CLI not found", file=sys.stderr)
        return 2
    proc = subprocess.run(
        ["docker", "compose", "ps", "--format", "json"],
        cwd=src, capture_output=True, text=True,
    )
    sys.stdout.write(proc.stdout)
    return proc.returncode


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(prog="bluechall_docker", description=__doc__)
    sub = p.add_subparsers(dest="command", required=True)

    pu = sub.add_parser("up", help="provision and wait for healthcheck")
    pu.add_argument("slug_dir")
    pu.add_argument("--mode", default="analyze",
                    help="provenance label recorded in manifest (analyze|live)")
    pu.add_argument("--no-runtime", action="store_true",
                    help="dry-run: do not invoke docker, but record provenance")
    pu.add_argument("--healthcheck-timeout-s", dest="healthcheck_timeout_s",
                    type=int, default=60)
    pu.set_defaults(func=cmd_up)

    pd = sub.add_parser("down", help="best-effort docker compose down -v")
    pd.add_argument("slug_dir")
    pd.set_defaults(func=cmd_down)

    pp = sub.add_parser("ps", help="list compose containers")
    pp.add_argument("slug_dir")
    pp.set_defaults(func=cmd_ps)

    args = p.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
