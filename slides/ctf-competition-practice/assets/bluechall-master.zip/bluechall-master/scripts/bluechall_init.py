#!/usr/bin/env python3
"""bluechall_init — Stage 3 scaffold for a single bluechall challenge.

Stage 0 precondition: verifies that `.rules.env` exists at the current
working directory and parses cleanly. On missing or malformed file, exits
with status 2 and prints a bootstrap hint to stderr.

Stage 3 dispatch: based on `--category` (forensics | reverse | blue-team |
misc), `--recipe`, `--slug`, and `--lab-backend`, scaffolds:

    <slug>/
    ├── src/                  challenge source (author edits here)
    ├── publish/              player-facing artifacts (author populates from
    │                         src/; Stage 5 Analyze is the gate that scans
    │                         this tree for canonical-flag leakage)
    ├── solution/             solve.py + flag.txt / questions.yaml / stages.yaml
    │                         depending on flag_emission
    ├── recipe.yaml           recipe metadata (frontmatter linking to wiki)
    └── .bluechall.manifest.yaml

Template rendering for the actual src/ files is delegated to the recipe
template tree under `templates/<category>/<recipe>/`. When the template tree
is absent, this scaffolder produces a minimal but author-editable layout
with placeholder README files and a manifest stub.
"""

from __future__ import annotations

import argparse
import re
import shutil
import sys
import textwrap
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from _bcm_common import manifest, rules_env  # noqa: E402


SKILL_ROOT = Path(__file__).resolve().parent.parent
TEMPLATES_DIR = SKILL_ROOT / "templates"

EXIT_OK = 0
EXIT_USER_ERROR = 1
EXIT_PRECONDITION = 2
EXIT_INTERNAL = 3

CATEGORIES = ("forensics", "reverse", "blue-team", "misc")
LAB_BACKENDS = ("docker", "orbstack", "qemu", "none")
FLAG_EMISSIONS = ("single-static", "questions-as-flags", "service-derived", "multi-stage-pivot")

_SLUG_RE = re.compile(r"^[a-z0-9][a-z0-9-]*[a-z0-9]$")
# Recipe ids share the slug grammar — kebab-case alphanumerics. The strict
# regex prevents path traversal (`../foo`) and absolute paths from being
# resolved as a template subtree, which would otherwise let a malicious
# `--recipe` value copy arbitrary host files into `<slug>/src/`.
_RECIPE_RE = _SLUG_RE


def stage_0_check(*, cwd: Path | None = None) -> dict[str, str]:
    """Stage 0 precondition: load and validate `.rules.env` at the event-repo root."""
    target = (cwd or Path.cwd()) / rules_env.DEFAULT_FILENAME
    if not target.exists():
        _print_bootstrap_hint(target, reason="missing")
        raise SystemExit(EXIT_PRECONDITION)
    try:
        mapping = rules_env.load(target)
    except ValueError as e:
        _print_bootstrap_hint(target, reason=f"malformed: {e}")
        raise SystemExit(EXIT_PRECONDITION) from e
    if not mapping:
        _print_bootstrap_hint(target, reason="empty")
        raise SystemExit(EXIT_PRECONDITION)
    try:
        rules_env.validate(mapping)
    except ValueError as e:
        _print_bootstrap_hint(target, reason=f"invalid: {e}")
        raise SystemExit(EXIT_PRECONDITION) from e
    return mapping


def _print_bootstrap_hint(target: Path, *, reason: str) -> None:
    print(
        f"error: .rules.env at {target} is {reason}.\n"
        "Bootstrap an event configuration first:\n"
        "  python <skill-dir>/scripts/bluechall_bootstrap.py \\\n"
        "      --name TEST.HSCTF --long-name 'Test HSCTF' \\\n"
        "      --flag-prefix TEST.HSCTF --port-range 8080:8099 \\\n"
        "      --categories forensics,reverse,blue-team --yes",
        file=sys.stderr,
    )


def _resolve_category(args_category: str | None, rules: dict[str, str]) -> str:
    """Pick the category. Author-supplied wins; otherwise infer from .rules.env
    CATEGORIES (first member that is one of the three primaries).
    """
    if args_category:
        if args_category not in CATEGORIES:
            raise ValueError(
                f"--category {args_category!r} not in {list(CATEGORIES)}"
            )
        return args_category
    declared = [t.strip() for t in rules.get("CATEGORIES", "").split(",") if t.strip()]
    for t in declared:
        if t in ("forensics", "reverse", "blue-team"):
            return t
    if "misc" in declared:
        return "misc"
    raise ValueError(
        "no --category given and CATEGORIES in .rules.env contains no "
        "forensics/reverse/blue-team/misc member"
    )


def _resolve_lab_backend(args_lab: str | None, rules: dict[str, str]) -> str:
    if args_lab:
        return args_lab
    return rules.get("LAB_BACKEND_DEFAULT", "docker")


def _resolve_flag_emission(args_emission: str | None, rules: dict[str, str]) -> str:
    if args_emission:
        return args_emission
    return rules.get("FLAG_EMISSION_DEFAULT", "single-static")


def _scaffold_dirs(slug_dir: Path) -> None:
    for sub in ("src", "publish", "solution"):
        (slug_dir / sub).mkdir(parents=True, exist_ok=True)


def _emit_placeholder_solution(
    slug_dir: Path, *, flag_emission: str, flag_format_literal: str,
) -> None:
    """Write the per-emission solution stub. The author fills it in
    Stage 4 (Implement). Critical for `bluechall_validate.py` which
    parses these files.
    """
    sol = slug_dir / "solution"
    sol.mkdir(parents=True, exist_ok=True)
    if flag_emission == "single-static":
        (sol / "flag.txt").write_text(
            flag_format_literal.replace("<text>", "REPLACE_ME") + "\n",
            encoding="utf-8",
        )
    elif flag_emission == "questions-as-flags":
        # Top-level dict with `questions:` key — matches the publisher
        # (`bluechall_publish._load_questions`), every shipped template,
        # and the test suite. Older versions of this scaffolder emitted a
        # bare top-level list, which the publisher silently treated as
        # empty; the Confused-Developer trap is fixed by aligning here.
        (sol / "questions.yaml").write_text(textwrap.dedent("""\
            # Sherlocks-style question bundle.
            # Each entry MUST declare id, question, answer, attack_technique, points.
            # Optional: nist_phase, freeform_answer.
            questions:
              - id: q1
                question: "<player-facing question 1>"
                answer: REPLACE_ME
                attack_technique: T1059
                points: 10
                nist_phase: examination
        """), encoding="utf-8")
    elif flag_emission == "service-derived":
        # service/server.py is generated separately by bluechall_flagserver.py.
        (sol / "service_meta.yaml").write_text(textwrap.dedent("""\
            # Author runs:
            #   python <skill-dir>/scripts/bluechall_flagserver.py <slug>/ --port <N>
            # to generate the full service/ tree and overwrite this file.
            service_port: 0
            variant: http
            hmac_key_source: per-team
        """), encoding="utf-8")
    elif flag_emission == "multi-stage-pivot":
        (sol / "stages.yaml").write_text(textwrap.dedent("""\
            # Multi-stage pivot DAG. Exactly one entry MUST have terminal: true.
            - id: s1
              requires: []
              output_artifact: src/stage1.bin
              unlock_token_format: "^[A-Z]{8}$"
            - id: s2
              requires: [s1]
              output_artifact: src/stage2.bin
              unlock_token_format: "^[A-Z]{16}$"
              terminal: true
        """), encoding="utf-8")
    # Universal solve.py stub.
    (sol / "solve.py").write_text(textwrap.dedent("""\
        #!/usr/bin/env python3
        \"\"\"Reference solver for this challenge. Author fills this in.\"\"\"
        import sys

        def solve():
            raise NotImplementedError("author: implement the reference solve")

        if __name__ == "__main__":
            print(solve())
    """), encoding="utf-8")


def _emit_recipe_yaml(
    slug_dir: Path,
    *,
    slug: str, category: str, recipe_id: str,
    flag_emission: str, lab_backend: str,
) -> None:
    text = textwrap.dedent(f"""\
        ---
        id: {recipe_id}
        title: "Recipe for {slug}"
        type: recipe
        category: {category}
        subdomain: REPLACE-ME
        flag_emission: {flag_emission}
        lab_backend: {lab_backend}
        difficulty: medium
        last_compiled: 1970-01-01
        concept_refs: []
        cve_refs: []
        sources:
          - wiki/recipes/{recipe_id}.md
        ---
        # Recipe: {slug}

        Stage 4 (Implement) author notes go here.
    """)
    (slug_dir / "recipe.yaml").write_text(text, encoding="utf-8")


def _emit_player_readme(slug_dir: Path, *, slug: str, category: str) -> None:
    (slug_dir / "src" / "README.player.md").write_text(textwrap.dedent(f"""\
        # {slug}

        Category: {category}

        <player-facing description; the author replaces this in Stage 4>

        ## Provided artefacts

        TODO: list player-visible artefact files.

        ## How to submit

        TODO: describe the flag submission flow (single-static, questions, or
        service-derived endpoint).
    """), encoding="utf-8")


def _try_copy_template_tree(
    slug_dir: Path, *, category: str, recipe: str,
) -> bool:
    """If a template tree exists at templates/<category>/<recipe>/, copy its
    contents into <slug>/src/. Returns True on copy, False if no template.

    `recipe` MUST already match `_RECIPE_RE` (kebab-case slug); the caller
    is responsible for that check. Even so, defence in depth: resolve the
    candidate path and require it to stay inside `TEMPLATES_DIR`.
    """
    if not _RECIPE_RE.match(recipe):
        return False
    tpl = TEMPLATES_DIR / category / recipe
    try:
        tpl.resolve(strict=False).relative_to(TEMPLATES_DIR.resolve(strict=False))
    except ValueError:
        return False
    if not tpl.exists() or not tpl.is_dir():
        return False
    src = slug_dir / "src"
    src.mkdir(parents=True, exist_ok=True)
    for item in tpl.iterdir():
        target = src / item.name
        if item.is_dir():
            if target.exists():
                shutil.rmtree(target)
            shutil.copytree(item, target)
        else:
            shutil.copy2(item, target)
    return True


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(prog="bluechall_init", description=__doc__)
    p.add_argument("--category", choices=CATEGORIES,
                   help="primary challenge category")
    p.add_argument("--recipe", help="recipe id from wiki/recipes/")
    p.add_argument("--slug", required=True,
                   help="challenge slug directory name (kebab-case)")
    p.add_argument("--lab-backend", dest="lab_backend", choices=LAB_BACKENDS,
                   help="lab backend override (default from .rules.env)")
    p.add_argument("--flag-emission", dest="flag_emission",
                   choices=FLAG_EMISSIONS,
                   help="flag emission mode override (default from .rules.env)")
    p.add_argument("--force", action="store_true",
                   help="overwrite an existing slug directory")
    args = p.parse_args(argv)

    if not _SLUG_RE.match(args.slug):
        print(
            f"error: --slug {args.slug!r} must match ^[a-z0-9][a-z0-9-]*[a-z0-9]$",
            file=sys.stderr,
        )
        return EXIT_USER_ERROR

    if args.recipe is not None and not _RECIPE_RE.match(args.recipe):
        print(
            f"error: --recipe {args.recipe!r} must match "
            f"^[a-z0-9][a-z0-9-]*[a-z0-9]$ (kebab-case slug); reject "
            "path-traversal-shaped values",
            file=sys.stderr,
        )
        return EXIT_USER_ERROR

    try:
        rules = stage_0_check()
    except SystemExit as e:
        return int(e.code) if e.code is not None else EXIT_INTERNAL

    try:
        category = _resolve_category(args.category, rules)
    except ValueError as e:
        print(f"error: {e}", file=sys.stderr)
        return EXIT_USER_ERROR

    lab_backend = _resolve_lab_backend(args.lab_backend, rules)
    flag_emission = _resolve_flag_emission(args.flag_emission, rules)
    recipe_id = args.recipe or "untitled"

    slug_dir = Path.cwd() / args.slug
    if slug_dir.exists():
        if not args.force:
            print(
                f"error: {slug_dir} already exists; pass --force to overwrite",
                file=sys.stderr,
            )
            return EXIT_USER_ERROR
        shutil.rmtree(slug_dir)

    _scaffold_dirs(slug_dir)
    template_used = _try_copy_template_tree(
        slug_dir, category=category, recipe=recipe_id,
    )

    flag_literal = rules.get("FLAG_FORMAT_LITERAL", "FLAG{<text>}")
    _emit_placeholder_solution(
        slug_dir, flag_emission=flag_emission, flag_format_literal=flag_literal,
    )
    _emit_recipe_yaml(
        slug_dir, slug=args.slug, category=category, recipe_id=recipe_id,
        flag_emission=flag_emission, lab_backend=lab_backend,
    )
    _emit_player_readme(slug_dir, slug=args.slug, category=category)

    m = manifest.create(
        args.slug,
        category=category,
        recipe_id=recipe_id,
        flag_emission=flag_emission,
        lab_backend=lab_backend,
    )
    manifest.write(slug_dir, m)

    print(f"✓ scaffolded {slug_dir}")
    print(f"  category={category} recipe={recipe_id} "
          f"flag_emission={flag_emission} lab_backend={lab_backend}")
    print(
        "  next: edit src/ → bluechall_analyze.py → bluechall_validate.py "
        "→ bluechall_publish.py "
        "(populate publish/ yourself; analyze rejects flag leakage there)"
    )
    if not template_used:
        print(
            f"  note: no template found at templates/{category}/{recipe_id}/; "
            "scaffold uses placeholder src/ — author fills Stage 4 manually",
            file=sys.stderr,
        )
    return EXIT_OK


if __name__ == "__main__":
    sys.exit(main())
