#!/usr/bin/env python3
"""bluechall_manifest — read and mutate `<slug>/.bluechall.manifest.yaml`.

Subcommands:
  show <slug>/                     Pretty-print the manifest.
  mark-stage-complete <slug>/ <N>  Set stages.<N>.complete = true.
  append-audit-verdict <slug>/ <N> <pass|advisory|fail> [--persona <p>]
  next-incomplete <slug>/          Print the smallest incomplete stage number.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from _bcm_common import manifest  # noqa: E402


def cmd_show(args: argparse.Namespace) -> int:
    m = manifest.load(Path(args.slug_dir))
    if args.json:
        print(json.dumps(m, indent=2, default=str))
    else:
        print(f"slug: {m['slug']}")
        print(f"category: {m.get('category')}")
        print(f"recipe_id: {m.get('recipe_id')}")
        print(f"flag_emission: {m.get('flag_emission')}")
        print(f"lab_backend: {m.get('lab_backend')}")
        print("stages:")
        for n in range(1, 8):
            s = m["stages"][str(n)]
            sym = "✓" if s["complete"] else "·"
            verdict = s.get("audit_verdict") or "-"
            persona = s.get("audit_persona") or ""
            print(f"  {sym} {n}: complete={s['complete']} verdict={verdict} persona={persona}")
        prov = m.get("lab_provenance") or []
        print(f"lab_provenance entries: {len(prov)}")
    return 0


def cmd_mark_stage_complete(args: argparse.Namespace) -> int:
    manifest.mark_stage_complete(Path(args.slug_dir), args.stage)
    print(f"✓ stage {args.stage} marked complete")
    return 0


def cmd_append_audit_verdict(args: argparse.Namespace) -> int:
    manifest.append_audit_verdict(
        Path(args.slug_dir), args.stage, args.verdict, args.persona,
    )
    print(f"✓ stage {args.stage} verdict={args.verdict} persona={args.persona or '-'}")
    return 0


def cmd_next_incomplete(args: argparse.Namespace) -> int:
    n = manifest.next_incomplete_stage(Path(args.slug_dir))
    if n is None:
        print("all stages complete")
    else:
        print(n)
    return 0


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(prog="bluechall_manifest", description=__doc__)
    sub = p.add_subparsers(dest="command", required=True)

    ps = sub.add_parser("show")
    ps.add_argument("slug_dir")
    ps.add_argument("--json", action="store_true")
    ps.set_defaults(func=cmd_show)

    pm = sub.add_parser("mark-stage-complete")
    pm.add_argument("slug_dir")
    pm.add_argument("stage", type=int)
    pm.set_defaults(func=cmd_mark_stage_complete)

    pa = sub.add_parser("append-audit-verdict")
    pa.add_argument("slug_dir")
    pa.add_argument("stage", type=int)
    pa.add_argument("verdict", choices=("pass", "advisory", "fail"))
    pa.add_argument("--persona", default=None)
    pa.set_defaults(func=cmd_append_audit_verdict)

    pn = sub.add_parser("next-incomplete")
    pn.add_argument("slug_dir")
    pn.set_defaults(func=cmd_next_incomplete)

    args = p.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
