#!/usr/bin/env python3
"""bluechall_orbstack — OrbStack VM lab orchestrator.

Wraps `_bcm_common.lab_helpers.vm_session` for direct CLI use. Two profiles:

  --mode artifact-generation  Build attacked host, install vulnerable
                              software, drop attacker payload, then
                              dump-mem and dump-disk for player consumption.
  --mode interactive          Provision a VM and print SSH key + connection
                              details for live forensics.

  bluechall_orbstack.py up <slug>/ --mode <m> [--no-runtime] [--recipe <r>]
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from _bcm_common import lab_helpers  # noqa: E402


def cmd_up(args: argparse.Namespace) -> int:
    slug_dir = Path(args.slug_dir).resolve()
    with lab_helpers.vm_session(
        slug_dir, profile=args.mode, dry_run=args.no_runtime,
    ) as session:
        print(f"backend={session.backend} mode={session.mode} profile={args.mode}")
        print(f"started_at={session.started_at}")
        if session.endpoints:
            print(f"endpoints={session.endpoints}")
        if args.dump_memory and session.mode == "live":
            out = slug_dir / "src" / "artifacts" / "memory.raw"
            lab_helpers.dump_memory(session, out)
            print(f"✓ dumped memory to {out}")
    return 0


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(prog="bluechall_orbstack", description=__doc__)
    sub = p.add_subparsers(dest="command", required=True)

    pu = sub.add_parser("up", help="provision OrbStack VM via cloud-init")
    pu.add_argument("slug_dir")
    pu.add_argument("--mode", choices=("artifact-generation", "interactive"),
                    default="artifact-generation")
    pu.add_argument("--no-runtime", action="store_true",
                    help="dry-run: do not invoke orb, but record provenance")
    pu.add_argument("--recipe", help="recipe id (informational; influences cloud-init)")
    pu.add_argument("--dump-memory", action="store_true",
                    help="capture /proc/kcore to src/artifacts/memory.raw")
    pu.set_defaults(func=cmd_up)

    args = p.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
