"""Tests for `_bcm_common.lab_helpers`.

Spec scenarios:
- compose_session writes provenance digest on exit
- --no-runtime suppresses provisioning across all backends
"""

from __future__ import annotations

import sys
import yaml
from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(REPO_ROOT / "scripts"))

from _bcm_common import lab_helpers as lab  # noqa: E402


def make_slug_with_compose(tmp_path: Path) -> Path:
    slug = tmp_path / "demo-stego"
    src = slug / "src"
    src.mkdir(parents=True)
    (src / "docker-compose.yml").write_text(
        "version: '3.9'\nservices:\n  challenge:\n    image: alpine:latest\n",
        encoding="utf-8",
    )
    (src / "Dockerfile").write_text(
        "FROM alpine:latest\nCMD echo hello\n",
        encoding="utf-8",
    )
    return slug


def test_compose_session_dry_run_writes_provenance(tmp_path):
    """Spec: compose_session writes provenance digest on exit (dry-run mode)."""
    slug = make_slug_with_compose(tmp_path)
    with lab.compose_session(slug, mode="analyze", dry_run=True) as session:
        assert session.backend == "docker"
        assert session.mode == "dry-run"
        assert session.started_at != ""
    manifest = slug / lab.MANIFEST_FILENAME
    assert manifest.exists(), "manifest must be written on exit"
    data = yaml.safe_load(manifest.read_text(encoding="utf-8"))
    prov = data["lab_provenance"]
    assert len(prov) == 1
    entry = prov[0]
    assert entry["backend"] == "docker"
    assert entry["mode"] == "dry-run"
    assert entry["sha256"]  # non-empty digest
    assert entry["started_at"]
    assert entry["ended_at"]


def test_compose_session_no_runtime_skips_subprocess(tmp_path, monkeypatch):
    """Spec: --no-runtime suppresses provisioning across all backends."""
    slug = make_slug_with_compose(tmp_path)
    called = {"docker": 0}
    import subprocess as sp
    real_run = sp.run

    def fake_run(*args, **kwargs):
        if args and isinstance(args[0], list) and args[0] and args[0][0] == "docker":
            called["docker"] += 1
        return real_run(*args, **kwargs)

    monkeypatch.setattr(sp, "run", fake_run)
    with lab.compose_session(slug, dry_run=True):
        pass
    assert called["docker"] == 0, "no docker subprocess in dry-run"


def test_vm_session_dry_run_writes_provenance(tmp_path):
    slug = tmp_path / "demo-ir"
    (slug / "src").mkdir(parents=True)
    (slug / "src" / "orbstack.cloud-init.yaml").write_text(
        "#cloud-config\nhostname: demo\n", encoding="utf-8",
    )
    with lab.vm_session(slug, profile="artifact-generation", dry_run=True) as session:
        assert session.backend == "orbstack"
        assert session.mode == "dry-run"
        assert session.extra["profile"] == "artifact-generation"
        assert session.extra["vm_name"] == "bluechall-demo-ir"
    data = yaml.safe_load((slug / lab.MANIFEST_FILENAME).read_text(encoding="utf-8"))
    assert data["lab_provenance"][0]["mode"] == "dry-run"


def test_qemu_session_dry_run_writes_provenance(tmp_path):
    slug = tmp_path / "demo-vm"
    slug.mkdir()
    binary = tmp_path / "fake_bin"
    binary.write_bytes(b"\x7fELF...")
    with lab.qemu_session(
        slug, profile="user-mode", arch="mips",
        binary=binary, dry_run=True,
    ) as session:
        assert session.backend == "qemu"
        assert session.mode == "dry-run"
    data = yaml.safe_load((slug / lab.MANIFEST_FILENAME).read_text(encoding="utf-8"))
    assert data["lab_provenance"][0]["backend"] == "qemu"


def test_session_appends_to_existing_manifest(tmp_path):
    slug = make_slug_with_compose(tmp_path)
    manifest = slug / lab.MANIFEST_FILENAME
    manifest.write_text(yaml.safe_dump({"slug": slug.name, "lab_provenance": []}),
                        encoding="utf-8")
    for _ in range(3):
        with lab.compose_session(slug, dry_run=True):
            pass
    data = yaml.safe_load(manifest.read_text(encoding="utf-8"))
    assert data["slug"] == slug.name
    assert len(data["lab_provenance"]) == 3


def test_provenance_digest_changes_when_compose_changes(tmp_path):
    slug = make_slug_with_compose(tmp_path)
    with lab.compose_session(slug, dry_run=True):
        pass
    digest_a = yaml.safe_load((slug / lab.MANIFEST_FILENAME).read_text(encoding="utf-8"))["lab_provenance"][0]["sha256"]

    (slug / "src" / "docker-compose.yml").write_text(
        "version: '3.9'\nservices:\n  challenge:\n    image: alpine:edge\n",
        encoding="utf-8",
    )
    with lab.compose_session(slug, dry_run=True):
        pass
    digest_b = yaml.safe_load((slug / lab.MANIFEST_FILENAME).read_text(encoding="utf-8"))["lab_provenance"][1]["sha256"]
    assert digest_a != digest_b


def test_compose_session_records_error_on_exception(tmp_path):
    slug = make_slug_with_compose(tmp_path)
    with pytest.raises(ValueError):
        with lab.compose_session(slug, dry_run=True):
            raise ValueError("simulated failure")
    data = yaml.safe_load((slug / lab.MANIFEST_FILENAME).read_text(encoding="utf-8"))
    entry = data["lab_provenance"][0]
    assert entry["extra"]["error"] == "ValueError"


def test_dump_memory_rejects_dry_run_session(tmp_path):
    slug = tmp_path / "demo"
    slug.mkdir()
    session = lab.LabSession(backend="orbstack", mode="dry-run", slug_dir=slug)
    with pytest.raises(RuntimeError, match=r"requires a live"):
        lab.dump_memory(session, slug / "out.raw")
