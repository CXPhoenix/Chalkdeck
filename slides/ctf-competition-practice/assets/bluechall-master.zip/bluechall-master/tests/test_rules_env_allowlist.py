"""`.rules.env` validator MUST reject any key outside the documented schema.

Replaces the prior blocklist approach (`_FORBIDDEN_EXTRA_KEY_PATTERNS`)
which kept missing newly-discovered env-poison vectors. Allowlist is
derived from `REQUIRED_KEYS` plus an explicit `OPTIONAL_KEYS` tuple.
"""

from __future__ import annotations

import sys
from pathlib import Path

import pytest


REPO = Path(__file__).resolve().parent.parent
SCRIPTS = REPO / "scripts"
sys.path.insert(0, str(SCRIPTS))

from _bcm_common import rules_env  # noqa: E402


_BASE_VALID_MAPPING = {
    # 15 webchall keys
    "CTF_EVENT_NAME": "TEST.HSCTF",
    "CTF_EVENT_LONG_NAME": "Test HSCTF",
    "FLAG_FORMAT_LITERAL": "TEST.HSCTF{<text>}",
    "FLAG_REGEX": r"TEST\.HSCTF\{[A-Za-z0-9_]+\}",
    "FLAG_TYPE": "static",
    "AUTHOR_NAME": "phoenix",
    "AUTHOR_EMAIL": "phoenix@example.org",
    "HOST_PORT_RANGE_START": "8080",
    "HOST_PORT_RANGE_END": "8099",
    "FLAG_ASSET_VERSION_CONTROLLED": "true",
    "BLOCK_PRC_VOCAB": "false",
    "ENFORCE_ANTI_AI_SLOP": "true",
    "PLAYER_FACING_LOCALE": "zh-TW",
    "SPEC_LOCALE": "en-US",
    "CATEGORIES": "forensics,reverse,blue-team",
    "DIFFICULTIES": "easy,medium,hard",
    # 8 bluechall keys
    "FORENSICS_TOOLCHAIN_PROFILE": "default",
    "REVERSE_TOOLCHAIN_PROFILE": "default",
    "BLUE_TEAM_QUESTION_LIMIT": "10",
    "LAB_BACKEND_DEFAULT": "docker",
    "FLAG_EMISSION_DEFAULT": "single-static",
    "EXTERNAL_FLAG_SERVICE_PORT_RANGE_START": "8500",
    "EXTERNAL_FLAG_SERVICE_PORT_RANGE_END": "8599",
    "MITRE_ATTACK_VERSION": "v15.0",
}


def test_valid_23_key_mapping_accepted():
    """Sanity: the canonical 23-key file MUST validate cleanly."""
    rules_env.validate(dict(_BASE_VALID_MAPPING))


def test_bash_env_rejected_as_unknown_key():
    """`BASH_ENV` was outside the prior blocklist but is a known shell
    env-poison vector. Allowlist semantics SHALL reject it as unknown.
    """
    bad = dict(_BASE_VALID_MAPPING, BASH_ENV="/tmp/x")
    with pytest.raises(ValueError, match=r"BASH_ENV"):
        rules_env.validate(bad)


def test_node_options_rejected_as_unknown_key():
    bad = dict(_BASE_VALID_MAPPING, NODE_OPTIONS="--require=/tmp/x.js")
    with pytest.raises(ValueError, match=r"NODE_OPTIONS"):
        rules_env.validate(bad)


def test_misspelled_required_key_rejected():
    """Drop the canonical key and add a typo'd variant — the resulting
    mapping is missing a required key AND has an unknown extra. The
    validator SHALL surface both signals (or at least name the unknown
    key in the error so the operator can match against the schema).
    """
    bad = dict(_BASE_VALID_MAPPING)
    bad.pop("FLAG_REGEX")
    bad["FLAG_REGX"] = r"TEST\.HSCTF\{[A-Za-z0-9_]+\}"
    with pytest.raises(ValueError, match=r"FLAG_REG"):
        rules_env.validate(bad)


def test_allowlist_error_lists_env_poison_hints():
    """The validator's error message SHOULD enumerate at least a handful
    of canonical env-poison vectors as a hint for the operator.
    """
    bad = dict(_BASE_VALID_MAPPING, ARBITRARY_KEY_NAME="x")
    with pytest.raises(ValueError) as excinfo:
        rules_env.validate(bad)
    msg = str(excinfo.value)
    # Operator hint: either via direct mention of the offender, or via
    # the env-poison hint enumeration. We check the offending key is
    # named explicitly.
    assert "ARBITRARY_KEY_NAME" in msg
