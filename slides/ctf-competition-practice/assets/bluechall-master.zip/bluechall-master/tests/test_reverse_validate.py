"""End-to-end tests for bluechall_validate.py against reverse-category challenges."""

from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

import yaml

REPO = Path(__file__).resolve().parent.parent
SCRIPTS = REPO / "scripts"


def _run_cli(*args):
    cmd = [sys.executable, str(SCRIPTS / "bluechall_validate.py"), *args]
    return subprocess.run(cmd, capture_output=True, text=True)


def _make_reverse_manifest(*, flag_emission="single-static"):
    return {
        "slug": "demo-rev-vm",
        "category": "reverse",
        "recipe_id": "rev-vm-bytecode",
        "flag_emission": flag_emission,
        "lab_backend": "docker",
        "concept_refs": ["vm-bytecode-reverse"],
        "cve_refs": [],
        "stages": {str(i): {"complete": True, "audit_verdict": "pass",
                            "audit_persona": None, "timestamp": "2026-05-04T00:00:00+00:00"}
                   for i in range(1, 8)},
        "lab_provenance": [],
        "canonical_flag": "FLAG{vm_byt3c0d3_real_2026}",
    }


def _build(tmp_path, *, manifest, layout=None):
    slug = tmp_path / manifest["slug"]
    slug.mkdir()
    (slug / ".bluechall.manifest.yaml").write_text(
        yaml.safe_dump(manifest, default_flow_style=False, sort_keys=False),
        encoding="utf-8",
    )
    if layout:
        for relpath, content in layout.items():
            target = slug / relpath
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(content, encoding="utf-8")
    return slug


def test_reverse_single_static_passes(tmp_path):
    m = _make_reverse_manifest()
    slug = _build(tmp_path, manifest=m, layout={
        "solution/solve.py": "import angr\n",
        "solution/flag.txt": "FLAG{vm_bytecode_reversed_2026}",
        "recipe.yaml": "---\nid: rev-vm-bytecode\nflag_emission: single-static\n---\n",
    })
    r = _run_cli(str(slug), "--allow-stage-skip")
    assert r.returncode == 0, r.stdout + r.stderr


def test_reverse_multi_stage_pivot_requires_stages_yaml(tmp_path):
    m = _make_reverse_manifest(flag_emission="multi-stage-pivot")
    slug = _build(tmp_path, manifest=m, layout={
        "solution/solve.py": "x",
        "recipe.yaml": "---\nid: rev-vm-bytecode\nflag_emission: multi-stage-pivot\n---\n",
    })
    r = _run_cli(str(slug), "--allow-stage-skip")
    assert r.returncode == 1
    assert "stages.yaml" in r.stdout


def test_reverse_multi_stage_pivot_passes_with_stages_yaml(tmp_path):
    m = _make_reverse_manifest(flag_emission="multi-stage-pivot")
    # Top-level YAML list with a single terminal stage; matches the
    # canonical shape expected by `flag_emission.validate_multi_stage_pivot`.
    stages_yaml = (
        "- id: s1\n"
        "  requires: []\n"
        "  output_artifact: stage1.out\n"
        "  unlock_token_format: '^[A-Z]{8}$'\n"
        "  terminal: true\n"
    )
    slug = _build(tmp_path, manifest=m, layout={
        "solution/solve.py": "x",
        "solution/stages.yaml": stages_yaml,
        "recipe.yaml": "---\nid: rev-vm-bytecode\nflag_emission: multi-stage-pivot\n---\n",
    })
    r = _run_cli(str(slug), "--allow-stage-skip")
    assert r.returncode == 0, r.stdout + r.stderr


def test_reverse_invalid_category_rejected(tmp_path):
    m = _make_reverse_manifest()
    m["category"] = "exploit"  # not in CATEGORIES
    slug = _build(tmp_path, manifest=m, layout={
        "solution/solve.py": "x", "solution/flag.txt": "FLAG{ok}",
        "recipe.yaml": "x",
    })
    r = _run_cli(str(slug), "--allow-stage-skip")
    assert r.returncode == 1
    assert "category" in r.stdout
    assert "exploit" in r.stdout


def test_reverse_service_derived_requires_service_dir(tmp_path):
    m = _make_reverse_manifest(flag_emission="service-derived")
    slug = _build(tmp_path, manifest=m, layout={
        "solution/solve.py": "x",
        "recipe.yaml": "---\nid: rev-vm-bytecode\nflag_emission: single-static\n---\n",
    })
    r = _run_cli(str(slug), "--allow-stage-skip", "--json")
    assert r.returncode == 1
    parsed = json.loads(r.stdout)
    mismatches = [f for f in parsed if f["rule_id"] == "flag-emission-mismatch"]
    assert mismatches
    assert "service" in mismatches[0]["message"].lower()
