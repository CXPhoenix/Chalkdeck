"""Tests for `_bcm_common.rules_env`.

Covers the spec scenarios:
- minimal valid 23-key file at event repo root
- missing CATEGORIES bluechall member rejected
- forbidden environment variable rejected
"""

from __future__ import annotations

import re
import sys
from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(REPO_ROOT / "scripts"))

from _bcm_common import rules_env  # noqa: E402


# Helper -----------------------------------------------------------------------


def valid_mapping() -> dict[str, str]:
    """Return a valid 23-key mapping suitable for validate()."""
    return {
        # 15 webchall keys
        "CTF_EVENT_NAME": "TEST.HSCTF",
        "CTF_EVENT_LONG_NAME": "Test HSCTF",
        "FLAG_REGEX": r"TEST\.HSCTF\{[A-Za-z0-9_]+\}",
        "FLAG_FORMAT_LITERAL": "TEST.HSCTF{<text>}",
        "FLAG_TYPE": "static",
        "FLAG_ASSET_VERSION_CONTROLLED": "true",
        "AUTHOR_NAME": "Test Author",
        "AUTHOR_EMAIL": "test@example.org",
        "CATEGORIES": "forensics,reverse,blue-team,misc",
        "DIFFICULTIES": "easy,medium,hard",
        "HOST_PORT_RANGE_START": "8080",
        "HOST_PORT_RANGE_END": "8099",
        "PLAYER_FACING_LOCALE": "zh-Hant-TW",
        "SPEC_LOCALE": "en",
        "BLOCK_PRC_VOCAB": "true",
        "ENFORCE_ANTI_AI_SLOP": "true",
        # 8 bluechall keys
        "FORENSICS_TOOLCHAIN_PROFILE": "volatility3,wireshark,binwalk,exiftool,zsteg,oletools",
        "REVERSE_TOOLCHAIN_PROFILE": "ghidra,angr,qiling,unicorn,frida",
        "BLUE_TEAM_QUESTION_LIMIT": "10",
        "LAB_BACKEND_DEFAULT": "docker",
        "FLAG_EMISSION_DEFAULT": "single-static",
        "EXTERNAL_FLAG_SERVICE_PORT_RANGE_START": "8500",
        "EXTERNAL_FLAG_SERVICE_PORT_RANGE_END": "8599",
        "MITRE_ATTACK_VERSION": "v15.0",
    }


# Schema -----------------------------------------------------------------------


def test_required_keys_count_matches_webchall_plus_bluechall():
    # Spec narrative says "15 + 8 = 23"; the actual webchall implementation
    # carries 16 keys (the narrative was off by one), so we assert dynamically:
    # REQUIRED = WEBCHALL_KEYS ∪ BLUECHALL_KEYS, both disjoint.
    assert len(rules_env.REQUIRED_KEYS) == len(rules_env.WEBCHALL_KEYS) + len(rules_env.BLUECHALL_KEYS)
    assert set(rules_env.REQUIRED_KEYS) == set(rules_env.WEBCHALL_KEYS) | set(rules_env.BLUECHALL_KEYS)
    assert not (set(rules_env.WEBCHALL_KEYS) & set(rules_env.BLUECHALL_KEYS)), \
        "WEBCHALL_KEYS and BLUECHALL_KEYS must be disjoint"


def test_required_keys_include_all_webchall_keys():
    assert {
        "CTF_EVENT_NAME", "CTF_EVENT_LONG_NAME",
        "FLAG_REGEX", "FLAG_FORMAT_LITERAL", "FLAG_TYPE",
        "FLAG_ASSET_VERSION_CONTROLLED",
        "AUTHOR_NAME", "AUTHOR_EMAIL",
        "CATEGORIES", "DIFFICULTIES",
        "HOST_PORT_RANGE_START", "HOST_PORT_RANGE_END",
        "PLAYER_FACING_LOCALE", "SPEC_LOCALE",
        "BLOCK_PRC_VOCAB", "ENFORCE_ANTI_AI_SLOP",
    }.issubset(set(rules_env.REQUIRED_KEYS))


def test_required_keys_include_all_8_bluechall_keys():
    bluechall_keys = {
        "FORENSICS_TOOLCHAIN_PROFILE",
        "REVERSE_TOOLCHAIN_PROFILE",
        "BLUE_TEAM_QUESTION_LIMIT",
        "LAB_BACKEND_DEFAULT",
        "FLAG_EMISSION_DEFAULT",
        "EXTERNAL_FLAG_SERVICE_PORT_RANGE_START",
        "EXTERNAL_FLAG_SERVICE_PORT_RANGE_END",
        "MITRE_ATTACK_VERSION",
    }
    assert bluechall_keys.issubset(set(rules_env.REQUIRED_KEYS))


# Validation: minimal valid 23-key file ----------------------------------------


def test_validate_accepts_minimal_valid_mapping():
    rules_env.validate(valid_mapping())  # no exception


# Validation: CATEGORIES must include at least one bluechall member ------------


def test_validate_rejects_categories_without_bluechall_member():
    m = valid_mapping()
    m["CATEGORIES"] = "web,crypto,pwn"
    with pytest.raises(ValueError, match=r"CATEGORIES"):
        rules_env.validate(m)


def test_validate_accepts_categories_with_only_blue_team():
    m = valid_mapping()
    m["CATEGORIES"] = "blue-team"
    rules_env.validate(m)


def test_validate_accepts_categories_with_only_forensics():
    m = valid_mapping()
    m["CATEGORIES"] = "forensics"
    rules_env.validate(m)


def test_validate_accepts_categories_with_only_reverse():
    m = valid_mapping()
    m["CATEGORIES"] = "reverse"
    rules_env.validate(m)


def test_validate_accepts_categories_with_misc_and_one_primary():
    m = valid_mapping()
    m["CATEGORIES"] = "forensics,misc"
    rules_env.validate(m)


# Forbidden vars ---------------------------------------------------------------


@pytest.mark.parametrize("forbidden_key", [
    "LD_PRELOAD",
    "LD_LIBRARY_PATH",
    "DYLD_INSERT_LIBRARIES",
    "PYTHONPATH",
    "PYTHONSTARTUP",
    "HTTP_PROXY",
    "HTTPS_PROXY",
    "NO_PROXY",
    "ALL_PROXY",
    "GIT_SSH_COMMAND",
])
def test_validate_rejects_forbidden_extra_key(forbidden_key):
    """The validator now uses an allowlist (REQUIRED_KEYS | OPTIONAL_KEYS);
    any key outside that set is rejected. The error message names the
    offending key explicitly.
    """
    m = valid_mapping()
    m[forbidden_key] = "/tmp/evil.so"
    with pytest.raises(ValueError, match=re.escape(forbidden_key)):
        rules_env.validate(m)


# Per-key validation: 8 bluechall keys -----------------------------------------


def test_blue_team_question_limit_must_be_positive_int():
    m = valid_mapping()
    m["BLUE_TEAM_QUESTION_LIMIT"] = "0"
    with pytest.raises(ValueError, match=r"BLUE_TEAM_QUESTION_LIMIT"):
        rules_env.validate(m)


def test_blue_team_question_limit_upper_bound():
    m = valid_mapping()
    m["BLUE_TEAM_QUESTION_LIMIT"] = "999"
    with pytest.raises(ValueError, match=r"BLUE_TEAM_QUESTION_LIMIT"):
        rules_env.validate(m)


def test_lab_backend_default_must_be_enum():
    m = valid_mapping()
    m["LAB_BACKEND_DEFAULT"] = "vmware"
    with pytest.raises(ValueError, match=r"LAB_BACKEND_DEFAULT"):
        rules_env.validate(m)


@pytest.mark.parametrize("backend", ["docker", "orbstack", "qemu", "none"])
def test_lab_backend_default_accepts_valid_enum(backend):
    m = valid_mapping()
    m["LAB_BACKEND_DEFAULT"] = backend
    rules_env.validate(m)


def test_flag_emission_default_must_be_enum():
    m = valid_mapping()
    m["FLAG_EMISSION_DEFAULT"] = "computed"
    with pytest.raises(ValueError, match=r"FLAG_EMISSION_DEFAULT"):
        rules_env.validate(m)


@pytest.mark.parametrize("mode", [
    "single-static",
    "questions-as-flags",
    "service-derived",
    "multi-stage-pivot",
])
def test_flag_emission_default_accepts_valid_enum(mode):
    m = valid_mapping()
    m["FLAG_EMISSION_DEFAULT"] = mode
    rules_env.validate(m)


def test_external_flag_service_port_range_validation():
    m = valid_mapping()
    m["EXTERNAL_FLAG_SERVICE_PORT_RANGE_START"] = "9000"
    m["EXTERNAL_FLAG_SERVICE_PORT_RANGE_END"] = "8500"
    with pytest.raises(ValueError, match=r"EXTERNAL_FLAG_SERVICE"):
        rules_env.validate(m)


def test_external_flag_service_port_range_overlap_with_host_range_rejected():
    m = valid_mapping()
    m["HOST_PORT_RANGE_START"] = "8000"
    m["HOST_PORT_RANGE_END"] = "8999"
    m["EXTERNAL_FLAG_SERVICE_PORT_RANGE_START"] = "8500"
    m["EXTERNAL_FLAG_SERVICE_PORT_RANGE_END"] = "8599"
    with pytest.raises(ValueError, match=r"overlap"):
        rules_env.validate(m)


def test_mitre_attack_version_must_match_v_pattern():
    m = valid_mapping()
    m["MITRE_ATTACK_VERSION"] = "fifteen"
    with pytest.raises(ValueError, match=r"MITRE_ATTACK_VERSION"):
        rules_env.validate(m)


@pytest.mark.parametrize("version", ["v14.0", "v15.0", "v15.1", "v16.0"])
def test_mitre_attack_version_accepts_valid_pattern(version):
    m = valid_mapping()
    m["MITRE_ATTACK_VERSION"] = version
    rules_env.validate(m)


def test_forensics_toolchain_profile_must_be_csv_enum():
    m = valid_mapping()
    m["FORENSICS_TOOLCHAIN_PROFILE"] = ""
    with pytest.raises(ValueError, match=r"FORENSICS_TOOLCHAIN_PROFILE"):
        rules_env.validate(m)


def test_reverse_toolchain_profile_must_be_csv_enum():
    m = valid_mapping()
    m["REVERSE_TOOLCHAIN_PROFILE"] = ""
    with pytest.raises(ValueError, match=r"REVERSE_TOOLCHAIN_PROFILE"):
        rules_env.validate(m)


# Round-trip parse / render ---------------------------------------------------


def test_render_then_parse_roundtrip():
    text = rules_env.render(valid_mapping())
    parsed = rules_env._parse_text(text)
    rules_env.validate(parsed)
    for k in rules_env.REQUIRED_KEYS:
        assert parsed[k] == valid_mapping()[k], f"key {k!r} did not round-trip"


def test_parse_rejects_export_prefix():
    with pytest.raises(ValueError, match=r"export"):
        rules_env._parse_text("export CTF_EVENT_NAME=TEST.HSCTF\n")


def test_parse_rejects_variable_expansion():
    with pytest.raises(ValueError, match=r"expansion"):
        rules_env._parse_text("CTF_EVENT_NAME=$BASE.HSCTF\n")


def test_load_returns_empty_dict_for_missing_file(tmp_path):
    assert rules_env.load(tmp_path / "absent") == {}


def test_load_accepts_valid_written_file(tmp_path):
    target = tmp_path / ".rules.env"
    rules_env.write(target, valid_mapping())
    parsed = rules_env.load(target)
    rules_env.validate(parsed)


def test_write_refuses_overwrite_without_force(tmp_path):
    target = tmp_path / ".rules.env"
    rules_env.write(target, valid_mapping())
    with pytest.raises(FileExistsError):
        rules_env.write(target, valid_mapping())


def test_write_accepts_overwrite_with_force(tmp_path):
    target = tmp_path / ".rules.env"
    rules_env.write(target, valid_mapping())
    m = valid_mapping()
    m["CTF_EVENT_LONG_NAME"] = "Different Name"
    rules_env.write(target, m, force=True)
    parsed = rules_env.load(target)
    assert parsed["CTF_EVENT_LONG_NAME"] == "Different Name"


def test_load_returns_empty_when_file_oversized(tmp_path):
    target = tmp_path / ".rules.env"
    target.write_text("x" * (rules_env.MAX_FILE_BYTES + 1))
    with pytest.raises(ValueError, match=r"DoS"):
        rules_env.load(target)


# Cross-key invariants --------------------------------------------------------


def test_host_port_range_end_must_be_ge_start():
    m = valid_mapping()
    m["HOST_PORT_RANGE_START"] = "9000"
    m["HOST_PORT_RANGE_END"] = "8000"
    with pytest.raises(ValueError, match=r"HOST_PORT_RANGE"):
        rules_env.validate(m)


def test_flag_format_literal_must_contain_text_placeholder():
    m = valid_mapping()
    m["FLAG_FORMAT_LITERAL"] = "TEST.HSCTF{example}"  # no <text>
    with pytest.raises(ValueError, match=r"<text>"):
        rules_env.validate(m)


def test_flag_regex_must_be_compilable():
    m = valid_mapping()
    m["FLAG_REGEX"] = r"TEST\.HSCTF\{[A-Z"
    with pytest.raises(ValueError, match=r"FLAG_REGEX"):
        rules_env.validate(m)
