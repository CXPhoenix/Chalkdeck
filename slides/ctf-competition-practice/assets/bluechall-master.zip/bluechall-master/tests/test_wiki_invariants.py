"""Tests for `_bcm_common.wiki` and `bluechall_wiki` CLI.

Covers spec scenarios:
- in-place raw edit rejected by verify
- recipe page missing flag_emission rejected
- missing survey coverage emits advisory, not critical
- AGENTS.md missing one of four mandatory sections
- cross-model lint catches embedded tool names
"""

from __future__ import annotations

import sys
import textwrap
from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(REPO_ROOT / "scripts"))

from _bcm_common import wiki  # noqa: E402


# Helpers ---------------------------------------------------------------------


def make_raw_file(path: Path, body: str, *, sha_override: str | None = None) -> None:
    """Write a raw file with valid bluechall raw frontmatter."""
    digest = sha_override or wiki.sha256_of_body(body)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        f"---\nfetch_url: https://example.test/raw\nfetch_date: 2026-05-03\n"
        f"sha256: {digest}\n---\n{body}",
        encoding="utf-8",
    )


def write_minimal_skill_root(root: Path) -> None:
    """Build a minimal skill root with profile.yaml, AGENTS.md, and SKILL.md."""
    (root / "profile.yaml").write_text(textwrap.dedent("""\
        name: bluechall-defensive-wiki-profile
        version: "0.1.0"
        min_core_schema_version: "1.0.0"
        required_dirs:
          - taxonomies
          - concepts
          - frameworks
          - cves
          - recipes
        raw_subtypes:
          - papers
          - tools
          - flare-on-solutions
          - ctf-writeups
        required_fields:
          taxonomy:
            - id
            - title
            - type
            - last_compiled
            - sources
          concept:
            - id
            - title
            - type
            - category
            - subdomain
            - last_compiled
            - sources
          framework:
            - id
            - title
            - type
            - tool_class
            - last_compiled
            - sources
            - cves
          cve:
            - id
            - title
            - type
            - cve_id
            - last_compiled
            - sources
          recipe:
            - id
            - title
            - type
            - category
            - subdomain
            - flag_emission
            - lab_backend
            - last_compiled
            - sources
        page_frontmatter_schema:
          type: object
          required:
            - id
            - title
            - type
            - last_compiled
            - sources
        survey_coverage_subdomains:
          forensics:
            - stego
            - memory
          reverse:
            - cpp-binary
            - custom-vm
        validator_extensions:
          - bluechall-cross-model-lint
        log_format_strict: true
    """), encoding="utf-8")
    (root / "AGENTS.md").write_text(textwrap.dedent("""\
        # bluechall-master AGENTS.md

        ## 1. Layout

        Some content.

        ## 2. Page frontmatter schema

        Some content.

        ## 3. Operations

        Some content.

        ## 4. Cross-model contract

        Some content.
    """), encoding="utf-8")
    (root / "SKILL.md").write_text(
        "# Skill\n\nImperative-mood prose only.\n",
        encoding="utf-8",
    )
    for sub in ("taxonomies", "concepts", "frameworks", "cves", "recipes",
                "raw", "raw/papers", "raw/tools", "raw/flare-on-solutions",
                "raw/ctf-writeups"):
        (root / "wiki" / sub).mkdir(parents=True, exist_ok=True)


# === Spec scenarios ==========================================================


def test_in_place_raw_edit_rejected_by_verify(tmp_path):
    """Spec scenario: in-place raw edit rejected by verify."""
    write_minimal_skill_root(tmp_path)
    raw = tmp_path / "wiki" / "raw" / "papers" / "example.md"
    make_raw_file(raw, "Original body\n")
    # Tamper: rewrite body but keep frontmatter SHA unchanged.
    text = raw.read_text(encoding="utf-8")
    head, _ = text.split("---\n", 2)[1:3] if text.startswith("---\n") else ("", "")
    raw.write_text(
        text.split("\n---\n", 1)[0] + "\n---\nTampered body\n",
        encoding="utf-8",
    )
    findings = wiki.verify(tmp_path / "wiki", profile=wiki.Profile.load(tmp_path))
    rule_ids = [f.rule_id for f in findings]
    severities = [f.severity for f in findings if f.rule_id == "raw-tampered"]
    assert "raw-tampered" in rule_ids
    assert "critical" in severities


def test_recipe_page_missing_flag_emission_rejected(tmp_path):
    """Spec scenario: recipe page missing flag_emission rejected."""
    write_minimal_skill_root(tmp_path)
    recipe = tmp_path / "wiki" / "recipes" / "stego-image-lsb.md"
    recipe.parent.mkdir(parents=True, exist_ok=True)
    recipe.write_text(textwrap.dedent("""\
        ---
        id: stego-image-lsb
        title: PNG LSB Steganography
        type: recipe
        category: forensics
        subdomain: stego
        lab_backend: docker
        last_compiled: 2026-05-03
        sources:
          - wiki/raw/papers/srnet-2019.md
        ---
        Recipe body.
    """), encoding="utf-8")
    findings = wiki.verify(tmp_path / "wiki", profile=wiki.Profile.load(tmp_path))
    missing_field_findings = [f for f in findings if f.rule_id == "layer2-missing-field"]
    flag_emission_missing = [
        f for f in missing_field_findings if "flag_emission" in f.message
    ]
    assert flag_emission_missing, "verify must flag missing flag_emission field"
    assert all(f.severity == "critical" for f in flag_emission_missing)


def test_missing_survey_coverage_emits_advisory(tmp_path):
    """Spec scenario: missing survey coverage emits advisory, not critical."""
    write_minimal_skill_root(tmp_path)
    findings = wiki.verify(
        tmp_path / "wiki",
        profile=wiki.Profile.load(tmp_path),
        check_survey_coverage=True,
    )
    survey_gaps = [f for f in findings if f.rule_id == "survey-coverage-gap"]
    assert survey_gaps, "expected survey-coverage-gap advisories"
    assert all(f.severity == "advisory" for f in survey_gaps)
    assert not any(f.severity == "critical" for f in survey_gaps)


def test_agents_md_missing_section_emits_critical(tmp_path):
    """Spec scenario: AGENTS.md missing one of four mandatory sections."""
    write_minimal_skill_root(tmp_path)
    # Remove the "Cross-model contract" section.
    agents = tmp_path / "AGENTS.md"
    text = agents.read_text(encoding="utf-8")
    text = text.replace("## 4. Cross-model contract\n\nSome content.\n", "")
    agents.write_text(text, encoding="utf-8")
    findings = wiki.verify(
        tmp_path / "wiki",
        profile=wiki.Profile.load(tmp_path),
        cross_model_lint=True,
    )
    missing = [
        f for f in findings
        if f.rule_id == "agents-missing-section"
        and "Cross-model contract" in f.message
    ]
    assert missing
    assert all(f.severity == "critical" for f in missing)


def test_cross_model_lint_catches_embedded_tool_name(tmp_path):
    """Spec scenario: cross-model lint catches embedded tool names."""
    write_minimal_skill_root(tmp_path)
    # Inject a forbidden tool name into SKILL.md.
    skill = tmp_path / "SKILL.md"
    skill.write_text(
        skill.read_text(encoding="utf-8") + "\nUse Read( to load the file.\n",
        encoding="utf-8",
    )
    findings = wiki.verify(
        tmp_path / "wiki",
        profile=wiki.Profile.load(tmp_path),
        cross_model_lint=True,
    )
    tool_findings = [
        f for f in findings if f.rule_id == "cross-model-tool-name"
    ]
    assert tool_findings
    assert all(f.severity == "critical" for f in tool_findings)


# === Other invariants ========================================================


def test_verify_clean_on_minimal_skill_root(tmp_path):
    write_minimal_skill_root(tmp_path)
    findings = wiki.verify(tmp_path / "wiki", profile=wiki.Profile.load(tmp_path))
    critical = [f for f in findings if f.severity == "critical"]
    assert not critical, f"unexpected critical findings: {critical}"


def test_duplicate_id_detected(tmp_path):
    write_minimal_skill_root(tmp_path)
    page1 = tmp_path / "wiki" / "concepts" / "lsb-stego.md"
    page2 = tmp_path / "wiki" / "concepts" / "alt-lsb-stego.md"
    body = textwrap.dedent("""\
        ---
        id: lsb-stego
        title: LSB Steganography
        type: concept
        category: forensics
        subdomain: stego
        last_compiled: 2026-05-03
        sources:
          - wiki/raw/papers/srnet-2019.md
        ---
        body
    """)
    page1.write_text(body, encoding="utf-8")
    page2.write_text(body, encoding="utf-8")
    findings = wiki.verify(tmp_path / "wiki", profile=wiki.Profile.load(tmp_path))
    dup = [f for f in findings if f.rule_id == "layer2-duplicate-id"]
    assert dup
    assert all(f.severity == "critical" for f in dup)


def test_max_age_emits_advisory(tmp_path):
    write_minimal_skill_root(tmp_path)
    page = tmp_path / "wiki" / "concepts" / "old.md"
    page.write_text(textwrap.dedent("""\
        ---
        id: old-page
        title: Old Page
        type: concept
        category: forensics
        subdomain: stego
        last_compiled: 2020-01-01
        sources:
          - wiki/raw/papers/srnet-2019.md
        ---
        body
    """), encoding="utf-8")
    findings = wiki.verify(
        tmp_path / "wiki",
        profile=wiki.Profile.load(tmp_path),
        max_age_days=30,
    )
    stale = [f for f in findings if f.rule_id == "layer2-stale"]
    assert stale
    assert all(f.severity == "advisory" for f in stale)


def test_ingest_produces_parseable_frontmatter():
    body = "Some content body\n"
    wrapped = wiki.ingest(
        body,
        fetch_url="https://example.test/foo",
        fetch_date="2026-05-03",
    )
    parsed = wiki.parse_frontmatter(wrapped)
    assert parsed is not None
    meta, recovered_body = parsed
    assert meta["fetch_url"] == "https://example.test/foo"
    assert meta["fetch_date"] == "2026-05-03"
    assert meta["sha256"] == wiki.sha256_of_body(body)
    assert recovered_body == body


def test_find_by_category(tmp_path):
    write_minimal_skill_root(tmp_path)
    page = tmp_path / "wiki" / "concepts" / "lsb-stego.md"
    page.write_text(textwrap.dedent("""\
        ---
        id: lsb-stego
        title: LSB Steganography
        type: concept
        category: forensics
        subdomain: stego
        last_compiled: 2026-05-03
        sources:
          - wiki/raw/papers/srnet-2019.md
        ---
        body
    """), encoding="utf-8")
    matches = wiki.find(tmp_path / "wiki", category="forensics")
    assert len(matches) == 1
    assert matches[0] == page
    assert wiki.find(tmp_path / "wiki", category="reverse") == []
