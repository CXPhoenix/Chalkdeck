"""Tests for _bcm_common.rules — strict validation rule catalog.

These exercise the catalog mechanics; per-category exhaustive coverage
lives in `test_bluechall_validate.py` / `test_reverse_validate.py` /
`test_blue_team_validate.py` (which drive the catalog through the CLI).
"""

from __future__ import annotations

import sys
from pathlib import Path

import pytest
import yaml

REPO_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(REPO_ROOT / "scripts"))

from _bcm_common import rules as rule_lib  # noqa: E402


def _make_manifest(**overrides):
    base = {
        "slug": "demo-stego",
        "category": "forensics",
        "recipe_id": "stego-image-lsb",
        "flag_emission": "single-static",
        "lab_backend": "docker",
        "concept_refs": ["lsb-stego"],
        "cve_refs": [],
        "stages": {str(i): {"complete": False, "audit_verdict": None,
                            "audit_persona": None, "timestamp": None}
                   for i in range(1, 8)},
        "lab_provenance": [],
    }
    base.update(overrides)
    return base


def _build_slug(tmp_path, *, manifest, layout=None):
    slug = tmp_path / manifest["slug"]
    slug.mkdir()
    (slug / ".bluechall.manifest.yaml").write_text(
        yaml.safe_dump(manifest, default_flow_style=False, sort_keys=False),
        encoding="utf-8",
    )
    if layout:
        for relpath, content in layout.items():
            target = slug / relpath
            target.parent.mkdir(parents=True, exist_ok=True)
            if isinstance(content, (bytes, bytearray)):
                target.write_bytes(content)
            else:
                target.write_text(content, encoding="utf-8")
    return slug


def test_manifest_present_critical_when_missing(tmp_path):
    slug = tmp_path / "demo"
    slug.mkdir()
    findings = rule_lib.rule_manifest_present(slug, {})
    assert any(f.severity == "critical" and f.rule_id == "manifest-missing" for f in findings)


def test_manifest_schema_flags_missing_required_field(tmp_path):
    bad = _make_manifest()
    del bad["recipe_id"]
    slug = _build_slug(tmp_path, manifest=bad)
    findings = rule_lib.rule_manifest_schema(slug, bad)
    assert any(
        f.severity == "critical" and "recipe_id" in f.message and f.rule_id == "manifest-schema"
        for f in findings
    )


def test_manifest_schema_rejects_invalid_category(tmp_path):
    bad = _make_manifest(category="hacking")
    slug = _build_slug(tmp_path, manifest=bad)
    findings = rule_lib.rule_manifest_schema(slug, bad)
    assert any(
        f.severity == "critical" and "category" in f.message and "hacking" in f.message
        for f in findings
    )


def test_manifest_schema_rejects_invalid_flag_emission(tmp_path):
    bad = _make_manifest(flag_emission="single_static")  # underscore not hyphen
    slug = _build_slug(tmp_path, manifest=bad)
    findings = rule_lib.rule_manifest_schema(slug, bad)
    assert any(
        f.severity == "critical" and "flag_emission" in f.message
        for f in findings
    )


def test_solution_dir_required(tmp_path):
    m = _make_manifest()
    slug = _build_slug(tmp_path, manifest=m)
    findings = rule_lib.rule_solution_dir_present(slug, m)
    assert any(f.severity == "critical" and f.rule_id == "solution-dir-missing" for f in findings)


def test_solution_dir_present_passes(tmp_path):
    m = _make_manifest()
    slug = _build_slug(tmp_path, manifest=m, layout={"solution/solve.py": "print('demo')\n"})
    findings = rule_lib.rule_solution_dir_present(slug, m)
    assert all(f.rule_id != "solution-dir-missing" for f in findings)


def test_flag_emission_consistency_single_static_requires_flag_txt(tmp_path):
    m = _make_manifest(flag_emission="single-static")
    slug = _build_slug(tmp_path, manifest=m, layout={"solution/solve.py": "x"})
    findings = rule_lib.rule_flag_emission_consistency(slug, m)
    assert any(f.severity == "critical" and "flag.txt" in f.message for f in findings)


def test_flag_emission_consistency_questions_as_flags_requires_questions_yaml(tmp_path):
    m = _make_manifest(flag_emission="questions-as-flags", category="blue-team")
    slug = _build_slug(tmp_path, manifest=m, layout={"solution/solve.py": "x"})
    findings = rule_lib.rule_flag_emission_consistency(slug, m)
    assert any(f.severity == "critical" and "questions.yaml" in f.message for f in findings)


def test_flag_emission_consistency_multi_stage_pivot_requires_stages_yaml(tmp_path):
    m = _make_manifest(flag_emission="multi-stage-pivot", category="forensics")
    slug = _build_slug(tmp_path, manifest=m, layout={"solution/solve.py": "x"})
    findings = rule_lib.rule_flag_emission_consistency(slug, m)
    assert any(f.severity == "critical" and "stages.yaml" in f.message for f in findings)


def test_flag_emission_consistency_service_derived_requires_service_dir(tmp_path):
    m = _make_manifest(flag_emission="service-derived", category="forensics")
    slug = _build_slug(tmp_path, manifest=m, layout={"solution/solve.py": "x"})
    findings = rule_lib.rule_flag_emission_consistency(slug, m)
    assert any(f.severity == "critical" and "service" in f.message.lower() for f in findings)


def test_no_placeholder_flag_detects_replace_me(tmp_path):
    m = _make_manifest()
    slug = _build_slug(tmp_path, manifest=m, layout={
        "solution/solve.py": "x",
        "solution/flag.txt": "FLAG{REPLACE_ME_BEFORE_SHIPPING}",
    })
    findings = rule_lib.rule_no_placeholder_flag(slug, m)
    assert any(
        f.severity == "critical" and f.rule_id == "placeholder-flag"
        for f in findings
    )


def test_no_placeholder_flag_detects_todo(tmp_path):
    m = _make_manifest()
    slug = _build_slug(tmp_path, manifest=m, layout={
        "solution/solve.py": "x",
        "solution/flag.txt": "FLAG{TODO}",
    })
    findings = rule_lib.rule_no_placeholder_flag(slug, m)
    assert any(f.severity == "critical" and f.rule_id == "placeholder-flag" for f in findings)


def test_no_placeholder_flag_clean_when_real(tmp_path):
    m = _make_manifest()
    slug = _build_slug(tmp_path, manifest=m, layout={
        "solution/solve.py": "x",
        "solution/flag.txt": "FLAG{l5b_st3g0_w1th_perm_key_2024}",
    })
    findings = rule_lib.rule_no_placeholder_flag(slug, m)
    assert all(f.rule_id != "placeholder-flag" for f in findings)


@pytest.mark.parametrize("placeholder", [
    "FLAG{REPLACE_ME}",
    "FLAG{REPLACEME}",
    "FLAG{REPLACE-ME}",
    "FLAG{REPLACE_ME_BEFORE_SHIPPING}",
    "FLAG{CHANGE_ME}",
    "FLAG{CHANGE-ME}",
    "FLAG{CHANGEME}",
    "FLAG{TODO}",
    "FLAG{TBD}",
    "FLAG{XXX}",
    "FLAG{XXXX}",
    "FLAG{INSERT_HERE}",
    "FLAG{INSERT-HERE}",
    "FLAG{PLACEHOLDER}",
    "FLAG{EXAMPLE}",
    "FLAG{TEST}",
    "FLAG{}",
    "flag{todo}",  # case-insensitive
    "Flag{Replace_Me}",
])
def test_placeholder_flag_pattern_catches_known_sentinels(tmp_path, placeholder):
    m = _make_manifest()
    slug = _build_slug(tmp_path, manifest=m, layout={
        "solution/solve.py": "x",
        "solution/flag.txt": placeholder,
    })
    findings = rule_lib.rule_no_placeholder_flag(slug, m)
    assert any(f.rule_id == "placeholder-flag" for f in findings), (
        f"placeholder {placeholder!r} should be caught"
    )


def test_empty_concept_refs_emits_advisory(tmp_path):
    m = _make_manifest(concept_refs=[])
    slug = _build_slug(tmp_path, manifest=m)
    findings = rule_lib.rule_manifest_schema(slug, m)
    assert any(
        f.severity == "advisory" and f.rule_id == "manifest-empty-concept-refs"
        for f in findings
    )


def test_stage_constants_exposed_for_cli_imports():
    """STAGE_* constants must live in rules.py so analyze and validate
    CLIs can import them rather than redefining magic numbers."""
    assert rule_lib.STAGE_IMPLEMENT == 4
    assert rule_lib.STAGE_ANALYZE == 5
    assert rule_lib.STAGE_PUBLISH == 7


def test_run_all_isolates_failures(monkeypatch, tmp_path):
    m = _make_manifest()
    slug = _build_slug(tmp_path, manifest=m, layout={"solution/solve.py": "x", "solution/flag.txt": "FLAG{a}"})

    def bomb(challenge, mfst):
        raise RuntimeError("boom")
    monkeypatch.setattr(rule_lib, "rule_manifest_schema", bomb)
    findings = rule_lib.run_all(slug, m)
    assert any(f.rule_id == "internal-error" and "schema" in f.message.lower() for f in findings)


def test_catalog_must_have_at_least_one_rule():
    """Lazy-Developer trap: an empty catalog would silently 'validate' anything."""
    assert len(rule_lib.CATALOG) >= 5
