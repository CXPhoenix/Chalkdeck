"""End-to-end tests for bluechall_validate.py CLI (forensics-flavoured)."""

from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

import pytest
import yaml

REPO = Path(__file__).resolve().parent.parent
SCRIPTS = REPO / "scripts"
sys.path.insert(0, str(SCRIPTS))


def _run_cli(*args, cwd=None):
    cmd = [sys.executable, str(SCRIPTS / "bluechall_validate.py"), *args]
    return subprocess.run(cmd, capture_output=True, text=True, cwd=cwd)


def _make_forensics_manifest(*, stage5_verdict=None):
    stages = {str(i): {"complete": True, "audit_verdict": "pass",
                       "audit_persona": None, "timestamp": "2026-05-04T00:00:00+00:00"}
              for i in range(1, 8)}
    if stage5_verdict is not None:
        stages["5"]["audit_verdict"] = stage5_verdict
        stages["5"]["audit_persona"] = "tool-grep-solver"
    return {
        "slug": "demo-stego",
        "category": "forensics",
        "recipe_id": "stego-image-lsb",
        "flag_emission": "single-static",
        "lab_backend": "docker",
        "concept_refs": ["lsb-stego"],
        "cve_refs": [],
        "stages": stages,
        "lab_provenance": [],
        "canonical_flag": "FLAG{l5b_st3g0_real_2026}",
    }


def _build_demo(tmp_path, *, manifest, layout=None):
    slug = tmp_path / manifest["slug"]
    slug.mkdir()
    (slug / ".bluechall.manifest.yaml").write_text(
        yaml.safe_dump(manifest, default_flow_style=False, sort_keys=False),
        encoding="utf-8",
    )
    if layout:
        for relpath, content in layout.items():
            target = slug / relpath
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(content, encoding="utf-8")
    return slug


def test_help_exits_zero():
    r = _run_cli("--help")
    assert r.returncode == 0
    assert "bluechall_validate" in r.stdout


def test_missing_manifest_exits_2(tmp_path):
    slug = tmp_path / "empty"
    slug.mkdir()
    r = _run_cli(str(slug))
    assert r.returncode == 2
    assert "precondition" in r.stderr


def test_failed_stage5_audit_blocks_validate(tmp_path):
    m = _make_forensics_manifest(stage5_verdict="fail")
    slug = _build_demo(tmp_path, manifest=m, layout={"solution/solve.py": "x", "solution/flag.txt": "FLAG{x}"})
    r = _run_cli(str(slug))
    assert r.returncode == 2
    assert "tool-grep-solver" in r.stderr
    assert "Analyze" in r.stderr or "Stage 5" in r.stderr


def test_passing_forensics_challenge_exits_zero(tmp_path):
    m = _make_forensics_manifest()
    slug = _build_demo(tmp_path, manifest=m, layout={
        "solution/solve.py": "from PIL import Image\n",
        "solution/flag.txt": "FLAG{l5b_st3g0_real_2026}",
        "recipe.yaml": "---\nid: stego-image-lsb\nflag_emission: single-static\n---\n",
    })
    r = _run_cli(str(slug), "--allow-stage-skip")
    assert r.returncode == 0, r.stdout + r.stderr


def test_placeholder_flag_critical_then_soft_passes(tmp_path):
    m = _make_forensics_manifest()
    slug = _build_demo(tmp_path, manifest=m, layout={
        "solution/solve.py": "x",
        "solution/flag.txt": "FLAG{REPLACE_ME_BEFORE_SHIPPING}",
        "recipe.yaml": "---\nid: stego-image-lsb\nflag_emission: single-static\n---\n",
    })
    r_strict = _run_cli(str(slug), "--allow-stage-skip")
    assert r_strict.returncode == 1
    r_soft = _run_cli(str(slug), "--allow-stage-skip", "--soft", "--json")
    assert r_soft.returncode == 0
    parsed = json.loads(r_soft.stdout)
    placeholder = [f for f in parsed if f["rule_id"] == "placeholder-flag"]
    assert placeholder
    assert placeholder[0]["effective_severity"] == "warning"
    assert placeholder[0]["original_severity"] == "critical"


def test_json_format_is_valid(tmp_path):
    m = _make_forensics_manifest()
    slug = _build_demo(tmp_path, manifest=m, layout={
        "solution/solve.py": "x", "solution/flag.txt": "FLAG{ok}", "recipe.yaml": "---\nid: stego-image-lsb\nflag_emission: single-static\n---\n"})
    r = _run_cli(str(slug), "--allow-stage-skip", "--json")
    assert r.returncode == 0
    parsed = json.loads(r.stdout)
    assert isinstance(parsed, list)


def test_sarif_format_is_valid_2_1_0(tmp_path):
    m = _make_forensics_manifest()
    slug = _build_demo(tmp_path, manifest=m, layout={
        "solution/solve.py": "x", "solution/flag.txt": "FLAG{ok}", "recipe.yaml": "---\nid: stego-image-lsb\nflag_emission: single-static\n---\n"})
    r = _run_cli(str(slug), "--allow-stage-skip", "--sarif")
    assert r.returncode == 0
    sarif = json.loads(r.stdout)
    assert sarif["version"] == "2.1.0"
    assert sarif["runs"][0]["tool"]["driver"]["name"] == "bluechall_validate"


def test_missing_solution_dir_critical(tmp_path):
    m = _make_forensics_manifest()
    slug = _build_demo(tmp_path, manifest=m)
    r = _run_cli(str(slug), "--allow-stage-skip")
    assert r.returncode == 1
    assert "solution" in r.stdout.lower()


def test_soft_flag_emits_loud_stderr_warning(tmp_path):
    """--soft must announce itself to stderr so CI logs show the relaxation."""
    m = _make_forensics_manifest()
    slug = _build_demo(tmp_path, manifest=m, layout={
        "solution/solve.py": "x", "solution/flag.txt": "FLAG{ok}", "recipe.yaml": "---\nid: stego-image-lsb\nflag_emission: single-static\n---\n",
    })
    r = _run_cli(str(slug), "--allow-stage-skip", "--soft")
    assert r.returncode == 0
    assert "--soft" in r.stderr
    assert "DO NOT ship" in r.stderr or "DO NOT" in r.stderr


def test_allow_stage_skip_emits_loud_stderr_warning(tmp_path):
    m = _make_forensics_manifest(stage5_verdict="fail")  # would normally block
    slug = _build_demo(tmp_path, manifest=m, layout={
        "solution/solve.py": "x", "solution/flag.txt": "FLAG{ok}", "recipe.yaml": "---\nid: stego-image-lsb\nflag_emission: single-static\n---\n",
    })
    r = _run_cli(str(slug), "--allow-stage-skip")
    assert "DANGER" in r.stderr
    assert "--allow-stage-skip" in r.stderr
