"""Tests for _bcm_common.binary_fuzz — anti-RE static checks."""

from __future__ import annotations

import struct
import sys
from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(REPO_ROOT / "scripts"))

from _bcm_common import binary_fuzz  # noqa: E402


def _make_slug(tmp_path, *, layout: dict[str, bytes]) -> Path:
    slug = tmp_path / "demo"
    slug.mkdir()
    for relpath, content in layout.items():
        target = slug / relpath
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(content)
    return slug


# Minimal valid ELF64 header (e_ident + first fixed fields).
# ABI Linux (0x03), x86_64 (0x3e), exec (0x02). e_shnum / e_shoff arbitrary.
def _elf64_header(*, has_debug: bool = False) -> bytes:
    e_ident = b"\x7fELF\x02\x01\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00"
    # We don't need real sections; binary_fuzz._is_elf only needs the magic.
    return e_ident


def test_strip_check_flags_unstripped_elf(monkeypatch, tmp_path):
    elf = _elf64_header()
    slug = _make_slug(tmp_path, layout={"publish/keygen": elf})
    # Pretend pyelftools is available; stub the section enumerator so we
    # don't depend on real ELF or the optional package.
    monkeypatch.setattr(binary_fuzz, "_HAS_PYELFTOOLS", True)
    monkeypatch.setattr(binary_fuzz, "_elf_section_names", lambda p: [".text", ".symtab", ".debug_info"])
    findings = binary_fuzz.rule_strip_check(slug)
    assert any(f.severity == "warning" and f.rule_id == "unstripped-binary" for f in findings)


def test_strip_check_clean_when_stripped(monkeypatch, tmp_path):
    elf = _elf64_header()
    slug = _make_slug(tmp_path, layout={"publish/keygen": elf})
    monkeypatch.setattr(binary_fuzz, "_HAS_PYELFTOOLS", True)
    monkeypatch.setattr(binary_fuzz, "_elf_section_names", lambda p: [".text", ".rodata"])
    findings = binary_fuzz.rule_strip_check(slug)
    assert all(f.severity != "warning" for f in findings)


def test_debug_info_check_flags_dwarf_sections(monkeypatch, tmp_path):
    elf = _elf64_header()
    slug = _make_slug(tmp_path, layout={"publish/keygen": elf})
    monkeypatch.setattr(binary_fuzz, "_HAS_PYELFTOOLS", True)
    monkeypatch.setattr(
        binary_fuzz, "_elf_section_names",
        lambda p: [".text", ".debug_info", ".debug_line", ".debug_str"],
    )
    findings = binary_fuzz.rule_debug_info(slug)
    crits = [f for f in findings if f.rule_id == "dwarf-debug-info-present"]
    assert len(crits) == 1
    assert crits[0].severity == "warning"


def test_panic_string_leak_detected(tmp_path):
    payload = b"\x7fELF\x02\x01\x01\x00..." + b"panicked at 'unwrap on None', src/main.rs:42:5\n"
    slug = _make_slug(tmp_path, layout={"publish/rusty": payload})
    findings = binary_fuzz.rule_panic_string_leak(slug)
    assert any(f.rule_id == "rust-panic-leak" and f.severity == "warning" for f in findings)


def test_panic_string_leak_clean(tmp_path):
    slug = _make_slug(tmp_path, layout={"publish/rusty": b"\x7fELFno panic strings here"})
    findings = binary_fuzz.rule_panic_string_leak(slug)
    assert all(f.rule_id != "rust-panic-leak" for f in findings)


def test_pyelftools_missing_emits_advisory(monkeypatch, tmp_path):
    elf = _elf64_header()
    slug = _make_slug(tmp_path, layout={"publish/keygen": elf})
    monkeypatch.setattr(binary_fuzz, "_HAS_PYELFTOOLS", False)
    findings = binary_fuzz.rule_strip_check(slug)
    assert any(f.severity == "advisory" and "pyelftools" in f.rule_id for f in findings)


def test_run_aggregates_and_isolates_failures(monkeypatch, tmp_path):
    slug = _make_slug(tmp_path, layout={"publish/keygen": _elf64_header()})

    def bomb(slug_dir):
        raise RuntimeError("simulated rule crash")

    monkeypatch.setattr(binary_fuzz, "rule_strip_check", bomb)
    findings = binary_fuzz.run(slug)
    assert any(f.rule_id == "internal-error" and "strip" in f.message.lower() for f in findings)
