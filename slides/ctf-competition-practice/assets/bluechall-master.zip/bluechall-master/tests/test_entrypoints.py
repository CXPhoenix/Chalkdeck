"""Smoke test: every entry point under `scripts/` exposes `--help` and exits
with status 0 on `--help`. Verifies the contract from the
`bluechall-tooling` capability.

Three entry points (analyze, validate, publish) are added in Section 7 / 10
of the change. Until they exist, this test marks them xfail. When they ship,
remove the xfail decorator.
"""

from __future__ import annotations

import subprocess
import sys
from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).resolve().parent.parent
SCRIPTS = REPO_ROOT / "scripts"

ENTRY_POINTS = [
    "bluechall_init.py",
    "bluechall_bootstrap.py",
    "bluechall_manifest.py",
    "bluechall_wiki.py",
    "bluechall_docker.py",
    "bluechall_orbstack.py",
    "bluechall_qemu.py",
    "bluechall_flagserver.py",
]

DEFERRED_ENTRY_POINTS = [
    "bluechall_analyze.py",
    "bluechall_validate.py",
    "bluechall_publish.py",
]


@pytest.mark.parametrize("script", ENTRY_POINTS)
def test_entry_point_help_exits_zero(script):
    path = SCRIPTS / script
    assert path.exists(), f"entry point {script} not found"
    proc = subprocess.run(
        [sys.executable, str(path), "--help"],
        capture_output=True, text=True, timeout=15,
    )
    assert proc.returncode == 0, f"{script} --help exit {proc.returncode}: {proc.stderr}"
    assert "usage" in proc.stdout.lower()


@pytest.mark.parametrize("script", DEFERRED_ENTRY_POINTS)
def test_deferred_entry_points_will_be_added(script):
    """Marker test: xfail until Section 7/10 lands the analyze, validate,
    and publish CLIs. When they ship, remove the xfail.
    """
    path = SCRIPTS / script
    if not path.exists():
        pytest.xfail(f"{script} not yet added (Section 7/10)")
    proc = subprocess.run(
        [sys.executable, str(path), "--help"],
        capture_output=True, text=True, timeout=15,
    )
    assert proc.returncode == 0
