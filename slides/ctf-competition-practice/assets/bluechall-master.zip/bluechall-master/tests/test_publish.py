"""End-to-end tests for bluechall_publish.py — 4 adapters + flag redaction."""

from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

import pytest
import yaml

REPO = Path(__file__).resolve().parent.parent
SCRIPTS = REPO / "scripts"


def _run_publish(*args, cwd=None):
    cmd = [sys.executable, str(SCRIPTS / "bluechall_publish.py"), *args]
    return subprocess.run(cmd, capture_output=True, text=True, cwd=cwd)


def _make_manifest(*, flag_emission="single-static", canonical_flag="FLAG{l5b_st3g0_2026_real}"):
    return {
        "slug": "demo-stego",
        "category": "forensics",
        "recipe_id": "stego-image-lsb",
        "flag_emission": flag_emission,
        "lab_backend": "docker",
        "concept_refs": ["lsb-stego"],
        "cve_refs": [],
        "stages": {str(i): {"complete": True, "audit_verdict": "pass",
                            "audit_persona": None, "timestamp": "2026-05-04T00:00:00+00:00"}
                   for i in range(1, 8)},
        "lab_provenance": [],
        "canonical_flag": canonical_flag,
        "value": 200,
        "author": "bluechall-test",
    }


def _build(tmp_path, *, manifest, layout=None):
    slug = tmp_path / manifest["slug"]
    slug.mkdir()
    (slug / ".bluechall.manifest.yaml").write_text(
        yaml.safe_dump(manifest, default_flow_style=False, sort_keys=False),
        encoding="utf-8",
    )
    if layout:
        for relpath, content in layout.items():
            target = slug / relpath
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(content, encoding="utf-8")
    return slug


def test_help_exits_zero():
    r = _run_publish("--help")
    assert r.returncode == 0


def test_redact_flag_in_text_empty_canonical_raises():
    """Round-2 audit (R1-Scoundrel-F3): empty canonical MUST raise so a
    forgetful caller cannot silently ship unredacted output.
    """
    import sys
    sys.path.insert(0, str(REPO / "scripts"))
    from _bcm_common import publish
    with pytest.raises(ValueError, match="canonical must be a non-empty"):
        publish.redact_flag_in_text("hello FLAG{x}", canonical="")


def test_redact_flag_in_text_canonical_is_keyword_only():
    """`canonical` must be a keyword-only parameter so two str positional
    arguments cannot be silently swapped (audit finding R1-Scoundrel-F11).
    """
    import sys
    sys.path.insert(0, str(REPO / "scripts"))
    from _bcm_common import publish
    with pytest.raises(TypeError):
        publish.redact_flag_in_text("hello FLAG{x} world", "FLAG{x}")
    text, hits = publish.redact_flag_in_text("hello FLAG{x} world", canonical="FLAG{x}")
    assert "FLAG{REDACTED}" in text
    assert "literal" in hits


def test_redact_flag_in_payload_canonical_is_keyword_only():
    import sys
    sys.path.insert(0, str(REPO / "scripts"))
    from _bcm_common import publish
    with pytest.raises(TypeError):
        publish.redact_flag_in_payload({"description": "FLAG{x}"}, "FLAG{x}")
    out, hits = publish.redact_flag_in_payload(
        {"description": "FLAG{x}"}, canonical="FLAG{x}",
    )
    assert "FLAG{REDACTED}" in out["description"]
    assert "literal" in hits


def test_publish_emits_all_four_adapters_for_questions_as_flags(tmp_path):
    m = _make_manifest(flag_emission="questions-as-flags",
                       canonical_flag="FLAG{ir_master_2026_h7k}")
    m["category"] = "blue-team"
    m["recipe_id"] = "bt-malware-pe-ir"
    questions = {
        "questions": [
            {"id": "q1", "question": "Malicious PID?", "answer": "FLAG{1234_pid_h7k}",
             "attack_technique": "T1055", "points": 50, "nist_phase": "examination"},
            {"id": "q2", "question": "C2 IP?", "answer": "FLAG{10_0_0_99_c2_h7k}",
             "attack_technique": "T1071.001", "points": 75, "nist_phase": "analysis"},
            {"id": "q3", "question": "Exfil bytes?", "answer": "FLAG{1024_bytes_exfil_h7k}",
             "attack_technique": "T1041", "points": 50, "nist_phase": "analysis"},
        ],
    }
    slug = _build(tmp_path, manifest=m, layout={
        "solution/solve.py": "x",
        "solution/questions.yaml": yaml.safe_dump(questions, sort_keys=False),
        "recipe.yaml": "id: bt-malware-pe-ir\n",
        "publish/dump.bin": "non-flag content",
        "README.player.md": "Investigate the malicious binary.",
    })
    r = _run_publish(str(slug))
    assert r.returncode == 0, r.stdout + r.stderr
    adapters = slug / "adapters"
    assert (adapters / "ctfcli.yml").exists()
    assert (adapters / "rctf.yml").exists()
    assert (adapters / "picoctf.yml").exists()
    assert (adapters / "sherlocks.yml").exists()


def test_questions_as_flags_flattened_to_n_ctfd_entries(tmp_path):
    """5 questions → 5 CTFd ctfcli challenge entries each with one flag."""
    m = _make_manifest(flag_emission="questions-as-flags", canonical_flag="FLAG{m}")
    m["category"] = "blue-team"
    m["recipe_id"] = "bt-malware-pe-ir"
    qs = [
        {"id": f"q{i}", "question": f"Q {i}", "answer": f"FLAG{{a{i}}}",
         "attack_technique": "T1055", "points": 50, "nist_phase": "analysis"}
        for i in range(1, 6)
    ]
    slug = _build(tmp_path, manifest=m, layout={
        "solution/solve.py": "x",
        "solution/questions.yaml": yaml.safe_dump({"questions": qs}, sort_keys=False),
        "recipe.yaml": "x",
    })
    r = _run_publish(str(slug))
    assert r.returncode == 0, r.stdout + r.stderr
    ctfcli = yaml.safe_load((slug / "adapters" / "ctfcli.yml").read_text())
    # CTFd canonical: a list of 5 entries when questions-as-flags.
    entries = ctfcli if isinstance(ctfcli, list) else ctfcli.get("challenges") or []
    assert len(entries) == 5
    for e in entries:
        assert len(e["flags"]) == 1


def test_rctf_drops_hints_with_stderr_advisory(tmp_path):
    m = _make_manifest()
    m["hints"] = ["Look at the LSB", "Try the alpha channel"]
    m["requirements"] = ["challenge-warmup"]
    slug = _build(tmp_path, manifest=m, layout={
        "solution/solve.py": "x", "solution/flag.txt": m["canonical_flag"],
        "recipe.yaml": "x",
    })
    r = _run_publish(str(slug))
    assert r.returncode == 0
    rctf = yaml.safe_load((slug / "adapters" / "rctf.yml").read_text())
    assert "hints" not in rctf
    assert "requirements" not in rctf
    assert "hints" in r.stderr.lower()


def test_picoctf_drops_dynamic_decay(tmp_path):
    m = _make_manifest()
    m["type"] = "dynamic"
    m["value_decay"] = {"initial": 500, "decay": 50, "minimum": 100}
    slug = _build(tmp_path, manifest=m, layout={
        "solution/solve.py": "x", "solution/flag.txt": m["canonical_flag"],
        "recipe.yaml": "x",
    })
    r = _run_publish(str(slug))
    assert r.returncode == 0
    pico = yaml.safe_load((slug / "adapters" / "picoctf.yml").read_text())
    assert pico.get("type") != "dynamic"
    assert "value_decay" not in pico
    assert isinstance(pico.get("value"), int)


def test_picoctf_remaps_attempts(tmp_path):
    m = _make_manifest()
    m["attempts"] = 3
    slug = _build(tmp_path, manifest=m, layout={
        "solution/solve.py": "x", "solution/flag.txt": m["canonical_flag"],
        "recipe.yaml": "x",
    })
    r = _run_publish(str(slug))
    assert r.returncode == 0
    pico = yaml.safe_load((slug / "adapters" / "picoctf.yml").read_text())
    assert "attempts" not in pico
    assert pico.get("instance", {}).get("max_attempts") == 3


def test_sherlocks_not_emitted_for_single_static(tmp_path):
    m = _make_manifest(flag_emission="single-static")
    slug = _build(tmp_path, manifest=m, layout={
        "solution/solve.py": "x", "solution/flag.txt": m["canonical_flag"],
        "recipe.yaml": "x",
    })
    r = _run_publish(str(slug))
    assert r.returncode == 0
    assert not (slug / "adapters" / "sherlocks.yml").exists()
    assert "sherlocks" in r.stderr.lower()
    assert "single-static" in r.stderr.lower() or "questions-as-flags" in r.stderr.lower()


def test_sherlocks_schema_includes_required_fields(tmp_path):
    m = _make_manifest(flag_emission="questions-as-flags")
    m["category"] = "blue-team"
    qs = [{"id": "q1", "question": "Q1?", "answer": "FLAG{a1}",
           "attack_technique": "T1055", "points": 50, "nist_phase": "analysis"}]
    slug = _build(tmp_path, manifest=m, layout={
        "solution/solve.py": "x",
        "solution/questions.yaml": yaml.safe_dump({"questions": qs}, sort_keys=False),
        "recipe.yaml": "x",
        "publish/scenario.md": "Investigate the breach.",
    })
    r = _run_publish(str(slug))
    assert r.returncode == 0
    sh = yaml.safe_load((slug / "adapters" / "sherlocks.yml").read_text())
    assert sh["category"] == "blue-team"
    assert "scenario" in sh
    assert "objectives" in sh
    obj = sh["objectives"][0]
    assert obj["question"] == "Q1?"
    assert obj["attack_technique"] == "T1055"
    assert obj["nist_phase"] == "analysis"


def test_flag_leak_in_description_redacted_with_critical(tmp_path):
    """If the canonical flag accidentally appears in a non-flag field, redact
    it AND emit critical to stderr AND exit 1.
    """
    m = _make_manifest(canonical_flag="FLAG{very_secret_token_2026}")
    m["description"] = (
        "This challenge tests stego. The answer should be FLAG{very_secret_token_2026}."
    )
    slug = _build(tmp_path, manifest=m, layout={
        "solution/solve.py": "x", "solution/flag.txt": m["canonical_flag"],
        "recipe.yaml": "x",
    })
    r = _run_publish(str(slug))
    assert r.returncode == 1
    assert "REDACTED" in r.stderr or "leak" in r.stderr.lower()
    ctfcli = yaml.safe_load((slug / "adapters" / "ctfcli.yml").read_text())
    desc = ctfcli["description"] if isinstance(ctfcli, dict) else ctfcli[0]["description"]
    assert "very_secret_token_2026" not in desc
    assert "FLAG{REDACTED}" in desc


def test_flag_leak_base64_encoded_redacted(tmp_path):
    """A scoundrel-grade leak via base64 of the flag must also redact."""
    import base64
    flag = "FLAG{base64_smuggle_2026}"
    m = _make_manifest(canonical_flag=flag)
    smuggled = base64.b64encode(flag.encode()).decode().rstrip("=")
    m["description"] = f"Hint: decode this base64 string: {smuggled}"
    slug = _build(tmp_path, manifest=m, layout={
        "solution/solve.py": "x", "solution/flag.txt": flag,
        "recipe.yaml": "x",
    })
    r = _run_publish(str(slug))
    assert r.returncode == 1, r.stderr
    ctfcli = yaml.safe_load((slug / "adapters" / "ctfcli.yml").read_text())
    desc = ctfcli["description"] if isinstance(ctfcli, dict) else ctfcli[0]["description"]
    assert smuggled not in desc


def test_placeholder_flag_blocks_publish(tmp_path):
    m = _make_manifest(canonical_flag="FLAG{REPLACE_ME_BEFORE_SHIPPING}")
    slug = _build(tmp_path, manifest=m, layout={
        "solution/solve.py": "x", "solution/flag.txt": m["canonical_flag"],
        "recipe.yaml": "x",
    })
    r = _run_publish(str(slug))
    assert r.returncode == 1
    assert "placeholder" in r.stderr.lower() or "REPLACE_ME" in r.stderr


def test_missing_canonical_flag_blocks_publish(tmp_path):
    m = _make_manifest()
    del m["canonical_flag"]
    slug = _build(tmp_path, manifest=m, layout={
        "solution/solve.py": "x", "solution/flag.txt": "FLAG{x}",
        "recipe.yaml": "x",
    })
    r = _run_publish(str(slug))
    assert r.returncode == 1
    assert "canonical_flag" in r.stderr


@pytest.mark.parametrize("demo_flag", [
    "FLAG{l5b_st3g0_demo_2026}",
    "FLAG{ir_demo_master}",
    "FLAG{my_test_flag}",
    "FLAG{my_example_flag}",
    "FLAG{TODO}",
    "FLAG{REPLACE_ME}",
])
def test_demo_or_placeholder_flag_blocks_publish(tmp_path, demo_flag):
    """Lazy-author trap: copying a template and never editing flag.txt
    must be caught by both validate and publish (single source of truth)."""
    m = _make_manifest(canonical_flag=demo_flag)
    slug = _build(tmp_path, manifest=m, layout={
        "solution/solve.py": "x", "solution/flag.txt": demo_flag,
        "recipe.yaml": "x",
    })
    r = _run_publish(str(slug))
    assert r.returncode == 1
    assert "placeholder" in r.stderr.lower() or "demo" in r.stderr.lower()


def test_artifact_path_traversal_rejected(tmp_path):
    """Scoundrel mitigation: a manifest with `..` in artifacts cannot
    smuggle an out-of-tree path into the Sherlocks adapter."""
    m = _make_manifest(flag_emission="questions-as-flags")
    m["category"] = "blue-team"
    m["artifacts"] = ["../../etc/passwd"]
    qs = [{"id": "q1", "question": "Q?", "answer": "FLAG{a1_h7k_real_2026}",
           "attack_technique": "T1055", "points": 50, "nist_phase": "analysis"}]
    slug = _build(tmp_path, manifest=m, layout={
        "solution/solve.py": "x",
        "solution/questions.yaml": yaml.safe_dump({"questions": qs}, sort_keys=False),
        "recipe.yaml": "x",
    })
    r = _run_publish(str(slug))
    assert r.returncode == 1
    assert "artifact" in r.stderr.lower()
    assert ".." in r.stderr or "traversal" in r.stderr.lower()


def test_artifact_absolute_path_rejected(tmp_path):
    m = _make_manifest(flag_emission="questions-as-flags")
    m["category"] = "blue-team"
    m["artifacts"] = ["/etc/shadow"]
    qs = [{"id": "q1", "question": "Q?", "answer": "FLAG{a1_h7k_real_2026}",
           "attack_technique": "T1055", "points": 50, "nist_phase": "analysis"}]
    slug = _build(tmp_path, manifest=m, layout={
        "solution/solve.py": "x",
        "solution/questions.yaml": yaml.safe_dump({"questions": qs}, sort_keys=False),
        "recipe.yaml": "x",
    })
    r = _run_publish(str(slug))
    assert r.returncode == 1
    assert "absolute" in r.stderr.lower()


def test_question_missing_attack_technique_rejected(tmp_path):
    m = _make_manifest(flag_emission="questions-as-flags")
    m["category"] = "blue-team"
    qs = [{"id": "q1", "question": "Q?", "answer": "FLAG{a1_h7k_real_2026}",
           "points": 50, "nist_phase": "analysis"}]  # no attack_technique
    slug = _build(tmp_path, manifest=m, layout={
        "solution/solve.py": "x",
        "solution/questions.yaml": yaml.safe_dump({"questions": qs}, sort_keys=False),
        "recipe.yaml": "x",
    })
    r = _run_publish(str(slug))
    assert r.returncode == 1
    assert "attack_technique" in r.stderr


def test_question_invalid_nist_phase_rejected(tmp_path):
    m = _make_manifest(flag_emission="questions-as-flags")
    m["category"] = "blue-team"
    qs = [{"id": "q1", "question": "Q?", "answer": "FLAG{a1_h7k_real_2026}",
           "attack_technique": "T1055", "points": 50, "nist_phase": "triage"}]  # invalid
    slug = _build(tmp_path, manifest=m, layout={
        "solution/solve.py": "x",
        "solution/questions.yaml": yaml.safe_dump({"questions": qs}, sort_keys=False),
        "recipe.yaml": "x",
    })
    r = _run_publish(str(slug))
    assert r.returncode == 1
    assert "nist_phase" in r.stderr
    assert "triage" in r.stderr


def test_invalid_attempts_returns_user_error_not_internal(tmp_path):
    """Confused-Dev mitigation: malformed `attempts` (e.g., a string that
    isn't a number) must surface as user error (1), not internal (3)."""
    m = _make_manifest()
    m["attempts"] = "three"  # not int-coercible
    slug = _build(tmp_path, manifest=m, layout={
        "solution/solve.py": "x", "solution/flag.txt": m["canonical_flag"],
        "recipe.yaml": "x",
    })
    r = _run_publish(str(slug))
    assert r.returncode == 1, r.stderr
    assert "attempts" in r.stderr.lower() or "manifest field" in r.stderr.lower()
