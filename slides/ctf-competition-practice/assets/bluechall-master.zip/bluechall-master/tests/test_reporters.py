"""Tests for _bcm_common.reporters — Finding dataclass + JSON/SARIF/pretty."""

from __future__ import annotations

import json
import sys
from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(REPO_ROOT / "scripts"))

from _bcm_common.reporters import (  # noqa: E402
    Finding,
    SARIF_LEVEL_MAP,
    VALID_ENGINES,
    VALID_SEVERITIES,
    downgrade_for_soft,
    to_json,
    to_pretty,
    to_sarif,
)


def test_sarif_level_map_covers_every_valid_severity():
    """Every VALID_SEVERITY MUST have a SARIF level mapping so `to_sarif`
    never silently falls back to the `none` default.
    """
    assert set(SARIF_LEVEL_MAP) == set(VALID_SEVERITIES), (
        f"SARIF_LEVEL_MAP keys {sorted(SARIF_LEVEL_MAP)} != "
        f"VALID_SEVERITIES {sorted(VALID_SEVERITIES)}"
    )


def test_valid_engines_includes_flag_emission_and_wiki():
    """flag_emission and wiki engines were unified into reporters.Finding;
    both engine names MUST be in VALID_ENGINES.
    """
    assert "flag-emission" in VALID_ENGINES
    assert "wiki" in VALID_ENGINES


def _make(**kw) -> Finding:
    base = dict(
        severity="critical",
        engine="artifact-fuzz",
        rule_id="strings-one-shot",
        path="demo/artifact.bin",
        message="binary contains the canonical flag in plain ASCII",
    )
    base.update(kw)
    return Finding(**base)


def test_finding_rejects_invalid_severity():
    with pytest.raises(ValueError, match="severity must be one of"):
        Finding(
            severity="error",  # webchall scheme; bluechall must reject
            engine="artifact-fuzz",
            rule_id="x",
            path="y",
            message="z",
        )


def test_finding_rejects_invalid_engine():
    with pytest.raises(ValueError, match="engine must be one of"):
        Finding(
            severity="warning",
            engine="artifact_fuzz",  # underscore — typo a Confused Dev would make
            rule_id="x",
            path="y",
            message="z",
        )


def test_finding_accepts_all_valid_severities():
    for s in VALID_SEVERITIES:
        _make(severity=s)


def test_to_json_roundtrip_critical():
    f = _make()
    out = to_json([f])
    parsed = json.loads(out)
    assert parsed[0]["severity"] == "critical"
    assert parsed[0]["rule_id"] == "strings-one-shot"
    assert parsed[0]["engine"] == "artifact-fuzz"


def test_to_json_soft_mode_records_original_severity():
    f = _make()
    downgrade_for_soft([f])
    out = to_json([f], soft_mode=True)
    parsed = json.loads(out)[0]
    # In soft mode, severity is downgraded but original is preserved.
    assert parsed["effective_severity"] == "warning"
    assert parsed["original_severity"] == "critical"


def test_downgrade_idempotent():
    f = _make()
    downgrade_for_soft([f])
    downgrade_for_soft([f])  # second call must not corrupt original
    assert f.severity == "warning"
    assert f.extra["original_severity"] == "critical"


def test_to_sarif_emits_2_1_0_with_correct_level_mapping():
    findings = [
        _make(severity="critical", rule_id="r1"),
        _make(severity="warning", rule_id="r2"),
        _make(severity="advisory", rule_id="r3"),
        _make(severity="info", rule_id="r4"),
    ]
    out = to_sarif(findings, tool_name="bluechall_validate")
    sarif = json.loads(out)
    assert sarif["version"] == "2.1.0"
    assert sarif["runs"][0]["tool"]["driver"]["name"] == "bluechall_validate"
    levels = [r["level"] for r in sarif["runs"][0]["results"]]
    assert levels == ["error", "warning", "note", "note"]


def test_to_sarif_includes_line_when_present():
    f = _make(line=42)
    sarif = json.loads(to_sarif([f], tool_name="x"))
    region = sarif["runs"][0]["results"][0]["locations"][0]["physicalLocation"]["region"]
    assert region["startLine"] == 42


def test_to_pretty_no_findings_message():
    assert to_pretty([]) == "no findings.\n"


def test_to_pretty_renders_severity_glyph():
    f = _make()
    out = to_pretty([f])
    assert "✗" in out
    assert "critical" in out
    assert "strings-one-shot" in out
