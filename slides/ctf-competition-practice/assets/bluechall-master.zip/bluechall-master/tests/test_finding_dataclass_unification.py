"""Assert that `_bcm_common/` exports exactly one `Finding` dataclass.

Background: prior to this change, `flag_emission.py` and `wiki.py` shipped
their own `@dataclass class Finding` with `location` (Path | str) where
`reporters.Finding` uses `path` (str). The schema mismatch makes it
impossible to feed `flag_emission.validate_*` Findings through
`reporters.to_sarif`/`to_json` without an adapter — and adapters are easy
to forget. The unification keeps a single canonical schema.
"""

from __future__ import annotations

import ast
from pathlib import Path

import pytest


SCRIPTS = Path(__file__).resolve().parent.parent / "scripts"
COMMON = SCRIPTS / "_bcm_common"


def _files_with_finding_dataclass() -> list[Path]:
    """Walk `_bcm_common/` AST-side; return files defining `class Finding`
    decorated by `@dataclass`.
    """
    hits: list[Path] = []
    for py in COMMON.rglob("*.py"):
        try:
            tree = ast.parse(py.read_text(encoding="utf-8"))
        except SyntaxError:
            continue
        for node in ast.walk(tree):
            if isinstance(node, ast.ClassDef) and node.name == "Finding":
                # @dataclass decorator may be applied as Name or Call
                has_dataclass = any(
                    (isinstance(d, ast.Name) and d.id == "dataclass")
                    or (isinstance(d, ast.Call) and isinstance(d.func, ast.Name)
                        and d.func.id == "dataclass")
                    for d in node.decorator_list
                )
                if has_dataclass:
                    hits.append(py)
                    break
    return hits


def test_finding_is_defined_exactly_once_under_bcm_common():
    hits = _files_with_finding_dataclass()
    assert len(hits) == 1, (
        f"expected exactly one `@dataclass class Finding` under {COMMON}; "
        f"found in {[str(h.relative_to(COMMON)) for h in hits]}"
    )
    # And the one definition lives in reporters.py.
    assert hits[0].name == "reporters.py"


def test_flag_emission_finding_is_re_exported_from_reporters():
    """`from _bcm_common.flag_emission import Finding` SHOULD resolve to
    the same class object as `reporters.Finding`. Re-export is allowed for
    one transitional release.
    """
    import sys
    sys.path.insert(0, str(SCRIPTS))
    from _bcm_common import flag_emission, reporters
    assert flag_emission.Finding is reporters.Finding


def test_wiki_finding_is_re_exported_from_reporters():
    import sys
    sys.path.insert(0, str(SCRIPTS))
    from _bcm_common import wiki, reporters
    assert wiki.Finding is reporters.Finding


def test_validate_consistency_emits_reporters_finding_with_engine():
    import sys
    sys.path.insert(0, str(SCRIPTS))
    from _bcm_common import flag_emission, reporters

    findings = flag_emission.validate_consistency(
        recipe_mode="single-static",
        manifest_mode="questions-as-flags",
    )
    assert findings, "expected at least one finding for mode mismatch"
    for f in findings:
        assert isinstance(f, reporters.Finding)
        assert f.engine in reporters.VALID_ENGINES
        assert f.engine == "flag-emission"


def test_wiki_verify_emits_reporters_finding_with_engine(tmp_path):
    import sys
    sys.path.insert(0, str(SCRIPTS))
    from _bcm_common import wiki, reporters

    # Create a minimal wiki tree that fails verification (no profile.yaml).
    # `verify` requires a Profile; the simplest red path is to pass an
    # explicit Profile but no required dirs — _verify_raw_immutability
    # surveys raw/ and emits findings on missing files etc.
    profile = wiki.Profile(
        name="test",
        version="0",
        raw_subtypes=("ctf-writeups",),
        required_dirs=("raw",),
        required_fields={},
        page_frontmatter_schema={},
        survey_subdomains={},
    )
    findings = wiki.verify(tmp_path, profile=profile)
    assert findings, "expected at least one finding for missing required dir"
    for f in findings:
        assert isinstance(f, reporters.Finding)
        assert f.engine in reporters.VALID_ENGINES
        assert f.engine == "wiki"
