"""Tests for _bcm_common.artifact_fuzz — anti-grep one-shot detectors.

Each rule pretends to invoke a CLI (strings / binwalk / zsteg / exiftool /
olevba / oledump.py) and emits a `critical` Finding when the flag literal
appears in the tool's output. Tests use monkeypatch on subprocess so they
do not depend on these tools being installed.
"""

from __future__ import annotations

import sys
from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(REPO_ROOT / "scripts"))

from _bcm_common import artifact_fuzz  # noqa: E402


FLAG_REGEX = r"^FLAG\{[!-~]+\}$"
FLAG_LITERAL = "FLAG{anti_grep_bypass}"


def _make_slug(tmp_path, *, layout: dict[str, bytes]) -> Path:
    slug = tmp_path / "demo"
    slug.mkdir()
    (slug / "publish").mkdir()
    for relpath, content in layout.items():
        target = slug / relpath
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(content)
    return slug


def test_strings_one_shot_detects_plain_flag(monkeypatch, tmp_path):
    slug = _make_slug(tmp_path, layout={"publish/artifact.bin": b"prefix " + FLAG_LITERAL.encode() + b" suffix"})
    findings = artifact_fuzz.rule_strings_one_shot(slug, flag_regex=FLAG_REGEX)
    crits = [f for f in findings if f.severity == "critical"]
    assert len(crits) == 1
    assert "strings" in crits[0].rule_id
    assert "publish/artifact.bin" in crits[0].path


def test_strings_one_shot_clean_when_flag_absent(tmp_path):
    slug = _make_slug(tmp_path, layout={"publish/artifact.bin": b"\x00\x01nothing here\x02"})
    findings = artifact_fuzz.rule_strings_one_shot(slug, flag_regex=FLAG_REGEX)
    assert all(f.severity != "critical" for f in findings)


def test_binwalk_one_shot_detects_flag_in_extracted_file(monkeypatch, tmp_path):
    slug = _make_slug(tmp_path, layout={"publish/firmware.bin": b"\x00fakebin"})
    # Stub binwalk_extract to simulate a successful extraction containing the flag.
    def fake_extract(src, dst):
        out = dst / "extracted.bin"
        out.write_bytes(FLAG_LITERAL.encode())
        return [out]
    monkeypatch.setattr(artifact_fuzz, "_binwalk_extract", fake_extract)
    monkeypatch.setattr(artifact_fuzz.shutil, "which", lambda name: "/usr/bin/binwalk")
    findings = artifact_fuzz.rule_binwalk_one_shot(slug, flag_regex=FLAG_REGEX)
    crits = [f for f in findings if f.severity == "critical"]
    assert len(crits) == 1
    assert "binwalk" in crits[0].rule_id


def test_binwalk_emits_info_when_tool_missing(monkeypatch, tmp_path):
    slug = _make_slug(tmp_path, layout={"publish/firmware.bin": b"x"})
    monkeypatch.setattr(artifact_fuzz.shutil, "which", lambda name: None)
    findings = artifact_fuzz.rule_binwalk_one_shot(slug, flag_regex=FLAG_REGEX)
    # Tool missing must NOT silently pass; emit an advisory the operator can act on.
    assert any(f.severity == "advisory" and "tool-missing" in f.rule_id for f in findings)


def test_zsteg_one_shot_detects_flag_in_lsb(monkeypatch, tmp_path):
    slug = _make_slug(tmp_path, layout={"publish/cover.png": b"\x89PNG\r\n\x1a\nfake"})
    monkeypatch.setattr(artifact_fuzz.shutil, "which", lambda name: "/usr/bin/zsteg")
    monkeypatch.setattr(
        artifact_fuzz, "_zsteg_run", lambda path: f"b1,rgb,lsb,xy: {FLAG_LITERAL}\n"
    )
    findings = artifact_fuzz.rule_zsteg_one_shot(slug, flag_regex=FLAG_REGEX)
    crits = [f for f in findings if f.severity == "critical"]
    assert len(crits) == 1


def test_exiftool_one_shot_detects_flag_in_metadata(monkeypatch, tmp_path):
    slug = _make_slug(tmp_path, layout={"publish/photo.jpg": b"\xff\xd8\xff\xe0fake"})
    monkeypatch.setattr(artifact_fuzz.shutil, "which", lambda name: "/usr/bin/exiftool")
    monkeypatch.setattr(
        artifact_fuzz,
        "_exiftool_run",
        lambda path: f"Comment                         : {FLAG_LITERAL}\n",
    )
    findings = artifact_fuzz.rule_exiftool_one_shot(slug, flag_regex=FLAG_REGEX)
    crits = [f for f in findings if f.severity == "critical"]
    assert len(crits) == 1


def test_oletools_one_shot_detects_flag_in_macro(monkeypatch, tmp_path):
    slug = _make_slug(tmp_path, layout={"publish/report.xlsm": b"PK\x03\x04fake-zip"})
    monkeypatch.setattr(artifact_fuzz.shutil, "which", lambda name: "/usr/bin/olevba")
    monkeypatch.setattr(
        artifact_fuzz, "_olevba_run", lambda path: f"Sub Auto_Open()\n  msg = \"{FLAG_LITERAL}\"\nEnd Sub\n"
    )
    findings = artifact_fuzz.rule_oletools_one_shot(slug, flag_regex=FLAG_REGEX)
    crits = [f for f in findings if f.severity == "critical"]
    assert len(crits) == 1


def test_run_all_aggregates_findings(monkeypatch, tmp_path):
    slug = _make_slug(tmp_path, layout={"publish/a.bin": FLAG_LITERAL.encode()})
    findings = artifact_fuzz.run(slug, flag_regex=FLAG_REGEX)
    # `strings` rule must have surfaced the critical without external tools.
    assert any(f.severity == "critical" and "strings" in f.rule_id for f in findings)


def test_coverage_degraded_warning_when_threshold_tools_missing(monkeypatch, tmp_path):
    """When 3+ of 5 anti-grep tools are missing, run() emits an aggregate
    `coverage-degraded` warning so a Lazy Developer cannot ship a challenge
    by counting only criticals.
    """
    slug = _make_slug(tmp_path, layout={"publish/x.bin": b"safe"})
    # Pretend binwalk, zsteg, exiftool are missing (3 of 5 → threshold).
    def fake_which(name):
        return None if name in ("binwalk", "zsteg", "exiftool") else "/usr/bin/" + name
    monkeypatch.setattr(artifact_fuzz.shutil, "which", fake_which)
    findings = artifact_fuzz.run(slug, flag_regex=FLAG_REGEX)
    assert any(
        f.severity == "warning" and f.rule_id == "coverage-degraded"
        for f in findings
    )


def test_no_coverage_warning_when_all_tools_present(monkeypatch, tmp_path):
    slug = _make_slug(tmp_path, layout={"publish/x.bin": b"safe"})
    monkeypatch.setattr(artifact_fuzz.shutil, "which", lambda name: "/usr/bin/" + name)
    # Stub the run helpers so they don't actually execute anything.
    monkeypatch.setattr(artifact_fuzz, "_zsteg_run", lambda p: "")
    monkeypatch.setattr(artifact_fuzz, "_exiftool_run", lambda p: "")
    monkeypatch.setattr(artifact_fuzz, "_olevba_run", lambda p: "")
    monkeypatch.setattr(artifact_fuzz, "_binwalk_extract", lambda src, dst: [])
    findings = artifact_fuzz.run(slug, flag_regex=FLAG_REGEX)
    assert all(f.rule_id != "coverage-degraded" for f in findings)


def test_rule_failure_does_not_abort_batch(monkeypatch, tmp_path):
    """A rule that raises must produce an `internal-error` finding, not abort."""
    slug = _make_slug(tmp_path, layout={"publish/x.bin": b"safe"})
    def bomb(slug_dir, **kw):
        raise RuntimeError("simulated rule crash")
    monkeypatch.setattr(artifact_fuzz, "rule_strings_one_shot", bomb)
    findings = artifact_fuzz.run(slug, flag_regex=FLAG_REGEX)
    assert any(f.rule_id == "internal-error" and "strings" in f.message.lower() for f in findings)
