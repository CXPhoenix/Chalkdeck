"""End-to-end tests for bluechall_analyze.py CLI.

Covers task 6.5 (--no-runtime wiring) and the spec scenarios:
- --no-runtime skips live lab_fuzz invocation
- Stage-4-incomplete precondition exits 2
- JSON / SARIF / pretty output shapes
"""

from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

import yaml

REPO = Path(__file__).resolve().parent.parent
SCRIPTS = REPO / "scripts"


def _run_cli(*args, env_extra=None):
    cmd = [sys.executable, str(SCRIPTS / "bluechall_analyze.py"), *args]
    import os
    env = os.environ.copy()
    if env_extra:
        env.update(env_extra)
    return subprocess.run(cmd, capture_output=True, text=True, env=env)


def _make_manifest(*, stage4_complete=True, lab_backend="none"):
    stages = {str(i): {"complete": True, "audit_verdict": "pass",
                       "audit_persona": None, "timestamp": "2026-05-04T00:00:00+00:00"}
              for i in range(1, 8)}
    if not stage4_complete:
        stages["4"] = {"complete": False, "audit_verdict": None,
                       "audit_persona": None, "timestamp": None}
    return {
        "slug": "demo",
        "category": "forensics",
        "recipe_id": "stego-image-lsb",
        "flag_emission": "single-static",
        "lab_backend": lab_backend,
        "concept_refs": ["lsb-stego"],
        "cve_refs": [],
        "stages": stages,
        "lab_provenance": [],
    }


def _build(tmp_path, *, manifest, layout=None):
    slug = tmp_path / manifest["slug"]
    slug.mkdir()
    (slug / ".bluechall.manifest.yaml").write_text(
        yaml.safe_dump(manifest, default_flow_style=False, sort_keys=False),
        encoding="utf-8",
    )
    if layout:
        for relpath, content in layout.items():
            target = slug / relpath
            target.parent.mkdir(parents=True, exist_ok=True)
            if isinstance(content, (bytes, bytearray)):
                target.write_bytes(content)
            else:
                target.write_text(content, encoding="utf-8")
    return slug


def test_help_exits_zero():
    r = _run_cli("--help")
    assert r.returncode == 0


def test_missing_manifest_exits_2(tmp_path):
    slug = tmp_path / "demo"
    slug.mkdir()
    r = _run_cli(str(slug))
    assert r.returncode == 2


def test_stage4_incomplete_blocks(tmp_path):
    m = _make_manifest(stage4_complete=False)
    slug = _build(tmp_path, manifest=m, layout={"publish/x.bin": b"safe"})
    r = _run_cli(str(slug))
    assert r.returncode == 2
    assert "Stage 4" in r.stderr


def test_no_runtime_does_not_invoke_live_backend(tmp_path):
    """Per spec: --no-runtime skips live lab provisioning. With lab_backend=none,
    the engine emits info findings only and exits 0 cleanly.
    """
    m = _make_manifest(lab_backend="none")
    slug = _build(tmp_path, manifest=m, layout={"publish/x.bin": b"safe"})
    r = _run_cli(str(slug), "--no-runtime", "--json")
    assert r.returncode == 0, r.stdout + r.stderr
    findings = json.loads(r.stdout)
    # No critical findings
    assert all(f["severity"] != "critical" for f in findings)


def test_strings_one_shot_critical_when_flag_in_publish(tmp_path):
    m = _make_manifest()
    slug = _build(tmp_path, manifest=m, layout={
        "publish/leaky.bin": b"oops " + b"FLAG{plain_text_leak}" + b" oops",
    })
    r = _run_cli(str(slug), "--no-runtime", "--json")
    assert r.returncode == 1, r.stdout + r.stderr
    findings = json.loads(r.stdout)
    crits = [f for f in findings if f["severity"] == "critical"]
    assert any(f["rule_id"] == "strings-one-shot" for f in crits)


def test_sarif_output_is_valid(tmp_path):
    m = _make_manifest()
    slug = _build(tmp_path, manifest=m, layout={"publish/x.bin": b"safe"})
    r = _run_cli(str(slug), "--no-runtime", "--sarif")
    assert r.returncode == 0
    sarif = json.loads(r.stdout)
    assert sarif["version"] == "2.1.0"
    assert sarif["runs"][0]["tool"]["driver"]["name"] == "bluechall_analyze"


def test_no_publish_dir_does_not_crash(tmp_path):
    m = _make_manifest()
    slug = _build(tmp_path, manifest=m)  # no publish/ dir
    r = _run_cli(str(slug), "--no-runtime")
    assert r.returncode == 0


def test_allow_stage_skip_emits_loud_stderr_warning(tmp_path):
    """--allow-stage-skip must announce its bypass to stderr so CI logs
    cannot silently relax the gate (Scoundrel mitigation)."""
    m = _make_manifest(stage4_complete=False)
    slug = _build(tmp_path, manifest=m, layout={"publish/x.bin": b"safe"})
    r = _run_cli(str(slug), "--no-runtime", "--allow-stage-skip")
    assert r.returncode == 0
    assert "DANGER" in r.stderr
    assert "--allow-stage-skip" in r.stderr


def test_no_runtime_signal_when_lab_backend_active(tmp_path):
    """--no-runtime should emit a stderr line so CI cannot silently
    default the flag and lose live lab coverage (Lazy Developer mitigation)."""
    m = _make_manifest(lab_backend="docker")
    slug = _build(tmp_path, manifest=m, layout={"publish/x.bin": b"safe"})
    r = _run_cli(str(slug), "--no-runtime")
    assert "no-runtime" in r.stderr
    assert "dry-run" in r.stderr


def test_no_runtime_no_signal_when_lab_backend_none(tmp_path):
    """Quiet path: lab_backend=none means there's nothing to warn about."""
    m = _make_manifest(lab_backend="none")
    slug = _build(tmp_path, manifest=m, layout={"publish/x.bin": b"safe"})
    r = _run_cli(str(slug), "--no-runtime")
    assert "no-runtime" not in r.stderr


def test_flag_regex_override_detects_picoctf_prefix(tmp_path):
    """When --flag-regex is set, artifact-fuzz uses the override and
    catches non-canonical flag prefixes that the default would miss."""
    m = _make_manifest()
    slug = _build(tmp_path, manifest=m, layout={
        "publish/leaky.bin": b"oops " + b"picoCTF{wrong_prefix_oh_no}" + b" oops",
    })
    # Without override: default FLAG\{...\} doesn't match picoCTF{...}
    r_default = _run_cli(str(slug), "--no-runtime")
    assert r_default.returncode == 0
    # With override: matches.
    r_override = _run_cli(str(slug), "--no-runtime",
                          "--flag-regex", r"^picoCTF\{[!-~]+\}$",
                          "--json")
    assert r_override.returncode == 1
    findings = json.loads(r_override.stdout)
    assert any(f["rule_id"] == "strings-one-shot" and f["severity"] == "critical"
               for f in findings)
