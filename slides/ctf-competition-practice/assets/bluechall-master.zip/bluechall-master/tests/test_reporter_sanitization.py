"""Reporter output MUST sanitize ANSI / ASCII control characters.

Adversary scenario: a malicious challenge bundle ships an artefact whose
path/filename contains ANSI escapes (e.g. `\\x1b[2J`). Without sanitisation
those bytes flow straight from `to_pretty` to the operator's terminal and
can clear / repaint the screen, hiding genuine critical findings.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path


REPO = Path(__file__).resolve().parent.parent
SCRIPTS = REPO / "scripts"
sys.path.insert(0, str(SCRIPTS))

from _bcm_common.reporters import (  # noqa: E402
    Finding,
    to_json,
    to_pretty,
    to_sarif,
)


def _ansi_finding() -> Finding:
    return Finding(
        severity="critical",
        engine="artifact-fuzz",
        rule_id="strings-one-shot",
        # filename packs CSI 2J (clear screen) + CSI H (home cursor)
        path="publish/innocent\x1b[2J\x1b[H[OK].bin",
        message="binary contains \x07 bell + \x1b[31m red \x1b[0m",
        remediation_hint="strip metadata and re-emit\x07",
        extra={"detected_by": "strings\x00\x01"},
    )


def _ctrl_byte_runs(text: str) -> list[str]:
    """Return any literal ANSI / control bytes still in `text`. Used to
    assert the sanitiser actually replaces them.
    """
    out = []
    for ch in text:
        cp = ord(ch)
        if cp < 0x20 and cp not in (0x09, 0x0a, 0x0d):
            out.append(ch)
        elif cp == 0x7f:
            out.append(ch)
    return out


def test_to_pretty_sanitises_ansi_escape_in_path():
    pretty = to_pretty([_ansi_finding()])
    # The literal escape bytes must NOT survive into the rendered output.
    assert _ctrl_byte_runs(pretty) == [], (
        f"pretty output still contains control bytes: {_ctrl_byte_runs(pretty)!r}"
    )
    # And the escaped form (e.g. `\x1b`) MUST appear as visible characters
    # so the operator sees that something suspicious is in the path.
    assert "\\x1b" in pretty


def test_to_json_sanitises_message_and_path():
    text = to_json([_ansi_finding()])
    # Parse JSON to verify the sanitised values round-trip cleanly.
    items = json.loads(text)
    assert isinstance(items, list) and items
    f = items[0]
    assert _ctrl_byte_runs(f["path"]) == []
    assert _ctrl_byte_runs(f["message"]) == []
    assert _ctrl_byte_runs(f["remediation_hint"]) == []
    # Extra dict string values are also sanitised.
    assert _ctrl_byte_runs(f["extra"]["detected_by"]) == []


def test_to_sarif_sanitises_message_and_path():
    sarif_text = to_sarif([_ansi_finding()], tool_name="bluechall_test")
    sarif = json.loads(sarif_text)
    result = sarif["runs"][0]["results"][0]
    msg = result["message"]["text"]
    uri = result["locations"][0]["physicalLocation"]["artifactLocation"]["uri"]
    assert _ctrl_byte_runs(msg) == []
    assert _ctrl_byte_runs(uri) == []


def test_utf8_multibyte_passes_through_unchanged():
    """Chinese / emoji must not be escaped — only ASCII control bytes are."""
    f = Finding(
        severity="advisory", engine="rule-catalog",
        rule_id="advisory", path="solution/中文.txt",
        message="中文訊息 + 🚩",
    )
    pretty = to_pretty([f])
    json_text = to_json([f])
    sarif_text = to_sarif([f], tool_name="t")
    for blob in (pretty, json_text, sarif_text):
        assert "中文" in blob, f"UTF-8 stripped from output: {blob!r}"


def test_unicode_bidi_and_zero_width_are_escaped():
    """Round-2 audit (R2-Scoundrel-F4 / R2-Lazy-F5): U+202E RTLO and
    zero-width characters MUST be escaped, not silently passed.
    """
    f = Finding(
        severity="critical", engine="artifact-fuzz",
        rule_id="strings-one-shot",
        path="safe.txt‮gpj.exe",  # RTLO masks .exe extension
        message="zero-width ​ separator and BOM ﻿",
    )
    pretty = to_pretty([f])
    # The escaped form MUST appear; the literal RTLO/zero-width MUST NOT.
    assert "\\u202e" in pretty
    assert "‮" not in pretty
    assert "\\u200b" in pretty
    assert "​" not in pretty


def test_c1_control_byte_csi_is_escaped():
    """U+009B is the 8-bit CSI introducer (== ESC `[`) and MUST be
    escaped so an attacker-supplied filename containing 0x9b cannot
    repaint the operator's terminal.
    """
    f = Finding(
        severity="critical", engine="artifact-fuzz",
        rule_id="strings-one-shot",
        path="evil2J.bin",
        message="x",
    )
    pretty = to_pretty([f])
    assert "\\x9b" in pretty
    assert "" not in pretty


def test_sanitize_recursion_depth_guard():
    """Round-2 audit (R2-Lazy-F6): deep nested `extra` MUST NOT raise
    `RecursionError`; depth-exceeded values are replaced with a sentinel.
    """
    # Build a 200-deep nested dict (well past _SANITIZE_MAX_DEPTH=64).
    deep = "leaf"
    for _ in range(200):
        deep = {"x": deep}
    f = Finding(
        severity="warning", engine="rule-catalog",
        rule_id="r", path="p", message="m", extra={"chain": deep},
    )
    text = to_json([f])  # Should not raise.
    items = json.loads(text)
    # The sentinel string must appear somewhere in the serialized output.
    assert "<sanitize-depth-exceeded>" in text


def test_sanitize_recurses_into_tuples_and_sets():
    """Round-2 audit (R2-Confused-F6): tuples/sets inside structures
    handed to the sanitizer MUST have their string contents cleaned and
    the container type preserved.
    """
    from _bcm_common.reporters import _sanitize  # noqa: E402

    cleaned = _sanitize({
        "chain": ("clean", "evil\x1b[2J"),
        "tags": frozenset({"clean", "rtlo‮"}),
        "set_of_strs": {"clean", "evil\x9b2J"},
    })
    assert isinstance(cleaned["chain"], tuple)
    assert "\\x1b" in cleaned["chain"][1]
    assert isinstance(cleaned["tags"], frozenset)
    assert any("\\u202e" in s for s in cleaned["tags"])
    assert isinstance(cleaned["set_of_strs"], set)
    assert any("\\x9b" in s for s in cleaned["set_of_strs"])


def test_tab_newline_carriage_return_pass_through():
    f = Finding(
        severity="advisory", engine="rule-catalog",
        rule_id="advisory", path="x.txt",
        message="line1\tcol\nline2\rline3",
    )
    pretty = to_pretty([f])
    # \n is a normal line break (the renderer emits multiple lines); \t
    # and \r MUST be preserved as literal chars (not escaped).
    assert "line1\tcol" in pretty
    assert "line3" in pretty
