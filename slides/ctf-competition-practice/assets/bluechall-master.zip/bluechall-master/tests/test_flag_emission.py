"""Tests for `_bcm_common.flag_emission` covering all 4 modes.

Spec scenarios:
- recipe and manifest disagree on emission mode (critical)
- single-static flag matches event regex (accept)
- single-static flag mismatch rejected (critical)
- question count exceeds BLUE_TEAM_QUESTION_LIMIT (critical)
- service-derived port out of range rejected (critical)
- cyclic stage graph rejected (critical)
"""

from __future__ import annotations

import sys
import textwrap
from pathlib import Path

import pytest
import yaml

REPO_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(REPO_ROOT / "scripts"))

from _bcm_common import flag_emission as fe  # noqa: E402


FLAG_REGEX = r"TEST\.HSCTF\{[A-Za-z0-9_]+\}"
FLAG_LITERAL = "TEST.HSCTF{<text>}"


# === Mode consistency ========================================================


def test_consistency_clean_when_modes_match():
    findings = fe.validate_consistency("single-static", "single-static")
    assert findings == []


def test_consistency_critical_on_mode_mismatch():
    findings = fe.validate_consistency("single-static", "questions-as-flags")
    assert any(f.rule_id == "flag-emission-mismatch" for f in findings)
    assert all(f.severity == "critical" for f in findings if f.rule_id == "flag-emission-mismatch")


def test_consistency_critical_on_unknown_mode():
    findings = fe.validate_consistency("computed", "computed")
    assert any(f.rule_id == "flag-emission-unknown" for f in findings)


def test_consistency_critical_when_recipe_omits_mode():
    findings = fe.validate_consistency(None, "single-static")
    assert any(f.rule_id == "flag-emission-recipe-missing" for f in findings)


# === single-static ==========================================================


def test_single_static_accepts_matching_flag(tmp_path):
    f = tmp_path / "flag.txt"
    f.write_text("TEST.HSCTF{example_flag}\n", encoding="utf-8")
    findings = fe.validate_single_static(f, flag_regex=FLAG_REGEX)
    assert findings == []


def test_single_static_rejects_mismatch(tmp_path):
    f = tmp_path / "flag.txt"
    f.write_text("flag{wrong_format}\n", encoding="utf-8")
    findings = fe.validate_single_static(f, flag_regex=FLAG_REGEX)
    crits = [x for x in findings if x.severity == "critical"]
    assert any("regex-mismatch" in x.rule_id for x in crits)


def test_single_static_rejects_missing_file(tmp_path):
    f = tmp_path / "absent.txt"
    findings = fe.validate_single_static(f, flag_regex=FLAG_REGEX)
    assert any(x.rule_id == "single-static-missing-flag" for x in findings)


# === questions-as-flags ======================================================


def _write_questions(tmp_path: Path, entries: list[dict]) -> Path:
    f = tmp_path / "questions.yaml"
    f.write_text(yaml.safe_dump(entries), encoding="utf-8")
    return f


def test_questions_as_flags_accepts_valid(tmp_path):
    entries = [
        {"id": "q1", "question": "What is the C2 hostname?",
         "answer": "TEST.HSCTF{evil_c2_host}",
         "attack_technique": "T1071.001", "points": 10},
        {"id": "q2", "question": "What is the persistence mechanism?",
         "answer": "TEST.HSCTF{run_key}",
         "attack_technique": "T1547.001", "points": 15},
    ]
    f = _write_questions(tmp_path, entries)
    findings = fe.validate_questions_as_flags(
        f, flag_regex=FLAG_REGEX, blue_team_question_limit=10,
        mitre_attack_version="v15.0",
    )
    crits = [x for x in findings if x.severity == "critical"]
    assert crits == [], f"unexpected critical findings: {crits}"


def test_questions_as_flags_rejects_over_limit(tmp_path):
    entries = [
        {"id": f"q{i}", "question": "Q?", "answer": "TEST.HSCTF{a}",
         "attack_technique": "T1059", "points": 1}
        for i in range(12)
    ]
    f = _write_questions(tmp_path, entries)
    findings = fe.validate_questions_as_flags(
        f, flag_regex=FLAG_REGEX, blue_team_question_limit=10,
        mitre_attack_version="v15.0",
    )
    assert any(x.rule_id == "questions-as-flags-over-limit" for x in findings)


def test_questions_as_flags_rejects_missing_field(tmp_path):
    entries = [{"id": "q1", "question": "Q?", "answer": "TEST.HSCTF{a}", "points": 5}]
    # missing attack_technique
    f = _write_questions(tmp_path, entries)
    findings = fe.validate_questions_as_flags(
        f, flag_regex=FLAG_REGEX, blue_team_question_limit=10,
        mitre_attack_version="v15.0",
    )
    assert any(
        x.rule_id == "questions-as-flags-missing-field" and "attack_technique" in x.message
        for x in findings
    )


def test_questions_as_flags_warns_on_invalid_attack_id(tmp_path):
    entries = [
        {"id": "q1", "question": "Q?", "answer": "TEST.HSCTF{a}",
         "attack_technique": "INVALID-ID", "points": 5},
    ]
    f = _write_questions(tmp_path, entries)
    findings = fe.validate_questions_as_flags(
        f, flag_regex=FLAG_REGEX, blue_team_question_limit=10,
        mitre_attack_version="v15.0",
    )
    assert any(x.rule_id == "questions-as-flags-attack-technique-format" for x in findings)


def test_questions_as_flags_freeform_skips_regex(tmp_path):
    entries = [
        {"id": "q1", "question": "Q?", "answer": "192.168.1.5",
         "freeform_answer": True, "attack_technique": "T1059", "points": 5},
    ]
    f = _write_questions(tmp_path, entries)
    findings = fe.validate_questions_as_flags(
        f, flag_regex=FLAG_REGEX, blue_team_question_limit=10,
        mitre_attack_version="v15.0",
    )
    crits = [x for x in findings if x.severity == "critical"]
    assert crits == []


# === service-derived =========================================================


def _write_service_meta(tmp_path: Path, data: dict) -> Path:
    f = tmp_path / "service_meta.yaml"
    f.write_text(yaml.safe_dump(data), encoding="utf-8")
    return f


def test_service_derived_accepts_in_range_port(tmp_path):
    f = _write_service_meta(tmp_path, {"service_port": 8550, "hmac_key_source": "per-team"})
    findings = fe.validate_service_derived(f, external_port_start=8500, external_port_end=8599)
    crits = [x for x in findings if x.severity == "critical"]
    assert crits == []


def test_service_derived_rejects_out_of_range_port(tmp_path):
    f = _write_service_meta(tmp_path, {"service_port": 9000, "hmac_key_source": "per-team"})
    findings = fe.validate_service_derived(f, external_port_start=8500, external_port_end=8599)
    assert any(x.rule_id == "service-derived-port-out-of-range" for x in findings)


def test_service_derived_rejects_missing_port(tmp_path):
    f = _write_service_meta(tmp_path, {"hmac_key_source": "per-team"})
    findings = fe.validate_service_derived(f, external_port_start=8500, external_port_end=8599)
    assert any(x.rule_id == "service-derived-port-missing" for x in findings)


# === multi-stage-pivot =======================================================


def _write_stages(tmp_path: Path, data: list[dict]) -> Path:
    f = tmp_path / "stages.yaml"
    f.write_text(yaml.safe_dump(data), encoding="utf-8")
    return f


def test_multi_stage_pivot_accepts_valid_dag(tmp_path):
    stages = [
        {"id": "s1", "requires": [], "output_artifact": "src/a.bin",
         "unlock_token_format": r"^[A-Z]{4}$"},
        {"id": "s2", "requires": ["s1"], "output_artifact": "src/b.bin",
         "unlock_token_format": r"^[A-Z]{8}$", "terminal": True},
    ]
    f = _write_stages(tmp_path, stages)
    findings = fe.validate_multi_stage_pivot(f, flag_regex=FLAG_REGEX)
    crits = [x for x in findings if x.severity == "critical"]
    assert crits == []


def test_multi_stage_pivot_rejects_cycle(tmp_path):
    stages = [
        {"id": "s1", "requires": ["s2"], "output_artifact": "src/a.bin",
         "unlock_token_format": r"^[A-Z]{4}$"},
        {"id": "s2", "requires": ["s1"], "output_artifact": "src/b.bin",
         "unlock_token_format": r"^[A-Z]{8}$", "terminal": True},
    ]
    f = _write_stages(tmp_path, stages)
    findings = fe.validate_multi_stage_pivot(f, flag_regex=FLAG_REGEX)
    assert any(x.rule_id == "multi-stage-pivot-cycle" for x in findings)


def test_multi_stage_pivot_rejects_no_terminal(tmp_path):
    stages = [
        {"id": "s1", "requires": [], "output_artifact": "src/a.bin",
         "unlock_token_format": r"^[A-Z]{4}$"},
    ]
    f = _write_stages(tmp_path, stages)
    findings = fe.validate_multi_stage_pivot(f, flag_regex=FLAG_REGEX)
    assert any(x.rule_id == "multi-stage-pivot-no-terminal" for x in findings)


def test_multi_stage_pivot_rejects_unknown_dependency(tmp_path):
    stages = [
        {"id": "s1", "requires": ["s99"], "output_artifact": "src/a.bin",
         "unlock_token_format": r"^[A-Z]{4}$", "terminal": True},
    ]
    f = _write_stages(tmp_path, stages)
    findings = fe.validate_multi_stage_pivot(f, flag_regex=FLAG_REGEX)
    assert any(x.rule_id == "multi-stage-pivot-unknown-dependency" for x in findings)


def test_multi_stage_pivot_rejects_duplicate_id(tmp_path):
    stages = [
        {"id": "s1", "requires": [], "output_artifact": "src/a.bin",
         "unlock_token_format": r"^[A-Z]{4}$"},
        {"id": "s1", "requires": [], "output_artifact": "src/b.bin",
         "unlock_token_format": r"^[A-Z]{4}$", "terminal": True},
    ]
    f = _write_stages(tmp_path, stages)
    findings = fe.validate_multi_stage_pivot(f, flag_regex=FLAG_REGEX)
    assert any(x.rule_id == "multi-stage-pivot-duplicate-id" for x in findings)


# === HMAC helper ==============================================================


def test_hmac_per_team_flag_is_deterministic():
    f1 = fe.hmac_per_team_flag(b"secret", "team_a", flag_format_literal=FLAG_LITERAL)
    f2 = fe.hmac_per_team_flag(b"secret", "team_a", flag_format_literal=FLAG_LITERAL)
    assert f1 == f2


def test_hmac_per_team_flag_is_per_team_unique():
    f1 = fe.hmac_per_team_flag(b"secret", "team_a", flag_format_literal=FLAG_LITERAL)
    f2 = fe.hmac_per_team_flag(b"secret", "team_b", flag_format_literal=FLAG_LITERAL)
    assert f1 != f2


def test_hmac_per_team_flag_matches_format_literal():
    import re
    f = fe.hmac_per_team_flag(b"secret", "team_a", flag_format_literal=FLAG_LITERAL)
    assert re.fullmatch(FLAG_REGEX, f), f"flag {f!r} does not match {FLAG_REGEX}"
