"""Stage-6 (Validate) audit-verdict gate for `bluechall_publish.py`.

Without this gate, an author can publish adapters for a challenge that
has never seen the rule catalog (skipping the seven-stage discipline).
"""

from __future__ import annotations

import subprocess
import sys
from pathlib import Path

import yaml


REPO = Path(__file__).resolve().parent.parent
SCRIPTS = REPO / "scripts"


def _run_publish(*args, cwd: Path | None = None):
    cmd = [sys.executable, str(SCRIPTS / "bluechall_publish.py"), *args]
    return subprocess.run(cmd, capture_output=True, text=True, cwd=cwd)


def _make_manifest(*, stage6_verdict: str | None):
    """Stages 1-7 marked complete. Stage 6's audit_verdict is parametrized."""
    stages = {
        str(i): {"complete": True, "audit_verdict": "pass",
                 "audit_persona": None,
                 "timestamp": "2026-05-04T00:00:00+00:00"}
        for i in range(1, 8)
    }
    stages["6"]["audit_verdict"] = stage6_verdict
    stages["6"]["audit_persona"] = "tool-grep-solver"
    return {
        "slug": "demo-pubgate",
        "category": "forensics",
        "recipe_id": "stego-image-lsb",
        "flag_emission": "single-static",
        "lab_backend": "docker",
        "concept_refs": ["lsb-stego"],
        "cve_refs": [],
        "stages": stages,
        "lab_provenance": [],
        "canonical_flag": "FLAG{publish_gate_real_2026}",
    }


def _build(tmp_path: Path, manifest: dict):
    slug = tmp_path / manifest["slug"]
    slug.mkdir()
    (slug / ".bluechall.manifest.yaml").write_text(
        yaml.safe_dump(manifest, default_flow_style=False, sort_keys=False),
        encoding="utf-8",
    )
    sol = slug / "solution"
    sol.mkdir()
    (sol / "solve.py").write_text("x", encoding="utf-8")
    (sol / "flag.txt").write_text(manifest["canonical_flag"], encoding="utf-8")
    (slug / "recipe.yaml").write_text(
        "---\nid: stego-image-lsb\nflag_emission: single-static\n---\n",
        encoding="utf-8",
    )
    return slug


def test_stage6_audit_verdict_null_blocks_publish(tmp_path):
    slug = _build(tmp_path, _make_manifest(stage6_verdict=None))
    r = _run_publish(str(slug))
    assert r.returncode == 2, r.stdout + r.stderr
    assert "Stage 6" in r.stderr or "stage 6" in r.stderr.lower()
    assert "audit_verdict" in r.stderr or "audit verdict" in r.stderr.lower()


def test_stage6_audit_verdict_fail_blocks_publish(tmp_path):
    slug = _build(tmp_path, _make_manifest(stage6_verdict="fail"))
    r = _run_publish(str(slug))
    assert r.returncode == 2, r.stdout + r.stderr
    assert "fail" in r.stderr.lower()


def test_stage6_audit_verdict_pass_advances_publish(tmp_path):
    slug = _build(tmp_path, _make_manifest(stage6_verdict="pass"))
    r = _run_publish(str(slug))
    # Adapters successfully written, exit 0.
    assert r.returncode == 0, r.stdout + r.stderr
    assert (slug / "adapters" / "ctfcli.yml").exists()


def test_stage6_audit_verdict_advisory_advances_publish(tmp_path):
    slug = _build(tmp_path, _make_manifest(stage6_verdict="advisory"))
    r = _run_publish(str(slug))
    assert r.returncode == 0, r.stdout + r.stderr


def test_allow_stage_skip_bypasses_with_loud_warning(tmp_path):
    slug = _build(tmp_path, _make_manifest(stage6_verdict=None))
    r = _run_publish(str(slug), "--allow-stage-skip")
    assert r.returncode == 0, r.stdout + r.stderr
    assert "DANGER" in r.stderr
    assert "--allow-stage-skip" in r.stderr
