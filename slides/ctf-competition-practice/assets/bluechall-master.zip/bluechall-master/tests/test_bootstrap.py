"""Tests for `bluechall_bootstrap`.

Covers spec scenarios:
- bootstrap creates valid file with --yes
- bootstrap refuses to overwrite without --force
"""

from __future__ import annotations

import sys
from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(REPO_ROOT / "scripts"))

import bluechall_bootstrap as bb  # noqa: E402
from _bcm_common import rules_env  # noqa: E402


def common_argv(target: Path, **overrides) -> list[str]:
    """Build a non-interactive argv for tests, leveraging defaults."""
    base = [
        "--name", "TEST.HSCTF",
        "--long-name", "Test HSCTF",
        "--flag-prefix", "TEST.HSCTF",
        "--port-range", "8080:8099",
        "--categories", "forensics,reverse,blue-team",
        "--lab-backend-default", "docker",
        "--flag-emission-default", "single-static",
        "--yes",
    ]
    return base


def test_bootstrap_writes_valid_23key_file_with_yes(tmp_path, monkeypatch):
    target = tmp_path / ".rules.env"
    monkeypatch.setattr(sys.stdin, "isatty", lambda: False)

    rc = bb.main(common_argv(target), out_override=target)
    assert rc == 0
    assert target.exists()

    parsed = rules_env.load(target)
    rules_env.validate(parsed)
    # All 24 keys (16 webchall + 8 bluechall) present
    for k in rules_env.REQUIRED_KEYS:
        assert k in parsed, f"missing required key {k}"


def test_bootstrap_refuses_overwrite_without_force(tmp_path, monkeypatch):
    target = tmp_path / ".rules.env"
    monkeypatch.setattr(sys.stdin, "isatty", lambda: False)

    rc1 = bb.main(common_argv(target), out_override=target)
    assert rc1 == 0

    rc2 = bb.main(common_argv(target), out_override=target)
    assert rc2 == 1, "must refuse second invocation without --force"


def test_bootstrap_overwrites_with_force(tmp_path, monkeypatch, capsys):
    target = tmp_path / ".rules.env"
    monkeypatch.setattr(sys.stdin, "isatty", lambda: False)

    rc1 = bb.main(common_argv(target), out_override=target)
    assert rc1 == 0

    argv2 = common_argv(target) + ["--force", "--long-name", "Renamed Event"]
    rc2 = bb.main(argv2, out_override=target)
    assert rc2 == 0

    parsed = rules_env.load(target)
    assert parsed["CTF_EVENT_LONG_NAME"] == "Renamed Event"


def test_bootstrap_rejects_invalid_categories(tmp_path, monkeypatch):
    target = tmp_path / ".rules.env"
    monkeypatch.setattr(sys.stdin, "isatty", lambda: False)

    argv = [
        "--name", "TEST.HSCTF",
        "--long-name", "Test HSCTF",
        "--flag-prefix", "TEST.HSCTF",
        "--port-range", "8080:8099",
        "--categories", "web,crypto",  # missing bluechall primary member
        "--yes",
    ]
    rc = bb.main(argv, out_override=target)
    assert rc == 1, "must reject CATEGORIES without forensics/reverse/blue-team"


def test_bootstrap_requires_flags_in_non_tty(tmp_path, monkeypatch):
    target = tmp_path / ".rules.env"
    monkeypatch.setattr(sys.stdin, "isatty", lambda: False)

    rc = bb.main(["--name", "TEST"], out_override=target)
    assert rc == 1, "must reject when required flags missing in non-TTY"


def test_bootstrap_with_external_flag_port_range(tmp_path, monkeypatch):
    target = tmp_path / ".rules.env"
    monkeypatch.setattr(sys.stdin, "isatty", lambda: False)

    argv = common_argv(target) + ["--external-flag-port-range", "8500:8599"]
    rc = bb.main(argv, out_override=target)
    assert rc == 0

    parsed = rules_env.load(target)
    assert parsed["EXTERNAL_FLAG_SERVICE_PORT_RANGE_START"] == "8500"
    assert parsed["EXTERNAL_FLAG_SERVICE_PORT_RANGE_END"] == "8599"


def test_bootstrap_rejects_overlapping_port_ranges(tmp_path, monkeypatch):
    target = tmp_path / ".rules.env"
    monkeypatch.setattr(sys.stdin, "isatty", lambda: False)

    argv = common_argv(target) + ["--external-flag-port-range", "8090:8200"]
    rc = bb.main(argv, out_override=target)
    assert rc == 1, "external port range must not overlap host port range"


def test_bootstrap_with_custom_mitre_version(tmp_path, monkeypatch):
    target = tmp_path / ".rules.env"
    monkeypatch.setattr(sys.stdin, "isatty", lambda: False)

    argv = common_argv(target) + ["--mitre-version", "v16.0"]
    rc = bb.main(argv, out_override=target)
    assert rc == 0

    parsed = rules_env.load(target)
    assert parsed["MITRE_ATTACK_VERSION"] == "v16.0"


def test_derive_flag_keys():
    fr, fl = bb.derive_flag_keys("TEST.HSCTF")
    assert fr == r"TEST\.HSCTF\{\S+\}"
    assert fl == "TEST.HSCTF{<text>}"


def test_parse_port_range():
    assert bb.parse_port_range("8080:8099") == (8080, 8099)


def test_parse_port_range_rejects_missing_colon():
    with pytest.raises(ValueError, match=r"port-range"):
        bb.parse_port_range("8080-8099")
