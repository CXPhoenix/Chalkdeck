"""End-to-end tests for bluechall_validate.py against blue-team challenges.

Blue-team challenges canonically use `flag_emission: questions-as-flags`,
so the validate catalog enforces `solution/questions.yaml` presence and
the placeholder-flag rule in the manifest.
"""

from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

import yaml

REPO = Path(__file__).resolve().parent.parent
SCRIPTS = REPO / "scripts"


def _run_cli(*args):
    cmd = [sys.executable, str(SCRIPTS / "bluechall_validate.py"), *args]
    return subprocess.run(cmd, capture_output=True, text=True)


def _make_blue_team_manifest():
    return {
        "slug": "demo-bt-ir",
        "category": "blue-team",
        "recipe_id": "bt-malware-pe-ir",
        "flag_emission": "questions-as-flags",
        "lab_backend": "orbstack",
        "concept_refs": ["malware-pe-ir-multistage"],
        "cve_refs": [],
        "stages": {str(i): {"complete": True, "audit_verdict": "pass",
                            "audit_persona": None, "timestamp": "2026-05-04T00:00:00+00:00"}
                   for i in range(1, 8)},
        "lab_provenance": [],
        "canonical_flag": "FLAG{ir_master_real_2026}",
    }


def _build(tmp_path, *, manifest, layout=None):
    slug = tmp_path / manifest["slug"]
    slug.mkdir()
    (slug / ".bluechall.manifest.yaml").write_text(
        yaml.safe_dump(manifest, default_flow_style=False, sort_keys=False),
        encoding="utf-8",
    )
    if layout:
        for relpath, content in layout.items():
            target = slug / relpath
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(content, encoding="utf-8")
    return slug


def test_questions_as_flags_requires_questions_yaml(tmp_path):
    m = _make_blue_team_manifest()
    slug = _build(tmp_path, manifest=m, layout={
        "solution/solve.py": "x",
        "recipe.yaml": "id: bt-malware-pe-ir\n",
    })
    r = _run_cli(str(slug), "--allow-stage-skip")
    assert r.returncode == 1
    assert "questions.yaml" in r.stdout


def test_blue_team_with_questions_yaml_passes(tmp_path):
    m = _make_blue_team_manifest()
    slug = _build(tmp_path, manifest=m, layout={
        "solution/solve.py": "x",
        # Full canonical question entry: required fields populated and
        # MITRE technique format matches `^T\d{4}(\.\d{3})?$`. Recipe YAML
        # carries `flag_emission` so the new recipe/manifest match rule
        # finds them in agreement.
        "solution/questions.yaml": (
            "questions:\n"
            "  - id: q1\n"
            "    question: What is the malicious PID?\n"
            "    answer: FLAG{pid_correct}\n"
            "    attack_technique: T1055\n"
            "    points: 50\n"
            "    nist_phase: examination\n"
        ),
        "recipe.yaml": (
            "---\n"
            "id: bt-malware-pe-ir\n"
            "flag_emission: questions-as-flags\n"
            "---\n"
        ),
    })
    r = _run_cli(str(slug), "--allow-stage-skip")
    assert r.returncode == 0, r.stdout + r.stderr


def test_blue_team_placeholder_flag_in_questions_caught(tmp_path):
    m = _make_blue_team_manifest()
    slug = _build(tmp_path, manifest=m, layout={
        "solution/solve.py": "x",
        "solution/questions.yaml": (
            "questions:\n"
            "  - id: q1\n"
            "    question: What is X?\n"
            "    answer: FLAG{TODO}\n"
            "    attack_technique: T1055\n"
            "    points: 50\n"
            "    nist_phase: examination\n"
        ),
        "recipe.yaml": (
            "---\nid: bt-malware-pe-ir\n"
            "flag_emission: questions-as-flags\n---\n"
        ),
    })
    r = _run_cli(str(slug), "--allow-stage-skip", "--json")
    assert r.returncode == 1
    parsed = json.loads(r.stdout)
    assert any(f["rule_id"] == "placeholder-flag" for f in parsed)


def test_blue_team_invalid_lab_backend_rejected(tmp_path):
    m = _make_blue_team_manifest()
    m["lab_backend"] = "kubernetes"  # not in LAB_BACKENDS
    slug = _build(tmp_path, manifest=m, layout={
        "solution/solve.py": "x",
        "solution/questions.yaml": "questions:\n  - id: q1\n    answer: FLAG{x}\n",
        "recipe.yaml": "x",
    })
    r = _run_cli(str(slug), "--allow-stage-skip")
    assert r.returncode == 1
    assert "lab_backend" in r.stdout
    assert "kubernetes" in r.stdout
