"""`rule_no_placeholder_flag` MUST scan `solution/**` and `src/**`.

Previously the scan was hardcoded to four files
(`solution/{flag.txt,questions.yaml,stages.yaml,.bluechall.manifest.yaml}`).
Authors who hardcoded a demo flag inside `src/embed.py` or
`src/keygen.c` could ship without the rule firing.
"""

from __future__ import annotations

import json
import subprocess
import sys
import yaml
from pathlib import Path


REPO = Path(__file__).resolve().parent.parent
SCRIPTS = REPO / "scripts"


def _run_validate(*args):
    cmd = [sys.executable, str(SCRIPTS / "bluechall_validate.py"), *args]
    return subprocess.run(cmd, capture_output=True, text=True)


def _make_manifest(canonical_flag="FLAG{real_demo_2026}"):
    return {
        "slug": "demo-scan",
        "category": "forensics",
        "recipe_id": "stego-image-lsb",
        "flag_emission": "single-static",
        "lab_backend": "docker",
        "concept_refs": ["lsb-stego"],
        "cve_refs": [],
        "stages": {str(i): {"complete": True, "audit_verdict": "pass",
                            "audit_persona": None,
                            "timestamp": "2026-05-04T00:00:00+00:00"}
                   for i in range(1, 8)},
        "lab_provenance": [],
        "canonical_flag": canonical_flag,
    }


def _build(tmp_path: Path, *, manifest, layout):
    slug = tmp_path / manifest["slug"]
    slug.mkdir()
    (slug / ".bluechall.manifest.yaml").write_text(
        yaml.safe_dump(manifest, default_flow_style=False, sort_keys=False),
        encoding="utf-8",
    )
    for relpath, content in layout.items():
        target = slug / relpath
        if isinstance(content, bytes):
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(content)
        else:
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(content, encoding="utf-8")
    return slug


def test_src_embed_py_with_demo_flag_is_caught(tmp_path):
    """Author edits `solution/flag.txt` to a real flag but forgets the
    `_demo_` literal inside `src/embed.py` — the rule MUST catch it.
    """
    m = _make_manifest(canonical_flag="FLAG{real_lsb_2026}")
    slug = _build(tmp_path, manifest=m, layout={
        "solution/solve.py": "x",
        "solution/flag.txt": "FLAG{real_lsb_2026}",
        "recipe.yaml": "---\nid: stego-image-lsb\nflag_emission: single-static\n---\n",
        "src/embed.py": 'FLAG = "FLAG{lsb_demo_2026}"\n',
    })
    r = _run_validate(str(slug), "--allow-stage-skip", "--json")
    assert r.returncode == 1, r.stdout + r.stderr
    findings = json.loads(r.stdout)
    placeholder_hits = [f for f in findings
                        if f["rule_id"] == "placeholder-flag"
                        and "embed.py" in f["path"]]
    assert placeholder_hits, (
        f"expected placeholder-flag finding for src/embed.py; got {findings!r}"
    )


def test_src_keygen_c_with_demo_flag_is_caught(tmp_path):
    m = _make_manifest(canonical_flag="FLAG{real_keygen_2026}")
    slug = _build(tmp_path, manifest=m, layout={
        "solution/solve.py": "x",
        "solution/flag.txt": "FLAG{real_keygen_2026}",
        "recipe.yaml": "---\nid: keygen\nflag_emission: single-static\n---\n",
        "src/keygen.c": '// demo: FLAG{x64_test_default}\nint main(){return 0;}\n',
    })
    r = _run_validate(str(slug), "--allow-stage-skip", "--json")
    assert r.returncode == 1, r.stdout + r.stderr
    findings = json.loads(r.stdout)
    hits = [f for f in findings
            if f["rule_id"] == "placeholder-flag" and "keygen.c" in f["path"]]
    assert hits, f"expected placeholder finding for src/keygen.c; got {findings}"


def test_solution_solve_py_with_demo_flag_is_caught(tmp_path):
    m = _make_manifest(canonical_flag="FLAG{real_solve_2026}")
    slug = _build(tmp_path, manifest=m, layout={
        "solution/solve.py": 'print("FLAG{vm_demo_2026}")\n',
        "solution/flag.txt": "FLAG{real_solve_2026}",
        "recipe.yaml": "---\nid: any\nflag_emission: single-static\n---\n",
    })
    r = _run_validate(str(slug), "--allow-stage-skip", "--json")
    assert r.returncode == 1, r.stdout + r.stderr
    findings = json.loads(r.stdout)
    hits = [f for f in findings
            if f["rule_id"] == "placeholder-flag" and "solve.py" in f["path"]]
    assert hits, f"expected placeholder finding for solution/solve.py; got {findings}"


def test_publish_dump_bin_is_not_scanned(tmp_path):
    """Binary blobs under `publish/` must NOT be loaded by the scan
    (extension filter excludes `.bin`); the rule's job is source-tree
    placeholders, not artifact-fuzz coverage.
    """
    m = _make_manifest(canonical_flag="FLAG{real_pub_2026}")
    payload = b"\x00" * 4096 + b"FLAG{some_demo_test_2026}" + b"\x00" * 4096
    slug = _build(tmp_path, manifest=m, layout={
        "solution/solve.py": "x",
        "solution/flag.txt": "FLAG{real_pub_2026}",
        "recipe.yaml": "---\nid: any\nflag_emission: single-static\n---\n",
        "publish/dump.bin": payload,
    })
    r = _run_validate(str(slug), "--allow-stage-skip", "--json")
    findings = json.loads(r.stdout)
    bin_hits = [f for f in findings if "dump.bin" in f["path"]]
    assert not bin_hits, (
        f"placeholder rule should skip .bin under publish/; got {bin_hits}"
    )


def test_pycache_is_excluded(tmp_path):
    m = _make_manifest(canonical_flag="FLAG{real_cache_2026}")
    slug = _build(tmp_path, manifest=m, layout={
        "solution/solve.py": "x",
        "solution/flag.txt": "FLAG{real_cache_2026}",
        "recipe.yaml": "---\nid: any\nflag_emission: single-static\n---\n",
        "src/__pycache__/foo.cpython-313.pyc": "FLAG{cache_demo_2026}",
    })
    r = _run_validate(str(slug), "--allow-stage-skip", "--json")
    findings = json.loads(r.stdout)
    cache_hits = [f for f in findings if "__pycache__" in f["path"]]
    assert not cache_hits, f"pycache should be excluded; got {cache_hits}"
