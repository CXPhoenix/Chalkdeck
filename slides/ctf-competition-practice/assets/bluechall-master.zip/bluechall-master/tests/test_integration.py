"""End-to-end integration tests covering tasks 11.1-11.3.

Drives the full Stage-1-through-Stage-7 pipeline for three demos:

  - forensics demo-stego (single-static + docker)
  - reverse demo-vm (multi-stage-pivot + docker)
  - blue-team demo-ir (questions-as-flags + orbstack)

Across the three demos, the matrix exercises:
  - 3 of 4 flag emission modes (single-static, multi-stage-pivot, questions-as-flags)
  - 2 of 3 lab backends (docker, orbstack); QEMU is exercised by unit tests
  - 3 of 3 first-class categories (forensics, reverse, blue-team)

Each demo runs:
  bootstrap (event repo, once) →
  manual scaffold (in-test, since bluechall_init.py needs interactive input
                   for some recipes; tests use the documented bare-minimum
                   layout the validator accepts) →
  analyze --no-runtime --json →
  validate --soft --json AND validate (strict) →
  publish (asserts 4 adapter outputs, or 3 + advisory when emission=single-static
           or multi-stage-pivot which omit Sherlocks).
"""

from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

import pytest
import yaml

REPO = Path(__file__).resolve().parent.parent
SCRIPTS = REPO / "scripts"


def _run(cli: str, *args, cwd=None) -> subprocess.CompletedProcess:
    """Invoke a bluechall CLI as subprocess; returns the CompletedProcess.

    Callers MUST check `.returncode` against expectations — this helper
    does no implicit assertion, so test authors keep the failure-mode
    granularity they want.
    """
    cmd = [sys.executable, str(SCRIPTS / cli), *args]
    return subprocess.run(cmd, capture_output=True, text=True, cwd=cwd)


def _bootstrap_event_repo(tmp_path: Path) -> Path:
    """Run bluechall_bootstrap and return the event repo path."""
    event = tmp_path / "demo-event"
    event.mkdir()
    r = _run(
        "bluechall_bootstrap.py",
        "--name", "demo-event",
        "--long-name", "Demo Event 2026",
        "--flag-prefix", "FLAG",
        "--port-range", "8080:8099",
        "--author-name", "test",
        "--author-email", "test@example.com",
        "--categories", "forensics,reverse,blue-team",
        "--lab-backend-default", "docker",
        "--flag-emission-default", "single-static",
        "--external-flag-port-range", "8500:8599",
        "--mitre-version", "v15.0",
        "--yes",
        cwd=event,
    )
    assert r.returncode == 0, f"bootstrap failed: {r.stderr}"
    rules_env = event / ".rules.env"
    assert rules_env.exists()
    return event


# Explicit category → primary concept_refs default. Confused-Developer
# protection: an unknown category raises KeyError instead of silently
# falling through to a wrong concept (the prior ternary mapped misc → blue-team).
_DEFAULT_CONCEPT_REF_BY_CATEGORY = {
    "forensics": "lsb-stego",
    "reverse": "vm-bytecode-reverse",
    "blue-team": "malware-pe-ir-multistage",
    "misc": "lsb-stego",  # arbitrary but explicit
}


def _scaffold_challenge(event: Path, *, slug: str, category: str,
                       recipe_id: str, flag_emission: str,
                       lab_backend: str, canonical_flag: str,
                       layout: dict) -> Path:
    """Scaffold a minimal valid challenge directory under the event repo.

    NOTE: stages are pre-marked `complete: True, audit_verdict: pass` so the
    integration tests focus on Stage 5/6/7 (analyze / validate / publish)
    without re-running the entire 7-stage gating pipeline. Stage-gate
    enforcement is exercised by the unit tests
    (`tests/test_bluechall_validate.py::test_failed_stage5_audit_blocks_validate`,
    etc.). For tests that need a real init.py invocation, see
    `test_bluechall_init_dispatcher_*` below.

    NOTE: `canonical_flag` (manifest field) is the SINGLE source of truth
    for publish-time redaction. `solution/flag.txt` is solution metadata
    only — the publish CLI never reads it. Tests keep them aligned for
    realism, but mutating only the manifest still produces a correct
    redaction outcome.
    """
    challenge = event / slug
    challenge.mkdir()
    stages = {
        str(i): {"complete": True, "audit_verdict": "pass",
                 "audit_persona": None, "timestamp": "2026-05-04T00:00:00+00:00"}
        for i in range(1, 8)
    }
    manifest = {
        "slug": slug,
        "category": category,
        "recipe_id": recipe_id,
        "flag_emission": flag_emission,
        "lab_backend": lab_backend,
        "concept_refs": [_DEFAULT_CONCEPT_REF_BY_CATEGORY[category]],
        "cve_refs": [],
        "stages": stages,
        "lab_provenance": [],
        "canonical_flag": canonical_flag,
        "value": 200,
        "author": "integration-test",
    }
    (challenge / ".bluechall.manifest.yaml").write_text(
        yaml.safe_dump(manifest, default_flow_style=False, sort_keys=False),
        encoding="utf-8",
    )
    (challenge / "recipe.yaml").write_text(
        f"---\nid: {recipe_id}\nflag_emission: {flag_emission}\n---\n",
        encoding="utf-8",
    )
    for relpath, content in layout.items():
        target = challenge / relpath
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(content, encoding="utf-8")
    return challenge


# === Test 11.1 — bootstrap produces a 23-key .rules.env ====================


def test_bootstrap_produces_23_key_rules_env(tmp_path):
    """Stronger assertion than substring match: parse the rendered file
    via `rules_env.load` and verify all 23 keys parse with non-empty
    values. Catches malformed values (e.g., empty strings, invalid
    enum tokens) that the original substring check missed.
    """
    sys.path.insert(0, str(SCRIPTS))
    from _bcm_common import rules_env  # noqa: E402
    event = _bootstrap_event_repo(tmp_path)
    parsed = rules_env.load(event / ".rules.env")
    expected_keys = set(rules_env.WEBCHALL_KEYS) | set(rules_env.BLUECHALL_KEYS)
    assert expected_keys == set(rules_env.REQUIRED_KEYS)
    for key in expected_keys:
        assert key in parsed, f"missing key {key}"
        # Each key must have a value (parser already disallows expansion +
        # forbidden-var smuggling; we additionally require non-empty for
        # the keys with hard schema defaults).
        if key in (
            "CTF_EVENT_NAME", "CTF_EVENT_LONG_NAME",
            "FLAG_REGEX", "FLAG_FORMAT_LITERAL", "FLAG_TYPE",
            "CATEGORIES", "DIFFICULTIES",
            "HOST_PORT_RANGE_START", "HOST_PORT_RANGE_END",
            "PLAYER_FACING_LOCALE", "SPEC_LOCALE",
            "FORENSICS_TOOLCHAIN_PROFILE", "REVERSE_TOOLCHAIN_PROFILE",
            "BLUE_TEAM_QUESTION_LIMIT",
            "LAB_BACKEND_DEFAULT", "FLAG_EMISSION_DEFAULT",
            "EXTERNAL_FLAG_SERVICE_PORT_RANGE_START",
            "EXTERNAL_FLAG_SERVICE_PORT_RANGE_END",
            "MITRE_ATTACK_VERSION",
        ):
            assert parsed[key], f"key {key} has empty value: {parsed[key]!r}"
    # Validate semantic invariants: CATEGORIES contains a primary cat,
    # MITRE_ATTACK_VERSION matches v<NN>.<NN> pattern, port ranges are valid.
    rules_env.validate(parsed)  # raises ValueError on any schema violation


# === Test 11.2 + 11.3 — three-category demo matrix =========================


def _run_pipeline(challenge: Path) -> dict[str, subprocess.CompletedProcess]:
    """Run analyze (--no-runtime) → validate (--soft + strict) → publish.
    Returns a dict keyed by stage with the CompletedProcess."""
    out = {}
    out["analyze"] = _run(
        "bluechall_analyze.py", str(challenge), "--no-runtime", "--json",
    )
    out["validate_soft"] = _run(
        "bluechall_validate.py", str(challenge), "--soft", "--json",
    )
    out["validate_strict"] = _run(
        "bluechall_validate.py", str(challenge), "--json",
    )
    out["publish"] = _run("bluechall_publish.py", str(challenge))
    return out


def test_forensics_demo_stego_full_pipeline(tmp_path):
    event = _bootstrap_event_repo(tmp_path)
    challenge = _scaffold_challenge(
        event, slug="demo-stego", category="forensics",
        recipe_id="stego-image-lsb", flag_emission="single-static",
        lab_backend="docker",
        canonical_flag="FLAG{integration_stego_real_2026}",
        layout={
            "solution/solve.py": "# solver stub\n",
            "solution/flag.txt": "FLAG{integration_stego_real_2026}\n",
            "publish/cover.png": "fake-png-bytes",  # no flag in artifact
        },
    )
    results = _run_pipeline(challenge)

    # analyze: no critical, exit 0
    assert results["analyze"].returncode == 0, results["analyze"].stderr
    findings = json.loads(results["analyze"].stdout)
    assert all(f["severity"] != "critical" for f in findings)

    # validate --soft: exit 0 (downgrade), expect no real criticals
    assert results["validate_soft"].returncode == 0
    soft_findings = json.loads(results["validate_soft"].stdout)
    assert all(f["severity"] != "critical" for f in soft_findings)

    # validate strict: exit 0 (clean)
    assert results["validate_strict"].returncode == 0, results["validate_strict"].stdout

    # publish: 4 adapters? single-static skips sherlocks → 3 + advisory
    assert results["publish"].returncode == 0, results["publish"].stderr
    adapters = challenge / "adapters"
    assert (adapters / "ctfcli.yml").exists()
    assert (adapters / "rctf.yml").exists()
    assert (adapters / "picoctf.yml").exists()
    assert not (adapters / "sherlocks.yml").exists()
    assert "sherlocks" in results["publish"].stderr.lower()


def test_reverse_demo_vm_multi_stage_pipeline(tmp_path):
    event = _bootstrap_event_repo(tmp_path)
    challenge = _scaffold_challenge(
        event, slug="demo-vm", category="reverse",
        recipe_id="rev-vm-bytecode", flag_emission="multi-stage-pivot",
        lab_backend="docker",
        canonical_flag="FLAG{integration_vm_real_2026}",
        layout={
            "solution/solve.py": "# solver stub\n",
            # multi-stage-pivot canonical shape: top-level YAML list with
            # exactly one terminal entry (validated by
            # `flag_emission.validate_multi_stage_pivot`).
            "solution/stages.yaml": yaml.safe_dump([
                {"id": "s1", "requires": [],
                 "output_artifact": "stage1.out",
                 "unlock_token_format": r"^[A-Z]{8}$"},
                {"id": "s2", "requires": ["s1"],
                 "output_artifact": "flag.txt",
                 "unlock_token_format": r"^FLAG\{[!-~]+\}$",
                 "terminal": True},
            ], sort_keys=False),
            "publish/binary": "fake-elf-bytes",
        },
    )
    results = _run_pipeline(challenge)
    assert results["analyze"].returncode == 0, results["analyze"].stderr
    assert results["validate_strict"].returncode == 0, results["validate_strict"].stdout
    assert results["publish"].returncode == 0, results["publish"].stderr
    # multi-stage-pivot also skips Sherlocks (Sherlocks is questions-as-flags only)
    assert not (challenge / "adapters" / "sherlocks.yml").exists()


def test_blue_team_demo_ir_questions_pipeline(tmp_path):
    event = _bootstrap_event_repo(tmp_path)
    challenge = _scaffold_challenge(
        event, slug="demo-ir", category="blue-team",
        recipe_id="bt-malware-pe-ir", flag_emission="questions-as-flags",
        lab_backend="orbstack",
        canonical_flag="FLAG{integration_ir_real_2026}",
        layout={
            "solution/solve.py": "# solver stub\n",
            "solution/questions.yaml": yaml.safe_dump({
                "questions": [
                    {"id": "q1", "question": "PID?",
                     "answer": "FLAG{q1_pid_real_2026}",
                     "attack_technique": "T1055", "points": 50,
                     "nist_phase": "examination"},
                    {"id": "q2", "question": "C2?",
                     "answer": "FLAG{q2_c2_real_2026}",
                     "attack_technique": "T1071.001", "points": 75,
                     "nist_phase": "analysis"},
                ],
            }, sort_keys=False),
            "publish/triage.bundle": "fake-bundle",
        },
    )
    results = _run_pipeline(challenge)
    assert results["analyze"].returncode == 0, results["analyze"].stderr
    assert results["validate_strict"].returncode == 0, results["validate_strict"].stdout
    assert results["publish"].returncode == 0, results["publish"].stderr
    # questions-as-flags emits all 4 adapters
    adapters = challenge / "adapters"
    for name in ("ctfcli.yml", "rctf.yml", "picoctf.yml", "sherlocks.yml"):
        assert (adapters / name).exists(), f"missing {name}"

    # Sherlocks must contain both objectives
    sherlocks = yaml.safe_load((adapters / "sherlocks.yml").read_text())
    assert sherlocks["category"] == "blue-team"
    assert len(sherlocks["objectives"]) == 2
    assert sherlocks["objectives"][0]["nist_phase"] == "examination"
    assert sherlocks["objectives"][1]["nist_phase"] == "analysis"


def test_strict_validate_blocks_publish_when_placeholder(tmp_path):
    """Demo-flag canonical_flag must fail at validate stage and never
    reach publish (single source of truth: rules.PLACEHOLDER_PATTERNS)."""
    event = _bootstrap_event_repo(tmp_path)
    challenge = _scaffold_challenge(
        event, slug="demo-bad", category="forensics",
        recipe_id="stego-image-lsb", flag_emission="single-static",
        lab_backend="docker",
        canonical_flag="FLAG{l5b_st3g0_demo_2026}",  # demo-pattern flag
        layout={
            "solution/solve.py": "# x\n",
            "solution/flag.txt": "FLAG{l5b_st3g0_demo_2026}\n",
        },
    )
    r_validate = _run("bluechall_validate.py", str(challenge), "--json")
    assert r_validate.returncode == 1
    findings = json.loads(r_validate.stdout)
    assert any(f["rule_id"] == "placeholder-flag" for f in findings)


def test_no_flag_leak_in_adapters(tmp_path):
    """The 4 adapter files must not contain the canonical flag anywhere
    outside flag/flags/answer fields. We exercise both the literal-substring
    and base64-encoded leak paths via redact_flag_in_payload's structural
    walk; this is a smoke check that complements the unit tests in
    test_publish.py (which exhaustively cover the redact_flag_in_text
    encoding matrix).
    """
    event = _bootstrap_event_repo(tmp_path)
    challenge = _scaffold_challenge(
        event, slug="demo-clean", category="forensics",
        recipe_id="stego-image-lsb", flag_emission="single-static",
        lab_backend="docker",
        canonical_flag="FLAG{integration_no_leak_real_2026}",
        layout={
            "solution/solve.py": "# x\n",
            "solution/flag.txt": "FLAG{integration_no_leak_real_2026}\n",
            "publish/x.bin": "safe",
        },
    )
    r = _run("bluechall_publish.py", str(challenge))
    assert r.returncode == 0, r.stderr
    import base64
    flag = "integration_no_leak_real_2026"
    flag_full = "FLAG{integration_no_leak_real_2026}"
    flag_b64 = base64.b64encode(flag_full.encode()).decode().rstrip("=")
    for adapter in ("ctfcli.yml", "rctf.yml", "picoctf.yml"):
        text = (challenge / "adapters" / adapter).read_text()
        # Literal substring: appears exactly once (in flag/flags field).
        count = text.count(flag)
        assert count == 1, (
            f"{adapter}: canonical flag literal appears {count} times; "
            f"expected 1 (only in flag/flags field)"
        )
        # Encoded variants must NEVER appear (publish redacts them).
        assert flag_b64 not in text, (
            f"{adapter}: base64-encoded flag {flag_b64!r} present; "
            "publish-layer redaction failed"
        )


# === Test bluechall_init.py dispatcher (Section 8.1 trichotomy) ============


@pytest.mark.parametrize("category,recipe,emission", [
    ("forensics", "stego-image-lsb", "single-static"),
    ("reverse", "rev-vm-bytecode", "single-static"),
    ("blue-team", "bt-malware-pe-ir", "questions-as-flags"),
])
def test_bluechall_init_dispatcher_per_category(tmp_path, category, recipe, emission):
    """Exercise the init.py trichotomy that Section 13.1 names as a design
    decision. Without this, a broken init dispatcher would never fail any
    integration test (the other tests hand-craft the manifest).
    """
    event = _bootstrap_event_repo(tmp_path)
    slug = f"demo-init-{category.replace('-', '_')}"
    r = _run(
        "bluechall_init.py",
        "--slug", slug,
        "--category", category,
        "--recipe", recipe,
        "--lab-backend", "docker" if category != "blue-team" else "orbstack",
        "--flag-emission", emission,
        "--force",
        cwd=event,
    )
    # init may exit 0 (success) or, depending on recipe template completeness,
    # produce a partial scaffold and exit 0 with a stderr advisory. We
    # require it to NOT crash (exit != 3) and to leave a parseable manifest.
    assert r.returncode in (0, 1), (
        f"init.py crashed (exit {r.returncode}): "
        f"stdout={r.stdout!r} stderr={r.stderr!r}"
    )
    challenge = event / slug
    if r.returncode == 0:
        # Successful scaffold must produce a valid manifest.
        manifest_path = challenge / ".bluechall.manifest.yaml"
        assert manifest_path.exists(), f"init.py exit 0 but no manifest at {manifest_path}"
        m = yaml.safe_load(manifest_path.read_text())
        assert m["category"] == category
        assert m["flag_emission"] == emission
