---
id: cpp-x64-keygen
title: x86_64 native keygen with anti-IDA-F5 obfuscation
type: concept
category: reverse
subdomain: cpp-binary
owasp: []
mitre_attack:
- T1027
cwe: []
last_compiled: '2026-05-04'
sources:
- raw/papers/binary-obfuscation-survey-2023.md
- raw/papers/malware-re-taxonomy-sok-2023.md
- raw/flare-on-solutions/flare-on-2020-official-solutions.md
related:
- vm-bytecode-reverse
---

# x86_64 native keygen with anti-IDA-F5 obfuscation

The keygen-style challenge reduces to: solver receives a stripped x86_64 ELF that
checks an input string against a per-input transform; reverse the transform, write a
keygen, generate the canonical flag.

## Defensive challenge design

- Strip symbols (`-s`); set `OPTIMIZE_FLAG=-O2` so trivial inlining happens.
- Insert opaque predicates around the check function so IDA F5 produces wrong-looking
  code. Validate via `_bcm_common/binary_fuzz.py` rule `decompiler-trust`.
- Use a non-obvious crypto primitive (XOR + S-box + ARX rotation) to force solvers to
  reverse the transform rather than constraint-solve a black box.
- Mark every panic / debug-print path so the binary never leaks intermediate state.

## Bluechall mapping

Recipe `templates/reverse/rev-cpp-x64-keygen/` cites this concept. The Flare-On 7
`fidler` (.NET) and Flare-On 9 `complex` (Rust) challenges show genre-adjacent design;
`binary-obfuscation-survey-2023` gives the academic taxonomy.

