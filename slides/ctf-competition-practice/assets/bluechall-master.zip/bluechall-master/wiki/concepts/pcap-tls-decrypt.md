---
id: pcap-tls-decrypt
title: PCAP analysis with TLS decryption via SSLKEYLOGFILE
type: concept
category: forensics
subdomain: network
owasp:
- A02:2021
mitre_attack:
- T1071.001
cwe:
- CWE-319
last_compiled: '2026-05-04'
sources:
- raw/papers/network-forensics-survey-2024.md
- raw/ctf-writeups/googlectf-2023-weather.md
related:
- lsb-stego
---

# PCAP analysis with TLS decryption via SSLKEYLOGFILE

Modern application-layer forensics requires bridging the TLS-visibility gap. The
canonical pattern in CTF authoring: ship the pcap *and* an `SSLKEYLOGFILE` so Wireshark
can decrypt session keys, then hide the flag in an HTTP/2 header or gRPC frame inside
the decrypted stream.

## Defensive challenge design

- Generate the pcap with `tcpdump`, the SSLKEYLOG via the client's `SSL_KEYLOG_FILE`
  env var (Firefox / Chromium / curl with `--ssl-no-revoke`).
- Place the flag inside an HTTP/2 stream (not raw HTTP) to require the solver to
  trace stream multiplexing.
- Replay-test the decryption end-to-end inside the Docker compose lab.

## Bluechall mapping

Recipe `templates/forensics/network-pcap-tls/` cites this concept. The
`googlectf-2023-weather` boundary writeup demonstrates an extended firmware+pcap
correlation chain.

