---
id: vm-bytecode-reverse
title: Custom VM bytecode reverse engineering
type: concept
category: reverse
subdomain: custom-vm
owasp: []
mitre_attack:
- T1027
cwe: []
last_compiled: '2026-05-04'
sources:
- raw/papers/malware-re-taxonomy-sok-2023.md
- raw/flare-on-solutions/flare-on-2023-official-solutions.md
- raw/ctf-writeups/htb-ca-cave-system.md
related:
- cpp-x64-keygen
---

# Custom VM bytecode reverse engineering

Author-designed bytecode interpreters force solvers to (a) recover the dispatch
loop, (b) reconstruct the opcode-handler table, (c) decode encrypted bytecode blobs.
The dispatch loop is the canonical anchor for static analysis (Ghidra / IDA / radare)
and the symbolic-execution surface (angr / triton).

## Defensive challenge design

- Use a 16-32 opcode set with a single-dispatch jump table, not a switch — switch
  decompiles too cleanly with IDA F5.
- Encrypt the bytecode at rest; decrypt in `init` with a key the solver MUST extract
  from a separate stage (motivates `multi-stage-pivot` emission).
- Layer 1+ levels of register-renaming so naive trace-extraction yields garbage.

## Bluechall mapping

Recipe `templates/reverse/rev-vm-bytecode/` cites this concept. The Flare-On 10 `HVM`
challenge and HTB Cyber Apocalypse 2024 `Cave System` are the canonical references.

