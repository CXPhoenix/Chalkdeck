---
id: lsb-stego
title: LSB image steganography
type: concept
category: forensics
subdomain: stego
owasp: []
mitre_attack:
- T1027.003
cwe: []
last_compiled: '2026-05-04'
sources:
- raw/papers/steganalysis-sok-2023.md
related:
- pcap-tls-decrypt
---

# LSB image steganography

Least-Significant-Bit steganography hides payload bits in the lowest bit-plane of pixel
samples (and optionally G/R/A channels). Detection ranges from naive
`zsteg -a` exhaustive search to CNN-based universal steganalysis.

## Defensive challenge design

- Rotate which bit-plane carries the payload across regions of the image to defeat
  `zsteg -a` one-shot solving (anti-`zsteg -a` rule in `_bcm_common/artifact_fuzz.py`).
- Use random-permutation indexing on the pixel-coordinate space so contiguous LSB
  scanning yields garbage.
- Validate solution against the canonical extraction script in `solution/solve.py`.

## Bluechall mapping

Recipe `templates/forensics/stego-image-lsb/` cites this concept. The `lsb-stego`
subdomain tag (`stego`) is also referenced by the `steganalysis-sok-2023.md` survey.

