---
id: memory-vol3-windows
title: Windows memory triage with Volatility 3
type: concept
category: forensics
subdomain: memory
owasp: []
mitre_attack:
- T1055
- T1003.001
cwe: []
last_compiled: '2026-05-04'
sources:
- raw/papers/memory-forensics-survey-2024.md
- raw/ctf-writeups/htb-reminiscent.md
- raw/ctf-writeups/nahamcon-2024-raided.md
related:
- malware-pe-ir-multistage
---

# Windows memory triage with Volatility 3

Volatility 3 is the canonical Python framework for Windows / Linux / macOS memory
analysis. The plugin model exposes `windows.pslist`, `windows.cmdline`,
`windows.malfind`, `windows.netscan`, and many more.

## Defensive challenge design

- Generate the dump from a controlled OrbStack Ubuntu VM running the artefact-generation
  mode (`bluechall_orbstack.py --mode artifact-generation`).
- Pre-bake a process-injection scenario so `windows.malfind` surfaces the canonical
  `MZ` header in an RWX region.
- Use multi-stage-pivot emission: stage-1 = injected PID, stage-2 = C2 IPv4 from
  `netscan`, stage-3 = decrypted payload bytes.

## Bluechall mapping

Recipe `templates/forensics/memory-volatility-windows/` cites this concept. Boundary
writeup `htb-reminiscent` is the canonical multi-question reference; `nahamcon-2024-raided`
demonstrates the Linux memory analogue.

