---
title: A Survey of Embedded Firmware Analysis, Emulation, and Vulnerability Discovery
fetch_url: https://www.semanticscholar.org/search?q=firmware%20analysis%20survey%20emulation
fetch_date: '2026-05-04'
sha256: aaee3020d1ccddc4743a2184a8ac63696aedab5dec77f75b7994a63dd4153eb3
survey: true
subdomains:
- firmware
---
# Firmware Analysis — Survey of static unpacking, dynamic emulation, and vulnerability discovery (condensed summary)

This metadata page records that the bluechall wiki includes survey-grade material covering
the `firmware` reverse subdomain. Scope: binwalk-style header-driven unpacking, partial
re-hosting (Avatar², HALucinator), full-system emulation (QEMU virt, raspi3, mips/arm),
and Qiling-driven library symbolisation. Includes IoT-router and Cortex-M case studies
relevant to the bluechall QEMU lab backend.

## Subdomains covered

- firmware

## Key references

- Wright C., Moeglein W. A., Bagchi S., et al. *Challenges in firmware re-hosting, emulation, and analysis.* ACM Comp. Surveys 2021.
- Zaddach J., Bruno L., et al. *Avatar: A framework to support dynamic security analysis of embedded systems firmwares.* NDSS 2014.
- Clements A. A., Gustafson E., et al. *HALucinator: Firmware re-hosting through abstraction layer emulation.* USENIX Security 2020.

## Bluechall mapping

QEMU lab backend (`bluechall_qemu.py`, task 6.4) cites this bundle. Recipe
`rev-firmware-mips` (v0.2 scope) extends from this DNA.
