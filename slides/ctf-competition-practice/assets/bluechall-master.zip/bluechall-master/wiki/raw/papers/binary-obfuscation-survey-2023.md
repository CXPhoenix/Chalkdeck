---
title: A Survey of Binary Obfuscation, Packing, and Anti-Reverse-Engineering Techniques
fetch_url: https://www.semanticscholar.org/search?q=binary%20obfuscation%20survey
fetch_date: '2026-05-04'
sha256: d43228e72b4ac9efe9f522ad6b85f807623db9e04396e3b0feeb22f21df71a8a
survey: true
subdomains:
- obfuscation
- packer
---
# Binary Obfuscation & Packing — Survey of opaque predicates, control-flow flattening, and runtime packers (condensed summary)

This metadata page records that the bluechall wiki includes survey-grade material covering
the `obfuscation` and `packer` reverse-engineering subdomains. Scope: opaque-predicate
construction, control-flow flattening (Tigress), virtualisation-based obfuscation, runtime
packers (UPX, Themida, VMProtect), and unpacking-detection heuristics.

## Subdomains covered

- obfuscation
- packer

## Key references

- Collberg C., Thomborson C., Low D. *A taxonomy of obfuscating transformations.* Tech Report Univ. of Auckland 1997.
- Yadegari B., Johannesmeyer B., et al. *A generic approach to automatic deobfuscation of executable code.* IEEE S&P 2015.
- Banescu S., Pretschner A. *A tutorial on software obfuscation.* Advances in Computers 2018.

## Bluechall mapping

`templates/reverse/rev-cpp-x64-keygen/` (9.4) cites this bundle for the anti-IDA-F5
opaque-predicate design pattern.
