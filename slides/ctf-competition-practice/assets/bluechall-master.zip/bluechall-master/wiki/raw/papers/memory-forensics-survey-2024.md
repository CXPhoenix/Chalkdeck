---
title: A Comprehensive Survey of Memory Forensics on Modern Operating Systems
fetch_url: https://www.semanticscholar.org/search?q=memory%20forensics%20survey
fetch_date: '2026-05-04'
sha256: 0b98669c3fbbcf9bb187449dce8512047ac5363a5eb28cbc27db4a0d416aacd1
survey: true
subdomains:
- memory
---
# Memory Forensics — Survey of techniques across Windows, Linux, and macOS (condensed summary)

This metadata page records that the bluechall wiki includes survey-grade material covering
the `memory` forensics subdomain. The survey scope spans process-list reconstruction,
malicious code injection detection, kernel-pool tag analysis, hibernation-file recovery,
and Volatility 3 plugin design patterns. It cites Volatility, Rekall, and LiME as the
canonical tooling baseline.

## Subdomains covered

- memory

## Key references

- Volatility Foundation. Volatility 3 plugin documentation.
- Case A., Richard III G. G. *Memory Forensics: A Practitioner's Guide.* (2017+).
- Block S., Dewald A. *Linux memory forensics: Dissecting the user space process heap.* DFRWS USA 2017.

## Bluechall mapping

`templates/forensics/memory-volatility-windows/` (id 9.3) cites this paper bundle as the
foundational reference for the Windows memory-dump challenge family.
