---
title: 'SoK: Image Steganalysis in the Deep-Learning Era'
fetch_url: https://www.semanticscholar.org/search?q=steganalysis%20systematization%20deep%20learning
fetch_date: '2026-05-04'
sha256: a0c74f666f29eaaa0d944cef03df6ec4d12ff00084101d41b4919ed993af032f
survey: true
subdomains:
- stego
---
# Steganalysis — SoK of detection across LSB, F5, JPEG-domain, and deep-learning approaches (condensed summary)

This metadata page records that the bluechall wiki includes SoK-grade material covering
the `stego` forensics subdomain. Scope: spatial-domain LSB, JPEG-domain (F5, J-UNIWARD),
audio-domain stego, and CNN/transformer-based universal steganalysis. Includes adversarial
robustness considerations relevant to designing CTF challenges that resist `zsteg -a` and
`stegdetect` one-shot solutions.

## Subdomains covered

- stego

## Key references

- Boroumand M., Chen M., Fridrich J. *Deep residual network for steganalysis of digital images.* IEEE T-IFS 2019.
- Holub V., Fridrich J. *Universal distortion function for steganography in an arbitrary domain.* EURASIP J. on Information Security 2014.
- You W., Zhang H., Zhao X. *A Siamese CNN for Image Steganalysis.* IEEE T-IFS 2021.

## Bluechall mapping

`templates/forensics/stego-image-lsb/` (9.1) cites this bundle for the anti-`zsteg -a`
random-bit-plane design pattern.
