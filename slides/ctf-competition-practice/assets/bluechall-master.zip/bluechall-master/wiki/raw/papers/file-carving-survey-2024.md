---
title: A Survey of File Carving Algorithms and Disk-Image Forensic Recovery
fetch_url: https://www.semanticscholar.org/search?q=file%20carving%20survey%20forensics
fetch_date: '2026-05-04'
sha256: a72b243ff930dc1e758888ff56d161801918d233a08a7162be98a0d2b4a01730
survey: true
subdomains:
- disk
- file-repair
---
# File Carving — Survey of header/footer carving, fragmented-file recovery, and disk-image reconstruction (condensed summary)

This metadata page records that the bluechall wiki includes survey-grade material covering
the `disk` and `file-repair` forensics subdomains. Scope: header-footer carving (Foremost,
Scalpel), Bifragment Gap Carving, in-place file system reconstruction (TestDisk/PhotoRec),
and SQLite WAL/journal recovery.

## Subdomains covered

- disk
- file-repair

## Key references

- Garfinkel S. L. *Carving contiguous and fragmented files with fast object validation.* DFRWS 2007.
- Pal A., Memon N. *The Evolution of File Carving.* IEEE Signal Processing Magazine 2009.
- Casey E., Stellatos G. *The impact of full disk encryption on digital forensics.* OS Review 2008.

## Bluechall mapping

Provides DNA for `templates/forensics/disk-bifragment-recovery/` (v0.2 scope) and the
`bt-ransomware-disk-ir` recipe.
