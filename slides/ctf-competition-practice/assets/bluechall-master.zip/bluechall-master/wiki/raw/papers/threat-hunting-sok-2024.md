---
title: 'SoK: Hypothesis-Driven Threat Hunting and Sysmon/EVTX Analytics at Scale'
fetch_url: https://www.semanticscholar.org/search?q=threat%20hunting%20sysmon%20EVTX%20systematization
fetch_date: '2026-05-04'
sha256: 573f276aba19273c74f2ec094619b4ceeace7f35126aee6153ce0c9ace9cd5eb
survey: true
subdomains:
- log
- malicious-file
---
# Threat Hunting — SoK of log-driven IR, Sysmon/EVTX analytics, and ATT&CK-mapped detection (condensed summary)

This metadata page records that the bluechall wiki includes SoK-grade material covering
the `log` and `malicious-file` forensics subdomains. Scope: hypothesis-driven hunt loops,
Sigma rules, MITRE ATT&CK technique tagging, EVTX channel correlation, and the
"questions-as-flags" CTF Sherlocks pattern.

## Subdomains covered

- log
- malicious-file

## Key references

- Strom B., Applebaum A., et al. *MITRE ATT&CK: Design and philosophy.* MITRE Corp Technical Report 2018.
- HawkEye / Sigma project. Sigma rule format specification, GitHub.
- Mavroeidis V., Bromander S. *Cyber threat intelligence model: An evaluation of taxonomies, sharing standards, and ontologies.* EISIC 2017.

## Bluechall mapping

`templates/blue-team/bt-malware-pe-ir/` (9.6) cites this bundle for the multi-question
ATT&CK-tagged answer chain.
