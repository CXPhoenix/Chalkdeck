---
title: A Survey of Network Forensics Techniques and TLS-Era Visibility
fetch_url: https://www.semanticscholar.org/search?q=network%20forensics%20survey%20TLS
fetch_date: '2026-05-04'
sha256: f6f4b622ab0b9b9daa52941c26193e34699a3b89f5dc312776e3a66b01061a65
survey: true
subdomains:
- network
---
# Network Forensics — Survey of pcap analysis, TLS visibility, and replay (condensed summary)

This metadata page records that the bluechall wiki includes survey-grade material covering
the `network` forensics subdomain across pcap analysis, NetFlow/sFlow/IPFIX, TLS-era
endpoint visibility (sslkeylogfile, eBPF probes), and protocol replay techniques.

## Subdomains covered

- network

## Key references

- Pilli E. S., Joshi R. C., Niyogi R. *Network forensic frameworks: Survey and research challenges.* Digital Investigation 2010.
- Sikos L. F. *Packet analysis for network forensics: A comprehensive survey.* Forensic Science International: Digital Investigation 2020.
- Holmes A., Mortimer T. *Modern TLS Decryption for Incident Response.* SANS Reading Room 2023.

## Bluechall mapping

`templates/forensics/network-pcap-tls/` (9.2) cites this bundle for the pcap+sslkeylog
correlation pattern.
