---
fetch_url: https://nvlpubs.nist.gov/nistpubs/Legacy/SP/nistspecialpublication800-86.pdf
fetch_date: '2026-05-04'
sha256: c69afc8627485a95895efe4356326ee0786b48fe307b5f6e78ef407d7145d8f2
---
# NIST SP 800-86 — Guide to Integrating Forensic Techniques into Incident Response (condensed summary)

NIST Special Publication 800-86 (Kent, Chevalier, Grance, Dang; published August 2006) defines
the canonical four-phase digital-forensics process. Bluechall taxonomies and recipes MUST cite
this document as the authoritative source for forensic-process structure.

## The four forensic phases

1. **Collection** — Identify, label, record, and acquire data from possible sources of relevant
   data while following procedures that preserve the integrity of the data. Volatile data first
   (memory, network connections, running processes), then non-volatile (disk images, log files).
2. **Examination** — Forensically process collected data using a combination of automated and
   manual methods to assess and extract data of particular interest while preserving the
   integrity of the data. File carving, signature scanning, decoding, decompression sit here.
3. **Analysis** — Analyze the results of the examination, using legally justifiable methods and
   techniques, to derive useful information that addresses the questions that were the impetus
   for performing the collection and examination. Timelines, correlation, attribution.
4. **Reporting** — Report the results of the analysis, which may include describing the actions
   used, explaining how tools and procedures were selected, determining what other actions need
   to be performed (e.g., forensic examination of additional data sources), and recommending
   improvements to policies, procedures, tools, and other aspects of the forensic process.

## Bluechall mapping

- `wiki/taxonomies/nist-sp-800-86-phases.md` enumerates the four phases as a taxonomy page.
- `wiki/concepts/*.md` use `nist_phase: collection|examination|analysis|reporting` in
  frontmatter to anchor concepts to a phase.
- The skill's `bluechall_init.py` recipe wizard MUST surface a `nist_phase` selector for
  forensics-category challenges.

## Out-of-scope sections

The full publication also covers data sources (files, OS, network traffic, applications) and
the legal/policy framework. Bluechall references those sections by URL but does not mirror
their content here.
