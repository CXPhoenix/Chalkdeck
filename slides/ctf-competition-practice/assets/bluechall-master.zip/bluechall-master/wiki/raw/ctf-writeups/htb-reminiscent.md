---
fetch_url: https://www.hackthebox.com/blog/sherlock-reminiscent-walkthrough
fetch_date: '2026-05-04'
sha256: d7a53ca80b7059bb022f080a1afe9b6e67814b302b5caa9e26ff2a45541f5296
---
# HackTheBox Sherlock — Reminiscent (boundary case writeup, condensed summary)

Boundary classification: **memory forensics + malware analysis (blue-team)**.
Six-question Sherlock challenge centred on a Windows 10 memory dump infected by
emotet-style banking malware.

## Question chain (questions-as-flags pattern)

1. PID of the malicious process
2. C2 IPv4 first contacted
3. Persistence registry key
4. SHA-256 of the dropped payload
5. Distinct exfil destinations
6. Final IOC list (CSV)

## Bluechall relevance

This is the canonical reference for bluechall's `questions-as-flags` emission mode and
`bt-malware-pe-ir` template (id 9.6 / `templates/blue-team/bt-malware-pe-ir/`). The
six-question structure motivates the `BLUE_TEAM_QUESTION_LIMIT` schema field.
