---
fetch_url: https://www.hackthebox.com/blog/cyber-apocalypse-2024-cave-system-writeup
fetch_date: '2026-05-04'
sha256: f738360b8331e6a842b58bd13410d9559e8b98a35c3aa61e36f2ad0985806b4a
---
# HTB Cyber Apocalypse 2024 — Cave System (boundary case writeup, condensed summary)

Boundary classification: **custom-VM reverse + multi-stage pivot**. Solver navigates a
text-adventure-style binary whose core is a 32-opcode VM; subsequent stages unlock
files containing further VMs.

## Solution outline

1. Identify VM dispatch loop; recover opcode table.
2. Symbolic execute the level-1 VM with angr to find the "go to next room" sequence.
3. Decrypt level-2 ROM unlocked by level-1 path; repeat.
4. Three-stage flag concatenation.

## Bluechall relevance

Canonical reference for bluechall's `multi-stage-pivot` emission mode and
`templates/reverse/rev-vm-bytecode/` template (id 9.5).
