---
fetch_url: https://blog.hitcon.org/posts/2023/ac1750-writeup/
fetch_date: '2026-05-04'
sha256: 1a7cdd7d0550e8daccbd72b1d6b5f0f9c0c64fbfb6bbfab11acca01a77f9e9fa
---
# HITCON CTF 2023 — AC1750 (boundary case writeup, condensed summary)

Boundary classification: **firmware reverse + blue-team**. TP-Link AC1750 router
firmware extraction, kernel-module reverse, and timeline-style flag delivery.

## Solution outline

1. `binwalk -e` extracts squashfs (anti-`binwalk -e` defended in bluechall by
   `artifact_fuzz` rule `binwalk-one-shot`).
2. Inspect kernel module exposing IOCTL backdoor.
3. Reproduce trigger via QEMU `mips-linux-user` against the extracted httpd.
4. Timeline alignment between `dmesg`, `httpd` access log, and IOCTL response yields the
   final flag set.

## Why it's a boundary case

The challenge cleanly straddles firmware reverse-engineering (kernel-module RE) and
blue-team IR (multi-source-log timeline). Bluechall's `templates/reverse/rev-firmware-mips/`
(v0.2) and `templates/blue-team/bt-router-ir/` (v0.2) both descend from this DNA.
