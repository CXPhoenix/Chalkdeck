---
fetch_url: https://github.com/google/google-ctf/tree/main/2023/quals/hw-weather
fetch_date: '2026-05-04'
sha256: 986b361f07e8d2b8ee703e21eaed9acf4b665e95026c5e18aef6ec28f485eb32
---
# Google CTF 2023 — Weather (boundary case writeup, condensed summary)

Boundary classification: **firmware reverse + protocol forensics**. ESP32 firmware
image plus Bluetooth Low-Energy packet capture; flag emerges from correlating reversed
GATT-handler logic with the BLE pairing flow in the pcap.

## Solution outline

1. `binwalk` rejected by anti-binwalk padding; manual partition table parse required.
2. Symbolicate ESP32 image with Ghidra ESP32 loader; locate GATT write callback.
3. Replay BLE pairing pcap through `bluetoothctl` against an emulator; observe the
   challenge response.
4. Combine reverse-derived key with pcap nonce for flag.

## Bluechall relevance

Canonical example of firmware RE that requires network forensics to complete. Cited by
`templates/forensics/network-pcap-tls/` (id 9.2) for the protocol-correlation pattern
and by `templates/reverse/rev-firmware-esp32/` (v0.2 scope).
