---
fetch_url: https://www.hackthebox.com/blog/sherlock-subatomic-walkthrough
fetch_date: '2026-05-04'
sha256: da7fbc42cb9d29e12f635460127a0aab61fe67802bf70763252fa7de6df128c4
---
# HackTheBox Sherlock — Subatomic (boundary case writeup, condensed summary)

Boundary classification: **supply-chain forensics + reverse**. Trojanised Notion-clone
Electron app; investigator receives the installer plus a network capture from the
victim's first launch.

## Question chain

1. SHA-256 of the malicious `app.asar`
2. C2 domain contacted at startup
3. Encryption key embedded in the Electron preload script
4. Persistence mechanism (LaunchAgent / Run-key / cron)
5. Exfiltration size in bytes
6. Initial victim's hostname

## Bluechall relevance

Demonstrates the `supply-chain` flavour of blue-team challenges. Cited as boundary
case for the `bt-supply-chain-electron` recipe (v0.2 scope).
