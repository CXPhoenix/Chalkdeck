---
fetch_url: https://github.com/Nahamcon/CTF-Writeups/2024/raided
fetch_date: '2026-05-04'
sha256: e5aa59cc885b33b3f9782909215da1961a6fef7b59a7481071108e9f5bb289fe
---
# NahamCon 2024 — Raided (boundary case writeup, condensed summary)

Boundary classification: **memory forensics + reverse engineering**. Linux memory dump
plus an unstripped ELF; flag emerges from reconstructing the in-memory cleartext heap
of a self-decrypting binary.

## Solution outline

1. `vol3 linux.bash` recovers shell history pointing to `./crypter <input>`.
2. `vol3 linux.proc.Maps` locates the unmapped ANON region.
3. Static reverse on `crypter` reveals an in-place RC4 decryption keyed by argv[1].
4. Combine bash-history argument with extracted ANON bytes to recover the flag.

## Bluechall relevance

Cited as boundary reference for `templates/forensics/memory-volatility-windows/` (id
9.3) — demonstrates the *Linux* memory-forensics analogue and motivates extending the
template family to `memory-volatility-linux` (v0.2 scope).
