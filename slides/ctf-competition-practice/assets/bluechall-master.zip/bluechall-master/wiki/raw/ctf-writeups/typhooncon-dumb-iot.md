---
fetch_url: https://typhooncon.com/ctf/2023/dumb-iot-writeup
fetch_date: '2026-05-04'
sha256: 1aebfdd1dca41ea42db31f1b459bede072545c016c98d6fa6e180319f1228bb8
---
# TyphoonCon 2023 — Dumb IoT (boundary case writeup, condensed summary)

Boundary classification: **firmware reverse + blue-team**. ARM Cortex-M firmware blob
extracted from an IoT device flash dump; correlate with serial-console packet capture
to reach the flag.

## Solution outline

1. `binwalk -A` identifies thumb-mode entry; load into Ghidra with `Cortex-M` profile.
2. Locate uart-print routine; trace ascii-armored debug output.
3. Decode the captured serial pcap via `socat` + a custom xmodem-like script.
4. Correlate firmware print strings to pcap timestamps; the flag is encoded in the
   inter-print delays.

## Bluechall relevance

Canonical reference for `rev-firmware-arm-cortex-m` recipe (v0.2 scope) and the
side-channel-via-timing analysis pattern.
