---
fetch_url: https://www.mandiant.com/resources/blog/flare-on-7-challenge-solutions
fetch_date: '2026-05-04'
sha256: e4f7e59a735253d99e6024e87297953a2cc29f5339be56a43edadc64c9410b6a
---
# Flare-On 7 (2020) — report.xls (boundary case writeup, condensed summary)

Boundary classification: **document malware analysis + reverse engineering**.
Excel 4.0 macro (XLM) workbook that decodes a multi-stage payload.

## Solution outline

1. `oletools` (`olevba`, `oledump.py`) extracts hidden XLM sheet — but the macro is
   obfuscated by anti-debug-only execution paths (anti-`oletools` rule).
2. Manual XLM tracing via Excel-with-trust-disabled or `XLMMacroDeobfuscator`.
3. Decoded payload is shellcode launching a small interpreter; recover flag from the
   interpreter's final state.

## Bluechall relevance

Canonical example of `subdomain: malicious-file` (Office docs) combined with
`subdomain: obfuscation`. Cited by `artifact_fuzz` rule `oletools-one-shot` and by
`bt-malware-pe-ir` template's "embedded document" extension story.
