---
fetch_url: https://www.mandiant.com/resources/blog/flare-on-11-challenge-solutions
fetch_date: '2026-05-04'
sha256: 86152a3ea9ac2de6e6715d2ea0d320a08c4ea8c53eb617cfdf2b97876ed14ea3
---
# Flare-On 11 — sshd (boundary case writeup, condensed summary)

Boundary classification: **reverse + blue-team**. Demonstrates how a single binary
artefact (a backdoored sshd) can be solved either by static reverse-engineering of the
patched ELF or by incident-response-style timeline analysis of the supplied core dump
plus packet capture.

## Why it's a boundary case

- Authors shipped an unmodified `sshd` plus a patched-in backdoor that triggers on a
  specific TLS-extension byte sequence.
- Solvers split into two camps: pure-RE solvers patched out anti-debug and traced the
  malicious code path; IR-flavored solvers correlated `core` + `pcap` to identify the
  trigger without ever opening Ghidra.
- This dual-path solution motivates bluechall's `blue-team` first-class category and the
  `questions-as-flags` emission mode (multiple sub-questions about kill-chain stages).

## MITRE ATT&CK mapping

- T1554 (Compromise Client Software Binary)
- T1090 (Proxy)
- T1071.001 (Application Layer Protocol — Web Protocols)

## Bluechall reference

Recipe `bt-supply-chain-emulated-ssh` (v0.2) cites this writeup for the dual-path
narrative; Phase-A taxonomy `ctf-subdomains.md` lists this challenge as the canonical
boundary case under `subdomain: ssh-backdoor-ir`.
