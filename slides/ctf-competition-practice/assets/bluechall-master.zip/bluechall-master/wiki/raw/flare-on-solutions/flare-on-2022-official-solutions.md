---
fetch_url: https://www.mandiant.com/resources/blog/flare-on-9-challenge-solutions
fetch_date: '2026-05-04'
sha256: c5fa425ed51daed3b012993368f97557db45fbfa221afc827711031d09ae15f0
---
# Flare-On 9 (2022) — Mandiant official solutions (condensed summary)

Flare-On 9 ran September 2022 with 11 challenges. Notable for its breadth across
Rust binaries, Go binaries, custom encryption schemes, and a Windows kernel driver.

## Challenge index (selected)

1. flaredle — wordle clone in JS — `obfuscation`
2. pipe — Bash + Python pipe chain — `compiled-python`
3. magic 8 ball — Unity / IL2CPP — `dotnet-java`
4. burning down the house — Win32 PE custom encryption — `cpp-binary`
5. complex — Rust binary, hand-rolled crypto — `rust`
6. ezpz — Go binary, `go` calling convention — `go`
7. anode — Node.js single executable application — `compiled-python` (script wrapper)
8. backdoor — Windows kernel driver — `cpp-binary` + `firmware`
9. encryptor — multi-platform Go ransomware sim — `go`
10. nur ner mol — anti-debug Win32 — `obfuscation`
11. The Challenge That Shall Not Be Named — multi-stage Rust + WASM — `rust`

## Bluechall relevance

The Rust `complex` and `The Challenge That Shall Not Be Named` solutions document
the rustc symbol-mangling and trait-dispatch pattern used by bluechall's
`rev-rust-async` template (v0.2).
