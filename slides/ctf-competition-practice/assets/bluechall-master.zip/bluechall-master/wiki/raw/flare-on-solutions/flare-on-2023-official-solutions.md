---
fetch_url: https://www.mandiant.com/resources/blog/flare-on-10-challenge-solutions
fetch_date: '2026-05-04'
sha256: b8cfda56554aede45a978e38e64a01175c49a92642528894ed3b6bf55a5027d2
---
# Flare-On 10 (2023) — Mandiant official solutions (condensed summary)

Flare-On 10 ran September 2023 with 14 challenges. Notable expansion of dotnet/Unity
challenges and inclusion of multiple firmware-flavored stages.

## Challenge index (selected)

1. X — Win32 keygen — `cpp-binary`
2. ItsOnFire — packed PE — `packer`
3. HxD — hex-editor plugin reverse — `cpp-binary`
4. aimbot — Unity / IL2CPP cheat — `dotnet-java`
5. fullspeed — Go binary high-performance — `go`
6. flake — Rust binary with custom VM — `rust` + `custom-vm`
7. where_is_the_file_lebowski — JavaScript + WebAssembly — `obfuscation`
8. game — Unity multiplayer reverse — `dotnet-java`
9. mypassion — Win32 obfuscated JS engine — `obfuscation`
10. kupo — Final-Fantasy-themed Go ransomware sim — `go`
11. y0da — anti-AV Win32 — `cpp-binary`
12. HVM — custom VM with garbage collector — `custom-vm`
13. y0us0lvedit — composite, Rust — `rust`
14. Final — meta-stage — multi-stage

## Bluechall relevance

`HVM` is the canonical custom-VM-with-GC reference cited by recipe
`rev-vm-bytecode` (challenge id 9.5 / `templates/reverse/rev-vm-bytecode/`).
