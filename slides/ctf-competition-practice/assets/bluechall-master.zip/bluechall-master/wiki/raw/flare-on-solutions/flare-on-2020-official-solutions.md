---
fetch_url: https://www.mandiant.com/resources/blog/flare-on-7-challenge-solutions
fetch_date: '2026-05-04'
sha256: 3c5839af69427df2eeba613cc5938873f25b93693c1ec87e24812c520d10f80d
---
# Flare-On 7 (2020) — Mandiant official solutions (condensed summary)

Flare-On 7 ran October 2020 with 11 challenges. Mandiant published per-challenge solution
PDFs covering reverse-engineering walkthroughs.

## Challenge index (id — title — primary subdomain)

1. fidler — .NET CrackMe — `dotnet-java`
2. garbage — packed Win32 PE, custom packer — `packer` + `cpp-binary`
3. wednesday — Windows GUI ransomware sim — `cpp-binary`
4. report.xls — Excel 4.0 macro / XLM weaponisation — `malicious-file` (boundary case;
   pure document forensics with anti-AMSI tricks)
5. tkapp — Tcl/Tk wrapped Python — `compiled-python`
6. codeit — QR-code-driven obfuscated loader — `obfuscation`
7. re_crowd — multi-binary reverse — `cpp-binary`
8. aardvark — packed PE-32 with anti-debug — `packer`
9. crackinstaller — MSI + custom action — `cpp-binary`
10. break — VM/bytecode interpreter — `custom-vm`
11. CodeIt — final composite — multi-stage

## Bluechall relevance

Challenge `report.xls` is the canonical boundary case demonstrating that pure-document
forensics can act as a reverse-engineering challenge. It motivates bluechall's
`blue-team` first-class category absorbing hybrid IR/forensics/malware-analysis flavors.
