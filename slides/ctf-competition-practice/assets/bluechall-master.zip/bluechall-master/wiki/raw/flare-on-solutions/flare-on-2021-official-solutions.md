---
fetch_url: https://www.mandiant.com/resources/blog/flare-on-8-challenge-solutions
fetch_date: '2026-05-04'
sha256: 2bb6aa998f703831a5186ea14b78e505541a7919ca9cc53af83b544d28d70475
---
# Flare-On 8 (2021) — Mandiant official solutions (condensed summary)

Flare-On 8 ran October 2021 with 10 challenges spanning Windows native, Android,
Excel-4.0 macro, and custom-VM bytecode.

## Challenge index (selected)

1. credchecker — JavaScript / Node — `obfuscation`
2. know_your_assembly — x86 hand-crafted assembly — `cpp-binary`
3. antioch — packed Win32 — `packer`
4. myaquaticlife — Adobe AIR / SWF — `obfuscation`
5. spel — Spell-corrected x86 keygen — `cpp-binary`
6. PETTHEKITTY — Win32 PE, anti-debug — `cpp-binary`
7. spellblade — Apple Silicon ARM64 — `cpp-binary` + `firmware`
8. beelogin — Win32 .NET keygen — `dotnet-java`
9. evil — VM bytecode interpreter — `custom-vm`
10. wizardcult — final stage, Go binary — `go`

## Bluechall relevance

`spellblade` is one of the earliest Apple-Silicon ARM64 RE challenges in mainstream CTF;
referenced by recipe `rev-arm64-macos` (v0.2 scope).
