---
fetch_url: https://www.mandiant.com/resources/blog/flare-on-11-challenge-solutions
fetch_date: '2026-05-04'
sha256: f6da36286625eb8e0b17d5f9379ce35683c5557ec73c9d334502f1da850e887a
---
# Flare-On 11 (2024) — Mandiant official solutions (condensed summary)

Flare-On 11 ran October 2024 with 10 challenges. Notable for the `sshd` challenge
that mimics the XZ Utils backdoor (CVE-2024-3094) supply-chain technique inside an
emulated SSH daemon.

## Challenge index (selected)

1. frollic — JS + Lua — `obfuscation`
2. checksum — x86 anti-disasm — `cpp-binary`
3. aray — Yara-rule reversal — `obfuscation`
4. Meme Maker 3000 — Web + WASM — `obfuscation`
5. sshd — Emulated OpenSSH with backdoor — `firmware` + `malicious-file` (canonical
   XZ-Utils-style supply-chain RE primer)
6. bunnyhop — Win32 packed — `packer`
7. fullspeed2 — Go binary — `go`
8. clearlyaplant — Unity decoy — `dotnet-java`
9. serpentine — Python anti-debug — `compiled-python`
10. CatBert — composite multi-binary — multi-stage

## Bluechall relevance

`sshd` is the canonical reference for bluechall's `bt-supply-chain-emulated-ssh` recipe
(v0.2 scope). The challenge demonstrates how a reverse-engineering challenge can be
framed as an incident-response narrative — directly motivating the `blue-team` category
absorbing hybrid flavors.
