---
fetch_url: https://attack.mitre.org/versions/v15/
fetch_date: '2026-05-04'
sha256: 94e17d708bd6ec5f4a5675d22e3c73aa94780b6c07f970f8fedf96ee17630bb4
---
# MITRE ATT&CK v15 — Enterprise Matrix snapshot (condensed summary)

MITRE ATT&CK v15 (Enterprise) released by The MITRE Corporation; this condensed summary
captures the v15 enterprise-matrix tactics and the technique-id format that bluechall
concept and recipe pages cite via `mitre_attack:` frontmatter fields.

## Enterprise tactics (left-to-right kill-chain order)

1. **Reconnaissance (TA0043)** — pre-compromise information gathering
2. **Resource Development (TA0042)** — adversary infrastructure / capability acquisition
3. **Initial Access (TA0001)** — entry into network
4. **Execution (TA0002)** — adversary-controlled code execution
5. **Persistence (TA0003)** — maintaining foothold across reboots/credential changes
6. **Privilege Escalation (TA0004)** — gaining higher-level permissions
7. **Defense Evasion (TA0005)** — avoiding detection
8. **Credential Access (TA0006)** — stealing credentials
9. **Discovery (TA0007)** — internal environment learning
10. **Lateral Movement (TA0008)** — pivoting through environment
11. **Collection (TA0009)** — gathering data of interest
12. **Command and Control (TA0011)** — communication with controlled systems
13. **Exfiltration (TA0010)** — data theft
14. **Impact (TA0040)** — disrupt availability or integrity

## Technique-id format

Top-level techniques use the form `T<NNNN>` (for example `T1059 — Command and Scripting
Interpreter`). Sub-techniques append a dot and three digits: `T1059.001 — PowerShell`,
`T1059.003 — Windows Command Shell`. Bluechall concept frontmatter accepts a CSV of these
identifiers; recipe pages additionally accept tactic IDs (e.g., `TA0008`).

## v15-specific notes

v15 (released 2024) introduced minor structural cleanup to ICS and Mobile matrices but did
not renumber existing enterprise techniques. The schema bluechall depends on (technique-id
format, tactic IDs, sub-technique notation) is stable across v14→v15→v16. Recipes that pin
`MITRE_ATTACK_VERSION=v15.x` SHALL accept any v15.x patch revision.

## Bluechall mapping

- `wiki/taxonomies/mitre-attack.md` enumerates the 14 enterprise tactics.
- `_bcm_common/rules_env.py` exposes `MITRE_ATTACK_VERSION` (default `v15.1`).
- `bluechall-flag-emission` `questions-as-flags` mode requires every question to declare
  `attack_technique:` matching this taxonomy.
