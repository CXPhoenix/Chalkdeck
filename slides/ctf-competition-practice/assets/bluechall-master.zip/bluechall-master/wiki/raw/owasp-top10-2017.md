---
fetch_url: https://owasp.org/www-project-top-ten/2017/
fetch_date: '2026-05-04'
sha256: 4cecee6e5843e2aae57d4d54aba52e3a095a27bb422c7af6446b0b358a7dbb4b
---
# OWASP Top 10 — 2017 — condensed summary

- **A1 Injection**
- **A2 Broken Authentication**
- **A3 Sensitive Data Exposure**
- **A4 XML External Entities (XXE)**
- **A5 Broken Access Control**
- **A6 Security Misconfiguration**
- **A7 Cross-Site Scripting (XSS)**
- **A8 Insecure Deserialization**
- **A9 Using Components with Known Vulnerabilities**
- **A10 Insufficient Logging & Monitoring**
