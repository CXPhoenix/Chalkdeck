---
id: qiling
title: "Qiling \u2014 emulation framework for cross-platform binary execution"
type: framework
tool_class: firmware
last_compiled: '2026-05-04'
applicable_concepts:
- vm-bytecode-reverse
cves: []
sources:
- raw/papers/firmware-analysis-survey-2024.md
---

# Qiling — emulation framework

Qiling (built on Unicorn engine) provides cross-platform binary emulation with
syscall-level and library-level abstraction. Useful for emulating IoT firmware
without full system QEMU when the binary's syscall surface is small.

## Bluechall mapping

Bluechall's `bluechall_qemu.py` user-mode wrapper falls back to Qiling for binaries
where `qemu-user` syscall stubs are missing. The firmware-analysis survey paper
documents the Qiling-vs-QEMU-vs-HALucinator trade-offs.

