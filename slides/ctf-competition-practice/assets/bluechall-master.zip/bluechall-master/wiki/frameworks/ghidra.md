---
id: ghidra
title: "Ghidra \u2014 NSA-released SRE framework for binary reverse engineering"
type: framework
tool_class: binary
last_compiled: '2026-05-04'
applicable_concepts:
- cpp-x64-keygen
- vm-bytecode-reverse
cves: []
sources:
- raw/papers/malware-re-taxonomy-sok-2023.md
- raw/papers/binary-obfuscation-survey-2023.md
---

# Ghidra — Software Reverse-Engineering framework

NSA-released open-source SRE platform supporting x86 / x86_64 / ARM / MIPS / PowerPC /
RISC-V architectures. Ships a Java/Eclipse-based UI, a Python (Jython) and JShell
scripting surface, and the GhidraScript / Headless Analyzer for batch processing.

## Bluechall mapping

Default decompiler for `templates/reverse/rev-cpp-x64-keygen/` (id 9.4) and
`templates/reverse/rev-vm-bytecode/` (id 9.5). The `_bcm_common/binary_fuzz.py`
rule `decompiler-trust` invokes the Headless Analyzer to detect IDA-F5-style
clean decompilation paths and emits a critical when the decompiled output reveals
the flag-check predicate too literally.

