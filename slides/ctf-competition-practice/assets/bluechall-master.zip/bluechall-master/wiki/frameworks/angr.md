---
id: angr
title: "angr \u2014 Python binary analysis with symbolic execution"
type: framework
tool_class: binary
last_compiled: '2026-05-04'
applicable_concepts:
- cpp-x64-keygen
- vm-bytecode-reverse
cves: []
sources:
- raw/papers/malware-re-taxonomy-sok-2023.md
---

# angr — Python binary-analysis framework

angr (UCSB SecLab) provides static + dynamic + symbolic-execution analysis over
multiple architectures via the VEX intermediate representation. Bluechall solution
scripts use angr to validate that a challenge is *solvable* by symbolic execution
within a configurable timeout — challenges where angr finds the flag in under 60
seconds are flagged as too easy by `_bcm_common/binary_fuzz.py`.

## Bluechall mapping

Used in `templates/reverse/rev-vm-bytecode/solution/solve.py` to symbolically
explore the VM dispatch loop. Keygen-style challenges (id 9.4) test angr-with-timeout
to ensure they can be solved but not trivially.

