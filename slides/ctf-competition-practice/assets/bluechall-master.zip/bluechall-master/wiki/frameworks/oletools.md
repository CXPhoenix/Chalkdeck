---
id: oletools
title: "oletools \u2014 Office Open XML / OLE / XLM analysis"
type: framework
tool_class: binary
last_compiled: '2026-05-04'
applicable_concepts:
- malware-pe-ir-multistage
cves: []
sources:
- raw/papers/threat-hunting-sok-2024.md
- raw/ctf-writeups/flare-on-7-report-xls.md
---

# oletools — Office / OLE / XLM analysis

`oletools` (Decalage) is the canonical Python toolkit for Office-document static
analysis: `olevba` (VBA / XLM extraction), `oledump.py` (OLE stream dump),
`mraptor` (heuristic macro classification), `pyxlsb2` (Excel-binary parser).

## Bluechall mapping

`_bcm_common/artifact_fuzz.py` rule `oletools-one-shot` flags Office-document
challenges where running `olevba` or `oledump.py` returns the flag-check macro
verbatim. The Flare-On 7 `report.xls` boundary writeup motivates the rule.

