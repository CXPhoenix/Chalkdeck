---
id: volatility3
title: "Volatility 3 \u2014 Windows / Linux / macOS memory analysis framework"
type: framework
tool_class: memory
last_compiled: '2026-05-04'
applicable_concepts:
- memory-vol3-windows
- malware-pe-ir-multistage
cves: []
sources:
- raw/papers/memory-forensics-survey-2024.md
---

# Volatility 3 — Windows / Linux / macOS memory analysis framework

Volatility 3 (Python 3) is the canonical memory-forensics framework. It supersedes
Volatility 2 with a typed plugin model, on-disk symbol-table caching, and faster
profile detection.

## Plugin families

- `windows.pslist`, `windows.psscan`, `windows.cmdline` — process triage
- `windows.malfind`, `windows.injectsec` — injection detection
- `windows.netscan`, `windows.netstat` — connection reconstruction
- `linux.bash`, `linux.proc.Maps`, `linux.lsmod` — Linux analogues
- `mac.pslist`, `mac.lsmod` — macOS analogues

## Bluechall mapping

`templates/forensics/memory-volatility-windows/` invokes Volatility 3 inside the
solution container. The `_bcm_common/lab_helpers.py` `vm_session` context manager
captures memory dumps from the OrbStack VM that Volatility 3 then triages.

