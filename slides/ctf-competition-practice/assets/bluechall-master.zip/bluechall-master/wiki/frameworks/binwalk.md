---
id: binwalk
title: "binwalk \u2014 firmware and embedded-blob analysis tool"
type: framework
tool_class: firmware
last_compiled: '2026-05-04'
applicable_concepts:
- vm-bytecode-reverse
cves: []
sources:
- raw/papers/firmware-analysis-survey-2024.md
- raw/ctf-writeups/hitcon-ac1750.md
---

# binwalk — firmware blob analysis

`binwalk` scans firmware blobs for embedded file-system signatures (squashfs, jffs2,
cramfs, ubifs, tar, gzip, etc.), extracts them with `binwalk -e`, and supports
matryoshka-style recursive extraction.

## Bluechall mapping

`_bcm_common/artifact_fuzz.py` rule `binwalk-one-shot` flags firmware challenges
where `binwalk -Me` extracts a file-system containing the flag verbatim. Defended
in `templates/reverse/rev-firmware-mips/` (v0.2) by adding nonstandard partition
headers that require manual table parsing.

