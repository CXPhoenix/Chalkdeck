---
id: yara
title: "YARA \u2014 IOC matching and malware classification rules"
type: framework
tool_class: binary
last_compiled: '2026-05-04'
applicable_concepts:
- malware-pe-ir-multistage
cves: []
sources:
- raw/papers/threat-hunting-sok-2024.md
- raw/papers/malware-re-taxonomy-sok-2023.md
---

# YARA — pattern-matching for malware classification

YARA (Virustotal) provides byte / string / hex pattern matching with conditional
combinators, used widely for malware-family classification, IOC matching, and
process-memory scanning.

## Bluechall mapping

Blue-team challenges (`templates/blue-team/bt-malware-pe-ir/`, id 9.6) ship YARA
rules that questions can require the solver to author or extend. The
`questions-as-flags` emission mode permits a question whose answer is "the YARA
rule fingerprint" — the solver writes the rule, the validator verifies it matches
the malicious sample but not the benign baseline.

