---
id: wireshark
title: "Wireshark \u2014 pcap analysis and protocol dissection"
type: framework
tool_class: network
last_compiled: '2026-05-04'
applicable_concepts:
- pcap-tls-decrypt
cves: []
sources:
- raw/papers/network-forensics-survey-2024.md
---

# Wireshark — pcap analysis and protocol dissection

Wireshark provides 3000+ protocol dissectors, TLS-decryption via SSLKEYLOGFILE,
HTTP/2 stream reassembly, gRPC frame parsing, and a Lua dissector API for custom
protocols. The CLI variant `tshark` is bluechall's default for solution scripts.

## Bluechall mapping

`templates/forensics/network-pcap-tls/` (id 9.2) ships an SSLKEYLOGFILE alongside
the pcap. Solution scripts use `tshark -K <keylog> -Y http2`.

