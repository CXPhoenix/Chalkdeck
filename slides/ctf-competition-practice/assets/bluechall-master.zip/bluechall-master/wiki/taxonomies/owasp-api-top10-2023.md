---
id: owasp-api-top10-2023
title: "OWASP API Security Top 10 \u2014 2023"
type: taxonomy
last_compiled: '2026-05-04'
sources:
- raw/owasp-api-top10-2023.md
---

# OWASP API Security Top 10 — 2023 (taxonomy)

This taxonomy enumerates the API-specific risk categories from the OWASP API Security
project's 2023 edition. Bluechall pages MAY tag with any of these IDs via `owasp_api:`
or, for combined coverage, by including them in the regular `owasp:` CSV field.

## 2023 categories

- API1:2023 Broken Object Level Authorization
- API2:2023 Broken Authentication
- API3:2023 Broken Object Property Level Authorization
- API4:2023 Unrestricted Resource Consumption
- API5:2023 Broken Function Level Authorization
- API6:2023 Unrestricted Access to Sensitive Business Flows
- API7:2023 Server-Side Request Forgery
- API8:2023 Security Misconfiguration
- API9:2023 Improper Inventory Management
- API10:2023 Unsafe Consumption of APIs

## Bluechall mapping

API-specific categories appear most often in `bt-api-misconfig-ir` and similar
blue-team recipes that examine artefacts produced by attacks against API endpoints
(e.g., NetFlow showing API4 abuse, audit logs showing API1 enumeration).

