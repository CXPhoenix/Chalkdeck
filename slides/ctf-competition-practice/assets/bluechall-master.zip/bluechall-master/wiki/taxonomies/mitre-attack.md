---
id: mitre-attack
title: "MITRE ATT&CK \u2014 Enterprise tactics taxonomy"
type: taxonomy
last_compiled: '2026-05-04'
sources:
- raw/mitre-attack-v15-snapshot.md
---

# MITRE ATT&CK — Enterprise tactics (taxonomy)

This taxonomy enumerates the 14 enterprise tactics of MITRE ATT&CK and the technique-id
format that bluechall concept and recipe pages use in their `mitre_attack:` frontmatter
field. The pinned default is `MITRE_ATTACK_VERSION=v15.1` (configurable via `.rules.env`).

## Enterprise tactics

- TA0043 Reconnaissance
- TA0042 Resource Development
- TA0001 Initial Access
- TA0002 Execution
- TA0003 Persistence
- TA0004 Privilege Escalation
- TA0005 Defense Evasion
- TA0006 Credential Access
- TA0007 Discovery
- TA0008 Lateral Movement
- TA0009 Collection
- TA0011 Command and Control
- TA0010 Exfiltration
- TA0040 Impact

## Technique-id format

Top-level techniques: `T<NNNN>` (e.g., `T1059 — Command and Scripting Interpreter`).
Sub-techniques: dot-separated three-digit suffix (`T1059.001 — PowerShell`,
`T1059.003 — Windows Command Shell`).

## Bluechall mapping

`questions-as-flags` flag-emission mode requires every question to declare an
`attack_technique:` field that MUST exist in the version pinned by
`MITRE_ATTACK_VERSION`. The validator at `_bcm_common/flag_emission.py` enforces this.

