---
id: nist-sp-800-86-phases
title: "NIST SP 800-86 \u2014 four-phase forensic process taxonomy"
type: taxonomy
last_compiled: '2026-05-04'
sources:
- raw/nist-sp-800-86.md
---

# NIST SP 800-86 — Forensic process phases (taxonomy)

This taxonomy enumerates the four phases of the NIST SP 800-86 digital-forensics
process. Bluechall concept pages and forensics-category recipes set `nist_phase:` to
one of the four enum values to anchor the artefact in the canonical workflow.

## Phases

- **collection** — identify, label, record, and acquire data from possible sources
  while preserving integrity. Volatile data first.
- **examination** — forensic processing of collected data: file carving, signature
  scanning, decoding, decompression, format normalization.
- **analysis** — correlation and timeline reconstruction yielding answers to the
  investigation's questions.
- **reporting** — communicating findings, methodologies, and recommended improvements.

## Bluechall mapping

The `bluechall_init.py` recipe wizard surfaces a `nist_phase` selector when the
operator chooses `category: forensics`. The `wiki find --nist-phase analysis` CLI
returns all concept pages anchored to a given phase.

