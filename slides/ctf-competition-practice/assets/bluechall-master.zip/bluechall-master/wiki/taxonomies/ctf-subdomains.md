---
id: ctf-subdomains
title: Bluechall CTF subdomain taxonomy (forensics + reverse + blue-team)
type: taxonomy
last_compiled: '2026-05-04'
sources:
- raw/papers/memory-forensics-survey-2024.md
- raw/papers/malware-re-taxonomy-sok-2023.md
- raw/papers/network-forensics-survey-2024.md
- raw/papers/steganalysis-sok-2023.md
- raw/papers/file-carving-survey-2024.md
- raw/papers/threat-hunting-sok-2024.md
- raw/papers/binary-obfuscation-survey-2023.md
- raw/papers/firmware-analysis-survey-2024.md
- raw/ctf-writeups/flare-on-11-sshd.md
---

# Bluechall CTF subdomain taxonomy

Three first-class categories — `forensics`, `reverse`, `blue-team` — and their
canonical subdomains. The `blue-team` category absorbs all hybrid IR/malware-analysis
flavours (per design decision). `misc` is allowed as a fallback only.

## forensics subdomains

- `file-repair` — corrupted-header recovery, partial-file reconstruction
- `stego` — image / audio / file steganography
- `network` — pcap / NetFlow analysis, TLS visibility
- `memory` — RAM dump triage (Windows / Linux / macOS)
- `disk` — disk-image carving, file-system reconstruction
- `log` — EVTX / syslog / audit-trail correlation
- `malicious-file` — Office docs, PDFs, scripts under inspection (no behaviour assumed)

## reverse subdomains

- `cpp-binary` — C/C++ native ELF / Mach-O / PE
- `rust` — rustc-mangled binaries
- `go` — Go-runtime binaries with pcln tables
- `compiled-python` — pyinstaller, py2exe, Nuitka, packed `.pyc`
- `dotnet-java` — .NET / IL2CPP / JVM-class-file challenges
- `firmware` — embedded systems, MIPS / ARM / Cortex-M / firmware blobs
- `custom-vm` — author-designed bytecode interpreters
- `packer` — runtime packers (UPX, Themida, VMProtect)
- `obfuscation` — opaque predicates, control-flow flattening, virtualised obfuscation

## blue-team subdomains (hybrid absorption)

- `malware-pe-ir` — Windows PE under IR with EVTX + pcap
- `supply-chain` — trojanised installer / CI-injected backdoor
- `ransomware-ir` — disk + memory + network IR for ransomware infection
- `router-ir` — embedded-device IR with firmware reverse component
- `webapp-ir` — webserver-log-driven application-attack IR

## Bluechall mapping

`_bcm_common/rules_env.py` `CATEGORIES` enum requires at least one of forensics /
reverse / blue-team in the `.rules.env` `CATEGORIES` field. Recipe pages set
`subdomain:` to one of the values listed above.

