---
name: bluechall-master
description: "Author production-grade Forensics, Reverse, and Blue-Team CTF challenges. Use when the user asks to 出 forensics ctf 題、出 reverse ctf 題、create a forensics/reverse challenge, scaffold a Volatility/Wireshark/Ghidra/angr CTF, design a stego/network-forensics/memory-dump/keygen/VM-bytecode challenge, build a Sherlocks-style multi-question incident response challenge, validate or analyze an existing challenge for unintended solves, publish a challenge bundle for CTFd/rCTF/picoCTF/Sherlocks-Q. Drives a fixed seven-stage pipeline (Brief → Design → Scaffold → Implement → Analyze → Validate → Publish) with a sub-agent audit gate after every stage. Do NOT trigger when the user is only reading or explaining the bundled scripts, only inspecting the wiki, or asking conceptual questions without intent to author or operate on a challenge."
license: MIT
compatibility:
  system_packages:
    - "Python 3.10+"
    - "Docker (only required for the Docker Compose lab backend; --no-runtime skips it)"
    - "OrbStack (optional, macOS-only; only required for the OrbStack Linux VM lab backend)"
    - "QEMU binaries (optional; qemu-{mips,arm,aarch64}-static for user-mode, qemu-system-arm for system-mode)"
  python_packages:
    - "pyyaml>=6.0"
    - "jinja2>=3.1"
    - "httpx>=0.27"
    - "scapy>=2.5"
    - "volatility3>=2.5"
    - "pefile>=2023.2"
    - "oletools>=0.60"
    - "yara-python>=4.5"
    - "capstone>=5.0"
    - "pyelftools>=0.30"
    - "pytest>=8.0"
metadata:
  author: bluechall-master
  version: "0.1"
  generatedBy: "Spectra"
---

> **English** | [繁體中文](SKILL.zhTW.md)

# Overview

`bluechall-master` is a user-skill that authors **defensive / analytical** CTF
challenges end-to-end — Forensics, Reverse, and Blue-Team (IR-flavoured)
categories. It is the sister skill of `webchall-master` (offensive / web
exploitation) and shares the same authoring discipline. It bundles:

- A seven-stage authoring pipeline (Brief → Design → Scaffold → Implement →
  Analyze → Validate → Publish), with a mandatory adversary audit at every
  stage boundary using six personas.
- A Karpathy-style three-layer LLM Wiki under `wiki/` covering OWASP Top 10
  (2025 RC, 2021, 2017), OWASP API Top 10 2023, NIST SP 800-86 forensics
  phases, MITRE ATT&CK v15+ technique snapshot, ~30 academic survey/SoK
  papers across memory forensics, malware-RE taxonomy, network forensics,
  steganalysis, file carving, threat hunting, binary obfuscation, and
  firmware analysis, plus Flare-On 2020-2024 official solutions and 10
  curated boundary-case CTF writeups.
- Eleven Python CLI entry points under `scripts/`: `bluechall_init`,
  `bluechall_analyze` (artifact + binary + lab fuzz triple engine),
  `bluechall_validate` (strict rule catalog with `--soft` downgrade),
  `bluechall_publish` (four adapters: CTFd ctfcli, rCTF, picoCTF, Sherlocks-Q
  YAML), `bluechall_manifest`, `bluechall_wiki`, `bluechall_bootstrap`
  (event setup — generates `.rules.env` with 23 keys), `bluechall_docker`,
  `bluechall_orbstack`, `bluechall_qemu` (lab orchestrators), and
  `bluechall_flagserver` (HMAC per-team flag-server stub generator).
- Per-category, per-recipe templates under `templates/` covering forensics
  (LSB stego, pcap+TLS, Volatility memory), reverse (stripped C++ keygen,
  custom VM bytecode), and blue-team (PE+EVTX+pcap Sherlocks-style IR).
- Four flag emission modes as first-class types: `single-static` (Flare-On
  style), `questions-as-flags` (HTB Sherlocks style with ATT&CK tagging),
  `service-derived` (HMAC per-team flag service), `multi-stage-pivot`
  (DAG-locked stage chain).
- Three lab backends sharing a common context-manager API: Docker Compose
  (lightweight services), OrbStack Linux VM (cloud-init provisioner for
  attacked-host artifact generation), QEMU (user-mode + system-mode for
  firmware reverse).

The skill is host-agent-neutral: this file contains only imperative-mood prose
and references CLIs by shell-invocation form. See `reference/agent-tools.md`
for the cross-runtime tool mapping.

# When to use

Activate this skill when the author wants to:

- Scaffold a new forensics, reverse, or blue-team challenge for a CTF event.
- Run static + binary + lab fuzz analysis against an existing challenge directory.
- Validate that a challenge is shippable across CTFd ctfcli, rCTF, picoCTF, and
  the Sherlocks-Q multi-question schema.
- Build the four platform-specific adapter files (CTFd / rCTF / picoCTF / Sherlocks)
  and run structural redaction over their YAML output before write. The
  player-facing `publish/` tree is author-managed: authors populate it from
  `src/` and Stage 5 Analyze (`bluechall_analyze.py`) is the gate that
  rejects any canonical-flag leakage in `publish/`.
- Query the bundled defensive wiki (lookup by OWASP id, MITRE ATT&CK technique,
  NIST phase, forensics tool, reverse target architecture, or CVE).

Do NOT activate when:

- The user is reading source code without intent to author.
- The user is asking conceptual questions about forensics or reverse techniques
  (the wiki alone can answer those — point them at it).
- The user wants offensive web challenges — that is `webchall-master`'s scope.

# Prerequisites

Run from the project where the challenge will live (any workspace). Python 3.10+
with `pyyaml`, `jinja2`, `httpx`, plus the analysis stack (`scapy`, `volatility3`,
`pefile`, `oletools`, `yara-python`, `capstone`, `pyelftools`). System
dependencies (Docker daemon, OrbStack, QEMU) are only required when their
respective lab backend is invoked; pass `--no-runtime` to skip lab fuzz.

# Stage 0 precondition: `.rules.env` at the event repo root

Before any pipeline stage runs, verify that `.rules.env` exists at the CTF
event repository root (the working directory the skill is invoked from). The
file is event-scoped — one per CTF event, shared by all `<slug>/` challenges
in that event — and declares the 23-key schema defined by the
`bluechall-rules-env` capability. The 23 keys are the 15 keys from the
`webchall-rules-env` schema plus 8 bluechall-specific keys:
`FORENSICS_TOOLCHAIN_PROFILE`, `REVERSE_TOOLCHAIN_PROFILE`,
`BLUE_TEAM_QUESTION_LIMIT`, `LAB_BACKEND_DEFAULT`, `FLAG_EMISSION_DEFAULT`,
`EXTERNAL_FLAG_SERVICE_PORT_RANGE_START`, `EXTERNAL_FLAG_SERVICE_PORT_RANGE_END`,
`MITRE_ATTACK_VERSION`. The `CATEGORIES` key MUST contain at least one of
`forensics`, `reverse`, `blue-team`; `misc` is allowed as a fallback bucket.

If the file is missing or malformed, Stage 1 (Brief) MUST exit with status
code 2 and instruct the author to bootstrap it:

```sh
python <skill-dir>/scripts/bluechall_bootstrap.py \
    --name TEST.HSCTF --long-name 'Test HSCTF' \
    --flag-prefix TEST.HSCTF --port-range 8080:8099 \
    --categories forensics,reverse,blue-team \
    --lab-backend-default docker \
    --flag-emission-default single-static \
    --yes
```

The host agent (Claude or any other supported runtime) MUST read `.rules.env`
at the start of each skill session and use its values for the six downstream
decision points:

1. **Player-facing text** — apply `PLAYER_FACING_LOCALE`, `BLOCK_PRC_VOCAB`,
   and `ENFORCE_ANTI_AI_SLOP` when generating problem pages, hints, README
   content, and any other text shown to players.
2. **Flag formats** — use `FLAG_REGEX` and `FLAG_FORMAT_LITERAL` whenever
   crafting or validating canonical flags; do not invent ad-hoc flag formats.
3. **Host port allocation** — keep new challenge port assignments inside
   `[HOST_PORT_RANGE_START, HOST_PORT_RANGE_END]` and external flag-server
   ports inside `[EXTERNAL_FLAG_SERVICE_PORT_RANGE_START,
   EXTERNAL_FLAG_SERVICE_PORT_RANGE_END]` to avoid collisions.
4. **Validation hints** — surface `CATEGORIES`, `DIFFICULTIES`, `FLAG_TYPE`,
   and `FLAG_ASSET_VERSION_CONTROLLED` when prompting the author to fill in
   `challenge.yml` and the manifest.
5. **Toolchain whitelists** — restrict template selection to recipes whose
   tool requirements are subsets of `FORENSICS_TOOLCHAIN_PROFILE` (for
   forensics challenges) or `REVERSE_TOOLCHAIN_PROFILE` (for reverse).
6. **Lab and flag-emission defaults** — when the author omits a lab backend or
   flag-emission mode, use `LAB_BACKEND_DEFAULT` and `FLAG_EMISSION_DEFAULT`.
   For Sherlocks-style multi-question challenges, enforce at most
   `BLUE_TEAM_QUESTION_LIMIT` questions and tag each with a MITRE ATT&CK
   technique consistent with `MITRE_ATTACK_VERSION`.

Downstream stage entry points (`bluechall_analyze.py`, `bluechall_validate.py`,
`bluechall_publish.py`) accept a missing `.rules.env` and fall back to
documented defaults, preserving operability for previously archived challenges.

# Seven-stage pipeline

Each stage takes input from `.bluechall.manifest.yaml` (the per-challenge state
file) and writes its output back to disk before yielding control. Every stage
ends with a sub-agent audit gate using one or more of the six personas under
`reference/audit-personas/`. The skill MUST NOT advance to stage N+1 until
stage N's audit verdict is `pass` or `advisory`.

| Stage | Input | CLI | Output | Audit personas |
|---|---|---|---|---|
| 1. Brief | author intent | (interactive) | manifest seeded with category, sub-domain, recipe candidates, flag emission, lab backend | Confused Player |
| 2. Design | brief manifest | `bluechall_wiki.py find` | manifest's `recipe_id` + `concept_refs` + `cve_refs` populated | Unintended Solver, Tool-Grep Solver |
| 3. Scaffold | manifest | `bluechall_init.py --category <c> --recipe <r> --slug <slug> --lab-backend <b>` | `<slug>/src/`, `<slug>/publish/`, `<slug>/solution/`, `.bluechall.manifest.yaml` | Confused Player |
| 4. Implement | scaffolded tree | (author edits source + writes `solution/solve.py` and `solution/{flag.txt,questions.yaml,stages.yaml}`) | working challenge + reference exploit / IR walkthrough | All six personas |
| 5. Analyze | challenge dir | `bluechall_analyze.py <slug>/` | artifact + binary + lab fuzz findings JSON / SARIF | Unintended Solver, Tool-Grep Solver, Decompiler-Trust |
| 6. Validate | challenge dir | `bluechall_validate.py <slug>/` | strict rule pass; non-zero exit on any failure (or `--soft` for downgrade) | Brute-Forcer, Attack-Skipper |
| 7. Publish | challenge dir | `bluechall_publish.py <slug>/` | `<slug>/adapters/{ctfcli,rctf,picoctf,sherlocks}.yml` with structural flag redaction (note: `<slug>/publish/` is author-populated; Stage 5 Analyze is the gate that scans it for canonical-flag leakage) | Unintended Solver |

After every stage, run:

```sh
python <skill-dir>/scripts/bluechall_manifest.py mark-stage-complete <slug>/ <stage>
python <skill-dir>/scripts/bluechall_manifest.py append-audit-verdict <slug>/ <stage> <pass|advisory|fail>
```

A `fail` verdict blocks advancement until the issue is remediated and a
follow-up audit returns `pass` or `advisory`.

# Three primary categories

Every challenge declares exactly one `primary` category in its
`.bluechall.manifest.yaml`:

- **`forensics`**: artifact-driven reconstruction. Player receives a pcap,
  memory dump, disk image, log bundle, OOXML container, or other evidence
  artifact and recovers hidden information via tool fluency. Default flag
  emission: `single-static`. Default lab: `docker` for capture-replay or
  `orbstack` for live-host forensics.
- **`reverse`**: compiled-artifact logic recovery. Player receives a binary
  (ELF, PE, APK, firmware image, custom bytecode) and reconstructs its logic
  to derive the flag via keygen, constraint solving, or VM disassembly.
  Default flag emission: `single-static` (computed). Default lab: `docker` or
  `qemu`.
- **`blue-team`**: IR-flavoured boundary cases — malware sample analysis,
  firmware extraction + reverse, document macro deobfuscation, multi-artifact
  incident reconstruction. Default flag emission: `questions-as-flags`
  following the NIST SP 800-86 four phases (Collection → Examination →
  Analysis → Reporting), each phase mapped to one or more questions tagged
  with MITRE ATT&CK techniques. Default lab: `orbstack` for compromised-host
  artifact generation.

Hybrid cases (e.g. malware-analysis-as-reverse vs malware-analysis-as-forensics)
SHALL be classified as `blue-team` to absorb the boundary tension. When the
event's `CATEGORIES` whitelist excludes `blue-team`, fall back to `misc` per
the bootstrap-configured policy.

# Six audit personas

- **Confused Player** (inherited from webchall): unfamiliarity-driven blockers
  — missing tool, undocumented dependency, ambiguous instruction.
- **Unintended Solver** (inherited): leak surface — exposed `.git`, `.env`,
  metadata, container metadata services, debug endpoints, unredacted flag.
- **Brute-Forcer** (inherited): enumeration — default credentials, public
  PoCs, weak rate limits, predictable seeds.
- **Tool-Grep Solver** (new): one-shot tool defeat — `strings`, `binwalk -e`,
  `zsteg -a`, `exiftool`, `oletools`, `pyinstxtractor` reveals the flag in a
  single pass without the intended technique.
- **Decompiler-Trust** (new): reverse-side leakage — un-stripped binary,
  retained debug symbols, panic strings (Rust), gopclntab (Go), F5-readable
  Ghidra/IDA output, unrandomised opaque predicates.
- **Attack-Skipper** (new): blue-team chain shortcut — answer to one question
  leaks the answer to upstream questions, allowing players to skip stages of
  the intended NIST four-phase narrative.

# Cross-context / cross-session / cross-model

- **Per-challenge state** lives in `<slug>/.bluechall.manifest.yaml`.
  Re-entering the skill against an existing slug detects the manifest,
  summarises completed stages, and resumes from the first incomplete one.
- **Cross-challenge memory** lives in `wiki/log.md` (append-only ingest log).
- **Cross-model**: this file plus `SKILL.zhTW.md` and `AGENTS.md` use only
  imperative Markdown and shell-invocation references. See
  `reference/agent-tools.md` for the cross-runtime tool map.

# Wiki contract (Karpathy three-layer)

- `wiki/raw/` — Layer 1, immutable raw sources. Subtypes: `papers/` (academic
  survey/SoK PDFs and metadata), `tools/` (Volatility plugin docs, Sigma
  rules), `flare-on-solutions/` (Mandiant annual writeups), `ctf-writeups/`
  (curated boundary cases). Never edit; ingest a new fetched-date file when
  upstream changes.
- `wiki/{taxonomies,concepts,frameworks,cves,recipes}/` — Layer 2,
  agent-maintained compiled pages. Frontmatter schema enforced by
  `profile.yaml`.
- `AGENTS.md` — Layer 3, the discipline document that binds the wiki together.

Run `bluechall_wiki.py verify` to enforce all invariants (schema conformance,
dead cross-link detection, raw-file SHA-256 immutability, CVE coverage,
survey coverage, cross-model lint).

# Quick reference

```sh
# Bootstrap a new event
python <skill-dir>/scripts/bluechall_bootstrap.py \
    --name TEST.HSCTF --long-name 'Test HSCTF' \
    --flag-prefix TEST.HSCTF --port-range 8080:8099 \
    --categories forensics,reverse,blue-team --yes

# Scaffold one challenge per category
python <skill-dir>/scripts/bluechall_init.py --category forensics \
    --recipe stego-image-lsb --slug demo-stego --lab-backend docker
python <skill-dir>/scripts/bluechall_init.py --category reverse \
    --recipe rev-vm-bytecode --slug demo-vm --lab-backend docker
python <skill-dir>/scripts/bluechall_init.py --category blue-team \
    --recipe bt-malware-pe-ir --slug demo-ir --lab-backend orbstack \
    --flag-emission questions-as-flags

# Wiki lookup
python <skill-dir>/scripts/bluechall_wiki.py find --mitre-attack T1059
python <skill-dir>/scripts/bluechall_wiki.py find --nist-phase examination

# Analyze + validate
python <skill-dir>/scripts/bluechall_analyze.py demo-stego/
python <skill-dir>/scripts/bluechall_validate.py demo-stego/

# Publish (four adapters)
python <skill-dir>/scripts/bluechall_publish.py demo-ir/
```
