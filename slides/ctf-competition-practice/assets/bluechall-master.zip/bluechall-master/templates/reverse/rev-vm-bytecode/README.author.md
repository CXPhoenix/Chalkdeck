# rev-vm-bytecode — Author notes

16-opcode VM with jump-table dispatch (not switch — defeats IDA F5).
Bytecode is XOR-encrypted at rest; key derived during init via a small
loop. Solver recovers opcode table, simulates the VM, finds the input
that triggers CHECK to print the flag.
