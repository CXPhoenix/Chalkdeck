# rev-vm-bytecode

A custom VM runs encrypted bytecode. Reverse the interpreter, recover
the bytecode semantics, find the input that yields the flag.
