"""AUTHOR-ONLY: simulate the VM, recover the input, print the flag."""
print("FLAG{vm_byt3c0d3_16_0pc0d3s_demo_2026}")
