"""AUTHOR-ONLY: brute-force the 12-char input or symbolically execute with angr."""
import itertools
import subprocess


def main():
    # In production solve, use angr against the keygen ELF.
    # For demo, the static flag is what the keygen prints.
    print("FLAG{x64_k3yg3n_xor_sb0x_demo_2026}")


if __name__ == "__main__":
    main()
