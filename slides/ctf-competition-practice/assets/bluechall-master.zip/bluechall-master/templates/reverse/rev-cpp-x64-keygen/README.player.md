# rev-cpp-x64-keygen

Reverse the keygen ELF. Find a 12-character input that prints the flag.
