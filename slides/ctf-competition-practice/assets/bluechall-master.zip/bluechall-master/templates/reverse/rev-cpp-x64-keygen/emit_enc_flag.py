#!/usr/bin/env python3
"""Regenerate the ENC_FLAG byte array in src/keygen.c from a plaintext flag.

Anti-`strings` defense: the keygen binary does NOT embed the flag literal
in `.rodata`. Instead it stores XOR-encoded bytes; the C runtime decodes
them to ASCII only after the input passes the check function. This
script computes the encoded byte array given a plaintext flag.

Usage:
  python emit_enc_flag.py 'FLAG{your_real_flag_2026}'

Then replace the `ENC_FLAG[]` array in `src/keygen.c` with the printed
byte array, update `ENC_FLAG_LEN`, rebuild the binary, and verify
`strings keygen | grep -i FLAG{` produces no hits.
"""
import sys

BASE_KEY = 0x84


def main() -> int:
    if len(sys.argv) != 2:
        print("usage: emit_enc_flag.py <flag>", file=sys.stderr)
        return 1
    flag = sys.argv[1].encode("utf-8")
    encoded = []
    for i, b in enumerate(flag):
        encoded.append(b ^ (BASE_KEY ^ ((i * 0x9b) & 0xff)))
    print(f"#define ENC_FLAG_LEN {len(encoded)}")
    print(f"#define BASE_KEY 0x{BASE_KEY:02x}")
    print("static const uint8_t ENC_FLAG[ENC_FLAG_LEN] = {")
    for chunk_start in range(0, len(encoded), 8):
        chunk = encoded[chunk_start:chunk_start + 8]
        print("    " + ", ".join(f"0x{b:02x}" for b in chunk) + ",")
    print("};")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
