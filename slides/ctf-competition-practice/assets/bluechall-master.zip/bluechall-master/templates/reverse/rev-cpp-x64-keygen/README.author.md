# rev-cpp-x64-keygen — Author notes

Build with `-O2 -s -static`. Ship the stripped ELF in publish/.
Anti-IDA-F5 via opaque predicate (`op()`); decompiler emits wrong-looking
code path. Solver inverts the SBOX + XOR + shift composition.

## Anti-`strings` defense

The flag is **not** embedded as a literal in `src/keygen.c`. Doing so
would let any player run `strings keygen | grep FLAG{` and recover the
flag without ever solving the keygen logic. Instead, `keygen.c` stores
an XOR-encoded byte array (`ENC_FLAG[]`) that is decoded at runtime
only after the input passes the `check()` function.

### Authoring a fresh challenge with a real flag

1. Run `python emit_enc_flag.py 'FLAG{your_real_flag_2026}'` from this
   template directory.
2. Replace the `ENC_FLAG[]` array, `ENC_FLAG_LEN`, and (if you wish to
   rotate) `BASE_KEY` macro in `src/keygen.c` with the printed values.
3. Update `solution/flag.txt` to match the plaintext flag.
4. Update `.bluechall.manifest.yaml` `canonical_flag:` field.
5. Rebuild: `docker compose -f src/docker-compose.yml build`.
6. Verify the build is clean:
   ```
   strings src/keygen | grep -i 'FLAG{'   # MUST produce no output
   ```
7. Run `bluechall_analyze.py <slug>/ --no-runtime` — `strings-one-shot`
   must NOT fire.

If `strings` ever surfaces the flag literal, the challenge is broken.
The audit has caught this exact failure mode in earlier drafts.
