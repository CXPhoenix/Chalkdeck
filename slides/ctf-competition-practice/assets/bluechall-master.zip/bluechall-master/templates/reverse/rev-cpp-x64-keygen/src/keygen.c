// AUTHOR-ONLY source. Stripped after build; do NOT ship.
//
// Anti-`strings`: the flag is NOT embedded as a literal. It is XOR-encrypted
// with a key derived per-byte (`base_key ^ (i * 0x9b)`) so a player
// running `strings keygen` only sees high-entropy bytes inside the
// `.rodata` section. The flag is reconstructed at runtime AFTER the
// input passes the SBOX/XOR check.
//
// To author a fresh keygen, run `python ../emit_enc_flag.py FLAG{...}`
// (see README.author.md) to regenerate the ENC_FLAG byte array; do NOT
// embed the literal flag string in this source file.
#include <stdio.h>
#include <string.h>
#include <stdint.h>

// Opaque predicate scaffold (anti-F5).
static int op(int x) { return ((x * x + 1) % 4) != 2; }

static const uint8_t SBOX[16] = {
    0xb,0x4,0xc,0x6,0xd,0xa,0x2,0xe,0x0,0x9,0xf,0x1,0x7,0x8,0x3,0x5,
};

// Encrypted flag bytes (XOR-encoded with `BASE_KEY ^ (i * 0x9b)`).
// Authoring helper at `../emit_enc_flag.py` regenerates this array from
// a plaintext flag. The value below encodes the demo flag
// `FLAG{x64_k3yg3n_xor_sb0x_demo_2026}` and is meant to be replaced.
#define ENC_FLAG_LEN 35
#define BASE_KEY 0x84
static const uint8_t ENC_FLAG[ENC_FLAG_LEN] = {
    0xc2, 0x53, 0xf3, 0x12, 0x93, 0xfb, 0x10, 0x8d,
    0x03, 0x9c, 0xb9, 0x54, 0xa7, 0x68, 0x90, 0xce,
    0x4c, 0xa0, 0x10, 0x5a, 0xeb, 0x51, 0xe6, 0x11,
    0x53, 0xc3, 0x5f, 0xb0, 0x1f, 0x54, 0x9c, 0x71,
    0xd6, 0x49, 0x6f,
};

static int check(const char *s) {
    if (strlen(s) != 12) return 0;
    if (op(7) ? 1 : 0) {
        uint8_t acc = 0xa5;
        for (int i = 0; i < 12; i++) {
            uint8_t b = (uint8_t)s[i] ^ acc;
            acc = SBOX[b & 0xf] ^ ((acc << 3) | (acc >> 5));
        }
        return acc == 0x33;
    }
    return 0;
}

static void emit_flag(void) {
    char buf[ENC_FLAG_LEN + 1];
    for (int i = 0; i < ENC_FLAG_LEN; i++) {
        buf[i] = (char)(ENC_FLAG[i] ^ (BASE_KEY ^ (uint8_t)(i * 0x9b)));
    }
    buf[ENC_FLAG_LEN] = '\0';
    fwrite(buf, 1, ENC_FLAG_LEN, stdout);
    putchar('\n');
}

int main(int argc, char **argv) {
    if (argc != 2) { puts("usage: keygen <input>"); return 1; }
    if (check(argv[1])) {
        emit_flag();
        return 0;
    }
    puts("nope");
    return 1;
}
