# stego-image-lsb

**Category:** forensics — stego

The cover image hides a message. Naive LSB extraction fails — the
payload is keyed.
