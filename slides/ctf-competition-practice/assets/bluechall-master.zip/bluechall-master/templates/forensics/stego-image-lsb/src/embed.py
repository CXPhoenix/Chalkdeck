"""AUTHOR-ONLY: embed flag via permuted-coordinate LSB to defeat zsteg -a."""
from PIL import Image
import numpy as np
import hashlib

FLAG = "FLAG{l5b_st3g0_demo_2026}"


def permuted_indices(n: int, seed: bytes) -> list[int]:
    rng = np.random.default_rng(int.from_bytes(hashlib.sha256(seed).digest()[:8], "big"))
    return list(rng.permutation(n))


def main():
    img = Image.open("cover.png").convert("RGBA")
    arr = np.array(img)
    h, w, _ = arr.shape
    flat = arr.reshape(-1, 4)
    bits = "".join(format(b, "08b") for b in FLAG.encode())
    idx = permuted_indices(len(flat), b"bluechall-stego-2026")
    for bit_i, ch_i in enumerate(idx[: len(bits)]):
        # Bit-plane rotation: cycle through R/G/B per pixel.
        plane = bit_i % 3
        flat[ch_i][plane] = (flat[ch_i][plane] & ~1) | int(bits[bit_i])
    out = flat.reshape(h, w, 4)
    Image.fromarray(out).save("cover.steg.png")
    print("embedded into cover.steg.png")


if __name__ == "__main__":
    main()
