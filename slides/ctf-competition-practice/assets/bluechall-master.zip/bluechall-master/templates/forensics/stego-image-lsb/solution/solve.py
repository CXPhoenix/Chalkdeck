"""AUTHOR-ONLY solution for stego-image-lsb.

The flag is encoded via permuted-coordinate LSB across R/G/B planes.
Naive zsteg / linear-scan extraction yields garbage. Recover with the
permutation seed `b"bluechall-stego-2026"`.
"""
from PIL import Image
import numpy as np
import hashlib

SEED = b"bluechall-stego-2026"


def permuted_indices(n, seed):
    rng = np.random.default_rng(int.from_bytes(hashlib.sha256(seed).digest()[:8], "big"))
    return list(rng.permutation(n))


def main():
    img = Image.open("../publish/cover.png").convert("RGBA")
    arr = np.array(img).reshape(-1, 4)
    idx = permuted_indices(len(arr), SEED)
    bits = []
    for bit_i, ch_i in enumerate(idx[: 8 * 64]):  # 64-byte read window
        plane = bit_i % 3
        bits.append(str(arr[ch_i][plane] & 1))
    bs = "".join(bits)
    out = bytes(int(bs[i:i+8], 2) for i in range(0, len(bs), 8))
    flag = out.split(b"}", 1)[0] + b"}"
    print(flag.decode())


if __name__ == "__main__":
    main()
