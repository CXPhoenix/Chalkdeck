<!-- Renders from _shared/README.author.md.j2; this file is the
     baked output for v0.1 quick-start. Author edits go here. -->
# stego-image-lsb — Author notes

Anti-`zsteg -a`: bits are permuted across the pixel-flat axis using a
keyed PRNG (SHA-256(seed)[:8] feeds NumPy default_rng). Linear scan or
zsteg's bit-plane brute-force misses the payload.
