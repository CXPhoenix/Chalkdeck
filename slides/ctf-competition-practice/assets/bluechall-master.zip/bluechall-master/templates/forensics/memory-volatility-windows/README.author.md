# memory-volatility-windows — Author notes

Generate the memory dump via OrbStack `artifact-generation` mode.
Pre-bake a Sysmon-monitored process injection scenario; ensure
`windows.malfind` shows the canonical RWX region.

Stages chain:
  PID → C2 IP → decrypted payload (RC4 keyed by PID).

## Known v0.1 template TODO — `src/` directory required before ship

This template ships **without** a `src/` directory because the artefact
generation flow requires a pre-baked Windows-equivalent OrbStack image
plus a Sysmon-instrumented process-injection sample, neither of which
is appropriate to commit into the bluechall-master skill repo.

Authors using this template MUST add a `src/` directory containing at
minimum:

- `orbstack.cloud-init.yaml` — provisioning script for the Linux VM that
  hosts the artefact-generation runtime
- `inject.py` or equivalent — drives the process injection that produces
  the malfind-detectable RWX region
- `Makefile` — runs the OrbStack `vm_session` to dump memory, then
  copies `memory.dmp` into `publish/`

`bluechall_analyze.py --no-runtime` will pass against the un-completed
template (artifact-fuzz only sees `publish/` content), so DO NOT rely on
analyze alone to catch this gap. Run a manual rehearsal of the full
pipeline before publishing.

A future version of bluechall_validate.py is planned to enforce
"`lab_backend` ∈ {docker, orbstack, qemu} requires `src/` directory" as
a critical rule. Until then, this README serves as the gating reminder.
