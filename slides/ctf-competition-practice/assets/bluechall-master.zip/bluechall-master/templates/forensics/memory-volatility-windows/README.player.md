# memory-volatility-windows

Triage the Windows memory dump. Three-stage challenge: identify the
malicious process, extract its C2, decrypt the dropped payload.
