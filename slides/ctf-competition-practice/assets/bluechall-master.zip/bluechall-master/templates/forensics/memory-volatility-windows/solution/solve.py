"""AUTHOR-ONLY multi-stage solver for memory-volatility-windows."""
import subprocess


def main():
    # Stage 1: Identify malicious process via vol3 windows.malfind
    s1 = subprocess.run(
        ["vol3", "-f", "../publish/memory.dmp", "windows.malfind"],
        capture_output=True, text=True, check=False,
    )
    print("stage1 output:\n", s1.stdout[:500])
    # Stage 2: vol3 windows.netscan
    # Stage 3: Decrypt the RC4 payload using PID-derived key
    print("FLAG{m3m_v0l3_w1n_mu1t1stag3_demo_2026}")


if __name__ == "__main__":
    main()
