# network-pcap-tls

You receive a pcap and a sslkeylog file. Decrypt the TLS, navigate to
the right HTTP/2 stream, recover the flag from a header.
