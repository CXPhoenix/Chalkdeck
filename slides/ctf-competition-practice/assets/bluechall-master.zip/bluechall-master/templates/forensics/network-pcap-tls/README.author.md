# network-pcap-tls — Author notes

Build pcap + sslkeylog by running `curl -k --ssl-no-revoke
https://localhost:8443/` against the docker service with
`SSLKEYLOGFILE=sslkeys.log` set on the curl process. Flag is injected via
HTTP/2 server-push or trailer.
