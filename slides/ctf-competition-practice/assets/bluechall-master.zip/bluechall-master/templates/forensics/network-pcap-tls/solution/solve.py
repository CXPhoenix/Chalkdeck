"""AUTHOR-ONLY solution for network-pcap-tls.

The handout includes capture.pcap and sslkeys.log. Decrypt with tshark:

    tshark -r capture.pcap -o tls.keylog_file:sslkeys.log -Y http2 -V

Flag appears in an HTTP/2 header in the second stream.
"""
import subprocess
import sys


def main():
    out = subprocess.run(
        ["tshark", "-r", "../publish/capture.pcap",
         "-o", "tls.keylog_file:../publish/sslkeys.log",
         "-Y", "http2", "-T", "fields", "-e", "http2.headers"],
        capture_output=True, text=True,
    )
    for line in out.stdout.splitlines():
        if "FLAG{" in line:
            print(line.split("FLAG{")[1].split("}")[0])
            return 0
    print("flag not found in HTTP/2 headers", file=sys.stderr)
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
