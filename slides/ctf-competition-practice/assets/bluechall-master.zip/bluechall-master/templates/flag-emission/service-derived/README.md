# service-derived flag-emission template

This directory describes how `bluechall_flagserver.py` produces the runtime
artefacts for a `service-derived` challenge. Authors invoke the generator via:

```sh
python <skill-dir>/scripts/bluechall_flagserver.py <slug>/ \
    --port 8550 --variant http
```

The generator writes:

- `<slug>/service/server.py` — Flask HTTP server (or asyncio TCP server when
  `--variant tcp` is passed).
- `<slug>/service/Dockerfile` — `python:3.12-slim` base, runs as non-root,
  declares an inline HEALTHCHECK that probes `/healthz` (HTTP) or the TCP port.
- `<slug>/service/healthcheck.sh` — probe script the Docker HEALTHCHECK calls.
- `<slug>/solution/service_meta.yaml` — service_port, variant, hmac_key_source,
  flag_format_literal, truncate_to. Consumed by `bluechall_validate.py`.

The HMAC secret is rotated per deployment. The value bundled in
`service_meta.yaml` is intended for local lab testing only; production
deployments MUST replace it from a secret store.

Per-team flag derivation:

```
flag = FLAG_FORMAT_LITERAL.replace(
    "<text>",
    HMAC_SHA256(secret_key, team_id).hex()[:truncate_to]
)
```

The truncated digest length defaults to 16 hex chars (64 bits of entropy),
which is sufficient against brute-force across an event lifetime when paired
with rate limiting on the flag-server.
