---
name: bluechall-master
description: "出 Forensics、Reverse、Blue-Team 三類別 CTF 賽題的 production-grade skill。當使用者要 出 forensics ctf 題、出 reverse ctf 題、設計 stego/network forensics/memory dump/keygen/VM bytecode 賽題、要做 Sherlocks 風格多題式 IR 賽題、對既有賽題做 unintended solve 分析、或把賽題打包成 CTFd/rCTF/picoCTF/Sherlocks-Q 格式時啟動本 skill。整個出題流程由七階段管線（Brief → Design → Scaffold → Implement → Analyze → Validate → Publish）驅動，每階段結尾都有 sub-agent 對抗審查。當使用者只是在閱讀或解釋本 skill 的腳本、只是查看 wiki、或在問與出題無關的概念問題時請勿觸發本 skill。"
license: MIT
compatibility:
  system_packages:
    - "Python 3.10+"
    - "Docker（僅在使用 Docker Compose lab 後端時需要；--no-runtime 可跳過）"
    - "OrbStack（選用，僅 macOS；僅在使用 OrbStack Linux VM lab 後端時需要）"
    - "QEMU 二進位（選用；user-mode 用 qemu-{mips,arm,aarch64}-static、system-mode 用 qemu-system-arm）"
  python_packages:
    - "pyyaml>=6.0"
    - "jinja2>=3.1"
    - "httpx>=0.27"
    - "scapy>=2.5"
    - "volatility3>=2.5"
    - "pefile>=2023.2"
    - "oletools>=0.60"
    - "yara-python>=4.5"
    - "capstone>=5.0"
    - "pyelftools>=0.30"
    - "pytest>=8.0"
metadata:
  author: bluechall-master
  version: "0.1"
  generatedBy: "Spectra"
---

> [English](SKILL.md) | **繁體中文**

# 概觀

`bluechall-master` 是一個 user-skill，端到端產出**防守 / 分析側**的 CTF 賽題
— Forensics 取證、Reverse 逆向、Blue-Team（IR 取向）三大類別。它是
`webchall-master`（攻擊 / Web Exploitation）的姊妹 skill，沿用同一套出題紀律。
本 skill 含：

- 七階段出題管線（Brief → Design → Scaffold → Implement → Analyze → Validate
  → Publish），每階段結尾以六種 audit persona 觸發強制對抗審查。
- 一份 Karpathy 風格三層 LLM Wiki（位於 `wiki/`）涵蓋 OWASP Top 10
  (2025 RC、2021、2017)、OWASP API Top 10 2023、NIST SP 800-86 取證四階段、
  MITRE ATT&CK v15+ 技術快照、~30 篇橫跨記憶體鑑識、惡意程式 RE 分類、網路
  鑑識、隱寫分析、檔案 carving、威脅獵殺、二進位混淆、韌體分析的 survey/SoK
  學術論文，以及 Flare-On 2020-2024 官方解題報告與 10 篇精選邊界案例 writeup。
- 11 個 Python CLI 入口（位於 `scripts/`）：`bluechall_init`、
  `bluechall_analyze`（artifact + binary + lab 三引擎模糊測試）、
  `bluechall_validate`（嚴格規則目錄，支援 `--soft` 降級）、
  `bluechall_publish`（四個 adapter：CTFd ctfcli、rCTF、picoCTF、
  Sherlocks-Q YAML）、`bluechall_manifest`、`bluechall_wiki`、
  `bluechall_bootstrap`（事件初始化 — 產出 23-key `.rules.env`）、
  `bluechall_docker`、`bluechall_orbstack`、`bluechall_qemu`（三個 lab
  orchestrator）、`bluechall_flagserver`（HMAC per-team flag-server stub
  產生器）。
- 每類別、每 recipe 一份 template（位於 `templates/`）：forensics 含 LSB
  stego、pcap+TLS、Volatility 記憶體鑑識；reverse 含 stripped C++ keygen、
  custom VM bytecode；blue-team 含 PE+EVTX+pcap 的 Sherlocks 風格 IR 題。
- 4 種 flag 發放模式為一級類別：`single-static`（Flare-On 風格）、
  `questions-as-flags`（HTB Sherlocks 多題式並標 ATT&CK）、`service-derived`
  （HMAC per-team flag service）、`multi-stage-pivot`（DAG 鎖鏈式階段）。
- 3 個 lab 後端共享同一組 context-manager API：Docker Compose（輕量服務）、
  OrbStack Linux VM（用 cloud-init 產製被攻擊主機並 dump artefact）、QEMU
  （user-mode + system-mode 供韌體逆向）。

本 skill 對 host-agent 中立：本檔僅含命令式語氣文字並以 shell 呼叫形式引用
CLI。跨執行時工具對照表見 `reference/agent-tools.md`。

# 何時啟動

當作者要：

- 為某 CTF 賽事 scaffold 一道新的 forensics、reverse 或 blue-team 賽題。
- 對既有賽題目錄跑靜態 + 二進位 + lab 三引擎模糊測試。
- 驗證賽題能跨 CTFd ctfcli、rCTF、picoCTF 與 Sherlocks-Q 多題式 schema 出貨。
- 產出 CTFd / rCTF / picoCTF / Sherlocks 四份平台 adapter 檔，並在寫檔前對 YAML
  結果執行結構化 flag 遮蔽。`publish/` 樹由作者自行 populate（從 `src/` 取材），
  Stage 5 Analyze（`bluechall_analyze.py`）是負責掃 `publish/` 內 canonical flag
  洩漏的 gate。
- 查詢 bundled 防守 wiki（依 OWASP id、MITRE ATT&CK 技術、NIST 階段、
  forensics 工具、reverse 目標架構、CVE id 查找）。

當下列情況發生時**請勿啟動**：

- 使用者只是在閱讀原始碼、沒有出題意圖。
- 使用者只是問 forensics 或 reverse 的概念性問題（直接指向 wiki 即可）。
- 使用者要的是攻擊面 web 賽題 — 那是 `webchall-master` 的範圍。

# 先決條件

從要放賽題的專案（任意工作目錄）執行。Python 3.10+ 並安裝 `pyyaml`、`jinja2`、
`httpx` 加上分析堆疊（`scapy`、`volatility3`、`pefile`、`oletools`、
`yara-python`、`capstone`、`pyelftools`）。系統依賴（Docker daemon、
OrbStack、QEMU）僅在對應 lab 後端被呼叫時才需要；傳 `--no-runtime` 可跳過
lab 模糊測試。

# Stage 0 前置條件：事件 repo 根目錄要有 `.rules.env`

任何階段開跑前，先確認 `.rules.env` 存在於 CTF 事件 repo 根目錄（也就是
skill 被呼叫的工作目錄）。該檔為**事件級**設定 — 一個 CTF 事件一份，
事件下所有 `<slug>/` 賽題共用 — 並依 `bluechall-rules-env` 能力宣告 23-key
schema。23 個 key 由 `webchall-rules-env` 的 15 個 key 加上 8 個 bluechall
專用 key 組成：`FORENSICS_TOOLCHAIN_PROFILE`、`REVERSE_TOOLCHAIN_PROFILE`、
`BLUE_TEAM_QUESTION_LIMIT`、`LAB_BACKEND_DEFAULT`、`FLAG_EMISSION_DEFAULT`、
`EXTERNAL_FLAG_SERVICE_PORT_RANGE_START`、`EXTERNAL_FLAG_SERVICE_PORT_RANGE_END`、
`MITRE_ATTACK_VERSION`。`CATEGORIES` 必含 `forensics`、`reverse`、
`blue-team` 任一；`misc` 允許作為 fallback。

若該檔缺失或格式錯誤，Stage 1（Brief）必須以退出碼 2 結束並指示作者先 bootstrap：

```sh
python <skill-dir>/scripts/bluechall_bootstrap.py \
    --name TEST.HSCTF --long-name 'Test HSCTF' \
    --flag-prefix TEST.HSCTF --port-range 8080:8099 \
    --categories forensics,reverse,blue-team \
    --lab-backend-default docker \
    --flag-emission-default single-static \
    --yes
```

Host agent（Claude 或任何受支援 runtime）必須在 skill 工作階段一開始就讀取
`.rules.env`，並把它的值用在六個下游決策點：

1. **玩家面文字** — 套用 `PLAYER_FACING_LOCALE`、`BLOCK_PRC_VOCAB`、
   `ENFORCE_ANTI_AI_SLOP` 來產出題目頁、提示、README 等任何玩家可見文字。
2. **Flag 格式** — 在製作或驗證 canonical flag 時用 `FLAG_REGEX` 與
   `FLAG_FORMAT_LITERAL`，不要自創 flag 格式。
3. **主機埠分配** — 新賽題的埠分配保持在
   `[HOST_PORT_RANGE_START, HOST_PORT_RANGE_END]`，外部 flag-server 的埠
   保持在 `[EXTERNAL_FLAG_SERVICE_PORT_RANGE_START,
   EXTERNAL_FLAG_SERVICE_PORT_RANGE_END]` 以避免衝突。
4. **驗證提示** — 在提醒作者填 `challenge.yml` 與 manifest 時，把
   `CATEGORIES`、`DIFFICULTIES`、`FLAG_TYPE`、`FLAG_ASSET_VERSION_CONTROLLED`
   攤開來。
5. **工具白名單** — template 選擇限制在工具需求是
   `FORENSICS_TOOLCHAIN_PROFILE`（forensics 賽題）或
   `REVERSE_TOOLCHAIN_PROFILE`（reverse 賽題）子集合的 recipe。
6. **Lab 與 flag-emission 預設** — 作者沒指定時，用
   `LAB_BACKEND_DEFAULT` 與 `FLAG_EMISSION_DEFAULT`。Sherlocks 多題式賽題
   強制最多 `BLUE_TEAM_QUESTION_LIMIT` 題，每題標的 MITRE ATT&CK 技術必須
   與 `MITRE_ATTACK_VERSION` 對應版本一致。

下游階段入口（`bluechall_analyze.py`、`bluechall_validate.py`、
`bluechall_publish.py`）允許 `.rules.env` 缺失，回退到文件化的預設值，以
保留對既有歸檔賽題的可操作性。

# 七階段管線

每階段從 `.bluechall.manifest.yaml`（每賽題狀態檔）讀取輸入，將輸出寫回磁碟
後才把控制權交給下一階段。每階段結尾以一個或多個 `reference/audit-personas/`
下的 persona 觸發 sub-agent 審查。Stage N 的審查結論為 `pass` 或
`advisory` 之前，skill 不得進入 Stage N+1。

| 階段 | 輸入 | CLI | 輸出 | Audit personas |
|---|---|---|---|---|
| 1. Brief | 作者意圖 | （互動式）| manifest 種上 category、子領域、recipe 候選、flag emission、lab backend | Confused Player |
| 2. Design | brief manifest | `bluechall_wiki.py find` | manifest 的 `recipe_id` + `concept_refs` + `cve_refs` 填入 | Unintended Solver、Tool-Grep Solver |
| 3. Scaffold | manifest | `bluechall_init.py --category <c> --recipe <r> --slug <slug> --lab-backend <b>` | `<slug>/src/`、`<slug>/publish/`、`<slug>/solution/`、`.bluechall.manifest.yaml` | Confused Player |
| 4. Implement | scaffold 後的目錄樹 | （作者改 source、寫 `solution/solve.py` 與 `solution/{flag.txt,questions.yaml,stages.yaml}`）| 可運作賽題 + 參考解題 / IR 走查 | 全六個 persona |
| 5. Analyze | 賽題目錄 | `bluechall_analyze.py <slug>/` | artifact + binary + lab 模糊測試發現 JSON / SARIF | Unintended Solver、Tool-Grep Solver、Decompiler-Trust |
| 6. Validate | 賽題目錄 | `bluechall_validate.py <slug>/` | 嚴格規則通過；任一 critical 退出非零（或 `--soft` 降級）| Brute-Forcer、Attack-Skipper |
| 7. Publish | 賽題目錄 | `bluechall_publish.py <slug>/` | `<slug>/adapters/{ctfcli,rctf,picoctf,sherlocks}.yml`，寫檔前對 YAML 執行結構化 flag 遮蔽（注意：`<slug>/publish/` 由作者 populate，Stage 5 Analyze 是負責掃此樹 flag 洩漏的 gate） | Unintended Solver |

每階段結尾執行：

```sh
python <skill-dir>/scripts/bluechall_manifest.py mark-stage-complete <slug>/ <stage>
python <skill-dir>/scripts/bluechall_manifest.py append-audit-verdict <slug>/ <stage> <pass|advisory|fail>
```

`fail` 結論會擋住階段推進，必須補救後重審得到 `pass` 或 `advisory` 才能繼續。

# 三大主類別

每道賽題在 `.bluechall.manifest.yaml` 宣告唯一一個 `primary` 類別：

- **`forensics`**：以取證重建為主軸。玩家拿到 pcap、記憶體 dump、磁碟 image、
  log bundle、OOXML 容器或其他 evidence artefact，靠工具熟練度還原隱藏資訊。
  預設 flag emission 為 `single-static`。預設 lab：capture-replay 用 `docker`、
  即時主機鑑識用 `orbstack`。
- **`reverse`**：以 compiled artefact 邏輯還原為主軸。玩家拿到 binary（ELF、
  PE、APK、firmware image、custom bytecode）並重建邏輯以推導 flag（keygen、
  constraint solving、VM disassembly）。預設 flag emission 為 `single-static`
  （演算得出）。預設 lab：`docker` 或 `qemu`。
- **`blue-team`**：IR 取向邊界案例 — 惡意程式樣本分析、韌體擷取後逆向、
  文件 macro 反混淆、多 artefact 事件重建。預設 flag emission 為
  `questions-as-flags`，遵循 NIST SP 800-86 四階段（Collection → Examination
  → Analysis → Reporting），每階段對映一或多題並標 MITRE ATT&CK 技術。
  預設 lab：用 `orbstack` 製造被攻擊主機 artefact。

混合案例（例如 malware-analysis 究竟算 reverse 還是 forensics）一律歸
`blue-team` 以化解邊界爭議。當事件 `CATEGORIES` 白名單不含 `blue-team` 時，
依 bootstrap 設定的 fallback 政策退回到 `misc`。

# 六種 audit persona

- **Confused Player**（沿用 webchall）：因不熟造成的卡關 — 缺工具、未文件化
  的依賴、語意模糊的指示。
- **Unintended Solver**（沿用）：洩漏面 — 暴露的 `.git`、`.env`、metadata、
  容器 metadata 服務、debug 端點、未遮蔽 flag。
- **Brute-Forcer**（沿用）：枚舉 — 預設認證、公開 PoC、率限不足、可預測種子。
- **Tool-Grep Solver**（新增）：一發解題工具 — `strings`、`binwalk -e`、
  `zsteg -a`、`exiftool`、`oletools`、`pyinstxtractor` 一次過揭露 flag，
  繞過原本預期的技巧。
- **Decompiler-Trust**（新增）：reverse 側洩漏 — 未 strip 的 binary、保留
  的 debug symbol、Rust panic 字串、Go gopclntab、Ghidra/IDA 一鍵 F5 顯白
  邏輯、未隨機化的 opaque predicate。
- **Attack-Skipper**（新增）：blue-team 鏈跳階段 — 後段問題答案洩漏前段答案，
  讓玩家可繞過原本預期的 NIST 四階段敘事。

# 跨 context / 跨 session / 跨 model

- **每賽題狀態**存於 `<slug>/.bluechall.manifest.yaml`。重新進入 skill 對既有
  slug 操作時偵測 manifest，摘要已完成階段，從第一個未完成階段續跑。
- **跨賽題記憶**存於 `wiki/log.md`（append-only ingest log）。
- **跨 model**：本檔加上 `SKILL.zhTW.md` 與 `AGENTS.md` 只用命令式 Markdown 與
  shell 呼叫引用。跨執行時工具對照見 `reference/agent-tools.md`。

# Wiki 契約（Karpathy 三層）

- `wiki/raw/` — Layer 1，不可變原始來源。子類型：`papers/`（學術 survey/SoK
  PDF 與 metadata）、`tools/`（Volatility plugin 文件、Sigma rules）、
  `flare-on-solutions/`（Mandiant 年度官方解題）、`ctf-writeups/`（精選邊界
  案例）。**永不就地修改**；上游有更新時 ingest 一個新的 fetch-date 檔。
- `wiki/{taxonomies,concepts,frameworks,cves,recipes}/` — Layer 2，由 agent
  維護的編譯頁。Frontmatter schema 由 `profile.yaml` 強制。
- `AGENTS.md` — Layer 3，把 wiki 綁起來的紀律文件。

跑 `bluechall_wiki.py verify` 強制所有不變式（schema 一致性、死連結偵測、
raw 檔 SHA-256 不變、CVE 涵蓋面、survey 涵蓋面、cross-model lint）。

# 速查表

```sh
# 初始化新事件
python <skill-dir>/scripts/bluechall_bootstrap.py \
    --name TEST.HSCTF --long-name 'Test HSCTF' \
    --flag-prefix TEST.HSCTF --port-range 8080:8099 \
    --categories forensics,reverse,blue-team --yes

# 三類別各 scaffold 一道
python <skill-dir>/scripts/bluechall_init.py --category forensics \
    --recipe stego-image-lsb --slug demo-stego --lab-backend docker
python <skill-dir>/scripts/bluechall_init.py --category reverse \
    --recipe rev-vm-bytecode --slug demo-vm --lab-backend docker
python <skill-dir>/scripts/bluechall_init.py --category blue-team \
    --recipe bt-malware-pe-ir --slug demo-ir --lab-backend orbstack \
    --flag-emission questions-as-flags

# Wiki 查詢
python <skill-dir>/scripts/bluechall_wiki.py find --mitre-attack T1059
python <skill-dir>/scripts/bluechall_wiki.py find --nist-phase examination

# 分析 + 驗證
python <skill-dir>/scripts/bluechall_analyze.py demo-stego/
python <skill-dir>/scripts/bluechall_validate.py demo-stego/

# 發布（四個 adapter）
python <skill-dir>/scripts/bluechall_publish.py demo-ir/
```
